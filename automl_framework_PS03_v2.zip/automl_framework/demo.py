#!/usr/bin/env python3
"""
Quick Demo — runs the full AutoML pipeline on synthetic credit data.
Usage: python demo.py
"""
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")
logger = logging.getLogger(__name__)


def main():
    print("\n" + "=" * 65)
    print("  AutoML Classification Framework — Quick Demo (PS-03)")
    print("=" * 65 + "\n")

    # Step 1: Generate sample data
    print("Step 1: Generating synthetic credit default dataset...")
    try:
        import generate_sample_data
        generate_sample_data.generate_credit_default(n=2000)
    except Exception as e:
        print(f"  Warning: Could not generate data ({e}). Trying to use existing data.")

    # Step 2: Build config programmatically (no YAML file needed)
    config = {
        "target_column": "default",
        "task_type": "binary",
        "feature_config": {
            "numeric_features": ["age", "credit_limit", "bill_amt1", "bill_amt2",
                                  "bill_amt3", "pay_amt1", "pay_amt2", "pay_amt3"],
            "categorical_features": ["sex", "education", "marriage"],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "robust",
        },
        "metric": "roc_auc",
        "direction": "maximize",
        "cv_folds": 3,
        "test_size": 0.2,
        "val_size": 0.1,
        # Use only fast algorithms for the demo
        "algorithms": ["logistic_regression", "random_forest", "xgboost"],
        "constraints": {
            "max_trials": 10,
            "max_time_seconds": 300,
        },
        "explainability_mode": "full",
        "shap_background_samples": 50,
        "leakage_correlation_threshold": 0.95,
        "auto_remove_leaky_features": False,
        "output_dir": "outputs/demo",
        "experiment_name": "demo_run",
        "use_mlflow": True,
        "log_level": "INFO",
    }

    print("Step 2: Initialising AutoML pipeline...")
    try:
        from automl import AutoMLPipeline
    except ImportError as e:
        print(f"\nERROR: {e}")
        print("Please install dependencies first:\n  pip install -r requirements.txt")
        sys.exit(1)

    pipeline = AutoMLPipeline(config)

    print("Step 3: Running full pipeline (ingest → preprocess → train → explain → report)...")
    results = pipeline.fit("data/credit_default.csv")

    print("\n" + "=" * 65)
    print("  DEMO RESULTS")
    print("=" * 65)
    print(f"  Champion     : {results['champion_model']}")
    print(f"  ROC-AUC      : {results['champion_score']:.4f}")
    print(f"  Features     : {results['features_count']}")
    print(f"  Train samples: {results['train_samples']:,}")
    print(f"  Elapsed      : {results['elapsed_seconds']}s")
    print(f"  Outputs      : {results['output_dir']}/")
    print("=" * 65)

    print("\nLeaderboard:")
    lb = pipeline.get_leaderboard()
    if not lb.empty:
        cols = [c for c in ["model", "roc_auc", "f1", "accuracy"] if c in lb.columns]
        print(lb[cols].to_string(index=False))

    print(f"""
Output files generated:
  {results['output_dir']}/performance_report.html   — Full metrics report
  {results['output_dir']}/model_card_{results['champion_model']}.md  — SR 11-7 model card
  {results['output_dir']}/shap_report.json           — SHAP explanations
  {results['output_dir']}/explanations/              — SHAP plots
  {results['output_dir']}/run_summary.json           — Pipeline run summary
  {results['output_dir']}/automl_run.log             — Full log

Open performance_report.html in your browser to see the full report.
""")


if __name__ == "__main__":
    main()
