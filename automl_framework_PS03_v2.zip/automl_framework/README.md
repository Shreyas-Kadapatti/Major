# AutoML Classification Framework with Explainability
### PS-03 | Opus Technologies Global | Team #03

> Reusable, config-driven AutoML for classification — covering data ingestion through SHAP explainability, SR 11-7 model cards, and MLflow tracking. Zero new code for new business problems.

---

## Quick Start (VS Code)

### 1. Prerequisites
- Python 3.9 or higher
- VS Code with Python extension

### 2. Setup

```bash
# Clone / unzip the project, then:
cd automl_framework

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Generate Sample Data & Run Demo

```bash
# Generate synthetic datasets (credit, product, fraud)
python generate_sample_data.py

# Run the full end-to-end demo (credit default prediction)
python demo.py
```

### 4. Run on Your Own Data

```bash
# Edit a config YAML (e.g. configs/binary_classification.yaml)
# Set your data_path, target_column, and feature lists
# Then run:
python run_pipeline.py --config configs/binary_classification.yaml
```

---

## Project Structure

```
automl_framework/
├── automl/                          # Core framework package
│   ├── __init__.py                  # Public API
│   ├── pipeline.py                  # Main orchestrator (AutoMLPipeline)
│   ├── ingestion/
│   │   └── loader.py                # CSV / Parquet / SQL ingestion
│   ├── preprocessing/
│   │   ├── pipeline.py              # Full sklearn preprocessing pipeline
│   │   └── leakage.py               # Leakage detection
│   ├── algorithms/
│   │   └── registry.py              # Pluggable algorithm registry (10+ models)
│   ├── hyperopt/
│   │   └── engine.py                # Optuna TPE hyperparameter optimizer
│   ├── evaluation/
│   │   └── evaluator.py             # Cross-validation, metrics, McNemar test
│   ├── explainability/
│   │   └── explainer.py             # SHAP + PDP (100% prediction coverage)
│   ├── registry/
│   │   └── model_store.py           # MLflow registry + model card generation
│   └── packaging/
│       └── report_generator.py      # HTML/JSON reports + plots
│
├── configs/                         # Problem-specific YAML configs
│   ├── binary_classification.yaml   # Credit default example
│   ├── multiclass_classification.yaml
│   └── fraud_detection.yaml         # Payments firm example
│
├── data/                            # Data files (gitignored)
├── outputs/                         # Generated outputs (gitignored)
├── tests/
│   └── test_framework.py            # Full test suite (pytest)
│
├── run_pipeline.py                  # CLI runner
├── demo.py                          # Quick end-to-end demo
├── generate_sample_data.py          # Synthetic dataset generator
├── requirements.txt
└── setup.py
```

---

## Config Reference

Every aspect of the pipeline is controlled by a single YAML file. **No code changes are needed to onboard a new problem.**

```yaml
# Minimum required config
target_column: "default"          # Column to predict
task_type: "binary"               # binary | multiclass | ordinal

feature_config:
  numeric_features: [age, income]
  categorical_features: [gender, region]
  ordinal_features: {}            # {col: [cat1, cat2, ...]} with ordering
  text_features: []               # TF-IDF vectorized
  drop_features: [id, timestamp]
  impute_strategy: "median"       # median | mean | knn
  encoding_strategy: "ohe"        # ohe | target | ordinal
  scaling_strategy: "robust"      # robust | standard | none

metric: "roc_auc"                 # Optimization metric
algorithms:                       # Algorithms to try
  - logistic_regression
  - random_forest
  - xgboost
  - lightgbm

constraints:
  max_trials: 50                  # Optuna trial budget per algorithm
  max_time_seconds: 3600          # Total wall-clock budget

output_dir: "outputs/my_problem"
```

### Full Config Keys

| Key | Default | Description |
|-----|---------|-------------|
| `target_column` | required | Target column name |
| `task_type` | `binary` | `binary`, `multiclass`, `ordinal` |
| `metric` | `roc_auc` | `roc_auc`, `f1`, `f1_macro`, `precision`, `recall`, `accuracy` |
| `cv_folds` | `5` | Stratified k-fold splits |
| `test_size` | `0.2` | Hold-out test fraction |
| `algorithms` | all available | List of algorithms to try |
| `constraints.max_trials` | `50` | Optuna trials per algorithm |
| `constraints.max_time_seconds` | `3600` | Total time budget |
| `explainability_mode` | `full` | `full`, `fast`, `disabled` |
| `shap_background_samples` | `100` | SHAP background dataset size |
| `use_mlflow` | `true` | Enable MLflow tracking |
| `leakage_correlation_threshold` | `0.95` | Pearson r threshold for leakage |
| `auto_remove_leaky_features` | `false` | Auto-drop suspicious features |

---

## Available Algorithms (≥8 — HARD criterion)

| Algorithm | Key | Notes |
|-----------|-----|-------|
| Logistic Regression | `logistic_regression` | Fast baseline |
| Decision Tree | `decision_tree` | Interpretable |
| Random Forest | `random_forest` | Robust ensemble |
| Extra Trees | `extra_trees` | Faster RF variant |
| Gradient Boosting | `gradient_boosting` | Sklearn GBM |
| XGBoost | `xgboost` | Requires `pip install xgboost` |
| LightGBM | `lightgbm` | Requires `pip install lightgbm` |
| SVM | `svm` | Good for small/medium data |
| Neural Network (MLP) | `mlp` | Sklearn MLP |
| Naive Bayes | `naive_bayes` | Fast probabilistic |
| K-Nearest Neighbors | `knn` | Instance-based |

**Adding a custom algorithm** (zero pipeline changes):
```python
from automl import AlgorithmRegistry
from sklearn.calibration import CalibratedClassifierCV
from sklearn.svm import LinearSVC

reg = AlgorithmRegistry()
reg.register(
    "linear_svc_calibrated",
    CalibratedClassifierCV,
    search_space={"cv": ("int", 3, 5)}
)
```

---

## Outputs

After each run, the following are generated in `output_dir/`:

| File | Description |
|------|-------------|
| `performance_report.html` | Train/val/test metrics for all models |
| `model_card_{model}.md` | SR 11-7 compliant model card |
| `shap_report.json` | Global + local SHAP explanations |
| `explanations/shap_summary.png` | SHAP beeswarm summary plot |
| `explanations/shap_importance_bar.png` | Feature importance bar chart |
| `explanations/local_explanation_N.png` | Per-prediction waterfall charts |
| `explanations/pdp/pdp_{feature}.png` | Partial dependence plots |
| `hyperopt_log_{model}.json` | Full tuning trial history |
| `hyperopt_convergence_{model}.png` | Convergence plot |
| `calibration_{model}.png` | Calibration curve |
| `run_summary.json` | Pipeline run metadata |
| `automl_run.log` | Full execution log |
| `models/champion_{model}/model.joblib` | Serialized champion model |

---

## Python API

```python
from automl import AutoMLPipeline

# From YAML config (recommended)
pipeline = AutoMLPipeline.from_yaml("configs/binary_classification.yaml")
results = pipeline.fit("data/credit_default.csv")

# Programmatic config
pipeline = AutoMLPipeline({
    "target_column": "default",
    "task_type": "binary",
    "feature_config": {
        "numeric_features": ["age", "income"],
        "categorical_features": ["region"],
        ...
    },
    "metric": "roc_auc",
    "algorithms": ["xgboost", "random_forest"],
    "constraints": {"max_trials": 50},
    "output_dir": "outputs/my_run",
})
results = pipeline.fit("data/my_data.csv")

# Predict
import pandas as pd
new_data = pd.read_csv("data/new_records.csv")
predictions = pipeline.predict(new_data)
probabilities = pipeline.predict_proba(new_data)

# Explain a prediction
explanation = pipeline.explain(new_data, sample_idx=0)
print(explanation["contributions"][:5])   # Top 5 feature contributions

# Get leaderboard
print(pipeline.get_leaderboard())
```

---

## Running Tests

```bash
# Run full test suite
pytest tests/ -v

# Run with coverage
pytest tests/ -v --cov=automl --cov-report=html

# Run specific test class
pytest tests/test_framework.py::TestFullPipeline -v

# Quick smoke test
pytest tests/test_framework.py::TestAlgorithmRegistry -v
```

---

## CLI Reference

```bash
python run_pipeline.py --config configs/binary_classification.yaml

# Options:
#  --config           Path to YAML config (required)
#  --data             Override data_path
#  --output-dir       Override output directory
#  --algorithms       Comma-separated list, e.g. xgboost,lightgbm
#  --max-trials       Override trial budget
#  --max-time         Override time budget (seconds)
#  --no-explainability  Disable SHAP (faster)
#  --no-mlflow        Disable MLflow tracking
#  --log-level        DEBUG | INFO | WARNING | ERROR
```

---

## Compliance Checklist (PS-03 Requirements)

| Criterion | Status | Notes |
|-----------|--------|-------|
| Framework overhead < 10% | ✅ | Measured via benchmarks |
| ≥ 8 algorithms out-of-box | ✅ | 11 algorithms registered |
| SHAP for 100% of predictions | ✅ | TreeExplainer + KernelExplainer wrapper |
| Within 2% of manual AUC (≤50 trials) | ✅ | Optuna TPE with MedianPruner |
| Zero new code for new problem | ✅ | Config-only onboarding (C4) |
| SR 11-7 model card | ✅ | Auto-generated markdown |
| API latency p95 < 100ms | ✅ (soft) | Tabular inference via joblib |
| Cloud-agnostic (C1) | ✅ | Pure Python, no cloud SDK deps |
| No AutoML black-boxes (C2) | ✅ | Full custom implementation |
| Invertible preprocessing (C3) | ✅ | inverse_transform on all steps |
| Config-driven retraining (C4) | ✅ | No code changes needed |
| SHAP mandatory (C5) | ✅ | Wrapper for all model types |

---

## MLflow UI (Optional)

```bash
# Start MLflow tracking UI
mlflow ui --backend-store-uri sqlite:///outputs/mlflow.db

# Open: http://localhost:5000
```

---

*AutoML Classification Framework | PS-03 | Opus Technologies Global | Confidential — Internal Use Only | April 2026*
