from setuptools import setup, find_packages

setup(
    name="automl-classification-framework",
    version="1.0.0",
    description="Reusable AutoML Classification Framework with Explainability (PS-03)",
    author="Team #03 — Mansi Apet, Shreyas Kadapatti, Sachi Parsekar",
    packages=find_packages(exclude=["tests*", "notebooks*", "data*", "outputs*"]),
    python_requires=">=3.9",
    install_requires=[
        "scikit-learn>=1.3.0",
        "numpy>=1.24.0",
        "pandas>=2.0.0",
        "scipy>=1.11.0",
        "optuna>=3.3.0",
        "shap>=0.43.0",
        "mlflow>=2.8.0",
        "joblib>=1.3.0",
        "statsmodels>=0.14.0",
        "matplotlib>=3.7.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "boosting": ["xgboost>=2.0.0", "lightgbm>=4.0.0", "catboost>=1.2.0"],
        "sql": ["sqlalchemy>=2.0.0"],
        "fairness": ["aif360>=0.5.0"],
        "all": [
            "xgboost>=2.0.0", "lightgbm>=4.0.0",
            "sqlalchemy>=2.0.0", "plotly>=5.17.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "automl-run=run_pipeline:main",
        ],
    },
)
