#!/usr/bin/env python3
"""
Generate synthetic datasets for testing the AutoML framework.
Produces credit_default.csv, product_category.csv, transactions.csv.
"""
from pathlib import Path
import numpy as np
import pandas as pd

RANDOM_STATE = 42
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)


def generate_credit_default(n=5000, random_state=RANDOM_STATE):
    """Binary classification: credit card default prediction."""
    rng = np.random.default_rng(random_state)

    age = rng.integers(21, 75, n)
    credit_limit = rng.choice([10000, 20000, 30000, 50000, 80000, 100000], n)
    sex = rng.choice(["male", "female"], n)
    education = rng.choice(["graduate_school", "university", "high_school", "other"], n,
                           p=[0.35, 0.40, 0.20, 0.05])
    marriage = rng.choice(["married", "single", "other"], n, p=[0.45, 0.45, 0.10])

    # Bills and payments (correlated with default)
    base = credit_limit * rng.uniform(0.2, 1.2, n)
    bill_amt1 = np.maximum(0, base + rng.normal(0, 5000, n)).astype(int)
    bill_amt2 = np.maximum(0, bill_amt1 * rng.uniform(0.8, 1.2, n)).astype(int)
    bill_amt3 = np.maximum(0, bill_amt2 * rng.uniform(0.8, 1.2, n)).astype(int)
    pay_amt1 = np.maximum(0, bill_amt1 * rng.uniform(0.0, 1.5, n)).astype(int)
    pay_amt2 = np.maximum(0, bill_amt2 * rng.uniform(0.0, 1.5, n)).astype(int)
    pay_amt3 = np.maximum(0, bill_amt3 * rng.uniform(0.0, 1.5, n)).astype(int)

    # Target: ~22% default rate
    logit = (
        -3.5
        + 0.8 * (bill_amt1 / (credit_limit + 1))
        - 0.5 * (pay_amt1 / (bill_amt1 + 1))
        - 0.3 * (age / 50)
        + 0.4 * (education == "high_school").astype(float)
        + rng.normal(0, 0.5, n)
    )
    prob = 1 / (1 + np.exp(-logit))
    default = (rng.uniform(size=n) < prob).astype(int)

    # Add some missing values
    mask = rng.random(n) < 0.03
    bill_amt2 = bill_amt2.astype(float)
    bill_amt2[mask] = np.nan

    df = pd.DataFrame({
        "age": age, "sex": sex, "education": education, "marriage": marriage,
        "credit_limit": credit_limit,
        "bill_amt1": bill_amt1, "bill_amt2": bill_amt2, "bill_amt3": bill_amt3,
        "pay_amt1": pay_amt1, "pay_amt2": pay_amt2, "pay_amt3": pay_amt3,
        "default": default,
    })
    path = DATA_DIR / "credit_default.csv"
    df.to_csv(path, index=False)
    print(f"  Created: {path} | {len(df):,} rows | default rate: {default.mean():.1%}")
    return df


def generate_product_category(n=3000, random_state=RANDOM_STATE):
    """Multiclass classification: product category prediction."""
    rng = np.random.default_rng(random_state)
    categories = ["electronics", "clothing", "home_garden", "sports", "books"]
    brands_by_cat = {
        "electronics": ["Samsung", "Apple", "Sony", "LG", "Philips"],
        "clothing": ["Nike", "Adidas", "Zara", "H&M", "Levi's"],
        "home_garden": ["IKEA", "Bosch", "Black+Decker", "Dyson", "Philips"],
        "sports": ["Nike", "Adidas", "Decathlon", "Under Armour", "Puma"],
        "books": ["Penguin", "HarperCollins", "Random House", "Scholastic", "Wiley"],
    }
    descriptions = {
        "electronics": "High performance device with advanced technology features",
        "clothing": "Comfortable stylish wear for everyday casual use",
        "home_garden": "Essential household item for kitchen and living spaces",
        "sports": "Athletic performance gear for training and competition",
        "books": "Informative reading material for education and leisure",
    }

    rows = []
    for _ in range(n):
        cat = rng.choice(categories)
        brand = rng.choice(brands_by_cat[cat])
        price = rng.lognormal(3.5, 1.2) if cat == "electronics" else \
                rng.lognormal(3.0, 0.8) if cat == "clothing" else \
                rng.lognormal(2.8, 0.9)
        rows.append({
            "product_id": f"P{rng.integers(10000, 99999)}",
            "price": round(float(price), 2),
            "weight": round(rng.exponential(1.5), 2),
            "num_reviews": int(rng.integers(0, 5000)),
            "avg_rating": round(rng.uniform(1.5, 5.0), 1),
            "brand": brand,
            "color": rng.choice(["black", "white", "red", "blue", "green", "grey", "other"]),
            "material": rng.choice(["plastic", "metal", "fabric", "wood", "glass", "other"]),
            "condition": rng.choice(["poor", "fair", "good", "excellent"], p=[0.05, 0.15, 0.45, 0.35]),
            "description": descriptions[cat] + " " + rng.choice(["premium quality", "great value", "best seller", ""]),
            "category": cat,
        })

    df = pd.DataFrame(rows)
    path = DATA_DIR / "product_category.csv"
    df.to_csv(path, index=False)
    print(f"  Created: {path} | {len(df):,} rows | {df['category'].nunique()} classes")
    return df


def generate_transactions(n=8000, random_state=RANDOM_STATE):
    """Binary classification: fraud detection."""
    rng = np.random.default_rng(random_state)

    n_fraud = int(n * 0.04)  # 4% fraud rate
    n_legit = n - n_fraud

    def make_rows(is_fraud, count):
        rows = []
        for i in range(count):
            if is_fraud:
                amount = rng.exponential(300)
                dist_home = rng.uniform(50, 1000)
                txn_7d = rng.integers(1, 5)
                age = rng.integers(0, 180)
            else:
                amount = rng.lognormal(3.5, 1.0)
                dist_home = rng.exponential(10)
                txn_7d = rng.integers(2, 20)
                age = rng.integers(180, 3650)

            rows.append({
                "transaction_id": f"TXN{rng.integers(1000000, 9999999)}",
                "transaction_amount": round(float(amount), 2),
                "account_age_days": int(age),
                "transactions_last_7d": int(txn_7d),
                "transactions_last_30d": int(txn_7d * rng.uniform(3, 5)),
                "avg_transaction_amount": round(float(rng.lognormal(3.2, 0.8)), 2),
                "time_since_last_txn_hours": round(float(rng.exponential(24)), 1),
                "distance_from_home_km": round(float(dist_home), 1),
                "merchant_category": rng.choice(
                    ["retail", "food", "travel", "online", "atm", "entertainment"],
                    p=[0.30, 0.25, 0.10, 0.20, 0.10, 0.05] if not is_fraud
                    else [0.15, 0.10, 0.30, 0.30, 0.10, 0.05]
                ),
                "payment_method": rng.choice(["credit", "debit", "contactless", "online"]),
                "card_type": rng.choice(["visa", "mastercard", "amex"]),
                "country_code": rng.choice(
                    ["US", "UK", "DE", "FR", "IN"],
                    p=[0.50, 0.20, 0.10, 0.10, 0.10] if not is_fraud
                    else [0.20, 0.10, 0.25, 0.25, 0.20]
                ),
                "timestamp": pd.Timestamp("2024-01-01") + pd.Timedelta(hours=int(rng.integers(0, 8760))),
                "customer_id": f"C{rng.integers(10000, 99999)}",
                "is_fraud": int(is_fraud),
            })
        return rows

    rows = make_rows(False, n_legit) + make_rows(True, n_fraud)
    df = pd.DataFrame(rows).sample(frac=1, random_state=random_state).reset_index(drop=True)
    path = DATA_DIR / "transactions.csv"
    df.to_csv(path, index=False)
    print(f"  Created: {path} | {len(df):,} rows | fraud rate: {df['is_fraud'].mean():.1%}")
    return df


if __name__ == "__main__":
    print("Generating synthetic datasets...")
    generate_credit_default()
    generate_product_category()
    generate_transactions()
    print("\nDone. Data saved to ./data/")
