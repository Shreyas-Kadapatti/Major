"""
Test Suite — AutoML Classification Framework
Run: pytest tests/ -v
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import pytest
from sklearn.datasets import make_classification, make_blobs


# ─────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────

@pytest.fixture
def binary_dataset():
    X, y = make_classification(
        n_samples=400, n_features=12, n_informative=8,
        n_redundant=2, random_state=42
    )
    df = pd.DataFrame(X, columns=[f"feat_{i}" for i in range(12)])
    df["target"] = y
    return df


@pytest.fixture
def multiclass_dataset():
    X, y = make_classification(
        n_samples=400, n_features=10, n_classes=3, n_informative=6,
        n_clusters_per_class=1, random_state=42
    )
    df = pd.DataFrame(X, columns=[f"feat_{i}" for i in range(10)])
    df["category"] = ["class_" + str(c) for c in y]
    return df


@pytest.fixture
def binary_config():
    return {
        "target_column": "target",
        "task_type": "binary",
        "feature_config": {
            "numeric_features": [f"feat_{i}" for i in range(12)],
            "categorical_features": [],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "robust",
        },
        "metric": "roc_auc",
        "direction": "maximize",
        "cv_folds": 3,
        "test_size": 0.2,
        "val_size": 0.1,
        "algorithms": ["logistic_regression", "random_forest"],
        "constraints": {"max_trials": 3, "max_time_seconds": 120},
        "explainability_mode": "full",
        "shap_background_samples": 20,
        "leakage_correlation_threshold": 0.95,
        "auto_remove_leaky_features": False,
        "output_dir": "outputs/test",
        "experiment_name": "test_run",
        "use_mlflow": False,
        "log_level": "WARNING",
    }


# ─────────────────────────────────────────────
# Data Ingestion Tests
# ─────────────────────────────────────────────

class TestDataLoader:
    def test_load_csv(self, tmp_path, binary_dataset):
        from automl.ingestion import DataLoader
        csv_path = tmp_path / "test.csv"
        binary_dataset.to_csv(csv_path, index=False)
        loader = DataLoader()
        df = loader.load(csv_path)
        assert df.shape == binary_dataset.shape

    def test_schema_inference(self, tmp_path, binary_dataset):
        from automl.ingestion import DataLoader
        csv_path = tmp_path / "test.csv"
        binary_dataset.to_csv(csv_path, index=False)
        loader = DataLoader()
        loader.load(csv_path)
        schema = loader.get_schema()
        assert "target" in schema
        assert schema["target"]["inferred_type"] in ("categorical_numeric", "numeric")

    def test_diagnostics(self, tmp_path, binary_dataset):
        from automl.ingestion import DataLoader
        # Inject missing values
        df = binary_dataset.copy()
        df.loc[0:10, "feat_0"] = np.nan
        csv_path = tmp_path / "test_missing.csv"
        df.to_csv(csv_path, index=False)
        loader = DataLoader()
        loader.load(csv_path)
        diag = loader.get_diagnostics()
        assert diag["n_missing_total"] > 0
        assert diag["n_rows"] == len(df)

    def test_unsupported_format(self, tmp_path):
        from automl.ingestion import DataLoader
        loader = DataLoader()
        with pytest.raises(ValueError, match="Unsupported file format"):
            loader.load(tmp_path / "test.xlsx")


# ─────────────────────────────────────────────
# Preprocessing Tests
# ─────────────────────────────────────────────

class TestPreprocessingPipeline:
    def test_fit_transform_numeric(self, binary_dataset):
        from automl.preprocessing import PreprocessingPipeline
        X = binary_dataset.drop(columns=["target"])
        y = binary_dataset["target"]
        config = {
            "numeric_features": [f"feat_{i}" for i in range(12)],
            "categorical_features": [],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "robust",
        }
        pp = PreprocessingPipeline(config)
        X_proc = pp.fit_transform(X, y)
        assert X_proc.shape[0] == len(X)
        assert X_proc.shape[1] == 12
        assert not X_proc.isnull().any().any()

    def test_categorical_encoding_ohe(self):
        from automl.preprocessing import PreprocessingPipeline
        df = pd.DataFrame({
            "num": [1.0, 2.0, 3.0, 4.0, 5.0],
            "cat": ["a", "b", "a", "c", "b"],
            "target": [0, 1, 0, 1, 0],
        })
        config = {
            "numeric_features": ["num"],
            "categorical_features": ["cat"],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "none",
        }
        pp = PreprocessingPipeline(config)
        X_proc = pp.fit_transform(df[["num", "cat"]], df["target"])
        # OHE: 1 numeric + 3 dummy cols (a,b,c)
        assert X_proc.shape[1] >= 3

    def test_missing_value_imputation(self):
        from automl.preprocessing import PreprocessingPipeline
        df = pd.DataFrame({
            "a": [1.0, np.nan, 3.0, 4.0, 5.0],
            "b": [10.0, 20.0, np.nan, 40.0, 50.0],
            "target": [0, 1, 0, 1, 0],
        })
        config = {
            "numeric_features": ["a", "b"],
            "categorical_features": [],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "none",
        }
        pp = PreprocessingPipeline(config)
        X_proc = pp.fit_transform(df[["a", "b"]], df["target"])
        assert not X_proc.isnull().any().any()

    def test_target_encoding(self):
        from automl.preprocessing import PreprocessingPipeline
        rng = np.random.default_rng(42)
        df = pd.DataFrame({
            "cat": rng.choice(["x", "y", "z"], 100),
            "num": rng.normal(0, 1, 100),
            "target": rng.integers(0, 2, 100),
        })
        config = {
            "numeric_features": ["num"],
            "categorical_features": ["cat"],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "target",
            "scaling_strategy": "robust",
        }
        pp = PreprocessingPipeline(config)
        X_proc = pp.fit_transform(df[["cat", "num"]], df["target"])
        assert X_proc.shape[0] == 100
        assert not X_proc.isnull().any().any()

    def test_target_encode_decode(self, binary_dataset):
        from automl.preprocessing import PreprocessingPipeline
        X = binary_dataset.drop(columns=["target"])
        y = binary_dataset["target"]
        config = {
            "numeric_features": [f"feat_{i}" for i in range(12)],
            "categorical_features": [],
            "ordinal_features": {},
            "text_features": [],
            "drop_features": [],
            "impute_strategy": "median",
            "encoding_strategy": "ohe",
            "scaling_strategy": "robust",
        }
        pp = PreprocessingPipeline(config)
        pp.fit(X, y)
        y_enc = pp.encode_target(y)
        y_dec = pp.decode_target(y_enc)
        assert list(y_dec) == list(y.values)


# ─────────────────────────────────────────────
# Leakage Detector Tests
# ─────────────────────────────────────────────

class TestLeakageDetector:
    def test_detects_highly_correlated_feature(self):
        from automl.preprocessing import LeakageDetector
        rng = np.random.default_rng(42)
        y = pd.Series(rng.integers(0, 2, 200))
        X = pd.DataFrame({
            "normal_feat": rng.normal(0, 1, 200),
            "leaky_feat": y * 0.99 + rng.normal(0, 0.01, 200),
        })
        detector = LeakageDetector(correlation_threshold=0.90)
        report = detector.check(X, y)
        assert "leaky_feat" in report["suspicious_features"]

    def test_clean_data_passes(self, binary_dataset):
        from automl.preprocessing import LeakageDetector
        X = binary_dataset.drop(columns=["target"])
        y = binary_dataset["target"]
        detector = LeakageDetector()
        report = detector.check(X, y)
        # Standard datasets shouldn't trigger leakage
        assert isinstance(report["n_suspicious"], int)


# ─────────────────────────────────────────────
# Algorithm Registry Tests
# ─────────────────────────────────────────────

class TestAlgorithmRegistry:
    def test_minimum_algorithm_coverage(self):
        from automl.algorithms import AlgorithmRegistry
        reg = AlgorithmRegistry()
        assert len(reg) >= 8, f"Expected ≥8 algorithms, got {len(reg)}: {reg.available()}"

    def test_instantiate_all_algorithms(self):
        from automl.algorithms import AlgorithmRegistry
        reg = AlgorithmRegistry()
        for name in reg.available():
            model = reg.instantiate(name)
            assert model is not None, f"Failed to instantiate {name}"

    def test_custom_registration(self):
        from automl.algorithms import AlgorithmRegistry
        from sklearn.dummy import DummyClassifier
        reg = AlgorithmRegistry()
        reg.register("dummy", DummyClassifier, {"strategy": ("categorical", ["most_frequent"])})
        assert "dummy" in reg.available()
        model = reg.instantiate("dummy")
        assert isinstance(model, DummyClassifier)

    def test_unknown_algorithm_raises(self):
        from automl.algorithms import AlgorithmRegistry
        reg = AlgorithmRegistry()
        with pytest.raises(ValueError):
            reg.get("nonexistent_algo")


# ─────────────────────────────────────────────
# Hyperopt Engine Tests
# ─────────────────────────────────────────────

class TestHyperoptEngine:
    def test_optimize_returns_params_and_score(self, binary_dataset):
        from automl.algorithms import AlgorithmRegistry
        from automl.hyperopt import HyperoptEngine
        X = binary_dataset.drop(columns=["target"]).values.astype(float)
        y = binary_dataset["target"].values
        config = {
            "max_trials": 3,
            "max_time_seconds": 60,
            "cv_folds": 3,
            "metric": "roc_auc",
            "direction": "maximize",
            "task_type": "binary",
        }
        reg = AlgorithmRegistry()
        engine = HyperoptEngine(config, reg)
        params, score = engine.optimize("logistic_regression", X, y)
        assert isinstance(params, dict)
        assert 0.0 <= score <= 1.0

    def test_respects_trial_budget(self, binary_dataset):
        from automl.algorithms import AlgorithmRegistry
        from automl.hyperopt import HyperoptEngine
        X = binary_dataset.drop(columns=["target"]).values.astype(float)
        y = binary_dataset["target"].values
        config = {
            "max_trials": 5,
            "max_time_seconds": 300,
            "cv_folds": 3,
            "metric": "roc_auc",
            "direction": "maximize",
            "task_type": "binary",
        }
        reg = AlgorithmRegistry()
        engine = HyperoptEngine(config, reg)
        engine.optimize("logistic_regression", X, y)
        assert len(engine.study_.trials) <= 5


# ─────────────────────────────────────────────
# Evaluator Tests
# ─────────────────────────────────────────────

class TestModelEvaluator:
    def test_binary_metrics(self, binary_dataset):
        from automl.evaluation import ModelEvaluator
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import train_test_split

        X = binary_dataset.drop(columns=["target"]).values
        y = binary_dataset["target"].values
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        model = LogisticRegression(max_iter=200, random_state=42)
        model.fit(X_train, y_train)

        config = {"task_type": "binary", "metric": "roc_auc", "cv_folds": 3}
        evaluator = ModelEvaluator(config)
        metrics = evaluator.evaluate_holdout(model, X_test, y_test, "lr_test")

        assert "roc_auc" in metrics
        assert "f1" in metrics
        assert "confusion_matrix" in metrics
        assert 0.0 <= metrics["roc_auc"] <= 1.0

    def test_mcnemar_test(self, binary_dataset):
        from automl.evaluation import ModelEvaluator
        rng = np.random.default_rng(42)
        y_true = rng.integers(0, 2, 200)
        preds_a = rng.integers(0, 2, 200)
        preds_b = rng.integers(0, 2, 200)

        config = {"task_type": "binary", "metric": "roc_auc", "cv_folds": 3}
        evaluator = ModelEvaluator(config)
        result = evaluator.mcnemar_test(y_true, preds_a, preds_b, "a", "b")
        assert "p_value" in result
        assert "significant" in result

    def test_model_ranking(self, binary_dataset):
        from automl.evaluation import ModelEvaluator
        from sklearn.linear_model import LogisticRegression
        from sklearn.dummy import DummyClassifier
        from sklearn.model_selection import train_test_split

        X = binary_dataset.drop(columns=["target"]).values
        y = binary_dataset["target"].values
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        config = {"task_type": "binary", "metric": "roc_auc", "cv_folds": 3}
        evaluator = ModelEvaluator(config)

        lr = LogisticRegression(max_iter=200, random_state=42)
        lr.fit(X_train, y_train)
        evaluator.evaluate_holdout(lr, X_test, y_test, "logistic_regression")

        dummy = DummyClassifier(strategy="most_frequent")
        dummy.fit(X_train, y_train)
        evaluator.evaluate_holdout(dummy, X_test, y_test, "dummy")

        ranking = evaluator.rank_models()
        assert len(ranking) == 2
        assert ranking.iloc[0]["model"] == "logistic_regression"


# ─────────────────────────────────────────────
# Explainability Tests
# ─────────────────────────────────────────────

class TestExplainabilityModule:
    def test_tree_explainer(self, tmp_path, binary_dataset):
        from automl.explainability import ExplainabilityModule
        from sklearn.ensemble import RandomForestClassifier

        X = binary_dataset.drop(columns=["target"])
        y = binary_dataset["target"]
        model = RandomForestClassifier(n_estimators=10, random_state=42)
        model.fit(X.values, y.values)

        config = {"explainability_mode": "full", "shap_background_samples": 20}
        explainer = ExplainabilityModule(config)
        explainer.fit(model, X.head(50), feature_names=list(X.columns))

        global_exp = explainer.explain_global(X.head(50), output_dir=tmp_path)
        assert "feature_importance" in global_exp
        assert len(global_exp["feature_importance"]) > 0

    def test_local_explanation_coverage(self, tmp_path, binary_dataset):
        from automl.explainability import ExplainabilityModule
        from sklearn.ensemble import RandomForestClassifier

        X = binary_dataset.drop(columns=["target"])
        y = binary_dataset["target"]
        model = RandomForestClassifier(n_estimators=10, random_state=42)
        model.fit(X.values, y.values)

        config = {"explainability_mode": "full", "shap_background_samples": 20}
        explainer = ExplainabilityModule(config)
        explainer.fit(model, X.head(50), feature_names=list(X.columns))

        # Test 100% coverage — every sample gets an explanation
        for i in range(min(5, len(X))):
            result = explainer.explain_local(X.head(20), sample_idx=i)
            assert "contributions" in result, f"Missing explanation for sample {i}"

    def test_disabled_mode(self, binary_dataset):
        from automl.explainability import ExplainabilityModule
        config = {"explainability_mode": "disabled"}
        explainer = ExplainabilityModule(config)
        explainer.fit(None, binary_dataset.head(10))
        assert explainer.explainer_ is None


# ─────────────────────────────────────────────
# Full Pipeline Integration Tests
# ─────────────────────────────────────────────

class TestFullPipeline:
    def test_pipeline_fit_binary(self, tmp_path, binary_dataset, binary_config):
        from automl import AutoMLPipeline
        binary_config["output_dir"] = str(tmp_path / "binary_outputs")
        pipeline = AutoMLPipeline(binary_config)
        results = pipeline.fit(binary_dataset)

        assert results["champion_model"] in binary_config["algorithms"]
        assert 0.0 <= results["champion_score"] <= 1.0
        assert results["features_count"] > 0

    def test_pipeline_predict(self, tmp_path, binary_dataset, binary_config):
        from automl import AutoMLPipeline
        binary_config["output_dir"] = str(tmp_path / "predict_outputs")
        pipeline = AutoMLPipeline(binary_config)
        pipeline.fit(binary_dataset)

        X_new = binary_dataset.drop(columns=["target"]).head(20)
        preds = pipeline.predict(X_new)
        assert len(preds) == 20
        assert set(preds).issubset({0, 1})

    def test_pipeline_predict_proba(self, tmp_path, binary_dataset, binary_config):
        from automl import AutoMLPipeline
        binary_config["output_dir"] = str(tmp_path / "proba_outputs")
        pipeline = AutoMLPipeline(binary_config)
        pipeline.fit(binary_dataset)

        X_new = binary_dataset.drop(columns=["target"]).head(20)
        probas = pipeline.predict_proba(X_new)
        assert probas.shape == (20, 2)
        assert np.allclose(probas.sum(axis=1), 1.0, atol=1e-5)

    def test_pipeline_zero_new_code(self, tmp_path, multiclass_dataset):
        """HARD criterion: New business problem — zero new code, config only."""
        from automl import AutoMLPipeline
        multiclass_config = {
            "target_column": "category",
            "task_type": "multiclass",
            "feature_config": {
                "numeric_features": [f"feat_{i}" for i in range(10)],
                "categorical_features": [],
                "ordinal_features": {},
                "text_features": [],
                "drop_features": [],
                "impute_strategy": "median",
                "encoding_strategy": "ohe",
                "scaling_strategy": "standard",
            },
            "metric": "f1_macro",
            "direction": "maximize",
            "cv_folds": 3,
            "test_size": 0.2,
            "val_size": 0.1,
            "algorithms": ["logistic_regression", "random_forest"],
            "constraints": {"max_trials": 3, "max_time_seconds": 120},
            "explainability_mode": "full",
            "shap_background_samples": 20,
            "leakage_correlation_threshold": 0.95,
            "auto_remove_leaky_features": False,
            "output_dir": str(tmp_path / "multiclass_outputs"),
            "experiment_name": "test_multiclass",
            "use_mlflow": False,
            "log_level": "WARNING",
        }
        pipeline = AutoMLPipeline(multiclass_config)
        results = pipeline.fit(multiclass_dataset)
        assert results["champion_score"] > 0.0

    def test_pipeline_reports_generated(self, tmp_path, binary_dataset, binary_config):
        from automl import AutoMLPipeline
        out = tmp_path / "report_outputs"
        binary_config["output_dir"] = str(out)
        pipeline = AutoMLPipeline(binary_config)
        pipeline.fit(binary_dataset)

        assert (out / "performance_report.html").exists()
        assert (out / "run_summary.json").exists()
        assert (out / "shap_report.json").exists()

    def test_pipeline_leaderboard(self, tmp_path, binary_dataset, binary_config):
        from automl import AutoMLPipeline
        binary_config["output_dir"] = str(tmp_path / "lb_outputs")
        pipeline = AutoMLPipeline(binary_config)
        pipeline.fit(binary_dataset)
        lb = pipeline.get_leaderboard()
        assert len(lb) >= 1
        assert "model" in lb.columns

    def test_from_yaml(self, tmp_path, binary_dataset, binary_config):
        """Test YAML config loading."""
        import yaml
        from automl import AutoMLPipeline
        binary_config["output_dir"] = str(tmp_path / "yaml_outputs")
        binary_config["data_path"] = str(tmp_path / "data.csv")
        binary_dataset.to_csv(binary_config["data_path"], index=False)
        yaml_path = tmp_path / "test_config.yaml"
        with open(yaml_path, "w") as f:
            yaml.dump(binary_config, f)
        pipeline = AutoMLPipeline.from_yaml(yaml_path)
        assert pipeline.config["target_column"] == "target"

    def test_missing_target_column_raises(self):
        from automl import AutoMLPipeline
        with pytest.raises(ValueError, match="target_column"):
            AutoMLPipeline({"some_key": "value"})


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
