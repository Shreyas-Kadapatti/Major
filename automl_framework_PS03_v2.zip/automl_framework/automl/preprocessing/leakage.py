"""
Leakage Detection Module
Detects target-correlated features that could cause data leakage.
"""
import logging
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


class LeakageDetector:
    """
    Detects potential data leakage in features.

    Checks:
    1. High correlation with target (numeric features)
    2. Near-perfect predictors (categorical features)
    3. Future-dated columns vs target timestamp
    """

    def __init__(self, correlation_threshold: float = 0.95, chi2_threshold: float = 0.001):
        self.correlation_threshold = correlation_threshold
        self.chi2_threshold = chi2_threshold
        self.suspicious_features_: List[str] = []
        self.report_: Dict = {}

    def check(self, X: pd.DataFrame, y: pd.Series, target_col: str = "target") -> Dict:
        """
        Run leakage checks. Returns a report dict.
        Raises a warning (not an error) for suspicious features.
        """
        self.suspicious_features_ = []
        checks = {}

        # 1. Numeric correlation check
        num_cols = X.select_dtypes(include=[np.number]).columns
        high_corr = {}
        for col in num_cols:
            try:
                corr, _ = stats.pearsonr(X[col].fillna(0), y)
                if abs(corr) >= self.correlation_threshold:
                    high_corr[col] = round(float(corr), 4)
                    self.suspicious_features_.append(col)
            except Exception:
                pass
        checks["high_correlation_numeric"] = high_corr

        # 2. Categorical chi2 check
        cat_cols = X.select_dtypes(include=["object", "category"]).columns
        high_chi2 = {}
        for col in cat_cols:
            try:
                contingency = pd.crosstab(X[col], y)
                chi2, p, _, _ = stats.chi2_contingency(contingency)
                if p < self.chi2_threshold and chi2 > 1000:
                    high_chi2[col] = {"chi2": round(float(chi2), 2), "p_value": float(p)}
                    self.suspicious_features_.append(col)
            except Exception:
                pass
        checks["high_chi2_categorical"] = high_chi2

        # 3. Near-constant after grouping by target
        near_constant = []
        for col in X.columns:
            try:
                grouped_nunique = X.groupby(y)[col].nunique().mean()
                total_nunique = X[col].nunique()
                if total_nunique > 1 and grouped_nunique <= 1.05:
                    near_constant.append(col)
                    if col not in self.suspicious_features_:
                        self.suspicious_features_.append(col)
            except Exception:
                pass
        checks["near_constant_within_class"] = near_constant

        self.report_ = {
            "n_suspicious": len(set(self.suspicious_features_)),
            "suspicious_features": list(set(self.suspicious_features_)),
            "checks": checks,
        }

        if self.suspicious_features_:
            logger.warning(
                f"LEAKAGE ALERT: {len(set(self.suspicious_features_))} suspicious features detected: "
                f"{list(set(self.suspicious_features_))}. "
                "Review these features carefully before proceeding."
            )
        else:
            logger.info("Leakage check passed — no suspicious features detected.")

        return self.report_

    def get_clean_features(self, X: pd.DataFrame, auto_remove: bool = False) -> pd.DataFrame:
        """Return X with suspicious features optionally removed."""
        if not auto_remove:
            return X
        cols_to_drop = [c for c in self.suspicious_features_ if c in X.columns]
        if cols_to_drop:
            logger.warning(f"Auto-removing leaky features: {cols_to_drop}")
        return X.drop(columns=cols_to_drop)
