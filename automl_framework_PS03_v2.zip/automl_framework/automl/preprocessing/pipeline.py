"""
Preprocessing Pipeline
Fully serializable sklearn pipeline with:
- Imputation (median/mode/KNN)
- Encoding (OHE, target, ordinal)
- Scaling (robust/standard)
- Text vectorization (TF-IDF)
All steps are invertible for data lineage compliance (C3).
"""
import logging
from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    StandardScaler, RobustScaler, OrdinalEncoder,
    OneHotEncoder, LabelEncoder
)

logger = logging.getLogger(__name__)


def _to_df(X, col_names=None) -> pd.DataFrame:
    """Safely convert numpy array or DataFrame to DataFrame."""
    if isinstance(X, pd.DataFrame):
        return X
    if isinstance(X, np.ndarray):
        if col_names is not None and X.ndim == 2 and len(col_names) == X.shape[1]:
            return pd.DataFrame(X, columns=col_names)
        if X.ndim == 2:
            return pd.DataFrame(X, columns=[str(i) for i in range(X.shape[1])])
        return pd.DataFrame(X.reshape(-1, 1))
    return pd.DataFrame(X)


# ---------------------------------------------------------------------------
# Invertible Target Encoder
# ---------------------------------------------------------------------------

class InvertibleTargetEncoder(BaseEstimator, TransformerMixin):
    """
    Target (mean) encoder for categorical features.
    Stores mapping for inverse transform (data lineage compliance).
    Uses smoothing to reduce overfitting.
    Handles both DataFrame and numpy array inputs (sklearn compatible).
    """

    def __init__(self, smoothing: float = 1.0):
        self.smoothing = smoothing

    def fit(self, X, y):
        self.mapping_ = {}
        X_df = _to_df(X)
        self.col_names_ = list(X_df.columns)
        y_arr = np.asarray(y).ravel()
        self.global_mean_ = float(y_arr.mean())
        for col in X_df.columns:
            frame = pd.DataFrame({"x": X_df[col].values, "y": y_arr})
            stats = frame.groupby("x")["y"].agg(["mean", "count"])
            smoother = stats["count"] / (stats["count"] + self.smoothing)
            stats["encoded"] = smoother * stats["mean"] + (1 - smoother) * self.global_mean_
            self.mapping_[col] = stats["encoded"].to_dict()
        return self

    def transform(self, X) -> np.ndarray:
        X_df = _to_df(X, self.col_names_)
        out = np.full((len(X_df), len(self.col_names_)), self.global_mean_, dtype=float)
        for i, col in enumerate(self.col_names_):
            src = col if col in X_df.columns else X_df.columns[i] if i < len(X_df.columns) else None
            if src is not None:
                out[:, i] = (
                    X_df[src].astype(str)
                    .map(self.mapping_.get(col, {}))
                    .fillna(self.global_mean_)
                    .values
                )
        return out

    def inverse_transform(self, X, columns=None) -> pd.DataFrame:
        cols = columns or self.col_names_
        X_arr = np.asarray(X)
        df = pd.DataFrame(index=range(X_arr.shape[0]))
        for i, col in enumerate(cols):
            reverse_map = {v: k for k, v in self.mapping_.get(col, {}).items()}
            if reverse_map:
                df[col] = [
                    min(reverse_map, key=lambda k, v=val: abs(reverse_map[k] - v))
                    for val in X_arr[:, i]
                ]
            else:
                df[col] = X_arr[:, i]
        return df


# ---------------------------------------------------------------------------
# Invertible OHE wrapper
# ---------------------------------------------------------------------------

class InvertibleOHE(BaseEstimator, TransformerMixin):
    """OHE with stored column names for inverse transform.
    Handles both DataFrame and numpy array inputs (sklearn compatible)."""

    def __init__(self, handle_unknown: str = "ignore", max_categories: int = 50):
        self.handle_unknown = handle_unknown
        self.max_categories = max_categories

    def fit(self, X, y=None):
        X_df = _to_df(X)
        self.input_cols_ = list(X_df.columns)
        self.ohe_ = OneHotEncoder(
            handle_unknown=self.handle_unknown,
            sparse_output=False,
            max_categories=self.max_categories,
        )
        self.ohe_.fit(X_df)
        self.output_cols_ = list(self.ohe_.get_feature_names_out(self.input_cols_))
        return self

    def transform(self, X) -> np.ndarray:
        X_df = _to_df(X, self.input_cols_)
        return self.ohe_.transform(X_df)

    def inverse_transform(self, X) -> pd.DataFrame:
        return pd.DataFrame(
            self.ohe_.inverse_transform(np.asarray(X)),
            columns=self.input_cols_
        )

    def get_feature_names_out(self, input_features=None):
        return np.array(self.output_cols_)


# ---------------------------------------------------------------------------
# Helper: flattens 2-D single-column array to 1-D for TF-IDF
# ---------------------------------------------------------------------------

class _FlattenTransformer(BaseEstimator, TransformerMixin):
    """Converts a 2-D (n, 1) array to 1-D string array for TfidfVectorizer."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        arr = np.asarray(X)
        if arr.ndim == 2 and arr.shape[1] == 1:
            return arr.ravel().astype(str)
        return arr.astype(str)


# ---------------------------------------------------------------------------
# Main Preprocessing Pipeline
# ---------------------------------------------------------------------------

class PreprocessingPipeline:
    """
    Builds a fully serializable sklearn ColumnTransformer pipeline.
    All transformation metadata is stored for inverse transform (C3).
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.pipeline_: Optional[Pipeline] = None
        self.label_encoder_: Optional[LabelEncoder] = None
        self.feature_names_out_: List[str] = []
        self._transformers_log: List[str] = []

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "PreprocessingPipeline":
        X = self._drop_features(X)
        transformers = self._build_transformers(X, y)

        self.column_transformer_ = ColumnTransformer(
            transformers=transformers,
            remainder="drop",
            verbose_feature_names_out=False,
        )
        self.pipeline_ = Pipeline([("preprocessor", self.column_transformer_)])
        self.pipeline_.fit(X, y)
        self._compute_feature_names(X)
        logger.info(f"Preprocessing fitted. Output features: {len(self.feature_names_out_)}")
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = self._drop_features(X)
        arr = self.pipeline_.transform(X)
        return pd.DataFrame(arr, columns=self.feature_names_out_, index=X.index)

    def fit_transform(self, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
        self.fit(X, y)
        return self.transform(X)

    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Inverse transform for data lineage compliance (C3)."""
        result = pd.DataFrame(index=X.index)
        for name, transformer, cols in self.column_transformer_.transformers_:
            if name == "remainder":
                continue
            sub_cols = [c for c in X.columns if c in (cols if isinstance(cols, list) else [])]
            if not sub_cols:
                continue
            sub = X[sub_cols]
            if hasattr(transformer, "inverse_transform"):
                try:
                    inv = transformer.inverse_transform(sub.values)
                    if isinstance(inv, pd.DataFrame):
                        result = pd.concat([result, inv], axis=1)
                    else:
                        n_cols = inv.shape[1] if inv.ndim > 1 else 1
                        use_cols = cols if len(cols) == n_cols else list(sub.columns)
                        result = pd.concat(
                            [result, pd.DataFrame(inv, columns=use_cols, index=X.index)], axis=1
                        )
                except Exception as e:
                    logger.warning(f"Could not inverse transform '{name}': {e}")
        return result

    def encode_target(self, y: pd.Series) -> np.ndarray:
        self.label_encoder_ = LabelEncoder()
        return self.label_encoder_.fit_transform(y)

    def decode_target(self, y_encoded: np.ndarray) -> np.ndarray:
        if self.label_encoder_ is None:
            return y_encoded
        return self.label_encoder_.inverse_transform(y_encoded.astype(int))

    def get_feature_names(self) -> List[str]:
        return self.feature_names_out_

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _drop_features(self, X: pd.DataFrame) -> pd.DataFrame:
        drop = self.config.get("drop_features", [])
        return X.drop(columns=[c for c in drop if c in X.columns])

    def _build_transformers(self, X: pd.DataFrame, y: pd.Series):
        transformers = []
        cfg = self.config
        impute_strategy = cfg.get("impute_strategy", "median")
        encoding_strategy = cfg.get("encoding_strategy", "ohe")
        scaling_strategy = cfg.get("scaling_strategy", "robust")

        # ---- Numeric features ----
        num_cols = [c for c in cfg.get("numeric_features", []) if c in X.columns]
        if num_cols:
            if impute_strategy == "knn":
                imputer = KNNImputer(n_neighbors=5)
            else:
                strategy = impute_strategy if impute_strategy in ["mean", "median"] else "median"
                imputer = SimpleImputer(strategy=strategy)
            steps = [("impute", imputer)]
            if scaling_strategy == "robust":
                steps.append(("scale", RobustScaler()))
            elif scaling_strategy == "standard":
                steps.append(("scale", StandardScaler()))
            transformers.append(("numeric", Pipeline(steps), num_cols))
            self._transformers_log.append(
                f"Numeric ({len(num_cols)} cols): impute={impute_strategy}, scale={scaling_strategy}"
            )

        # ---- Categorical features ----
        cat_cols = [c for c in cfg.get("categorical_features", []) if c in X.columns]
        if cat_cols:
            cat_imputer = SimpleImputer(strategy="most_frequent")

            if encoding_strategy == "target":
                encoder = InvertibleTargetEncoder(
                    smoothing=cfg.get("target_encoding_smoothing", 1.0)
                )
                # Pre-fit encoder on imputed data with y available
                imputed_arr = cat_imputer.fit_transform(X[cat_cols])
                imputed_df = pd.DataFrame(imputed_arr, columns=cat_cols, index=X.index)
                encoder.fit(imputed_df, y)
                cat_pipeline = Pipeline([("impute", cat_imputer), ("encode", encoder)])

            elif encoding_strategy == "ohe":
                encoder = InvertibleOHE(max_categories=cfg.get("ohe_max_categories", 50))
                cat_pipeline = Pipeline([("impute", cat_imputer), ("encode", encoder)])

            else:  # ordinal fallback
                encoder = OrdinalEncoder(
                    handle_unknown="use_encoded_value", unknown_value=-1
                )
                cat_pipeline = Pipeline([("impute", cat_imputer), ("encode", encoder)])

            transformers.append(("categorical", cat_pipeline, cat_cols))
            self._transformers_log.append(
                f"Categorical ({len(cat_cols)} cols): encode={encoding_strategy}"
            )

        # ---- Ordinal features ----
        ord_cfg = cfg.get("ordinal_features", {})
        ord_cols = [c for c in ord_cfg if c in X.columns]
        if ord_cols:
            categories = [ord_cfg[c] for c in ord_cols]
            ord_pipeline = Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("encode", OrdinalEncoder(
                    categories=categories,
                    handle_unknown="use_encoded_value",
                    unknown_value=-1
                )),
            ])
            transformers.append(("ordinal", ord_pipeline, ord_cols))
            self._transformers_log.append(f"Ordinal ({len(ord_cols)} cols)")

        # ---- Text features ----
        text_cols = [c for c in cfg.get("text_features", []) if c in X.columns]
        if text_cols:
            from sklearn.feature_extraction.text import TfidfVectorizer
            max_feat = cfg.get("text_max_features", 500)
            for col in text_cols:
                text_pipeline = Pipeline([
                    ("fill", SimpleImputer(strategy="constant", fill_value="")),
                    ("flatten", _FlattenTransformer()),
                    ("tfidf", TfidfVectorizer(max_features=max_feat)),
                ])
                transformers.append((f"text_{col}", text_pipeline, [col]))
            self._transformers_log.append(
                f"Text ({len(text_cols)} cols): TF-IDF max_features={max_feat}"
            )

        if not transformers:
            raise ValueError(
                "No features configured for preprocessing. "
                "Check your feature_config in the YAML (numeric_features, "
                "categorical_features, etc.)."
            )
        return transformers

    def _compute_feature_names(self, X: pd.DataFrame):
        try:
            self.feature_names_out_ = list(
                self.column_transformer_.get_feature_names_out()
            )
        except Exception:
            try:
                sample = self.pipeline_.transform(X.head(1))
                self.feature_names_out_ = [f"feature_{i}" for i in range(sample.shape[1])]
            except Exception:
                self.feature_names_out_ = []
