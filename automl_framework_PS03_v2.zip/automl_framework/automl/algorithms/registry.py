"""
Algorithm Registry
Pluggable registry of 10+ classification algorithms.
Adding a new algorithm requires only registering it here — no pipeline code changes.
"""
import logging
from typing import Dict, Any, List, Optional, Type

from sklearn.base import ClassifierMixin
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, ExtraTreesClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier

logger = logging.getLogger(__name__)


def _get_xgboost():
    try:
        from xgboost import XGBClassifier
        return XGBClassifier
    except ImportError:
        logger.warning("XGBoost not installed. Skipping.")
        return None


def _get_lightgbm():
    try:
        from lightgbm import LGBMClassifier
        return LGBMClassifier
    except ImportError:
        logger.warning("LightGBM not installed. Skipping.")
        return None


def _get_catboost():
    try:
        from catboost import CatBoostClassifier
        return CatBoostClassifier
    except ImportError:
        logger.warning("CatBoost not installed. Skipping.")
        return None


# ---------------------------------------------------------------------------
# Default search spaces per algorithm (used by Optuna)
# ---------------------------------------------------------------------------

DEFAULT_SEARCH_SPACES = {
    "logistic_regression": {
        "C": ("float_log", 1e-4, 1e2),
        "max_iter": ("int", 100, 1000),
        "solver": ("categorical", ["lbfgs", "liblinear", "saga"]),
    },
    "decision_tree": {
        "max_depth": ("int", 2, 20),
        "min_samples_split": ("int", 2, 50),
        "min_samples_leaf": ("int", 1, 20),
        "criterion": ("categorical", ["gini", "entropy"]),
    },
    "random_forest": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int_optional", 2, 20),
        "min_samples_split": ("int", 2, 20),
        "max_features": ("categorical", ["sqrt", "log2", 0.5]),
    },
    "extra_trees": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int_optional", 2, 20),
        "min_samples_split": ("int", 2, 20),
    },
    "gradient_boosting": {
        "n_estimators": ("int", 50, 300),
        "learning_rate": ("float_log", 1e-3, 0.5),
        "max_depth": ("int", 2, 8),
        "subsample": ("float", 0.5, 1.0),
    },
    "xgboost": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int", 2, 10),
        "learning_rate": ("float_log", 1e-3, 0.5),
        "subsample": ("float", 0.5, 1.0),
        "colsample_bytree": ("float", 0.5, 1.0),
        "reg_alpha": ("float_log", 1e-5, 10.0),
        "reg_lambda": ("float_log", 1e-5, 10.0),
    },
    "lightgbm": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int", 2, 10),
        "learning_rate": ("float_log", 1e-3, 0.5),
        "num_leaves": ("int", 15, 127),
        "subsample": ("float", 0.5, 1.0),
        "colsample_bytree": ("float", 0.5, 1.0),
    },
    "catboost": {
        "iterations": ("int", 50, 500),
        "depth": ("int", 2, 10),
        "learning_rate": ("float_log", 1e-3, 0.5),
        "l2_leaf_reg": ("float_log", 1e-3, 10.0),
    },
    "svm": {
        "C": ("float_log", 1e-3, 1e3),
        "kernel": ("categorical", ["rbf", "linear", "poly"]),
        "gamma": ("categorical", ["scale", "auto"]),
    },
    "mlp": {
        "hidden_layer_sizes": ("categorical", [(64,), (128,), (64, 64), (128, 64), (256, 128)]),
        "alpha": ("float_log", 1e-5, 1e-1),
        "learning_rate_init": ("float_log", 1e-4, 1e-1),
        "max_iter": ("int", 100, 500),
    },
    "knn": {
        "n_neighbors": ("int", 3, 30),
        "weights": ("categorical", ["uniform", "distance"]),
        "metric": ("categorical", ["euclidean", "manhattan"]),
    },
    "naive_bayes": {},
}

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class AlgorithmRegistry:
    """
    Central registry for classification algorithms.
    Pluggable: call .register() to add custom algorithms.
    """

    _BUILTIN = {
        "logistic_regression": LogisticRegression,
        "decision_tree": DecisionTreeClassifier,
        "random_forest": RandomForestClassifier,
        "extra_trees": ExtraTreesClassifier,
        "gradient_boosting": GradientBoostingClassifier,
        "svm": SVC,
        "mlp": MLPClassifier,
        "naive_bayes": GaussianNB,
        "knn": KNeighborsClassifier,
    }

    def __init__(self):
        self._registry: Dict[str, Type[ClassifierMixin]] = {}
        self._search_spaces: Dict[str, Dict] = {}
        self._load_builtins()

    def _load_builtins(self):
        for name, cls in self._BUILTIN.items():
            self._registry[name] = cls
            self._search_spaces[name] = DEFAULT_SEARCH_SPACES.get(name, {})

        # Optional heavy deps
        xgb = _get_xgboost()
        if xgb:
            self._registry["xgboost"] = xgb
            self._search_spaces["xgboost"] = DEFAULT_SEARCH_SPACES["xgboost"]

        lgbm = _get_lightgbm()
        if lgbm:
            self._registry["lightgbm"] = lgbm
            self._search_spaces["lightgbm"] = DEFAULT_SEARCH_SPACES["lightgbm"]

        cb = _get_catboost()
        if cb:
            self._registry["catboost"] = cb
            self._search_spaces["catboost"] = DEFAULT_SEARCH_SPACES["catboost"]

    def register(
        self,
        name: str,
        cls: Type[ClassifierMixin],
        search_space: Optional[Dict] = None,
    ):
        """Register a custom algorithm."""
        self._registry[name] = cls
        self._search_spaces[name] = search_space or {}
        logger.info(f"Registered custom algorithm: '{name}'")

    def get(self, name: str) -> Type[ClassifierMixin]:
        if name not in self._registry:
            raise ValueError(f"Algorithm '{name}' not registered. Available: {self.available()}")
        return self._registry[name]

    def instantiate(self, name: str, params: Optional[Dict] = None, task_type: str = "binary") -> ClassifierMixin:
        """Instantiate algorithm with given params, injecting task-specific defaults."""
        cls = self.get(name)
        params = params or {}

        # Task-specific defaults
        if name == "logistic_regression":
            params.setdefault("random_state", 42)
            if task_type == "multiclass":
                params.setdefault("multi_class", "multinomial")
        elif name in ("random_forest", "extra_trees", "gradient_boosting", "decision_tree"):
            params.setdefault("random_state", 42)
        elif name == "svm":
            params.setdefault("probability", True)
            params.setdefault("random_state", 42)
        elif name == "xgboost":
            params.setdefault("random_state", 42)
            params.setdefault("eval_metric", "logloss")
            params.setdefault("verbosity", 0)
            if task_type == "multiclass":
                params.setdefault("objective", "multi:softprob")
        elif name == "lightgbm":
            params.setdefault("random_state", 42)
            params.setdefault("verbosity", -1)
            params.setdefault("force_col_wise", True)
        elif name == "catboost":
            params.setdefault("random_state", 42)
            params.setdefault("verbose", 0)
        elif name == "mlp":
            params.setdefault("random_state", 42)
            params.setdefault("early_stopping", True)
            params.setdefault("n_iter_no_change", 10)

        return cls(**params)

    def get_search_space(self, name: str) -> Dict:
        return self._search_spaces.get(name, {})

    def available(self) -> List[str]:
        return sorted(self._registry.keys())

    def __len__(self):
        return len(self._registry)
