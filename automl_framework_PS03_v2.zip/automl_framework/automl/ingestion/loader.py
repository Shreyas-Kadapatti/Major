"""
Data Ingestion Module
Supports: CSV, Parquet, SQL (SQLAlchemy)
Features: Auto-schema inference, null/duplicate diagnostics
"""
import logging
from pathlib import Path
from typing import Optional, Union, Dict, Any

import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)


class DataLoader:
    """
    Handles data ingestion from multiple sources.
    Performs auto-schema inference and basic diagnostics on load.
    """

    SUPPORTED_FORMATS = [".csv", ".parquet", ".pq"]

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.schema_: Optional[Dict] = None
        self.diagnostics_: Optional[Dict] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(
        self,
        source: Union[str, Path],
        sql_query: Optional[str] = None,
        connection_string: Optional[str] = None,
        **kwargs,
    ) -> pd.DataFrame:
        """
        Load data from CSV, Parquet, or SQL.

        Parameters
        ----------
        source : path to file or table name for SQL
        sql_query : SQL query string (overrides source for SQL)
        connection_string : SQLAlchemy connection string
        """
        if connection_string or sql_query:
            df = self._load_sql(sql_query or f"SELECT * FROM {source}", connection_string)
        else:
            source = Path(source)
            suffix = source.suffix.lower()
            if suffix == ".csv":
                df = pd.read_csv(source, **kwargs)
            elif suffix in (".parquet", ".pq"):
                df = pd.read_parquet(source, **kwargs)
            else:
                raise ValueError(
                    f"Unsupported file format '{suffix}'. Supported: {self.SUPPORTED_FORMATS}"
                )

        logger.info(f"Loaded dataset: {df.shape[0]:,} rows × {df.shape[1]} columns")

        self.schema_ = self._infer_schema(df)
        self.diagnostics_ = self._run_diagnostics(df)
        self._log_diagnostics()

        return df

    def get_schema(self) -> Dict:
        if self.schema_ is None:
            raise RuntimeError("No data loaded yet. Call .load() first.")
        return self.schema_

    def get_diagnostics(self) -> Dict:
        if self.diagnostics_ is None:
            raise RuntimeError("No data loaded yet. Call .load() first.")
        return self.diagnostics_

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load_sql(self, query: str, connection_string: str) -> pd.DataFrame:
        try:
            from sqlalchemy import create_engine
            engine = create_engine(connection_string)
            with engine.connect() as conn:
                df = pd.read_sql(query, conn)
            return df
        except ImportError:
            raise ImportError("SQLAlchemy required for SQL ingestion: pip install sqlalchemy")

    def _infer_schema(self, df: pd.DataFrame) -> Dict:
        schema = {}
        for col in df.columns:
            dtype = df[col].dtype
            n_unique = df[col].nunique()
            if pd.api.types.is_numeric_dtype(dtype):
                try:
                    all_int = (
                        n_unique <= 20 and
                        df[col].dropna().apply(lambda v: float(v).is_integer()).all()
                    )
                except Exception:
                    all_int = n_unique <= 20
                if all_int:
                    col_type = "categorical_numeric"
                else:
                    col_type = "numeric"
            elif pd.api.types.is_datetime64_any_dtype(dtype):
                col_type = "datetime"
            elif pd.api.types.is_bool_dtype(dtype):
                col_type = "boolean"
            else:
                avg_len = df[col].dropna().astype(str).str.len().mean() if len(df) > 0 else 0
                if n_unique <= 50 or (n_unique / len(df) < 0.05):
                    col_type = "categorical"
                elif avg_len > 50:
                    col_type = "text"
                else:
                    col_type = "categorical"

            schema[col] = {
                "dtype": str(dtype),
                "inferred_type": col_type,
                "n_unique": int(n_unique),
                "n_missing": int(df[col].isna().sum()),
                "pct_missing": round(df[col].isna().mean() * 100, 2),
            }
        return schema

    def _run_diagnostics(self, df: pd.DataFrame) -> Dict:
        n_rows, n_cols = df.shape
        n_duplicates = int(df.duplicated().sum())
        n_missing_total = int(df.isna().sum().sum())
        pct_missing = round(n_missing_total / (n_rows * n_cols) * 100, 2)

        high_missing_cols = [
            col for col, info in self._infer_schema(df).items()
            if info["pct_missing"] > 30
        ]
        constant_cols = [col for col in df.columns if df[col].nunique() <= 1]

        return {
            "n_rows": n_rows,
            "n_cols": n_cols,
            "n_duplicates": n_duplicates,
            "pct_duplicates": round(n_duplicates / n_rows * 100, 2) if n_rows > 0 else 0,
            "n_missing_total": n_missing_total,
            "pct_missing_overall": pct_missing,
            "high_missing_cols": high_missing_cols,
            "constant_cols": constant_cols,
            "memory_mb": round(df.memory_usage(deep=True).sum() / 1e6, 2),
        }

    def _log_diagnostics(self):
        d = self.diagnostics_
        logger.info(f"  Duplicates: {d['n_duplicates']:,} ({d['pct_duplicates']}%)")
        logger.info(f"  Missing values: {d['n_missing_total']:,} ({d['pct_missing_overall']}% overall)")
        if d["high_missing_cols"]:
            logger.warning(f"  High-missing columns (>30%): {d['high_missing_cols']}")
        if d["constant_cols"]:
            logger.warning(f"  Constant/near-constant columns: {d['constant_cols']}")
