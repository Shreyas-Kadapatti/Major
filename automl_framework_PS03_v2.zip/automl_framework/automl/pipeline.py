"""
AutoML Pipeline Orchestrator
The main entry point. Config-driven — zero new code for new problems (C4, HARD).
"""
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from .ingestion import DataLoader
from .preprocessing import PreprocessingPipeline, LeakageDetector
from .algorithms import AlgorithmRegistry
from .evaluation import ModelEvaluator
from .explainability import ExplainabilityModule
from .registry import ModelRegistry
from .packaging import ReportGenerator

logger = logging.getLogger(__name__)


class AutoMLPipeline:
    """
    End-to-end AutoML classification pipeline.
    Fully config-driven — no code changes required for new problems (C4).

    Usage:
        pipeline = AutoMLPipeline.from_yaml("configs/my_problem.yaml")
        results = pipeline.fit("data/my_dataset.csv")
        predictions = pipeline.predict(new_df)
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._validate_config(config)
        self._setup_logging()

        self.output_dir = Path(config.get("output_dir", "outputs"))
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Sub-modules
        self.loader = DataLoader(config)
        self.leakage_detector = LeakageDetector(
            correlation_threshold=config.get("leakage_correlation_threshold", 0.95)
        )
        self.registry = AlgorithmRegistry()
        self.model_registry = ModelRegistry({**config, "output_dir": str(self.output_dir)})
        self.evaluator = ModelEvaluator(config)
        self.report_gen = ReportGenerator(self.output_dir)

        # State
        self.preprocessor_: Optional[PreprocessingPipeline] = None
        self.best_model_ = None
        self.best_model_name_: str = ""
        self.explainer_: Optional[ExplainabilityModule] = None
        self.feature_names_: List[str] = []
        self.run_summary_: Dict = {}
        self._fitted = False

    # ------------------------------------------------------------------
    # Class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, config_path: Union[str, Path]) -> "AutoMLPipeline":
        """Load config from YAML and instantiate pipeline."""
        import yaml
        with open(config_path) as f:
            config = yaml.safe_load(f)
        logger.info(f"Loaded config from: {config_path}")
        return cls(config)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(
        self,
        data_source: Union[str, Path, pd.DataFrame],
        sql_query: Optional[str] = None,
        connection_string: Optional[str] = None,
    ) -> Dict:
        """
        Run the full AutoML pipeline:
        1. Ingest data
        2. Leakage detection
        3. Preprocessing
        4. Algorithm search + hyperparameter optimization
        5. Evaluation
        6. Explainability (SHAP)
        7. Model card generation
        8. Reports

        Returns run summary dict.
        """
        start_time = time.time()
        logger.info("=" * 60)
        logger.info("AutoML Classification Framework — Starting Pipeline")
        logger.info("=" * 60)

        # --- 1. Ingest ---
        logger.info("\n[1/7] Data Ingestion")
        if isinstance(data_source, pd.DataFrame):
            df = data_source.copy()
        else:
            df = self.loader.load(data_source, sql_query=sql_query, connection_string=connection_string)

        target_col = self.config["target_column"]
        X = df.drop(columns=[target_col])
        y = df[target_col]

        logger.info(f"  Dataset: {X.shape[0]:,} rows × {X.shape[1]} features")
        logger.info(f"  Target: '{target_col}' | Classes: {sorted(y.unique().tolist())}")

        # --- 2. Leakage Detection ---
        logger.info("\n[2/7] Leakage Detection")
        leakage_report = self.leakage_detector.check(X, y, target_col)
        if leakage_report["n_suspicious"] > 0:
            auto_remove = self.config.get("auto_remove_leaky_features", False)
            X = self.leakage_detector.get_clean_features(X, auto_remove=auto_remove)

        # --- 3. Preprocessing ---
        logger.info("\n[3/7] Preprocessing")
        test_size = self.config.get("test_size", 0.2)
        val_size = self.config.get("val_size", 0.1)

        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp, test_size=val_size / (1 - test_size),
            random_state=42, stratify=y_temp
        )

        feat_config = self.config.get("feature_config", {})
        self.preprocessor_ = PreprocessingPipeline(feat_config)

        X_train_proc = self.preprocessor_.fit_transform(X_train, y_train)
        X_val_proc = self.preprocessor_.transform(X_val)
        X_test_proc = self.preprocessor_.transform(X_test)
        self.feature_names_ = self.preprocessor_.get_feature_names()

        y_train_enc = self.preprocessor_.encode_target(y_train)
        y_val_enc = self.preprocessor_.encode_target(y_val)
        y_test_enc = self.preprocessor_.encode_target(y_test)

        logger.info(f"  Train: {X_train_proc.shape} | Val: {X_val_proc.shape} | Test: {X_test_proc.shape}")
        logger.info(f"  Features after preprocessing: {len(self.feature_names_)}")

        # --- 4. Algorithm Search + Hyperopt ---
        logger.info("\n[4/7] Algorithm Selection & Hyperparameter Optimization")
        from .hyperopt import HyperoptEngine
        algorithms_to_try = self.config.get("algorithms", self.registry.available())
        constraints = self.config.get("constraints", {})
        max_time_per_algo = constraints.get("max_time_seconds", 3600) // max(len(algorithms_to_try), 1)

        hyperopt_config = {
            **self.config,
            "max_trials": constraints.get("max_trials", 50),
            "max_time_seconds": max_time_per_algo,
            "cv_folds": self.config.get("cv_folds", 5),
        }

        run_name = f"automl_{datetime.now():%Y%m%d_%H%M%S}"
        self.model_registry.start_run(run_name)

        best_score = -np.inf
        all_cv_results = {}

        for algo_name in algorithms_to_try:
            if algo_name not in self.registry.available():
                logger.warning(f"Algorithm '{algo_name}' not available — skipping.")
                continue

            logger.info(f"\n  Optimizing: {algo_name}")
            try:
                engine = HyperoptEngine(hyperopt_config, self.registry)
                X_tr_for_opt = X_train_proc.values if hasattr(X_train_proc, "values") else X_train_proc
                try:
                    best_params, cv_score = engine.optimize(
                        algo_name,
                        X_tr_for_opt,
                        y_train_enc,
                    )
                except ImportError:
                    logger.warning(
                        f"  Optuna not installed — training {algo_name} with default params. "
                        "Run: pip install optuna"
                    )
                    best_params = {}
                    # Compute a quick CV score with defaults for ranking
                    from sklearn.model_selection import cross_val_score, StratifiedKFold
                    default_model = self.registry.instantiate(algo_name, {}, self.config.get("task_type", "binary"))
                    cv_scores = cross_val_score(
                        default_model, X_tr_for_opt, y_train_enc,
                        cv=StratifiedKFold(n_splits=3, shuffle=True, random_state=42),
                        scoring="roc_auc" if self.config.get("task_type","binary") == "binary" else "roc_auc_ovr",
                        n_jobs=-1, error_score=0.0,
                    )
                    import numpy as _np
                    cv_score = float(_np.mean(cv_scores))
                    engine.trials_history_ = []

                # Fit final model with best params on full train set
                model = self.registry.instantiate(algo_name, best_params, self.config.get("task_type", "binary"))
                X_tr = X_train_proc.values if hasattr(X_train_proc, "values") else X_train_proc
                model.fit(X_tr, y_train_enc)

                # Evaluate on test set
                X_te = X_test_proc.values if hasattr(X_test_proc, "values") else X_test_proc
                test_metrics = self.evaluator.evaluate_holdout(model, X_te, y_test_enc, algo_name)

                # Cross-validation on full train+val
                X_tv = np.vstack([X_tr, X_val_proc.values if hasattr(X_val_proc, "values") else X_val_proc])
                y_tv = np.concatenate([y_train_enc, y_val_enc])
                cv_results = self.evaluator.cross_validate(model, X_tv, y_tv, algo_name)
                all_cv_results[algo_name] = cv_results

                # Save hyperopt log
                self.report_gen.save_hyperopt_log(
                    engine.trials_history_, algo_name,
                    self.output_dir / f"hyperopt_log_{algo_name}.json"
                )

                # Log to MLflow
                self.model_registry.log_params({f"{algo_name}_{k}": v for k, v in best_params.items()})
                self.model_registry.log_metrics({f"{algo_name}_{k}": v for k, v in test_metrics.items() if isinstance(v, float)})

                # Register result
                metadata = {
                    "algorithm": algo_name,
                    "params": best_params,
                    "metrics": test_metrics,
                    "feature_names": self.feature_names_,
                    "config": self.config,
                }
                self.model_registry.register_result(
                    algo_name, model, test_metrics, best_params, metadata
                )

                primary_metric = self.config.get("metric", "roc_auc")
                score = test_metrics.get(primary_metric, cv_score)
                if score > best_score:
                    best_score = score
                    self.best_model_ = model
                    self.best_model_name_ = algo_name
                    self._best_params = best_params
                    self._best_metrics = test_metrics
                    self._best_cv = cv_results

            except Exception as e:
                logger.error(f"  Failed to train {algo_name}: {e}", exc_info=True)
                continue

        if self.best_model_ is None:
            raise RuntimeError("All algorithms failed. Check your config and data.")

        logger.info(f"\n  Champion: {self.best_model_name_} "
                    f"({self.config.get('metric','roc_auc')}={best_score:.4f})")

        # --- 5. Explainability ---
        logger.info("\n[5/7] Explainability (SHAP)")
        expl_dir = self.output_dir / "explanations"
        self.explainer_ = ExplainabilityModule(self.config)
        X_tr_df = pd.DataFrame(
            X_train_proc.values if hasattr(X_train_proc, "values") else X_train_proc,
            columns=self.feature_names_
        )
        X_te_df = pd.DataFrame(
            X_test_proc.values if hasattr(X_test_proc, "values") else X_test_proc,
            columns=self.feature_names_
        )

        try:
            self.explainer_.fit(self.best_model_, X_tr_df)
            global_exp = self.explainer_.explain_global(X_te_df, output_dir=expl_dir)
            local_examples = [
                self.explainer_.explain_local(X_te_df, sample_idx=i, output_dir=expl_dir)
                for i in range(min(5, len(X_te_df)))
            ]
            self.explainer_.compute_partial_dependence(
                self.best_model_, X_te_df,
                features=global_exp.get("top_features", self.feature_names_[:5])[:5],
                output_dir=expl_dir / "pdp"
            )
            self.report_gen.save_shap_report(global_exp, local_examples)
        except Exception as e:
            logger.warning(f"Explainability step failed: {e}")
            global_exp = {}
            local_examples = []

        # --- 6. Model Card ---
        logger.info("\n[6/7] Generating Model Card (SR 11-7)")
        self.model_registry.generate_model_card(
            model_name=self.best_model_name_,
            metrics=self._best_metrics,
            params=self._best_params,
            config=self.config,
            feature_names=self.feature_names_,
            shap_report=global_exp,
            output_path=self.output_dir / f"model_card_{self.best_model_name_}.md",
        )

        # Calibration curve
        self.report_gen.plot_calibration_curve(
            self._best_metrics.get("calibration", {}),
            self.best_model_name_
        )

        # --- 7. Reports ---
        logger.info("\n[7/7] Generating Reports")
        leaderboard = self.model_registry.get_leaderboard()
        self.report_gen.save_performance_report(
            leaderboard, self._best_metrics, self._best_cv
        )
        self.model_registry.end_run()

        elapsed = time.time() - start_time
        self.run_summary_ = {
            "champion_model": self.best_model_name_,
            "champion_score": best_score,
            "primary_metric": self.config.get("metric", "roc_auc"),
            "metrics": self._best_metrics,
            "algorithms_tried": algorithms_to_try,
            "features_count": len(self.feature_names_),
            "train_samples": len(X_train),
            "test_samples": len(X_test),
            "elapsed_seconds": round(elapsed, 1),
            "output_dir": str(self.output_dir),
        }
        self.report_gen.save_run_summary(self.run_summary_)
        self._fitted = True

        logger.info("\n" + "=" * 60)
        logger.info(f"Pipeline complete in {elapsed:.1f}s")
        logger.info(f"Champion: {self.best_model_name_} | {self.config.get('metric','roc_auc')}={best_score:.4f}")
        logger.info(f"Outputs saved to: {self.output_dir}")
        logger.info("=" * 60)

        return self.run_summary_

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Predict class labels for new data."""
        self._check_fitted()
        X_proc = self.preprocessor_.transform(X)
        X_arr = X_proc.values if hasattr(X_proc, "values") else X_proc
        y_enc = self.best_model_.predict(X_arr)
        return self.preprocessor_.decode_target(y_enc)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict class probabilities for new data."""
        self._check_fitted()
        X_proc = self.preprocessor_.transform(X)
        X_arr = X_proc.values if hasattr(X_proc, "values") else X_proc
        if not hasattr(self.best_model_, "predict_proba"):
            raise ValueError(f"Model {self.best_model_name_} does not support predict_proba.")
        return self.best_model_.predict_proba(X_arr)

    def explain(self, X: pd.DataFrame, sample_idx: int = 0) -> Dict:
        """Get SHAP explanation for a single prediction."""
        self._check_fitted()
        if self.explainer_ is None:
            raise RuntimeError("Explainer not fitted.")
        X_proc = self.preprocessor_.transform(X)
        X_df = pd.DataFrame(
            X_proc.values if hasattr(X_proc, "values") else X_proc,
            columns=self.feature_names_
        )
        return self.explainer_.explain_local(X_df, sample_idx=sample_idx)

    def get_leaderboard(self) -> pd.DataFrame:
        return self.model_registry.get_leaderboard()

    def get_champion_info(self) -> Dict:
        return self.model_registry.get_champion() or {}

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_fitted(self):
        if not self._fitted:
            raise RuntimeError("Pipeline not fitted. Call .fit() first.")

    def _validate_config(self, config: Dict):
        required = ["target_column"]
        for key in required:
            if key not in config:
                raise ValueError(f"Config missing required key: '{key}'")

    def _setup_logging(self):
        level = self.config.get("log_level", "INFO").upper()
        log_dir = Path(self.config.get("output_dir", "outputs"))
        log_dir.mkdir(parents=True, exist_ok=True)

        logging.basicConfig(
            level=getattr(logging, level, logging.INFO),
            format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_dir / "automl_run.log", mode="a"),
            ],
        )
