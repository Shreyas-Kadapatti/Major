"""
AutoML Classification Framework with Explainability
PS-03 | Opus Technologies Global
"""
__version__ = "1.0.0"
__author__ = "Team #03 — Mansi Apet, Shreyas Kadapatti, Sachi Parsekar"

# Core imports — always available
from .ingestion import DataLoader
from .preprocessing import PreprocessingPipeline, LeakageDetector
from .algorithms import AlgorithmRegistry
from .evaluation import ModelEvaluator
from .explainability import ExplainabilityModule
from .registry import ModelRegistry
from .packaging import ReportGenerator

# Pipeline — imported last (depends on all above)
from .pipeline import AutoMLPipeline

# Optional heavy deps loaded lazily inside their modules
try:
    from .hyperopt import HyperoptEngine
    __all_hyperopt__ = ["HyperoptEngine"]
except ImportError:
    __all_hyperopt__ = []

__all__ = [
    "AutoMLPipeline",
    "DataLoader",
    "PreprocessingPipeline",
    "LeakageDetector",
    "AlgorithmRegistry",
    "ModelEvaluator",
    "ExplainabilityModule",
    "ModelRegistry",
    "ReportGenerator",
] + __all_hyperopt__
