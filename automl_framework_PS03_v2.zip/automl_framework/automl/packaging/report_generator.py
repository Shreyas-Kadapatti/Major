"""
Report Generator
Generates performance reports, SHAP explanation reports,
hyperparameter logs, and the full pipeline report.
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

logger = logging.getLogger(__name__)


class ReportGenerator:
    """
    Generates all framework output reports:
    - Performance report (train/val/test metrics)
    - Hyperparameter log
    - SHAP explanation report
    - Pipeline run summary
    """

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def save_performance_report(
        self,
        leaderboard: pd.DataFrame,
        champion_metrics: Dict,
        cv_results: Dict,
        output_path: Optional[Path] = None,
    ) -> Path:
        """Save train/val/test performance report as HTML + JSON."""
        output_path = output_path or self.output_dir / "performance_report.html"

        # JSON version
        report_data = {
            "generated_at": datetime.now().isoformat(),
            "champion": champion_metrics,
            "cv_results": cv_results,
            "leaderboard": leaderboard.to_dict("records") if not leaderboard.empty else [],
        }
        json_path = output_path.with_suffix(".json")
        with open(json_path, "w") as f:
            json.dump(report_data, f, indent=2, default=str)

        # HTML version
        leaderboard_html = leaderboard.to_html(index=False, classes="table", border=0) if not leaderboard.empty else "<p>No results</p>"
        champion_html = self._dict_to_html_table(
            {k: v for k, v in champion_metrics.items() if isinstance(v, (int, float, str))}
        )
        cv_html = self._dict_to_html_table(
            {k: v for k, v in cv_results.items() if isinstance(v, (int, float))}
        )

        html = f"""<!DOCTYPE html>
<html>
<head>
<title>AutoML Performance Report</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 40px; color: #333; }}
  h1 {{ color: #1a1a2e; }} h2 {{ color: #16213e; border-bottom: 2px solid #e0e0e0; padding-bottom: 8px; }}
  .table {{ border-collapse: collapse; width: 100%; margin: 16px 0; }}
  .table th, .table td {{ border: 1px solid #ddd; padding: 10px 14px; text-align: left; }}
  .table th {{ background: #f5f7fa; font-weight: 600; }}
  .table tr:hover {{ background: #f9fafb; }}
  .badge {{ display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; background: #e8f4fd; color: #1a73e8; }}
  .meta {{ color: #666; font-size: 13px; margin-bottom: 24px; }}
</style>
</head>
<body>
<h1>AutoML Classification Framework — Performance Report</h1>
<p class="meta">Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} &nbsp;|&nbsp; Framework: PS-03 v1.0.0</p>

<h2>🏆 Champion Model</h2>
{champion_html}

<h2>📊 Cross-Validation Results (Champion)</h2>
{cv_html}

<h2>📋 Model Leaderboard</h2>
{leaderboard_html}

<hr/>
<p class="meta">AutoML Classification Framework — Opus Technologies Global | Confidential</p>
</body>
</html>"""

        output_path.write_text(html)
        logger.info(f"Performance report saved: {output_path}")
        return output_path

    def save_hyperopt_log(
        self,
        trials_data: List[Dict],
        model_name: str,
        output_path: Optional[Path] = None,
    ) -> Path:
        """Save full hyperparameter tuning history."""
        output_path = output_path or self.output_dir / f"hyperopt_log_{model_name}.json"
        with open(output_path, "w") as f:
            json.dump({
                "model": model_name,
                "n_trials": len(trials_data),
                "generated_at": datetime.now().isoformat(),
                "trials": trials_data,
            }, f, indent=2, default=str)

        # Plot convergence
        if trials_data:
            self._plot_hyperopt_convergence(trials_data, model_name)

        logger.info(f"Hyperopt log saved: {output_path}")
        return output_path

    def save_shap_report(
        self,
        global_explanation: Dict,
        local_examples: Optional[List[Dict]] = None,
        output_path: Optional[Path] = None,
    ) -> Path:
        """Save SHAP global + local explanation report."""
        output_path = output_path or self.output_dir / "shap_report.json"
        report = {
            "generated_at": datetime.now().isoformat(),
            "global_importance": global_explanation.get("feature_importance", [])[:20],
            "top_features": global_explanation.get("top_features", []),
            "local_examples": local_examples[:5] if local_examples else [],
            "coverage": "100% of predictions",
            "method": "SHAP (TreeExplainer / KernelExplainer)",
        }
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
        logger.info(f"SHAP report saved: {output_path}")
        return output_path

    def save_run_summary(self, summary: Dict, output_path: Optional[Path] = None) -> Path:
        """Save the full pipeline run summary."""
        output_path = output_path or self.output_dir / "run_summary.json"
        summary["generated_at"] = datetime.now().isoformat()
        with open(output_path, "w") as f:
            json.dump(summary, f, indent=2, default=str)
        logger.info(f"Run summary saved: {output_path}")
        return output_path

    def plot_calibration_curve(
        self,
        calibration_data: Dict,
        model_name: str,
        output_path: Optional[Path] = None,
    ):
        """Plot model calibration curve."""
        if not calibration_data:
            return
        try:
            fop = calibration_data.get("fraction_of_positives", [])
            mpv = calibration_data.get("mean_predicted_value", [])
            if not fop or not mpv:
                return

            output_path = output_path or self.output_dir / f"calibration_{model_name}.png"
            fig, ax = plt.subplots(figsize=(6, 5))
            ax.plot(mpv, fop, marker="o", label="Model")
            ax.plot([0, 1], [0, 1], "k--", label="Perfect calibration")
            ax.set_xlabel("Mean predicted probability")
            ax.set_ylabel("Fraction of positives")
            ax.set_title(f"Calibration Curve — {model_name}")
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_path, dpi=100)
            plt.close(fig)
        except Exception as e:
            logger.debug(f"Calibration plot failed: {e}")

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _dict_to_html_table(self, d: Dict) -> str:
        rows = "".join(
            f"<tr><td><strong>{k}</strong></td><td>{v}</td></tr>"
            for k, v in d.items()
        )
        return f'<table class="table"><tbody>{rows}</tbody></table>'

    def _plot_hyperopt_convergence(self, trials: List[Dict], model_name: str):
        try:
            values = [t.get("value", np.nan) for t in trials if t.get("value") is not None]
            if not values:
                return
            best_so_far = [max(values[:i+1]) for i in range(len(values))]
            fig, ax = plt.subplots(figsize=(8, 4))
            ax.scatter(range(len(values)), values, alpha=0.4, s=20, label="Trial score")
            ax.plot(range(len(best_so_far)), best_so_far, "r-", linewidth=2, label="Best so far")
            ax.set_xlabel("Trial")
            ax.set_ylabel("Score")
            ax.set_title(f"Hyperopt Convergence — {model_name}")
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(self.output_dir / f"hyperopt_convergence_{model_name}.png", dpi=100)
            plt.close(fig)
        except Exception as e:
            logger.debug(f"Convergence plot failed: {e}")
