#!/usr/bin/env python3
"""
AutoML Framework — CLI Runner
Usage:
    python run_pipeline.py --config configs/binary_classification.yaml
    python run_pipeline.py --config configs/fraud_detection.yaml --data data/my_data.csv
    python run_pipeline.py --config configs/binary_classification.yaml --algorithms xgboost,lightgbm
"""
import argparse
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(
        description="AutoML Classification Framework (PS-03)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with default config
  python run_pipeline.py --config configs/binary_classification.yaml

  # Override data path
  python run_pipeline.py --config configs/binary_classification.yaml --data my_data.csv

  # Run specific algorithms only
  python run_pipeline.py --config configs/binary_classification.yaml --algorithms xgboost,lightgbm,random_forest

  # Override output directory
  python run_pipeline.py --config configs/binary_classification.yaml --output-dir my_outputs/

  # Quick test run (fast config)
  python run_pipeline.py --config configs/binary_classification.yaml --max-trials 5 --max-time 120
        """
    )
    parser.add_argument("--config", required=True, help="Path to YAML config file")
    parser.add_argument("--data", help="Override data_path in config")
    parser.add_argument("--output-dir", help="Override output_dir in config")
    parser.add_argument("--algorithms", help="Comma-separated list of algorithms to try")
    parser.add_argument("--max-trials", type=int, help="Override max_trials per algorithm")
    parser.add_argument("--max-time", type=int, help="Override max_time_seconds constraint")
    parser.add_argument("--no-explainability", action="store_true", help="Disable SHAP (faster)")
    parser.add_argument("--no-mlflow", action="store_true", help="Disable MLflow tracking")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    return parser.parse_args()


def main():
    args = parse_args()

    # Lazy imports after arg parse
    try:
        import yaml
    except ImportError:
        print("ERROR: PyYAML not installed. Run: pip install pyyaml")
        sys.exit(1)

    try:
        from automl import AutoMLPipeline
    except ImportError as e:
        print(f"ERROR: Could not import AutoML framework: {e}")
        print("Make sure you're running from the project root directory.")
        sys.exit(1)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}")
        sys.exit(1)

    with open(config_path) as f:
        config = yaml.safe_load(f)

    # Apply CLI overrides
    if args.data:
        config["data_path"] = args.data
    if args.output_dir:
        config["output_dir"] = args.output_dir
    if args.algorithms:
        config["algorithms"] = [a.strip() for a in args.algorithms.split(",")]
    if args.max_trials:
        config.setdefault("constraints", {})["max_trials"] = args.max_trials
    if args.max_time:
        config.setdefault("constraints", {})["max_time_seconds"] = args.max_time
    if args.no_explainability:
        config["explainability_mode"] = "disabled"
    if args.no_mlflow:
        config["use_mlflow"] = False
    config["log_level"] = args.log_level

    # Check data path
    data_path = config.get("data_path")
    if not data_path:
        print("ERROR: 'data_path' not specified in config or via --data")
        sys.exit(1)

    print(f"\n{'='*60}")
    print(f"  AutoML Classification Framework — PS-03")
    print(f"  Config : {config_path}")
    print(f"  Data   : {data_path}")
    print(f"  Output : {config.get('output_dir', 'outputs')}")
    print(f"{'='*60}\n")

    pipeline = AutoMLPipeline(config)
    results = pipeline.fit(data_path)

    print(f"\n{'='*60}")
    print(f"  RESULTS SUMMARY")
    print(f"{'='*60}")
    print(f"  Champion Model : {results['champion_model']}")
    print(f"  {results['primary_metric']:>15} : {results['champion_score']:.4f}")
    print(f"  Features       : {results['features_count']}")
    print(f"  Train samples  : {results['train_samples']:,}")
    print(f"  Test samples   : {results['test_samples']:,}")
    print(f"  Elapsed        : {results['elapsed_seconds']}s")
    print(f"  Outputs dir    : {results['output_dir']}")
    print(f"{'='*60}\n")

    # Print leaderboard
    lb = pipeline.get_leaderboard()
    if not lb.empty:
        print("  LEADERBOARD")
        print(f"  {'-'*40}")
        cols = ["model", results["primary_metric"]] if results["primary_metric"] in lb.columns else ["model", "score"]
        cols = [c for c in cols if c in lb.columns]
        print(lb[cols].to_string(index=False))
        print()

    print(f"  See full reports in: {results['output_dir']}/")
    print(f"  - performance_report.html")
    print(f"  - model_card_{results['champion_model']}.md")
    print(f"  - shap_report.json")
    print(f"  - explanations/shap_summary.png")


if __name__ == "__main__":
    main()
