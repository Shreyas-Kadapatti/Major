"""
AutoML Studio Dashboard — v1.3  (Final)

NEW IN v1.3:
  [N1] Hyperparameter Log page — full Optuna trial history, chosen trial highlighted
  [N2] Model Card page — auto-generated, downloadable as HTML
  [N3] Hypothesis Testing page — McNemar, Wilcoxon, Friedman, paired t-test
  [N4] Champion PKL with metadata (joblib) download — Model Performance page
  [N5] Performance Report (HTML) download — train/val/test metrics + leaderboard
  [N6] SHAP Beeswarm plot with per-graph explanations
  [N7] Calibration Curve — Model Performance page
  [N8] Joblib artifact with full metadata bundle
  [N9] Database connection panel — PostgreSQL/MySQL/SQLite
  [N10] 12 models
"""
import io
import json
import os
import pickle
import sys
import time
import warnings
from pathlib import Path
from typing import Dict, List, Optional

warnings.filterwarnings("ignore")

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
os.chdir(_PROJECT_ROOT)

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="AutoML Studio", page_icon="🤖",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
html,body,[class*="css"]{font-family:'Space Grotesk',sans-serif;}
.stApp{background:linear-gradient(135deg,#0d0f14 0%,#111520 100%);}
.metric-card{background:linear-gradient(145deg,#161b27,#1a2035);border:1px solid #2a3450;
  border-radius:12px;padding:20px;text-align:center;transition:transform .2s,box-shadow .2s;}
.metric-card:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(99,179,237,.15);}
.metric-value{font-size:2rem;font-weight:700;color:#63b3ed;font-family:'JetBrains Mono',monospace;}
.metric-label{font-size:.82rem;color:#8899bb;text-transform:uppercase;letter-spacing:.08em;margin-top:4px;}
.page-header{background:linear-gradient(135deg,#1a2035 0%,#0f1624 100%);
  border:1px solid #2a3450;border-left:4px solid #63b3ed;
  border-radius:8px;padding:18px 24px;margin-bottom:24px;}
.page-header h2{color:#e8f0fe;margin:0;font-size:1.5rem;font-weight:600;}
.page-header p{color:#8899bb;margin:4px 0 0;font-size:.9rem;}
.sidebar-section{background:#161b27;border:1px solid #2a3450;border-radius:8px;padding:14px;margin-bottom:14px;}
.log-box{background:#0a0d14;border:1px solid #2a3450;border-radius:8px;padding:16px;
  font-family:'JetBrains Mono',monospace;font-size:.82rem;color:#a0b0cc;
  max-height:300px;overflow-y:auto;line-height:1.7;}
.champion-box{background:linear-gradient(135deg,#1a2a1a,#0f1f0f);
  border:2px solid #48bb78;border-radius:12px;padding:20px;text-align:center;}
.explain-box{background:#161b27;border:1px solid #2a3450;border-left:3px solid #b794f4;
  border-radius:6px;padding:12px 16px;margin:10px 0;font-size:.85rem;color:#c8d0e0;line-height:1.6;}
div[data-testid="stSidebar"]{background:#0f1320;border-right:1px solid #1e2840;}
.stButton>button{background:linear-gradient(135deg,#3182ce,#2b6cb0);color:#fff;
  border:none;border-radius:8px;font-weight:600;transition:all .2s;}
.stButton>button:hover{background:linear-gradient(135deg,#4299e1,#3182ce);
  transform:translateY(-1px);box-shadow:0 4px 15px rgba(99,179,237,.3);}
h1,h2,h3{color:#e8f0fe!important;}
p,li{color:#b0c0d8;}
label{color:#8899bb!important;}
</style>""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
_DEFAULTS: Dict = {
    "df":None,"file_name":None,"target_col":None,"col_types":None,
    "trained":False,"training_logs":[],
    "leaderboard":None,"best_model_name":None,"best_model":None,
    "preprocessor":None,"class_names":[],"feature_names":[],
    "shap_values":None,"shap_sample":None,
    "X_test":None,"y_test":None,"X_train":None,"X_val":None,"y_val":None,
    "trained_models":{},"selected_models":[],"tune_enabled":True,
    "train_metrics":{},"val_metrics":{},"test_metrics":{},
    "best_params":{},"tuner_obj":None,"model_card_obj":None,
    "hypothesis_results":None,"artifact_path":None,
}
for _k,_v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k]=_v
# ── Initialize Session State ─────────────────────────────────────────────
if "X_train" not in st.session_state:
    st.session_state.X_train = None

if "y_train" not in st.session_state:
    st.session_state.y_train = None

if "X_test" not in st.session_state:
    st.session_state.X_test = None

if "y_test" not in st.session_state:
    st.session_state.y_test = None

if "best_model_name" not in st.session_state:
    st.session_state.best_model_name = None
# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="text-align:center;padding:16px 0 12px;">
      <div style="font-size:2rem;">🤖</div>
      <div style="font-size:1.2rem;font-weight:700;color:#e8f0fe;">AutoML Studio</div>
      <div style="font-size:.72rem;color:#8899bb;">v1.3 · 12 Models</div>
    </div>""", unsafe_allow_html=True)
    st.divider()
    page = st.radio("Nav",[
        "📂 Data Upload","⚙️ Configuration","🚀 Training",
        "📈 Model Performance","🔍 Explainability",
        "📋 Hyperparameter Log","🃏 Model Card",
        "🧪 Hypothesis Testing","🔮 Predictions","📦 Model Registry",
    ],label_visibility="collapsed")
    st.divider()
    data_ok=st.session_state.df is not None
    train_ok=st.session_state.trained
    st.markdown(f"""
    <div class="sidebar-section">
      <div style="color:#8899bb;font-size:.8rem;margin-bottom:6px;">
        📊 <span style="color:{'#48bb78' if data_ok else '#f6ad55'}">{'Loaded' if data_ok else 'No data'}</span>
      </div>
      <div style="color:#8899bb;font-size:.8rem;margin-bottom:6px;">
        🎯 <span style="color:#63b3ed">{st.session_state.target_col or '—'}</span>
      </div>
      <div style="color:#8899bb;font-size:.8rem;">
        🤖 <span style="color:{'#48bb78' if train_ok else '#f6ad55'}">{'Complete ✅' if train_ok else 'Not trained'}</span>
      </div>
    </div>""", unsafe_allow_html=True)
    if train_ok and st.session_state.best_model_name:
        st.markdown(f"""
        <div class="sidebar-section">
          <div style="color:#48bb78;font-size:.75rem;font-weight:600;">🏆 CHAMPION</div>
          <div style="color:#48bb78;font-weight:700;">{st.session_state.best_model_name}</div>
        </div>""", unsafe_allow_html=True)

# ── Helpers ───────────────────────────────────────────────────────────────────
def ph(icon,title,sub=""):
    st.markdown(f'<div class="page-header"><h2>{icon} {title}</h2>{"<p>"+sub+"</p>" if sub else ""}</div>',unsafe_allow_html=True)

def mc(val,lbl,col):
    col.markdown(f'<div class="metric-card"><div class="metric-value">{val}</div><div class="metric-label">{lbl}</div></div>',unsafe_allow_html=True)

def explain(text):
    st.markdown(f'<div class="explain-box">💡 {text}</div>',unsafe_allow_html=True)

def pd_layout(fig):
    fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(22,27,39,.6)",
                      font=dict(family="Space Grotesk",color="#b0c0d8"),
                      margin=dict(t=40,b=40,l=40,r=40))
    return fig

def safe_df(df):
    out=df.copy()
    for c in out.columns:
        if out[c].dtype==object: out[c]=out[c].astype(str)
        elif pd.api.types.is_float_dtype(out[c]): out[c]=out[c].astype(float)
        elif pd.api.types.is_integer_dtype(out[c]): out[c]=out[c].astype(int)
    return out

def shap_to_2d(raw):
    if isinstance(raw,list):
        sv=np.mean([np.abs(np.array(a)) for a in raw],axis=0)
    else:
        sv=np.array(raw)
    if sv.ndim==3:
        sv=np.abs(sv).mean(axis=0) if sv.shape[0]<sv.shape[1] else np.abs(sv).mean(axis=2)
    return sv.astype(float)

def pkl_dl(model,name,label="⬇️ Download Champion PKL"):
    buf=io.BytesIO()
    pickle.dump({"model":model,"model_name":name},buf)
    buf.seek(0)
    st.download_button(label,data=buf,file_name=f"{name}_champion.pkl",
                       mime="application/octet-stream",use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — DATA UPLOAD
# ══════════════════════════════════════════════════════════════════════════════
if page=="📂 Data Upload":
    ph("📂","Data Upload","File upload, sample datasets, or live database connection.")
    src_tab,db_tab=st.tabs(["📁 File / Sample","🗄️ Database"])

    with src_tab:
        cu,ci=st.columns([1,2])
        with cu:
            st.markdown("#### Upload Dataset")
            up=st.file_uploader("CSV / Excel / Parquet",type=["csv","xlsx","xls","parquet"])
            if up:
                try:
                    ext=Path(up.name).suffix.lower()
                    df=(pd.read_csv(up) if ext==".csv" else
                        pd.read_excel(up) if ext in[".xlsx",".xls"] else
                        pd.read_parquet(up))
                    st.session_state.df=df; st.session_state.file_name=up.name
                    Path("data/raw").mkdir(parents=True,exist_ok=True)
                    df.to_csv(f"data/raw/{up.name}",index=False)
                    st.success(f"✅ {up.name}  ({len(df):,} rows)")
                except Exception as e: st.error(f"Failed: {e}")
            st.divider()
            st.markdown("**Sample datasets:**")
            for btn,loader in [
                ("📊 Iris",lambda:(__import__('sklearn.datasets',fromlist=['load_iris']).load_iris,)),
                ("🏦 Breast Cancer",lambda:(__import__('sklearn.datasets',fromlist=['load_breast_cancer']).load_breast_cancer,)),
                ("🍷 Wine",lambda:(__import__('sklearn.datasets',fromlist=['load_wine']).load_wine,)),
            ]:
                if st.button(btn,use_container_width=True):
                    from sklearn import datasets as _ds
                    loaders={"📊 Iris":_ds.load_iris,"🏦 Breast Cancer":_ds.load_breast_cancer,"🍷 Wine":_ds.load_wine}
                    ds=loaders[btn](as_frame=True)
                    df=ds.frame.copy(); df["target"]=ds.target_names[ds.target]
                    st.session_state.df=df; st.session_state.file_name=f"{btn.split()[-1].lower()}.csv"
                    st.success(f"✅ {btn} loaded!"); st.rerun()

        with ci:
            if st.session_state.df is not None:
                df=st.session_state.df
                c1,c2,c3,c4=st.columns(4)
                mc(f"{df.shape[0]:,}","Rows",c1); mc(f"{df.shape[1]:,}","Cols",c2)
                mc(f"{df.isnull().sum().sum():,}","Missing",c3); mc(f"{df.duplicated().sum():,}","Dupes",c4)
                st.markdown("<br>",unsafe_allow_html=True)
                t1,t2,t3=st.tabs(["🔍 Preview","📊 Statistics","❓ Missing"])
                with t1: st.dataframe(safe_df(df.head(20)),use_container_width=True,height=340)
                with t2:
                    desc=df.describe(include="all").T.reset_index().rename(columns={"index":"column"})
                    st.dataframe(safe_df(desc),use_container_width=True)
                with t3:
                    miss=df.isnull().sum().reset_index(); miss.columns=["Column","Count"]
                    miss["Pct"]=(miss["Count"]/len(df)*100).round(2); miss=miss[miss["Count"]>0]
                    if miss.empty: st.success("🎉 No missing values!")
                    else:
                        st.plotly_chart(pd_layout(px.bar(miss,x="Column",y="Pct",color="Pct",
                            color_continuous_scale=["#63b3ed","#fc8181"],title="Missing %")),use_container_width=True)
                        st.dataframe(safe_df(miss),use_container_width=True)
            else: st.info("👆 Upload a dataset or connect to a database.")

    with db_tab:
        st.markdown("#### 🗄️ Database Connection")
        st.info("Connect to PostgreSQL, MySQL, SQLite, MSSQL, or Oracle. Requires SQLAlchemy + relevant driver.")
        dc1,dc2=st.columns(2)
        with dc1:
            db_type=st.selectbox("DB Type",["postgresql","mysql","sqlite","mssql","oracle","generic"])
            if db_type=="sqlite":
                db_path=st.text_input("SQLite File Path",placeholder=":memory: or path/to/db.sqlite")
                host=port=username=password=""; database=db_path
            elif db_type=="generic":
                raw_url=st.text_input("SQLAlchemy URL",placeholder="dialect+driver://user:pass@host/db")
                host=port=username=password=database=""
            else:
                host=st.text_input("Host","localhost")
                port=st.number_input("Port",value={"postgresql":5432,"mysql":3306,"mssql":1433,"oracle":1521}.get(db_type,5432),min_value=1,max_value=65535)
                database=st.text_input("Database"); username=st.text_input("Username"); password=st.text_input("Password",type="password")
        with dc2:
            qmode=st.radio("Load via",["SQL Query","Table Name"],horizontal=True)
            if qmode=="SQL Query":
                sql_q=st.text_area("SQL",value="SELECT * FROM my_table LIMIT 50000",height=100)
            else:
                tbl=st.text_input("Table Name"); rlim=st.number_input("Row Limit",value=50000,min_value=100,step=1000)
            if st.button("🔌 Connect & Load",use_container_width=True,type="primary"):
                try:
                    from src.ingestion.db_connector import DatabaseConnector
                    conn=(DatabaseConnector(db_type="sqlite",database=database) if db_type=="sqlite" else
                          DatabaseConnector(db_type="generic",connection_string=raw_url) if db_type=="generic" else
                          DatabaseConnector(db_type=db_type,host=host,port=int(port),database=database,username=username,password=password))
                    with st.spinner("Connecting…"):
                        df=conn.query(sql_q) if qmode=="SQL Query" else conn.read_table(tbl,limit=int(rlim))
                    st.session_state.df=df; st.session_state.file_name=f"db_{db_type}"
                    st.success(f"✅ {len(df):,} rows × {len(df.columns)} cols loaded!")
                    st.dataframe(safe_df(df.head(5)),use_container_width=True); conn.disconnect()
                except Exception as e: st.error(f"Failed: {e}")
            if st.button("📋 List Tables",use_container_width=True):
                try:
                    from src.ingestion.db_connector import DatabaseConnector
                    conn=(DatabaseConnector(db_type="sqlite",database=database) if db_type=="sqlite" else
                          DatabaseConnector(db_type="generic",connection_string=raw_url) if db_type=="generic" else
                          DatabaseConnector(db_type=db_type,host=host,port=int(port),database=database,username=username,password=password))
                    for t in conn.list_tables(): st.markdown(f"• `{t}`")
                    conn.disconnect()
                except Exception as e: st.error(f"{e}")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
elif page=="⚙️ Configuration":
    ph("⚙️","Configuration","12 models available. Configure preprocessing, tuning, and CV settings.")
    if st.session_state.df is None: st.warning("⚠️ Upload data first."); st.stop()
    df=st.session_state.df; cl,cr=st.columns(2)
    with cl:
        st.markdown("#### 🎯 Target")
        tc=st.selectbox("Target Column",df.columns.tolist(),index=len(df.columns)-1)
        st.session_state.target_col=tc
        if tc:
            vc=df[tc].value_counts()
            st.plotly_chart(pd_layout(px.bar(x=vc.index.astype(str),y=vc.values,
                labels={"x":"Class","y":"Count"},title="Class Distribution",
                color=vc.values,color_continuous_scale=["#3182ce","#63b3ed"])),use_container_width=True)
        st.markdown("#### 🔧 Preprocessing")
        scaler=st.selectbox("Scaler",["standard","minmax","robust"])
        ni=st.selectbox("Numeric Imputer",["median","mean","most_frequent"])
        ci_=st.selectbox("Categorical Imputer",["most_frequent","constant"])
        enc=st.selectbox("Encoding",["onehot","label"])
        ts=st.slider("Test Set %",10,40,20,5)
    with cr:
        st.markdown("#### 🤖 Model Selection (12 available)")
        from src.models.registry import get_available_models,MODEL_DESCRIPTIONS
        avail=get_available_models()
        with st.expander("📋 All 12 Model Descriptions"):
            for m in avail:
                st.markdown(f'<div style="background:#161b27;border:1px solid #2a3450;border-radius:6px;'
                            f'padding:8px 12px;margin-bottom:4px;"><span style="color:#63b3ed;font-weight:600;">'
                            f'{m.replace("_"," ").title()}</span><br>'
                            f'<span style="color:#8899bb;font-size:.78rem;">{MODEL_DESCRIPTIONS.get(m,"")}</span></div>',
                            unsafe_allow_html=True)
        sel=st.multiselect("Models to Train",avail,default=avail[:6] if len(avail)>=6 else avail)
        st.caption(f"**{len(sel)}** of **{len(avail)}** selected")
        st.markdown("#### 🔬 Tuning")
        tune=st.checkbox("Enable Optuna",value=True)
        nt=st.slider("Trials/Model",5,100,30,5,disabled=not tune)
        to=st.slider("Timeout/Model (s)",30,600,120,30,disabled=not tune)
        cv=st.slider("CV Folds",3,10,5)
        if st.button("💾 Save Config",use_container_width=True,type="primary"):
            import yaml
            cfg={"project":{"name":"AutoML","version":"1.3.0","random_state":42},
                 "data":{"raw_path":"data/raw","processed_path":"data/processed","test_size":ts/100},
                 "preprocessing":{"numeric_imputer":ni,"categorical_imputer":ci_,"scaler":scaler,"encoding":enc},
                 "models":{"enabled":sel,"cross_validation_folds":cv},
                 "tuning":{"enabled":tune,"n_trials":nt,"timeout":to,"metric":"f1_weighted"},
                 "evaluation":{"metrics":["accuracy","f1_weighted","precision_weighted","recall_weighted"],"threshold":.5},
                 "explainability":{"shap_enabled":True,"lime_enabled":False,"max_display_features":20},
                 "tracking":{"mlflow":{"enabled":True,"tracking_uri":"mlruns","experiment_name":"automl_classification"}},
                 "deployment":{"api":{"host":"0.0.0.0","port":8000}},"logging":{"level":"INFO"}}
            Path("config").mkdir(exist_ok=True)
            with open("config/config.yaml","w") as f: yaml.dump(cfg,f,default_flow_style=False)
            st.session_state.update({"dash_config":cfg,"selected_models":sel,"tune_enabled":tune})
            st.success(f"✅ Saved — {len(sel)} models")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — TRAINING
# ══════════════════════════════════════════════════════════════════════════════
elif page=="🚀 Training":
    ph("🚀","Training","One-click AutoML — preprocessing → tuning → training → evaluation.")
    if st.session_state.df is None or st.session_state.target_col is None:
        st.warning("⚠️ Configure data first."); st.stop()
    cc,cl2=st.columns([1,2])
    with cc:
        tc=st.session_state.target_col
        sel=st.session_state.get("selected_models",[])
        tune=st.session_state.get("tune_enabled",True)
        from src.models.registry import get_available_models
        if not sel: sel=get_available_models()[:5]
        st.info(f"🎯 Target: **{tc}**")
        st.info(f"📊 {st.session_state.df.shape[0]:,} × {st.session_state.df.shape[1]:,}")
        st.markdown(f"**Models ({len(sel)}):** {', '.join(sel)}")
        st.markdown(f"**Tuning:** {'✅' if tune else '❌'}")
        st.divider()
        if st.button("🚀 Start Training",use_container_width=True,type="primary"):
            st.session_state.update({"training_logs":[],"trained":False,"tuner_obj":None})
            cp="config/config.yaml"
            if not Path(cp).exists():
                import yaml
                Path("config").mkdir(exist_ok=True)
                with open(cp,"w") as f:
                    yaml.dump({"project":{"name":"AutoML","version":"1.3.0","random_state":42},
                               "data":{"raw_path":"data/raw","processed_path":"data/processed","test_size":.2},
                               "preprocessing":{"numeric_imputer":"median","categorical_imputer":"most_frequent","scaler":"standard","encoding":"onehot"},
                               "models":{"enabled":sel,"cross_validation_folds":5},
                               "tuning":{"enabled":tune,"n_trials":20,"timeout":60,"metric":"f1_weighted"},
                               "evaluation":{"metrics":["accuracy","f1_weighted"],"threshold":.5},
                               "explainability":{"shap_enabled":True,"lime_enabled":False,"max_display_features":20},
                               "tracking":{"mlflow":{"enabled":True,"tracking_uri":"mlruns","experiment_name":"automl_classification"}},
                               "deployment":{"api":{"host":"0.0.0.0","port":8000}},"logging":{"level":"INFO"}},f)
            try:
                tmp="data/raw/_upload.csv"; Path("data/raw").mkdir(parents=True,exist_ok=True)
                st.session_state.df.to_csv(tmp,index=False)
                from src.utils.config_loader import load_config
                cfg=load_config(cp)
                pb=st.progress(0); stxt=st.empty(); lph=st.empty(); logs=[]
                def cb(msg,pct):
                    logs.append(f"[{time.strftime('%H:%M:%S')}] {msg}"); pb.progress(pct/100)
                    stxt.markdown(f"**{msg}**")
                    lph.markdown('<div class="log-box">'+"<br>".join(f"<span style='color:#48bb78'>▶</span> {l}" for l in logs[-15:])+"</div>",unsafe_allow_html=True)
                from src.ingestion.data_loader import DataIngestion
                from src.preprocessing.pipeline import PreprocessingPipeline
                from src.models.trainer import ModelTrainer
                from src.models.selector import ModelSelector
                from src.evaluation.evaluator import ModelEvaluator
                from src.evaluation.artifact_exporter import save_model_artifact,build_performance_report
                from src.tracking.mlflow_tracker import ExperimentTracker
                from sklearn.model_selection import train_test_split
                cb("Ingesting data…",5)
                ing=DataIngestion(cfg); df_in,ct,_=ing.run(tmp,tc)
                cb("Preprocessing…",15)
                pp=PreprocessingPipeline(cfg)
                X,y=pp.fit_transform(df_in,tc,ct.get("numeric",[]),ct.get("categorical",[]))
                pp.save("models/preprocessor.pkl"); cn=[str(c) for c in pp.label_encoder.classes_]
                ts_v=cfg.get("data",{}).get("test_size",.2)
                X_tv,X_test,y_tv,y_test=train_test_split(X,y,test_size=ts_v,random_state=42,stratify=y)
                X_train,X_val,y_train,y_val=train_test_split(X_tv,y_tv,test_size=.15,random_state=42,stratify=y_tv)
                # ✅ Store in Streamlit session state
                st.session_state.X_train = X_train
                st.session_state.y_train = y_train

                st.session_state.X_val   = X_val
                st.session_state.y_val   = y_val

                st.session_state.X_test  = X_test
                st.session_state.y_test  = y_test

                bp={}
                if tune:
                    cb(f"Tuning {len(sel)} models…",28)
                    from src.tuning.optuna_tuner import HyperparameterTuner
                    tnr=HyperparameterTuner(cfg); bp=tnr.tune_all(X_train,y_train,sel)
                    st.session_state.tuner_obj=tnr
                    Path("models").mkdir(exist_ok=True)
                    with open("models/best_params.json","w") as f: json.dump(bp,f,indent=2,default=str)
                cb(f"Training {len(sel)} models…",55)
                tr=ModelTrainer(cfg); tms=tr.train_all(X_train,y_train,sel,bp)
                cb("Evaluating…",72)
                ev=ModelEvaluator(cfg); lb=ev.compare_models(tms,X_test,y_test)
                cb("Selecting champion…",82)
                sl=ModelSelector(cfg); bn,bm=sl.select(tms,lb); sl.save("models/best_model.pkl")
                # Train/val/test metrics for champion
                from sklearn.metrics import accuracy_score,f1_score,precision_score,recall_score,roc_auc_score
                def compute_metrics(m,Xd,yd):
                    yp=m.predict(Xd); res={"accuracy":round(accuracy_score(yd,yp),4),
                        "f1_weighted":round(f1_score(yd,yp,average="weighted",zero_division=0),4),
                        "precision_weighted":round(precision_score(yd,yp,average="weighted",zero_division=0),4),
                        "recall_weighted":round(recall_score(yd,yp,average="weighted",zero_division=0),4)}
                    if hasattr(m,"predict_proba"):
                        try:
                            ypr=m.predict_proba(Xd)
                            res["roc_auc"]=round(roc_auc_score(yd,ypr,multi_class="ovr",average="weighted") if len(np.unique(yd))>2 else roc_auc_score(yd,ypr[:,1]),4)
                        except: pass
                    return res
                tm_=compute_metrics(bm,X_train,y_train)
                vm_=compute_metrics(bm,X_val,y_val)
                tsm=compute_metrics(bm,X_test,y_test)
                cb("Saving joblib artifact with metadata…",88)
                meta={"train_metrics":tm_,"val_metrics":vm_,"test_metrics":tsm,
                      "best_params":bp.get(bn,{}),"class_names":cn,
                      "feature_names":pp.feature_names_out[:50],
                      "dataset_shape":df_in.shape,"model_version":"1.0"}
                ap=save_model_artifact(bm,pp,bn,meta,"models/champion_artifact.joblib")
                # Performance report
                pr_html=build_performance_report(bn,lb,tm_,vm_,tsm,bp.get(bn,{}),cn)
                with open("models/performance_report.html","w",encoding="utf-8") as f: f.write(pr_html)
                cb("MLflow logging…",93)
                tk=ExperimentTracker(cfg)
                for nm,mo in tms.items():
                    row=lb[lb["model"]==nm]; met=row.iloc[0].to_dict() if not row.empty else {}
                    tk.log_full_run(model_name=nm,model=mo,params=bp.get(nm,{}),
                                   metrics={k:v for k,v in met.items() if k!="model"},
                                   tags={"best":str(nm==bn)})
                cb("✅ All done!",100)
                st.session_state.update({
                    "trained":True,"leaderboard":lb,"best_model_name":bn,"best_model":bm,
                    "preprocessor":pp,"class_names":cn,"feature_names":pp.feature_names_out,
                    "X_test":X_test,"y_test":y_test,"X_train":X_train,"X_val":X_val,"y_val":y_val,
                    "trained_models":tms,"training_logs":logs,"best_params":bp,
                    "train_metrics":tm_,"val_metrics":vm_,"test_metrics":tsm,
                    "artifact_path":ap,
                })
                st.success(f"🏆 Champion: **{bn}**")
            except Exception as e:
                import traceback; st.error(f"❌ {e}"); st.code(traceback.format_exc())
    with cl2:
        st.markdown("#### Logs")
        logs=st.session_state.training_logs
        html=("<br>".join(f"<span style='color:#48bb78'>▶</span> {l}" for l in logs)
              if logs else "<span style='color:#8899bb'>Logs appear here…</span>")
        st.markdown(f'<div class="log-box">{html}</div>',unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — MODEL PERFORMANCE
# ══════════════════════════════════════════════════════════════════════════════
elif page=="📈 Model Performance":
    ph("📈","Model Performance","Leaderboard · Metrics · Confusion Matrix · ROC · Calibration · Downloads")
    if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
    lb=st.session_state.leaderboard; bn=st.session_state.best_model_name
    bm=st.session_state.best_model; cn=st.session_state.class_names
    br=lb[lb["model"]==bn].iloc[0]
    c1,c2,c3,c4,c5=st.columns(5)
    mc(bn,"🏆 Champion",c1); mc(f"{br.get('accuracy',0):.4f}","Accuracy",c2)
    mc(f"{br.get('f1_weighted',0):.4f}","F1",c3); mc(f"{br.get('precision_weighted',0):.4f}","Precision",c4)
    mc(f"{br.get('recall_weighted',0):.4f}","Recall",c5)
    st.markdown("<br>",unsafe_allow_html=True)

    # Download row
    dl1,dl2,dl3=st.columns(3)
    with dl1:
        st.markdown('<div class="champion-box"><div style="font-size:1.5rem;">🏆</div>'
                    f'<div style="color:#48bb78;font-weight:700;margin:6px 0;">{bn.replace("_"," ").title()}</div>'
                    '<div style="color:#8899bb;font-size:.78rem;">Champion PKL</div></div>',unsafe_allow_html=True)
        st.markdown("<br>",unsafe_allow_html=True); pkl_dl(bm,bn,"⬇️ Download PKL (pickle)")
        if Path("models/preprocessor.pkl").exists():
            with open("models/preprocessor.pkl","rb") as pf: pb=pf.read()
            st.download_button("⬇️ Download Preprocessor PKL",data=pb,
                               file_name="preprocessor.pkl",mime="application/octet-stream",use_container_width=True)
    with dl2:
        st.markdown("**Joblib Artifact (with metadata)**")
        ap=st.session_state.get("artifact_path","models/champion_artifact.joblib")
        if Path(ap).exists():
            with open(ap,"rb") as f: ab=f.read()
            st.download_button("⬇️ Download Joblib Artifact",data=ab,
                               file_name="champion_artifact.joblib",mime="application/octet-stream",use_container_width=True)
            st.caption(f"Includes: model, preprocessor, metadata (metrics, params, features)")
        else: st.info("Train to generate joblib artifact.")
    with dl3:
        st.markdown("**Performance Report (HTML)**")
        rp="models/performance_report.html"
        if Path(rp).exists():
            with open(rp,"r",encoding="utf-8",errors="replace") as f: rh=f.read()
            st.download_button("⬇️ Download Performance Report",data=rh.encode(),
                               file_name="performance_report.html",mime="text/html",use_container_width=True)
            st.caption("Train/val/test metrics · leaderboard · hyperparameters")
        else: st.info("Train to generate report.")

    st.info("ℹ️ Models ranked by **F1 (weighted)**. Change in `config.yaml → tuning.metric`.")
    st.markdown("<br>",unsafe_allow_html=True)

    tab1,tab2,tab3,tab4,tab5=st.tabs(["🏆 Leaderboard","📊 Metrics","🟦 Confusion Matrix","📈 ROC","🎯 Calibration"])

    with tab1:
        nc=[c for c in lb.columns if c!="model" and pd.api.types.is_numeric_dtype(lb[c])]
        def _hl(r): return(["background-color:rgba(72,187,120,.12);font-weight:bold"]*len(r) if r["model"]==bn else [""]*len(r))
        st.dataframe(lb.style.apply(_hl,axis=1).format({c:"{:.4f}" for c in nc}),use_container_width=True,height=350)

    with tab2:
        mc_list=["accuracy","f1_weighted","precision_weighted","recall_weighted","roc_auc"]
        av=[c for c in mc_list if c in lb.columns]
        mt=lb[["model"]+av].melt(id_vars="model",var_name="Metric",value_name="Score")
        fig=px.bar(mt,x="model",y="Score",color="Metric",barmode="group",title="All Models Comparison",
                   color_discrete_sequence=["#63b3ed","#48bb78","#f6ad55","#fc8181","#b794f4"])
        fig.update_xaxes(tickangle=25); st.plotly_chart(pd_layout(fig),use_container_width=True)
        explain("This grouped bar chart compares every selected metric across all trained models side-by-side. "
                "Taller bars = better performance. F1 is the primary ranking metric.")
        fig2=go.Figure()
        for _,r in lb.iterrows():
            vals=[r.get(m,0) for m in av]
            if vals: fig2.add_trace(go.Scatterpolar(r=vals+[vals[0]],theta=av+[av[0]],fill="toself",name=r["model"],opacity=.7))
        fig2.update_layout(polar=dict(radialaxis=dict(visible=True,range=[0,1])),title="Radar Chart")
        st.plotly_chart(pd_layout(fig2),use_container_width=True)
        explain("The radar chart shows the shape of each model's performance profile. "
                "A model with a large polygon area is strong across all metrics. "
                "Narrow spikes mean strong on one metric but weak on others.")

    with tab3:
        tms=st.session_state.get("trained_models",{}); Xt=st.session_state.X_test; yt=st.session_state.y_test
        mc_sel=st.selectbox("Model",lb["model"].tolist(),key="cm_m")
        if mc_sel in tms and Xt is not None:
            from sklearn.metrics import confusion_matrix as _cm
            yp=tms[mc_sel].predict(Xt); cm=_cm(yt,yp); lbs=cn or [str(i) for i in range(cm.shape[0])]
            fig=px.imshow(cm,x=lbs,y=lbs,color_continuous_scale="Blues",text_auto=True,
                          labels=dict(x="Predicted",y="Actual"),title=f"Confusion Matrix — {mc_sel}")
            st.plotly_chart(pd_layout(fig),use_container_width=True)
            explain("Diagonal cells (top-left to bottom-right) show correct predictions. "
                    "Off-diagonal cells show misclassifications. Darker blue = more samples. "
                    "A perfect model has values only on the diagonal.")

    with tab4:
        tms=st.session_state.get("trained_models",{}); Xt=st.session_state.X_test; yt=st.session_state.y_test
        roc_sel=st.selectbox("Model",lb["model"].tolist(),key="roc_m")
        if roc_sel in tms and Xt is not None:
            from sklearn.metrics import roc_curve,auc; from sklearn.preprocessing import label_binarize
            mo=tms[roc_sel]
            if hasattr(mo,"predict_proba"):
                ypr=mo.predict_proba(Xt); nc_=ypr.shape[1]; lbs=cn or [str(i) for i in range(nc_)]
                fig=go.Figure()
                if nc_==2:
                    fpr,tpr,_=roc_curve(yt,ypr[:,1]); fig.add_trace(go.Scatter(x=fpr,y=tpr,name=f"AUC={auc(fpr,tpr):.3f}",line=dict(color="#63b3ed",width=2)))
                else:
                    cls=np.unique(yt); yb=label_binarize(yt,classes=cls); cols=px.colors.qualitative.Set2
                    for i,c_ in enumerate(cls):
                        fpr,tpr,_=roc_curve(yb[:,i],ypr[:,i]); l=lbs[i] if i<len(lbs) else str(c_)
                        fig.add_trace(go.Scatter(x=fpr,y=tpr,name=f"{l} AUC={auc(fpr,tpr):.3f}",line=dict(color=cols[i%len(cols)],width=2)))
                fig.add_trace(go.Scatter(x=[0,1],y=[0,1],name="Random",line=dict(color="#8899bb",dash="dash")))
                fig.update_layout(title=f"ROC Curve — {roc_sel}",xaxis_title="FPR",yaxis_title="TPR")
                st.plotly_chart(pd_layout(fig),use_container_width=True)
                explain("The ROC curve plots True Positive Rate vs False Positive Rate at every threshold. "
                        "AUC (Area Under Curve) ranges 0–1: 1.0 = perfect, 0.5 = random guessing. "
                        "Curves closer to the top-left corner are better.")
            else: st.info("Model doesn't support predict_proba.")

    with tab5:
        st.markdown("#### Calibration Curve")
        tms=st.session_state.get("trained_models",{}); Xt=st.session_state.X_test; yt=st.session_state.y_test
        cal_sel=st.selectbox("Model",lb["model"].tolist(),key="cal_m")
        if cal_sel in tms and Xt is not None:
            mo=tms[cal_sel]
            if hasattr(mo,"predict_proba"):
                from sklearn.calibration import calibration_curve
                ypr=mo.predict_proba(Xt)
                if ypr.shape[1]==2:
                    frac_pos,mean_pred=calibration_curve(yt,ypr[:,1],n_bins=10,strategy="uniform")
                    fig=go.Figure()
                    fig.add_trace(go.Scatter(x=mean_pred,y=frac_pos,name="Calibration",
                                             mode="lines+markers",line=dict(color="#63b3ed",width=2),marker=dict(size=7)))
                    fig.add_trace(go.Scatter(x=[0,1],y=[0,1],name="Perfectly Calibrated",line=dict(color="#48bb78",dash="dash")))
                    fig.update_layout(title=f"Calibration Curve — {cal_sel}",
                                      xaxis_title="Mean Predicted Probability",yaxis_title="Fraction of Positives")
                    st.plotly_chart(pd_layout(fig),use_container_width=True)
                    explain("A perfectly calibrated model follows the dashed green diagonal — "
                            "when it predicts 70% probability, ~70% of those cases are actually positive. "
                            "Curves above the diagonal = overconfident. Below = underconfident.")
                else: st.info("Calibration curve shown for binary classification. For multiclass, select a one-vs-rest class.")
            else: st.info("Model doesn't support predict_proba.")
# ══════════════════════════════════════════════════════════════════════════════
# PAGE 5 — EXPLAINABILITY (FINAL, SHAP‑NATIVE)
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔍 Explainability":
    ph("🔍", "Explainability",
       "Feature importance · SHAP global · Beeswarm · Instance explanation")

    if not st.session_state.trained:
        st.warning("⚠️ Train a model first.")
        st.stop()

    bm = st.session_state.best_model
    Xt = st.session_state.X_test
    fn = st.session_state.feature_names
    cn = st.session_state.class_names

    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Feature Importance",
        "🌐 SHAP Global Bar",
        "🐝 SHAP Beeswarm",
        "🔍 Instance"
    ])

    # ───────────────────────── Tab 1 ─────────────────────────
    with tab1:
        st.markdown("#### Native Feature Importance")
        explain(
            "Shows which features the model considers most important during training. "
            "For tree models this is split gain; for linear models it is coefficient magnitude."
        )

        try:
            fi = None
            names = fn or [f"f{i}" for i in range(500)]

            if hasattr(bm, "feature_importances_"):
                fi = bm.feature_importances_
            elif hasattr(bm, "coef_"):
                c = bm.coef_
                fi = abs(c).mean(axis=0) if c.ndim > 1 else abs(c)

            if fi is not None:
                n = min(len(fi), len(names), 30)
                df_fi = (
                    pd.DataFrame({
                        "Feature": names[:n],
                        "Importance": fi[:n]
                    })
                    .sort_values("Importance", ascending=True)
                    .tail(20)
                )

                st.plotly_chart(
                    pd_layout(px.bar(
                        df_fi,
                        x="Importance",
                        y="Feature",
                        orientation="h",
                        title=f"Feature Importances — {st.session_state.best_model_name}",
                        color="Importance",
                        color_continuous_scale=["#3182ce", "#63b3ed"]
                    )),
                    use_container_width=True
                )
            else:
                st.info("Not available for this model. Use SHAP tabs.")
        except Exception as e:
            st.error(str(e))

    # ───────────────────────── Tab 2 ─────────────────────────
    with tab2:
        st.markdown("#### SHAP Global Bar")
        explain(
            "SHAP global importance shows the average absolute impact of each feature "
            "on model output across test samples."
        )

        try:
            import shap
        except ImportError:
            st.warning("Install SHAP: `pip install shap`")
            st.stop()

        if Xt is not None and st.button("🔬 Compute SHAP Values", use_container_width=True):
            with st.spinner("Computing SHAP values..."):
                smp = Xt[:min(150, len(Xt))]
                mt = type(bm).__name__.lower()

                explainer = (
                    shap.TreeExplainer(bm)
                    if any(t in mt for t in ["tree", "forest", "xgb", "lgbm", "catboost"])
                    else shap.LinearExplainer(bm, smp)
                    if "linear" in mt or "logistic" in mt
                    else shap.KernelExplainer(
                        bm.predict_proba if hasattr(bm, "predict_proba") else bm.predict,
                        shap.sample(smp, 50)
                    )
                )

                raw = explainer.shap_values(smp)
                st.session_state.shap_values = raw[1] if isinstance(raw, list) else raw
                st.session_state.shap_sample = smp

        if st.session_state.shap_values is not None:
            sv = st.session_state.shap_values
            names = fn or [f"f{i}" for i in range(sv.shape[1])]
            msv = abs(sv).mean(axis=0)

            max_features = min(40, len(msv))
            topn = max_features if max_features <= 5 else st.slider(
                "Top N features",
                5, max_features, min(20, max_features)
            )

            df_bar = (
                pd.DataFrame({
                    "Feature": names,
                    "Mean |SHAP|": msv
                })
                .sort_values("Mean |SHAP|", ascending=False)
                .head(topn)
                .sort_values("Mean |SHAP|")
            )

            st.plotly_chart(
                pd_layout(px.bar(
                    df_bar,
                    x="Mean |SHAP|",
                    y="Feature",
                    orientation="h",
                    title="SHAP Global Feature Importance",
                    color="Mean |SHAP|",
                    color_continuous_scale=["#553c9a", "#b794f4"]
                )),
                use_container_width=True
            )

    # ───────────────────────── Tab 3 ─────────────────────────
    with tab3:
        st.markdown("#### 🐝 SHAP Beeswarm Plot (Exact)")

        explain(
            "This is the standard SHAP beeswarm plot. Each dot represents one test sample. "
            "Red = high feature value, Blue = low feature value. "
            "Dots to the right increase the prediction, dots to the left decrease it."
        )

        if st.session_state.shap_values is None:
            st.info("Compute SHAP values first (SHAP Global Bar tab).")
        else:
            import shap
            import matplotlib.pyplot as plt

            sv = st.session_state.shap_values
            Xs = st.session_state.shap_sample

            max_features = min(30, sv.shape[1])
            topn = max_features if max_features <= 5 else st.slider(
                "Top N features",
                5, max_features, min(15, max_features)
            )

            plt.figure(figsize=(10, max(4, topn * 0.35)))

            shap.summary_plot(
                sv,
                Xs,
                feature_names=fn,
                max_display=topn,
                plot_type="dot",   # ✅ exact beeswarm
                show=False
            )

            st.pyplot(plt.gcf())
            plt.clf()

    # ───────────────────────── Tab 4 ─────────────────────────
    with tab4:
        st.markdown("#### Instance‑Level Explanation")
        explain(
            "This waterfall chart explains a SINGLE prediction by showing how each feature "
            "pushes the model output away from the baseline."
        )

        if Xt is not None and st.session_state.shap_values is not None:
            import matplotlib.pyplot as plt
            import shap

            idx = st.slider("Select test instance", 0, len(Xt) - 1, 0)

            expl = shap.Explanation(
                values=st.session_state.shap_values[idx],
                base_values=0,
                data=Xt.iloc[idx] if hasattr(Xt, "iloc") else Xt[idx],
                feature_names=fn
            )

            plt.figure(figsize=(8, 5))
            shap.plots.waterfall(expl, max_display=15, show=False)
            st.pyplot(plt.gcf())
            plt.clf()

            yp = bm.predict(Xt[idx:idx + 1])
            pc = cn[yp[0]] if cn and yp[0] < len(cn) else str(yp[0])
            st.markdown(f"**Predicted:** `{pc}`")

            if st.session_state.y_test is not None:
                yt = st.session_state.y_test[idx]
                tc = cn[yt] if cn and yt < len(cn) else str(yt)
                st.markdown(f"**Actual:** `{tc}`")
        else:
            st.info("Compute SHAP values first.")


# # ══════════════════════════════════════════════════════════════════════════════
# # PAGE 5 — EXPLAINABILITY
# # ══════════════════════════════════════════════════════════════════════════════
# elif page=="🔍 Explainability":
#     ph("🔍","Explainability","Feature importance · SHAP global · Beeswarm · Instance explanation")
#     if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
#     bm=st.session_state.best_model; Xt=st.session_state.X_test
#     fn=st.session_state.feature_names; cn=st.session_state.class_names

#     tab1,tab2,tab3,tab4=st.tabs(["📊 Feature Importance","🌐 SHAP Global Bar","🐝 SHAP Beeswarm","🔍 Instance"])

#     with tab1:
#         st.markdown("#### Native Feature Importance")
#         explain("This chart shows which features the model considers most important during training. "
#                 "Higher bars = more influence on predictions. For tree models this is split gain; "
#                 "for linear models it's absolute coefficient magnitude.")
#         try:
#             fi=None; names=fn or [f"f{i}" for i in range(500)]
#             if hasattr(bm,"feature_importances_"): fi=np.array(bm.feature_importances_)
#             elif hasattr(bm,"coef_"):
#                 c=np.array(bm.coef_); fi=np.abs(c).mean(axis=0) if c.ndim>1 else np.abs(c.flatten())
#             if fi is not None:
#                 n=min(len(fi),len(names),30)
#                 df_fi=pd.DataFrame({"Feature":[str(x) for x in names[:n]],"Importance":fi[:n].astype(float)})
#                 df_fi=df_fi.sort_values("Importance",ascending=True).tail(20)
#                 st.plotly_chart(pd_layout(px.bar(df_fi,x="Importance",y="Feature",orientation="h",
#                     title=f"Feature Importances — {st.session_state.best_model_name}",
#                     color="Importance",color_continuous_scale=["#3182ce","#63b3ed"])),use_container_width=True)
#             else: st.info("Not available for this model. Use SHAP tabs.")
#         except Exception as e: st.error(f"{e}")

#     with tab2:
#         st.markdown("#### SHAP Global Bar")
#         explain("SHAP (SHapley Additive exPlanations) values show the average impact of each feature "
#                 "on model output. The bar length represents the mean absolute SHAP value across all "
#                 "test samples — longer bar = greater average impact.")
#         try:
#             import shap as _; SHAP_OK=True
#         except: SHAP_OK=False; st.warning("`pip install shap`")
#         if SHAP_OK and Xt is not None:
#             if st.button("🔬 Compute SHAP Values",use_container_width=True,key="shap_go"):
#                 with st.spinner("Computing…"):
#                     try:
#                         import shap; smp=Xt[:min(150,len(Xt))]; mt=type(bm).__name__.lower()
#                         expl=(shap.TreeExplainer(bm) if any(t in mt for t in ["xgb","lgbm","catboost","forest","tree","extra"])
#                               else shap.LinearExplainer(bm,smp) if "logistic" in mt or "linear" in mt
#                               else shap.KernelExplainer(bm.predict_proba if hasattr(bm,"predict_proba") else bm.predict,shap.sample(smp,50)))
#                         raw=expl.shap_values(smp); sv=shap_to_2d(raw)
#                         st.session_state.shap_values=sv; st.session_state.shap_sample=smp
#                         st.success("✅ SHAP values computed! All SHAP tabs are now active.")
#                     except Exception as e:
#                         import traceback; st.error(f"{e}"); st.code(traceback.format_exc())
#             if st.session_state.shap_values is not None:
#                 sv=st.session_state.shap_values; names=fn or [f"f{i}" for i in range(sv.shape[1])]
#                 n=min(sv.shape[1],len(names)); msv=np.abs(sv).mean(axis=0)[:n].astype(float)
#                 max_features = min(n, 40)

#                 if max_features <= 5:
#                     topn = max_features
#                     st.info(f"Only {topn} features available. Showing all features.")
#                 else:
#                     topn = st.slider(
#                         "Top N features",
#                         min_value=5,
#                         max_value=max_features,
#                         value=min(20, max_features),
#                         key="gn",
#                     )
#                 df_s=pd.DataFrame({"Feature":[str(x) for x in names[:n]],"Mean |SHAP|":msv}).sort_values("Mean |SHAP|",ascending=False).head(topn).sort_values("Mean |SHAP|",ascending=True)
#                 st.plotly_chart(pd_layout(px.bar(df_s,x="Mean |SHAP|",y="Feature",orientation="h",
#                     title="SHAP Global Feature Importance",color="Mean |SHAP|",color_continuous_scale=["#553c9a","#b794f4"])),use_container_width=True)
#             else: st.info("Click **Compute SHAP Values** to begin.")

#     with tab3:
#         st.markdown("#### SHAP Beeswarm Plot")
#         explain("The beeswarm plot shows SHAP values for EVERY test sample for each top feature. "
#                 "Each dot = one sample. Position on x-axis = SHAP value (positive pushes toward predicted class, "
#                 "negative pushes away). The spread (width) of dots shows distribution. "
#                 "Color indicates the feature's raw value (if numeric) — use this to understand direction of effect.")
#         if st.session_state.shap_values is None:
#             st.info("Compute SHAP values first (SHAP Global Bar tab).")
#         else:
#             sv=st.session_state.shap_values; names=fn or [f"f{i}" for i in range(sv.shape[1])]
#             n=min(sv.shape[1],len(names)); msv=np.abs(sv).mean(axis=0)[:n]
# # n = number of available features

#             if n <= 5:
#                 top_bee = n
#                 st.info(f"Only {n} features available. Showing all features.")
#             else:
#                 top_bee = st.slider(
#                     "Top N features",
#                     min_value=5,
#                     max_value=min(n, 30),
#                     value=min(15, n),
#                     key="bee_n",
#                 )            
#             top_idx=np.argsort(msv)[::-1][:top_bee]
#             smp=st.session_state.shap_sample
#             rows=[]
#             for idx in top_idx:
#                 fname=str(names[idx]) if idx<len(names) else f"f{idx}"
#                 shap_col=sv[:,idx]
#                 feat_col=smp[:,idx] if smp is not None and idx<smp.shape[1] else np.zeros(len(shap_col))
#                 for i,(sv_val,fv) in enumerate(zip(shap_col,feat_col)):
#                     rows.append({"Feature":fname,"SHAP Value":float(sv_val),"Feature Value":float(fv),"Sample":i})
#             df_bee=pd.DataFrame(rows)
#             import numpy as np

#             # Create numeric positions for features
#             feature_order = df_bee["Feature"].unique()[::-1]
#             feature_to_num = {f: i for i, f in enumerate(feature_order)}

#             # Map feature names to numeric positions
#             y_numeric = df_bee["Feature"].map(feature_to_num)

#             # Add random jitter
#             rng = np.random.default_rng(42)
#             y_jittered = y_numeric + rng.normal(0, 0.15, size=len(y_numeric))
#             fig = px.scatter(
#                 df_bee,
#                 x="SHAP Value",
#                 y=y_jittered,
#                 orientation="h",
#                 color="Feature Value",                 # continuous
#                 color_continuous_scale="RdBu",
#                 title="SHAP Beeswarm (Plotly)",
#             )
#             fig.update_yaxes(
#             tickmode="array",
#             tickvals=list(feature_to_num.values()),
#             ticktext=list(feature_to_num.keys()),
#             )
#             fig.update_traces(
#             marker=dict(size=6, opacity=0.7)
#             )
#             # fig.update_traces(
#             #     jitter=0.4,
#             #     marker=dict(size=5, opacity=0.7),
#             # )

#             fig.update_layout(
#                 height=max(400, topn * 35),
#                 coloraxis_colorbar=dict(title="Feature Value"),
#             )

#             st.plotly_chart(fig, use_container_width=True)

            
#             explain("Red dots (high feature value) cluster on the right → high feature value increases prediction score. "
#                     "Blue dots (low feature value) cluster on the left → low feature value decreases prediction score. "
#                     "Wide horizontal spread = this feature has a large variance in impact across samples.")

#     with tab4:
#         st.markdown("#### Instance-Level Explanation")
#         explain("This waterfall chart explains a single prediction. Green bars push the prediction "
#                 "toward the positive class; red bars push it away. The longer the bar, the stronger "
#                 "the influence of that feature on THIS specific prediction.")
#         if Xt is not None and st.session_state.shap_values is not None:
#             sv=st.session_state.shap_values; idx=st.slider("Test instance",0,len(Xt)-1,0)
#             names=fn or [f"f{i}" for i in range(sv.shape[1])]; n=min(sv.shape[1],len(names))
#             isv=sv[idx,:n].astype(float)
#             df_i=pd.DataFrame({"Feature":[str(x) for x in names[:n]],"SHAP Value":isv,
#                                "Direction":["Positive ↑" if v>=0 else "Negative ↓" for v in isv]}
#                               ).sort_values("SHAP Value",key=abs,ascending=True).tail(15)
#             fig=px.bar(df_i,x="SHAP Value",y="Feature",orientation="h",color="Direction",
#                        color_discrete_map={"Positive ↑":"#48bb78","Negative ↓":"#fc8181"},
#                        title=f"SHAP Waterfall — Instance #{idx}")
#             st.plotly_chart(pd_layout(fig),use_container_width=True)
#             yp=bm.predict(Xt[idx:idx+1]); pc=cn[yp[0]] if cn and yp[0]<len(cn) else str(yp[0])
#             st.markdown(f"**Predicted:** `{pc}`")
#             if st.session_state.y_test is not None:
#                 ti=st.session_state.y_test[idx]; tc=cn[ti] if cn and ti<len(cn) else str(ti)
#                 st.markdown(f"**Actual:** `{tc}` {'✅' if str(pc)==str(tc) else '❌'}")
#         else: st.info("Compute SHAP values first.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 6 — HYPERPARAMETER LOG
# ══════════════════════════════════════════════════════════════════════════════
elif page=="📋 Hyperparameter Log":
    ph("📋","Hyperparameter Log","Full Optuna trial history — every trial, chosen params highlighted.")
    if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
    tnr=st.session_state.get("tuner_obj")
    if not st.session_state.get("tune_enabled",True) or tnr is None:
        bp=st.session_state.get("best_params",{})
        if bp:
            st.info("ℹ️ Tuning was disabled or trial objects not stored. Showing best params only.")
            for mn,p in bp.items():
                with st.expander(f"**{mn}**"):
                    if p:
                        df_p=pd.DataFrame([{"Parameter":k,"Value":str(v)} for k,v in p.items()])
                        st.dataframe(safe_df(df_p),use_container_width=True)
                    else: st.info("Default params used.")
        else: st.info("No tuning data found. Enable tuning and re-train.")
        st.stop()

    # Summary across models
    st.markdown("### 📊 Tuning Summary — All Models")
    sum_df=tnr.summary_dataframe()
    if not sum_df.empty:
        nc_s=[c for c in sum_df.columns if c!="model" and pd.api.types.is_numeric_dtype(sum_df[c])]
        st.dataframe(safe_df(sum_df).style.format({c:("{:.4f}" if "score" in c else "{}") for c in nc_s if c in sum_df.columns}),use_container_width=True)
        fig=px.bar(sum_df.sort_values("best_score",ascending=True),x="best_score",y="model",
                   orientation="h",title="Best Score per Model (Tuned)",
                   color="best_score",color_continuous_scale=["#3182ce","#48bb78"])
        st.plotly_chart(pd_layout(fig),use_container_width=True)
        explain("Each bar shows the best CV score achieved by Optuna for that model after all trials. "
                "The trial selected as best is shown in the trial detail below.")

    st.markdown("---")
    st.markdown("### 🔬 Trial-by-Trial Detail")
    models_with_trials=[m for m in tnr.all_trials if tnr.all_trials[m]]
    if not models_with_trials: st.info("No trial history available."); st.stop()
    sel_m=st.selectbox("Select Model",models_with_trials)
    df_t=tnr.trials_dataframe(sel_m)
    if df_t.empty: st.info("No trials for this model."); st.stop()

    bi=tnr.best_trial_info.get(sel_m,{})
    c1,c2,c3=st.columns(3)
    mc(f"#{bi.get('trial_number','?')}","✅ Chosen Trial",c1)
    mc(f"{bi.get('score',0):.4f}",f"Best {bi.get('metric','score')}",c2)
    mc(f"{bi.get('n_trials_run',0)}","Trials Run",c3)
    st.markdown("<br>",unsafe_allow_html=True)

    # Score over trials
    df_plot=df_t[df_t["score"].notna()].copy()
    if not df_plot.empty:
        df_plot["best_so_far"]=df_plot["score"].cummax()
        fig=go.Figure()
        fig.add_trace(go.Scatter(x=df_plot["trial"],y=df_plot["score"],name="Trial Score",
                                  mode="markers",marker=dict(color="#63b3ed",size=5,opacity=.7)))
        fig.add_trace(go.Scatter(x=df_plot["trial"],y=df_plot["best_so_far"],name="Best So Far",
                                  mode="lines",line=dict(color="#48bb78",width=2)))
        # mark chosen trial
        best_t=bi.get("trial_number",0)
        best_row=df_plot[df_plot["trial"]==best_t]
        if not best_row.empty:
            fig.add_trace(go.Scatter(x=best_row["trial"],y=best_row["score"],name="Chosen Trial",
                                      mode="markers",marker=dict(color="#f6ad55",size=14,symbol="star")))
        fig.update_layout(title=f"Optuna Trial Scores — {sel_m}",xaxis_title="Trial #",yaxis_title=bi.get("metric","Score"))
        st.plotly_chart(pd_layout(fig),use_container_width=True)
        explain("Blue dots = score of each individual trial. Green line = best score achieved so far (cumulative maximum). "
                "The gold star ⭐ marks the chosen trial (best trial). A rising green line means Optuna is finding "
                "better configurations over time.")

    # Best params card
    st.markdown(f"#### ✅ Chosen Trial #{bi.get('trial_number','?')} — Best Parameters")
    bp_d=bi.get("params",{})
    if bp_d:
        cols=st.columns(min(len(bp_d),4))
        for i,(k,v) in enumerate(bp_d.items()):
            cols[i%len(cols)].markdown(f"**`{k}`**\n\n`{v}`")
    else: st.info("Default params (no tuning params logged).")

    # Full trial table
    st.markdown("#### 📄 All Trials Table")
    df_display=df_t.copy()
    def highlight_best_trial(row):
        return(["background-color:rgba(246,173,85,.18);font-weight:bold"]*len(row) if row.get("is_best") else [""]*len(row))
    nc_t=[c for c in df_display.columns if pd.api.types.is_numeric_dtype(df_display[c]) and c!="trial"]
    st.dataframe(safe_df(df_display).style.apply(highlight_best_trial,axis=1).format(
        {c:"{:.4f}" for c in nc_t if "score" in c}),use_container_width=True,height=350)
    csv_t=df_t.to_csv(index=False).encode()
    st.download_button("⬇️ Download Trial Log CSV",data=csv_t,
                       file_name=f"{sel_m}_trials.csv",mime="text/csv")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 7 — MODEL CARD
# ══════════════════════════════════════════════════════════════════════════════
elif page=="🃏 Model Card":
    ph("🃏","Model Card","Auto-generated documentation — data lineage, algorithm, metrics, limitations.")
    if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
    bn=st.session_state.best_model_name; bm=st.session_state.best_model
    cn=st.session_state.class_names; fn=st.session_state.feature_names
    tm_=st.session_state.train_metrics; vm_=st.session_state.val_metrics; tsm=st.session_state.test_metrics
    bp=st.session_state.best_params.get(bn,{})
    tnr=st.session_state.get("tuner_obj"); ti=tnr.best_trial_info.get(bn,{}) if tnr else {}

    with st.form("card_form"):
        st.markdown("#### Customise Model Card")
        c1,c2=st.columns(2)
        iu=c1.text_area("Intended Use",value="Binary or multiclass tabular classification on structured data.",height=80)
        lim=c2.text_area("Limitations",value="Performance may degrade on out-of-distribution or highly imbalanced data. Requires retraining when data distribution shifts.",height=80)
        eth=st.text_area("Ethical Considerations",value="Ensure the training dataset is free of harmful bias. Audit predictions for fairness across demographic groups before production deployment.",height=60)
        gen=st.form_submit_button("🃏 Generate Model Card",use_container_width=True,type="primary")

    if gen or st.session_state.get("model_card_obj"):
        from src.evaluation.model_card import ModelCardGenerator
        mcg=ModelCardGenerator()
        mcg.build(model_name=bn,model_type=type(bm).__name__,
                  dataset_name=st.session_state.get("file_name","uploaded_dataset"),
                  target_col=st.session_state.target_col or "target",
                  feature_names=fn or [],class_names=cn,
                  train_metrics=tm_,val_metrics=vm_,test_metrics=tsm,
                  best_params=bp,
                  dataset_shape=st.session_state.df.shape if st.session_state.df is not None else (0,0),
                  n_trials_run=ti.get("n_trials_run",0),
                  best_trial_number=ti.get("trial_number",0),
                  tuning_metric=ti.get("metric","f1_weighted"),
                  intended_use=iu,limitations=lim,ethical_notes=eth)
        st.session_state.model_card_obj=mcg
        st.success("✅ Model card generated!")

    mc_obj=st.session_state.get("model_card_obj")
    if mc_obj:
        dl_md,dl_html=st.columns(2)
        md_text=mc_obj.to_markdown()
        with dl_md:
            st.download_button("⬇️ Download Markdown (.md)",data=md_text.encode(),
                               file_name=f"{bn}_model_card.md",mime="text/markdown",use_container_width=True)
        html_text=mc_obj.to_html()
        with dl_html:
            st.download_button("⬇️ Download HTML Report",data=html_text.encode(),
                               file_name=f"{bn}_model_card.html",mime="text/html",use_container_width=True)
        with st.expander("📄 Preview Model Card (Markdown)",expanded=True):
            st.markdown(md_text)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 8 — HYPOTHESIS TESTING
# ══════════════════════════════════════════════════════════════════════════════
elif page=="🧪 Hypothesis Testing":
    ph("🧪","Hypothesis Testing","Statistical significance: McNemar · Wilcoxon · Friedman · Paired t-Test")
    if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
    tms=st.session_state.get("trained_models",{}); 
    if (
        st.session_state.X_train is None
        or st.session_state.y_train is None
        or st.session_state.best_model_name is None
    ):
        st.warning("Please train a model first.")
        st.stop()


    Xt=st.session_state.X_test; yt=st.session_state.y_test
    Xt2=st.session_state.X_train; yt2=st.session_state.y_train; bn=st.session_state.best_model_name
    if len(tms)<2: st.warning("⚠️ Need at least 2 trained models for comparison."); st.stop()

    with st.expander("ℹ️ About these tests",expanded=False):
        st.markdown("""
        | Test | What it measures | When to use |
        |---|---|---|
        | **McNemar** | Whether two classifiers make different errors on the same test set | Any two classifiers on identical test data |
        | **Wilcoxon Signed-Rank** | Whether paired CV fold scores differ significantly (non-parametric) | Comparing CV score distributions |
        | **Paired t-Test** | Same as Wilcoxon but assumes normality of differences | Small CV fold counts, roughly normal scores |
        | **Friedman** | Whether ALL models perform equivalently (multi-model) | Comparing 3+ models simultaneously |
        | **Cohen's d** | Effect size — practical significance beyond p-value | Alongside any test |
        
        **α = 0.05** (default). p < 0.05 → statistically significant difference.
        """)

    c_ref,c_alpha=st.columns([2,1])
    ref_m=c_ref.selectbox("Reference / Champion Model",list(tms.keys()),
                           index=list(tms.keys()).index(bn) if bn in tms else 0)
    alpha=c_alpha.slider("Significance Level (α)",0.01,0.10,0.05,0.01)

    if st.button("🧪 Run All Hypothesis Tests",use_container_width=True,type="primary"):
        with st.spinner("Running statistical tests…"):
            from src.evaluation.hypothesis_testing import HypothesisTester
            from src.utils.config_loader import load_config
            try: cfg=load_config("config/config.yaml")
            except: cfg={"tuning":{"metric":"f1_weighted"},"models":{"cross_validation_folds":5},"project":{"random_state":42}}
            ht=HypothesisTester(cfg,alpha=alpha)
            res=ht.run_all(tms,Xt,yt,Xt2,yt2,reference_model=ref_m)
            st.session_state.hypothesis_results=res
            st.success("✅ Tests complete!")

    res=st.session_state.get("hypothesis_results")
    if res:
        tab1,tab2,tab3,tab4,tab5=st.tabs(["📋 Summary","🔬 McNemar","🔄 Wilcoxon","📐 Paired t-Test","🌐 Friedman"])

        with tab1:
            st.markdown("#### Pairwise Comparison Summary")
            sum_df=res.get("summary",pd.DataFrame())
            if not sum_df.empty:
                def hl_sig(r):
                    return(["background-color:rgba(72,187,120,.12)"]*len(r) if r.get("wilcoxon_sig")=="✅" else [""]*len(r))
                nc_s=[c for c in sum_df.columns if pd.api.types.is_numeric_dtype(sum_df[c])]
                st.dataframe(safe_df(sum_df).style.apply(hl_sig,axis=1).format(
                    {c:"{:.4f}" for c in nc_s if c in sum_df.columns}),use_container_width=True)
                explain("Green rows = statistically significant difference (p < α). "
                        "mean_A / mean_B = average CV score per model. "
                        "effect_size = Cohen's d (how practically large the difference is).")
                # p-value heatmap
                pw=res.get("wilcoxon",{})
                if pw:
                    pairs=[k for k in pw]; pvals=[pw[k].get("p_value",1) for k in pairs]
                    fig=px.bar(x=pairs,y=pvals,title="Wilcoxon p-values by Pair",
                               color=[1 if p<alpha else 0 for p in pvals],
                               color_continuous_scale=["#fc8181","#48bb78"],
                               labels={"x":"Pair","y":"p-value"})
                    fig.add_hline(y=alpha,line_dash="dash",line_color="#f6ad55",
                                  annotation_text=f"α={alpha}")
                    fig.update_xaxes(tickangle=30); st.plotly_chart(pd_layout(fig),use_container_width=True)
                    explain("Bars below the dashed orange line (α threshold) indicate statistically significant "
                            "differences between that pair of models. Green = significant, red = not significant.")

        with tab2:
            st.markdown(f"#### McNemar's Test  (reference: **{ref_m}**)")
            explain("McNemar's test checks if two classifiers disagree on DIFFERENT test samples. "
                    "It counts: (b) cases where model A was right but B was wrong, and (c) the reverse. "
                    "Significant result means the two models make systematically different errors.")
            for pair,r in res.get("mcnemar",{}).items():
                with st.expander(f"**{pair}** — p={r.get('p_value','?')}  {r.get('interpretation','')}"):
                    co1,co2=st.columns(2)
                    co1.metric("Statistic",f"{r.get('statistic',0):.4f}")
                    co2.metric("p-value",f"{r.get('p_value',1):.4f}")
                    ct=r.get("contingency")
                    if ct:
                        a_name=pair.split("_vs_")[0]; b_name=pair.split("_vs_")[1]
                        df_ct=pd.DataFrame(ct,index=[f"{a_name} correct",f"{a_name} wrong"],
                                           columns=[f"{b_name} correct",f"{b_name} wrong"])
                        st.dataframe(df_ct,use_container_width=True)
                        st.caption(f"b={r.get('b_only_A_correct',0)} (only A right), c={r.get('c_only_B_correct',0)} (only B right)")

        with tab3:
            st.markdown("#### Wilcoxon Signed-Rank Test")
            explain("Non-parametric test comparing paired CV fold scores. "
                    "Does NOT assume the score differences are normally distributed. "
                    "Recommended for most ML model comparisons where normality is uncertain.")
            for pair,r in res.get("wilcoxon",{}).items():
                if "error" in r: continue
                with st.expander(f"**{pair}**  p={r.get('p_value','?')}  {r.get('interpretation','')}  (effect={r.get('effect_label','?')})"):
                    co1,co2,co3,co4=st.columns(4)
                    co1.metric("Statistic",f"{r.get('statistic',0):.3f}")
                    co2.metric("p-value",f"{r.get('p_value',1):.4f}")
                    co3.metric("Effect Size (d)",f"{r.get('effect_size',0):.3f}")
                    co4.metric("Effect",r.get("effect_label","?"))
                    co1.metric("Mean A",f"{r.get('mean_A',0):.4f}"); co2.metric("Mean B",f"{r.get('mean_B',0):.4f}")

        with tab4:
            st.markdown("#### Paired t-Test")
            explain("Parametric paired test comparing CV fold scores. Assumes the differences between "
                    "paired scores are normally distributed. Use alongside Wilcoxon for robustness — "
                    "if both agree, the result is more trustworthy.")
            for pair,r in res.get("paired_ttest",{}).items():
                if "error" in r: continue
                with st.expander(f"**{pair}**  p={r.get('p_value','?')}  {r.get('interpretation','')}"):
                    co1,co2,co3=st.columns(3)
                    co1.metric("t-Statistic",f"{r.get('statistic',0):.3f}")
                    co2.metric("p-value",f"{r.get('p_value',1):.4f}")
                    co3.metric("Effect Size",f"{r.get('effect_size',0):.3f}")

        with tab5:
            st.markdown("#### Friedman Test  (all models simultaneously)")
            explain("The Friedman test extends Wilcoxon to 3+ models at once. "
                    "It tests whether all models perform equivalently across CV folds (null hypothesis). "
                    "Significant result means AT LEAST one model is different — use pairwise tests to find which.")
            fr=res.get("friedman",{})
            if "error" in (fr or {}): st.warning(fr["error"])
            elif fr:
                co1,co2=st.columns(2)
                co1.metric("χ² Statistic",f"{fr.get('statistic',0):.4f}")
                co2.metric("p-value",f"{fr.get('p_value',1):.4f}")
                st.markdown(f"**Result:** {fr.get('interpretation','')}")
                ranks=fr.get("rankings",[])
                if ranks:
                    df_r=pd.DataFrame(ranks,columns=["Model","Mean CV Score"])
                    df_r["Rank"]=range(1,len(df_r)+1)
                    fig=px.bar(df_r,x="Mean CV Score",y="Model",orientation="h",
                               color="Mean CV Score",color_continuous_scale=["#3182ce","#48bb78"],
                               title="Model Rankings (Friedman)")
                    st.plotly_chart(pd_layout(fig),use_container_width=True)
                    st.dataframe(safe_df(df_r),use_container_width=True)
            else: st.info("Need ≥3 models for Friedman test.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 9 — PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════
elif page=="🔮 Predictions":
    ph("🔮","Predictions","Manual input or batch file prediction.")
    if not st.session_state.trained: st.warning("⚠️ Train first."); st.stop()
    bm=st.session_state.best_model; pp=st.session_state.preprocessor
    cn=st.session_state.class_names; dfo=st.session_state.df; tc=st.session_state.target_col
    fcs=[c for c in dfo.columns if c!=tc]
    tab1,tab2=st.tabs(["✏️ Manual","📁 Batch Upload"])
    with tab1:
        with st.form("mp"):
            inputs={}
            for rc in [fcs[i:i+3] for i in range(0,len(fcs),3)]:
                fcols=st.columns(len(rc))
                for fc,col in zip(rc,fcols):
                    sv=dfo[fc].dropna()
                    if pd.api.types.is_numeric_dtype(dfo[fc]):
                        inputs[fc]=col.number_input(fc,value=float(sv.median()) if len(sv)>0 else 0.0,key=f"i_{fc}")
                    else:
                        opts=[str(v) for v in sv.unique().tolist()[:20]]
                        inputs[fc]=col.selectbox(fc,options=opts or [""],key=f"i_{fc}")
            sub=st.form_submit_button("🔮 Predict",use_container_width=True,type="primary")
        if sub:
            try:
                Xn=pp.transform(pd.DataFrame([inputs])); pred=bm.predict(Xn)
                pl=cn[pred[0]] if cn and pred[0]<len(cn) else str(pred[0])
                c1,c2=st.columns(2); c1.success(f"### 🎯 **{pl}**")
                if hasattr(bm,"predict_proba"):
                    probs=bm.predict_proba(Xn)[0].astype(float)
                    pf=pd.DataFrame({"Class":cn or [str(i) for i in range(len(probs))],"Probability":probs}).sort_values("Probability",ascending=True)
                    c2.plotly_chart(pd_layout(px.bar(pf,x="Probability",y="Class",orientation="h",color="Probability",color_continuous_scale=["#3182ce","#48bb78"],title="Probabilities")),use_container_width=True)
            except Exception as e: st.error(f"{e}")
    with tab2:
        tf=st.file_uploader("Upload test CSV",type=["csv","xlsx"])
        if tf:
            try:
                ext=Path(tf.name).suffix.lower()
                tdf=pd.read_csv(tf) if ext==".csv" else pd.read_excel(tf)
                st.dataframe(safe_df(tdf.head(5)),use_container_width=True)
                if st.button("🔮 Predict Batch",use_container_width=True,type="primary"):
                    Xb=pp.transform(tdf); preds=bm.predict(Xb)
                    lbls=[cn[p] if cn and p<len(cn) else str(p) for p in preds]
                    res=tdf.copy(); res["prediction"]=lbls
                    if hasattr(bm,"predict_proba"):
                        probs=bm.predict_proba(Xb).astype(float)
                        for i,c_ in enumerate(cn or range(probs.shape[1])): res[f"prob_{c_}"]=probs[:,i]
                    st.success(f"✅ {len(res):,} predictions"); st.dataframe(safe_df(res.head(20)),use_container_width=True)
                    st.download_button("⬇️ Download CSV",res.to_csv(index=False).encode(),"predictions.csv","text/csv")
            except Exception as e: st.error(f"{e}")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 10 — MODEL REGISTRY
# ══════════════════════════════════════════════════════════════════════════════
elif page=="📦 Model Registry":
    ph("📦","Model Registry","Browse all MLflow experiment runs.")
    try:
        import mlflow; from src.utils.config_loader import load_config
        cfg=load_config("config/config.yaml"); tc_=cfg.get("tracking",{}).get("mlflow",{})
        mlflow.set_tracking_uri(tc_.get("tracking_uri","mlruns"))
        exp=mlflow.get_experiment_by_name(tc_.get("experiment_name","automl_classification"))
    except Exception as e: st.error(f"MLflow: {e}"); st.stop()
    if exp is None: st.info("No experiment yet. Train first."); st.stop()
    rdf=mlflow.search_runs(experiment_ids=[exp.experiment_id],order_by=["metrics.f1_weighted DESC"],max_results=100)
    if rdf.empty: st.info("No runs yet."); st.stop()
    mc_list=[c for c in rdf.columns if c.startswith("metrics.")]
    dc=[c for c in ["tags.mlflow.runName","start_time","status"]+mc_list[:6] if c in rdf.columns]
    c1,c2,c3=st.columns(3); mc(str(len(rdf)),"Total Runs",c1)
    if "metrics.f1_weighted" in rdf.columns: mc(f"{rdf['metrics.f1_weighted'].max():.4f}","Best F1",c2)
    if "metrics.accuracy" in rdf.columns: mc(f"{rdf['metrics.accuracy'].max():.4f}","Best Acc",c3)
    st.markdown("<br>",unsafe_allow_html=True)
    t1,t2=st.tabs(["📋 All Runs","📊 Comparison"])
    with t1: st.dataframe(safe_df(rdf[dc].head(50)),use_container_width=True,height=400)
    with t2:
        avail=[c.replace("metrics.","") for c in mc_list if any(k in c for k in ["f1","accuracy","roc","precision","recall"])]
        if avail:
            sel=st.selectbox("Metric",avail); fc=f"metrics.{sel}"
            if fc in rdf.columns:
                pf=rdf[["tags.mlflow.runName",fc]].dropna(); pf.columns=["Run",sel]
                fig=px.bar(pf.sort_values(sel,ascending=True),x=sel,y="Run",orientation="h",
                           color=sel,color_continuous_scale=["#3182ce","#48bb78"],title=f"Comparison — {sel}")
                st.plotly_chart(pd_layout(fig),use_container_width=True)
