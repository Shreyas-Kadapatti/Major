"""
Experiment Tracking Module
MLflow integration for logging params, metrics, artifacts, and model registry.
"""
import os
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)

try:
    import mlflow
    import mlflow.sklearn
    from mlflow.tracking import MlflowClient
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False
    logger.warning("MLflow not available. Tracking disabled.")


class ExperimentTracker:
    """
    Handles MLflow experiment tracking: logging params, metrics, models, artifacts.
    """

    def __init__(self, config: Dict):
        self.config = config
        tracking_cfg = config.get("tracking", {}).get("mlflow", {})
        self.enabled = tracking_cfg.get("enabled", True) and MLFLOW_AVAILABLE
        self.tracking_uri = tracking_cfg.get("tracking_uri", "mlruns")
        self.experiment_name = tracking_cfg.get("experiment_name", "automl_classification")
        self.active_run = None
        self.client = None

        if self.enabled:
            mlflow.set_tracking_uri(self.tracking_uri)
            mlflow.set_experiment(self.experiment_name)
            self.client = MlflowClient()
            logger.info(f"MLflow tracking enabled. URI: {self.tracking_uri}")

    def start_run(self, run_name: Optional[str] = None) -> Optional[str]:
        """Start an MLflow run."""
        if not self.enabled:
            return None
        self.active_run = mlflow.start_run(run_name=run_name)
        logger.info(f"MLflow run started: {self.active_run.info.run_id}")
        return self.active_run.info.run_id

    def end_run(self) -> None:
        """End the active MLflow run."""
        if self.enabled and self.active_run:
            mlflow.end_run()
            logger.info("MLflow run ended.")

    def log_params(self, params: Dict) -> None:
        """Log hyperparameters."""
        if not self.enabled:
            return
        # MLflow limit: param values must be str and ≤ 500 chars
        safe = {k: str(v)[:500] for k, v in params.items()}
        mlflow.log_params(safe)

    def log_metrics(self, metrics: Dict[str, float]) -> None:
        """Log evaluation metrics."""
        if not self.enabled:
            return
        mlflow.log_metrics({k: float(v) for k, v in metrics.items() if isinstance(v, (int, float))})

    def log_model(self, model: Any, model_name: str, artifact_path: str = "model") -> None:
        """Log sklearn model artifact."""
        if not self.enabled:
            return
        try:
            mlflow.sklearn.log_model(model, artifact_path, registered_model_name=model_name)
            logger.info(f"Model '{model_name}' logged to MLflow.")
        except Exception as e:
            logger.error(f"Failed to log model '{model_name}': {e}")

    def log_artifact(self, file_path: str) -> None:
        """Log a file artifact."""
        if not self.enabled:
            return
        if Path(file_path).exists():
            mlflow.log_artifact(file_path)

    def log_dataframe(self, df: pd.DataFrame, name: str = "leaderboard.csv") -> None:
        """Log a DataFrame as CSV artifact."""
        if not self.enabled:
            return
        tmp = f"/tmp/{name}"
        df.to_csv(tmp, index=False)
        mlflow.log_artifact(tmp)

    def log_full_run(
        self,
        model_name: str,
        model: Any,
        params: Dict,
        metrics: Dict,
        tags: Optional[Dict] = None,
    ) -> Optional[str]:
        """
        Convenience: start run, log everything, end run.

        Args:
            model_name: Name tag for the run.
            model: Fitted model.
            params: Hyperparameters.
            metrics: Evaluation metrics.
            tags: Optional MLflow tags.

        Returns:
            Run ID string.
        """
        if not self.enabled:
            return None

        run_id = self.start_run(run_name=model_name)
        if tags:
            mlflow.set_tags(tags)
        self.log_params(params)
        self.log_metrics(metrics)
        self.log_model(model, model_name)
        self.end_run()
        return run_id

    def get_best_run(self, metric: str = "f1_weighted") -> Optional[Dict]:
        """
        Retrieve the best run from the experiment by metric.

        Args:
            metric: Metric name to sort by.

        Returns:
            Dictionary with run info or None.
        """
        if not self.enabled:
            return None
        try:
            experiment = mlflow.get_experiment_by_name(self.experiment_name)
            if not experiment:
                return None
            runs = mlflow.search_runs(
                experiment_ids=[experiment.experiment_id],
                order_by=[f"metrics.{metric} DESC"],
                max_results=1,
            )
            if runs.empty:
                return None
            return runs.iloc[0].to_dict()
        except Exception as e:
            logger.error(f"Failed to get best run: {e}")
            return None

    def list_runs(self, max_results: int = 50) -> Optional[pd.DataFrame]:
        """List all runs in the experiment."""
        if not self.enabled:
            return None
        try:
            experiment = mlflow.get_experiment_by_name(self.experiment_name)
            if not experiment:
                return pd.DataFrame()
            return mlflow.search_runs(
                experiment_ids=[experiment.experiment_id],
                max_results=max_results,
            )
        except Exception as e:
            logger.error(f"Failed to list runs: {e}")
            return pd.DataFrame()

    def promote_model(self, model_name: str, stage: str = "Production") -> None:
        """Promote latest model version to a registry stage."""
        if not self.enabled or not self.client:
            return
        try:
            versions = self.client.get_latest_versions(model_name)
            if versions:
                self.client.transition_model_version_stage(
                    name=model_name,
                    version=versions[-1].version,
                    stage=stage,
                )
                logger.info(f"Model '{model_name}' promoted to '{stage}'")
        except Exception as e:
            logger.error(f"Model promotion failed: {e}")
