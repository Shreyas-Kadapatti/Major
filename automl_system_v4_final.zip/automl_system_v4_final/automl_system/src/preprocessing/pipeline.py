"""
Preprocessing Pipeline Module
Builds sklearn Pipeline + ColumnTransformer for numeric and categorical features.
"""
import pickle
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    LabelEncoder,
    MinMaxScaler,
    OneHotEncoder,
    RobustScaler,
    StandardScaler,
)

from src.utils.logger import get_logger

logger = get_logger(__name__)


class PreprocessingPipeline:
    """
    Builds and applies a full feature preprocessing pipeline using
    sklearn's Pipeline and ColumnTransformer.
    """

    def __init__(self, config: Dict):
        self.config = config
        prep_cfg = config.get("preprocessing", {})
        self.numeric_imputer = prep_cfg.get("numeric_imputer", "median")
        self.categorical_imputer = prep_cfg.get("categorical_imputer", "most_frequent")
        self.scaler_type = prep_cfg.get("scaler", "standard")
        self.encoding = prep_cfg.get("encoding", "onehot")
        self.pipeline: Optional[Pipeline] = None
        self.label_encoder: Optional[LabelEncoder] = None
        self.feature_names_out: List[str] = []

    def _get_scaler(self):
        """Return scaler instance based on config."""
        scalers = {
            "standard": StandardScaler(),
            "minmax": MinMaxScaler(),
            "robust": RobustScaler(),
        }
        return scalers.get(self.scaler_type, StandardScaler())

    def build(self, numeric_cols: List[str], categorical_cols: List[str]) -> Pipeline:
        """
        Build the preprocessing pipeline.

        Args:
            numeric_cols: List of numeric feature column names.
            categorical_cols: List of categorical feature column names.

        Returns:
            Fitted-ready sklearn Pipeline.
        """
        transformers = []

        if numeric_cols:
            numeric_pipeline = Pipeline([
                ("imputer", SimpleImputer(strategy=self.numeric_imputer)),
                ("scaler", self._get_scaler()),
            ])
            transformers.append(("numeric", numeric_pipeline, numeric_cols))

        if categorical_cols:
            if self.encoding == "onehot":
                encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
            else:
                encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)

            categorical_pipeline = Pipeline([
                ("imputer", SimpleImputer(strategy=self.categorical_imputer)),
                ("encoder", encoder),
            ])
            transformers.append(("categorical", categorical_pipeline, categorical_cols))

        if not transformers:
            raise ValueError("No numeric or categorical columns provided for preprocessing.")

        preprocessor = ColumnTransformer(
            transformers=transformers,
            remainder="drop",
        )
        self.pipeline = Pipeline([("preprocessor", preprocessor)])
        logger.info(f"Preprocessing pipeline built. Numeric: {len(numeric_cols)}, Categorical: {len(categorical_cols)}")
        return self.pipeline

    def fit_transform(
        self,
        df: pd.DataFrame,
        target_col: str,
        numeric_cols: List[str],
        categorical_cols: List[str],
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Fit the pipeline and transform features. Encode target.

        Args:
            df: Input DataFrame.
            target_col: Target column name.
            numeric_cols: Numeric feature columns.
            categorical_cols: Categorical feature columns.

        Returns:
            Tuple of (X_transformed, y_encoded).
        """
        self.build(numeric_cols, categorical_cols)

        X = df.drop(columns=[target_col])
        y_raw = df[target_col]

        X_transformed = self.pipeline.fit_transform(X)

        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(y_raw)

        # Extract feature names
        try:
            col_transformer = self.pipeline.named_steps["preprocessor"]
            self.feature_names_out = list(col_transformer.get_feature_names_out())
        except Exception:
            self.feature_names_out = [f"feature_{i}" for i in range(X_transformed.shape[1])]

        logger.info(f"Fit-transform complete. X shape: {X_transformed.shape}, Classes: {list(self.label_encoder.classes_)}")
        return X_transformed, y_encoded

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """
        Transform new data using fitted pipeline.

        Args:
            df: New data DataFrame.

        Returns:
            Transformed feature array.
        """
        if self.pipeline is None:
            raise RuntimeError("Pipeline not fitted. Call fit_transform first.")
        return self.pipeline.transform(df)

    def save(self, path: str = "models/preprocessor.pkl") -> None:
        """Persist pipeline and label encoder to disk."""
        save_path = Path(path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        with open(save_path, "wb") as f:
            pickle.dump({"pipeline": self.pipeline, "label_encoder": self.label_encoder,
                         "feature_names": self.feature_names_out}, f)
        logger.info(f"Preprocessor saved to {save_path}")

    @classmethod
    def load(cls, path: str = "models/preprocessor.pkl") -> "PreprocessingPipeline":
        """Load a saved preprocessor from disk."""
        with open(path, "rb") as f:
            data = pickle.load(f)
        instance = cls.__new__(cls)
        instance.pipeline = data["pipeline"]
        instance.label_encoder = data["label_encoder"]
        instance.feature_names_out = data.get("feature_names", [])
        logger.info(f"Preprocessor loaded from {path}")
        return instance
