# AutoML Classification System v2.0
## React + FastAPI Architecture

Hypothesis-driven AutoML with a professional React dashboard.

---

## Quick Start (Development)

### 1. Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn api.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```
Dashboard: http://localhost:5173

---

## Docker (Production)
```bash
docker-compose up --build
```
- Dashboard: http://localhost:5173
- API:       http://localhost:8000
- MLflow:    http://localhost:5000

---

## API Endpoints

| Method | Path              | Description                        |
|--------|-------------------|------------------------------------|
| POST   | /upload-data      | Upload CSV/Excel dataset           |
| POST   | /run-pipeline     | Start AutoML pipeline              |
| GET    | /pipeline-status  | Poll training progress             |
| GET    | /hypothesis       | Hypothesis test results            |
| GET    | /models           | Leaderboard + model info           |
| GET    | /comparison       | McNemar comparison results         |
| POST   | /drift            | Drift detection on new data        |
| POST   | /predict          | Single-row prediction              |
| POST   | /batch-predict    | CSV batch prediction               |
| GET    | /predict/schema   | Feature schema for prediction form |
| GET    | /health           | Health check                       |

---

## Pipeline Order
1. Data Ingestion (minimal filtering — no weak feature drops)
2. Hypothesis Testing (Pearson / Chi-square / ANOVA)
3. Feature Engineering (auto-triggered if < threshold significant)
4. Re-run Hypothesis Testing
5. Feature Selection (significant features only)
6. Configuration + Leakage Detection
7. Training with Stratified K-Fold CV
8. Evaluation
9. McNemar Test (post-training)
10. MLflow Logging (internal only — not exposed in UI)

---

## Navigation
| Page          | Route            |
|---------------|------------------|
| Data          | /data            |
| Hypothesis    | /hypothesis      |
| Configuration | /configuration   |
| Training      | /training        |
| Evaluation    | /evaluation      |
| Predictions   | /predictions     |
| Monitoring    | /monitoring      |

---

## SR 11-7 Compliance
- No auto-retraining on drift
- Alert-only monitoring
- PSI + KS drift detection
- Human review policy enforced in UI
