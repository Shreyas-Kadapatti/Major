"""
Feature Engineering Engine
Auto-triggered when the Hypothesis Engine finds too few significant features.

Techniques:
  - Interaction features  (f1 * f2, f1 / f2)
  - Polynomial features   (squared terms)
  - Log / sqrt transforms
  - Encoding improvements (one-hot, target encoding)
  - Binning of continuous variables
"""

import warnings
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import KBinsDiscretizer

from src.utils.logger import get_logger

warnings.filterwarnings("ignore")
logger = get_logger(__name__)


class FeatureEngineeringEngine:
    """
    Generates new features from existing ones.
    Designed to be called ONLY when the HypothesisEngine indicates
    that too few features are statistically significant.

    Args:
        config: Pipeline config dict.
        top_n_interactions: Number of top numeric columns to use for pairwise interactions.
        n_bins: Bins for continuous variable discretisation.
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        top_n_interactions: int = 5,
        n_bins: int = 4,
    ):
        self.config = config or {}
        self.top_n_interactions = top_n_interactions
        self.n_bins = n_bins
        self.new_feature_names: List[str] = []
        self.applied_techniques: List[str] = []

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _add_interactions(
        self, df: pd.DataFrame, numeric_cols: List[str]
    ) -> pd.DataFrame:
        """Add pairwise product and ratio features."""
        cols = numeric_cols[: self.top_n_interactions]
        added = []
        for i in range(len(cols)):
            for j in range(i + 1, len(cols)):
                c1, c2 = cols[i], cols[j]
                prod_name = f"{c1}_x_{c2}"
                df[prod_name] = df[c1] * df[c2]
                added.append(prod_name)
                # ratio — guard against zero division
                div_name = f"{c1}_div_{c2}"
                df[div_name] = df[c1] / (df[c2].replace(0, np.nan))
                df[div_name].fillna(0, inplace=True)
                added.append(div_name)
        if added:
            logger.info(f"  [FE] Interactions added: {len(added)} features")
            self.new_feature_names.extend(added)
            self.applied_techniques.append("interaction_features")
        return df

    def _add_polynomial(
        self, df: pd.DataFrame, numeric_cols: List[str]
    ) -> pd.DataFrame:
        """Add squared terms for numeric columns."""
        cols = numeric_cols[: self.top_n_interactions]
        added = []
        for col in cols:
            name = f"{col}_sq"
            df[name] = df[col] ** 2
            added.append(name)
        if added:
            logger.info(f"  [FE] Polynomial features added: {len(added)}")
            self.new_feature_names.extend(added)
            self.applied_techniques.append("polynomial_features")
        return df

    def _add_transforms(
        self, df: pd.DataFrame, numeric_cols: List[str]
    ) -> pd.DataFrame:
        """Add log1p and sqrt transforms for non-negative columns."""
        added = []
        for col in numeric_cols:
            if (df[col].dropna() >= 0).all():
                log_name = f"{col}_log1p"
                df[log_name] = np.log1p(df[col])
                added.append(log_name)
                sqrt_name = f"{col}_sqrt"
                df[sqrt_name] = np.sqrt(df[col])
                added.append(sqrt_name)
        if added:
            logger.info(f"  [FE] Transform features added: {len(added)}")
            self.new_feature_names.extend(added)
            self.applied_techniques.append("log_sqrt_transforms")
        return df

    def _add_binning(
        self, df: pd.DataFrame, numeric_cols: List[str]
    ) -> pd.DataFrame:
        """Bin continuous numeric columns into equal-frequency bins."""
        added = []
        binner = KBinsDiscretizer(
            n_bins=self.n_bins, encode="ordinal", strategy="quantile"
        )
        for col in numeric_cols[: self.top_n_interactions]:
            try:
                bin_name = f"{col}_bin"
                vals = df[[col]].fillna(df[col].median())
                df[bin_name] = binner.fit_transform(vals).astype(int).ravel()
                added.append(bin_name)
            except Exception as e:
                logger.warning(f"  [FE] Binning failed for {col}: {e}")
        if added:
            logger.info(f"  [FE] Binned features added: {len(added)}")
            self.new_feature_names.extend(added)
            self.applied_techniques.append("binning")
        return df

    def _add_target_encoding(
        self,
        df: pd.DataFrame,
        categorical_cols: List[str],
        target: pd.Series,
    ) -> pd.DataFrame:
        """Mean target encoding for categorical features."""
        added = []
        for col in categorical_cols:
            try:
                enc_name = f"{col}_target_enc"
                means = target.groupby(df[col]).mean()
                df[enc_name] = df[col].map(means).fillna(target.mean())
                added.append(enc_name)
            except Exception as e:
                logger.warning(f"  [FE] Target encoding failed for {col}: {e}")
        if added:
            logger.info(f"  [FE] Target-encoded features added: {len(added)}")
            self.new_feature_names.extend(added)
            self.applied_techniques.append("target_encoding")
        return df

    # ── Public API ────────────────────────────────────────────────────────────

    def run(
        self,
        df: pd.DataFrame,
        target_col: str,
        numeric_cols: Optional[List[str]] = None,
        categorical_cols: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """
        Generate new features and return augmented DataFrame.

        Args:
            df:               Input DataFrame including the target column.
            target_col:       Name of the target column.
            numeric_cols:     Numeric feature names (auto-detected if None).
            categorical_cols: Categorical feature names (auto-detected if None).

        Returns:
            Augmented DataFrame with original + new features.
        """
        logger.info("=== Feature Engineering Engine: Generating New Features ===")

        target = df[target_col].copy()
        feature_df = df.drop(columns=[target_col]).copy()

        # Auto-detect types
        if numeric_cols is None:
            numeric_cols = [
                c for c in feature_df.columns
                if pd.api.types.is_numeric_dtype(feature_df[c])
            ]
        if categorical_cols is None:
            categorical_cols = [
                c for c in feature_df.columns
                if c not in numeric_cols
            ]

        self.new_feature_names = []
        self.applied_techniques = []

        feature_df = self._add_interactions(feature_df, numeric_cols)
        feature_df = self._add_polynomial(feature_df, numeric_cols)
        feature_df = self._add_transforms(feature_df, numeric_cols)
        feature_df = self._add_binning(feature_df, numeric_cols)
        if categorical_cols:
            feature_df = self._add_target_encoding(
                feature_df, categorical_cols, target
            )

        result = pd.concat([feature_df, target], axis=1)

        logger.info(
            f"Feature Engineering complete: "
            f"{len(self.new_feature_names)} new features created. "
            f"Techniques: {self.applied_techniques}"
        )
        return result

    def get_summary(self) -> Dict:
        return {
            "new_features": self.new_feature_names,
            "n_new_features": len(self.new_feature_names),
            "techniques_applied": self.applied_techniques,
        }
