"""
MLflow Logging Service — INTERNAL ONLY
All MLflow interactions are encapsulated here.
The main pipeline and UI must NEVER call mlflow directly.

Logs:
  - Parameters (model configs, hypothesis config)
  - Metrics (CV scores, evaluation metrics, McNemar results)
  - Artifacts (models, JSON reports, leaderboards)
  - Dataset lineage
"""

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from src.utils.logger import get_logger

_log = get_logger(__name__)

try:
    import mlflow
    import mlflow.sklearn
    from mlflow.tracking import MlflowClient
    _MLFLOW_OK = True
except ImportError:
    _MLFLOW_OK = False
    _log.warning("MLflow not installed — logging disabled.")


class MLflowLogger:
    """
    Internal MLflow logging service.

    This class is the single gateway to MLflow in the entire system.
    Nothing outside this module should import mlflow directly.

    Args:
        config: Pipeline config dict (must have tracking.mlflow section).
    """

    def __init__(self, config: Dict):
        tracking_cfg = config.get("tracking", {}).get("mlflow", {})
        self.enabled = tracking_cfg.get("enabled", True) and _MLFLOW_OK
        self.tracking_uri = tracking_cfg.get("tracking_uri", "mlruns")
        self.experiment_name = tracking_cfg.get(
            "experiment_name", "automl_classification"
        )
        self._active_run_id: Optional[str] = None
        self._client: Optional[Any] = None

        if self.enabled:
            mlflow.set_tracking_uri(self.tracking_uri)
            mlflow.set_experiment(self.experiment_name)
            self._client = MlflowClient()
            _log.info(
                f"[MLflowLogger] Tracking enabled → "
                f"URI={self.tracking_uri}  experiment={self.experiment_name}"
            )

    # ── Run lifecycle ─────────────────────────────────────────────────────────

    def start_run(self, run_name: Optional[str] = None) -> Optional[str]:
        if not self.enabled:
            return None
        run = mlflow.start_run(run_name=run_name)
        self._active_run_id = run.info.run_id
        _log.info(f"[MLflowLogger] Run started: {self._active_run_id}")
        return self._active_run_id

    def end_run(self) -> None:
        if self.enabled and self._active_run_id:
            mlflow.end_run()
            _log.info(f"[MLflowLogger] Run ended: {self._active_run_id}")
            self._active_run_id = None

    # ── Logging primitives ────────────────────────────────────────────────────

    def log_params(self, params: Dict) -> None:
        if not self.enabled:
            return
        safe = {k: str(v)[:500] for k, v in params.items()}
        mlflow.log_params(safe)

    def log_metrics(self, metrics: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        safe = {
            k: float(v)
            for k, v in metrics.items()
            if isinstance(v, (int, float)) and not (
                isinstance(v, float) and (v != v)  # NaN guard
            )
        }
        if safe:
            mlflow.log_metrics(safe)

    def log_tags(self, tags: Dict[str, str]) -> None:
        if not self.enabled:
            return
        mlflow.set_tags({k: str(v) for k, v in tags.items()})

    def log_model(
        self,
        model: Any,
        model_name: str,
        artifact_path: str = "model",
    ) -> None:
        if not self.enabled:
            return
        try:
            mlflow.sklearn.log_model(
                model,
                artifact_path=artifact_path,
                registered_model_name=model_name,
            )
            _log.info(f"[MLflowLogger] Model '{model_name}' registered.")
        except Exception as exc:
            _log.error(f"[MLflowLogger] log_model failed for '{model_name}': {exc}")

    def log_dict_as_artifact(self, data: Dict, filename: str) -> None:
        """Serialise a dict to JSON and log as artifact."""
        if not self.enabled:
            return
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".json", delete=False
            ) as fh:
                json.dump(data, fh, indent=2, default=str)
                tmp_path = fh.name
            mlflow.log_artifact(tmp_path, artifact_path="reports")
            os.unlink(tmp_path)
        except Exception as exc:
            _log.error(f"[MLflowLogger] log_dict_as_artifact failed: {exc}")

    def log_dataframe_as_artifact(self, df: pd.DataFrame, filename: str) -> None:
        """Save a DataFrame as CSV and log as artifact."""
        if not self.enabled:
            return
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".csv", delete=False
            ) as fh:
                df.to_csv(fh, index=False)
                tmp_path = fh.name
            mlflow.log_artifact(tmp_path, artifact_path="reports")
            os.unlink(tmp_path)
        except Exception as exc:
            _log.error(f"[MLflowLogger] log_dataframe_as_artifact failed: {exc}")

    def log_file_artifact(self, file_path: str) -> None:
        if not self.enabled:
            return
        if Path(file_path).exists():
            mlflow.log_artifact(file_path)

    def log_dataset(self, df: pd.DataFrame, source_name: str) -> None:
        """Log MLflow dataset lineage."""
        if not self.enabled:
            return
        try:
            dataset = mlflow.data.from_pandas(
                df, name="automl_training_dataset", source=source_name
            )
            mlflow.log_input(dataset, context="training")
        except Exception as exc:
            _log.warning(f"[MLflowLogger] Dataset logging failed: {exc}")

    # ── High-level convenience methods ────────────────────────────────────────

    def log_hypothesis_results(self, report: Dict) -> None:
        """Log hypothesis engine output as params + artifact."""
        if not self.enabled:
            return
        params = {
            "hypothesis_alpha":          report.get("alpha", 0.05),
            "hypothesis_n_total":        report.get("n_features_total", 0),
            "hypothesis_n_significant":  report.get("n_significant", 0),
            "hypothesis_ratio":          report.get("significant_ratio", 0.0),
            "fe_triggered":              report.get("trigger_feature_engineering", False),
        }
        self.log_params(params)
        self.log_dict_as_artifact(report, "hypothesis_report.json")
        _log.info("[MLflowLogger] Hypothesis results logged.")

    def log_feature_engineering_summary(self, fe_summary: Dict) -> None:
        """Log feature engineering summary as params + artifact."""
        if not self.enabled:
            return
        params = {
            "fe_n_new_features":  fe_summary.get("n_new_features", 0),
            "fe_techniques":      ", ".join(fe_summary.get("techniques_applied", [])),
        }
        self.log_params(params)
        self.log_dict_as_artifact(fe_summary, "feature_engineering_summary.json")
        _log.info("[MLflowLogger] Feature engineering summary logged.")

    def log_model_run(
        self,
        model_name: str,
        model: Any,
        params: Dict,
        metrics: Dict,
        tags: Optional[Dict] = None,
        df: Optional[pd.DataFrame] = None,
        source_name: str = "dataset",
    ) -> Optional[str]:
        """
        Full model run: start → log dataset → params → metrics → model → end.

        Args:
            model_name:  Used as run name and registered model name.
            model:       Fitted sklearn-compatible model.
            params:      Hyperparameters.
            metrics:     Evaluation metrics dict.
            tags:        Optional MLflow tags.
            df:          Training DataFrame for dataset lineage (optional).
            source_name: Dataset source name for lineage.

        Returns:
            Run ID or None.
        """
        if not self.enabled:
            return None

        run_id = self.start_run(run_name=model_name)
        try:
            if tags:
                self.log_tags(tags)
            if df is not None:
                self.log_dataset(df, source_name)
            self.log_params(params)
            self.log_metrics(metrics)
            self.log_model(model, model_name)
        finally:
            self.end_run()

        return run_id

    def log_mcnemar_results(self, comparison_results: Dict) -> None:
        """Log McNemar test results as metrics + artifact."""
        if not self.enabled:
            return
        pairwise = comparison_results.get("pairwise", [])
        for res in pairwise:
            key = f"{res.get('model_a','A')}_vs_{res.get('model_b','B')}"
            self.log_metrics({
                f"mcnemar_{key}_stat":   res.get("statistic", 0.0),
                f"mcnemar_{key}_pvalue": res.get("p_value", 1.0),
            })
        self.log_dict_as_artifact(
            {k: v for k, v in comparison_results.items() if k != "summary"},
            "mcnemar_results.json",
        )
        _log.info("[MLflowLogger] McNemar results logged.")

    # ── Query helpers (used by dashboard backend) ─────────────────────────────

    def list_runs(self, max_results: int = 50) -> pd.DataFrame:
        """Return DataFrame of all experiment runs (for dashboard)."""
        if not self.enabled:
            return pd.DataFrame()
        try:
            experiment = mlflow.get_experiment_by_name(self.experiment_name)
            if not experiment:
                return pd.DataFrame()
            return mlflow.search_runs(
                experiment_ids=[experiment.experiment_id],
                max_results=max_results,
            )
        except Exception as exc:
            _log.error(f"[MLflowLogger] list_runs failed: {exc}")
            return pd.DataFrame()

    def get_best_run(self, metric: str = "f1_weighted") -> Optional[Dict]:
        """Return the best run dict by a given metric."""
        if not self.enabled:
            return None
        try:
            experiment = mlflow.get_experiment_by_name(self.experiment_name)
            if not experiment:
                return None
            runs = mlflow.search_runs(
                experiment_ids=[experiment.experiment_id],
                order_by=[f"metrics.{metric} DESC"],
                max_results=1,
            )
            if runs.empty:
                return None
            return runs.iloc[0].to_dict()
        except Exception as exc:
            _log.error(f"[MLflowLogger] get_best_run failed: {exc}")
            return None

    def promote_to_production(self, model_name: str) -> None:
        """Promote the latest version of a registered model to Production."""
        if not self.enabled or not self._client:
            return
        try:
            versions = self._client.get_latest_versions(model_name)
            if versions:
                self._client.transition_model_version_stage(
                    name=model_name,
                    version=versions[-1].version,
                    stage="Production",
                )
                _log.info(
                    f"[MLflowLogger] '{model_name}' v{versions[-1].version} → Production"
                )
        except Exception as exc:
            _log.error(f"[MLflowLogger] promote_to_production failed: {exc}")
