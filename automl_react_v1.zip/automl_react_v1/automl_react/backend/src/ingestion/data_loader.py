"""
Data Ingestion Module
Handles loading, validation, and initial profiling of datasets.
"""
import os
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


class DataIngestion:
    """
    Handles data loading from multiple formats, type detection,
    deduplication, and dataset summary generation.
    """

    SUPPORTED_FORMATS = {".csv", ".xlsx", ".xls", ".parquet"}

    def __init__(self, config: Dict):
        self.config = config
        self.raw_path = Path(config.get("data", {}).get("raw_path", "data/raw"))
        self.processed_path = Path(config.get("data", {}).get("processed_path", "data/processed"))
        self.processed_path.mkdir(parents=True, exist_ok=True)

    def load(self, file_path: str) -> pd.DataFrame:
        """
        Load dataset from CSV, Excel, or Parquet.

        Args:
            file_path: Path to the dataset file.

        Returns:
            Loaded DataFrame.
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Dataset not found: {file_path}")

        suffix = path.suffix.lower()
        if suffix not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Unsupported format: {suffix}. Supported: {self.SUPPORTED_FORMATS}")

        logger.info(f"Loading dataset from: {file_path}")

        if suffix == ".csv":
            df = pd.read_csv(file_path)
        elif suffix in {".xlsx", ".xls"}:
            df = pd.read_excel(file_path)
        elif suffix == ".parquet":
            df = pd.read_parquet(file_path)

        logger.info(f"Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns")
        return df

    def validate(self, df: pd.DataFrame, target_col: str) -> pd.DataFrame:
        """
        Validate and clean dataset: remove duplicates, check target column.

        Args:
            df: Input DataFrame.
            target_col: Name of the target column.

        Returns:
            Validated and cleaned DataFrame.
        """
        if target_col not in df.columns:
            raise ValueError(f"Target column '{target_col}' not found in dataset.")

        original_shape = df.shape

        # Remove duplicate rows
        df = df.drop_duplicates()
        dropped = original_shape[0] - df.shape[0]
        if dropped > 0:
            logger.info(f"Removed {dropped} duplicate rows.")

        # Drop rows where target is null
        null_target = df[target_col].isnull().sum()
        if null_target > 0:
            df = df.dropna(subset=[target_col])
            logger.warning(f"Dropped {null_target} rows with null target values.")

        logger.info(f"Validated dataset shape: {df.shape}")
        return df

    def detect_column_types(self, df: pd.DataFrame, target_col: str) -> Dict[str, list]:
        """
        Auto-detect numeric, categorical, and text columns.

        Args:
            df: Input DataFrame.
            target_col: Name of target column to exclude.

        Returns:
            Dictionary with keys: numeric, categorical, text, datetime.
        """
        feature_cols = [c for c in df.columns if c != target_col]
        col_types: Dict[str, list] = {
            "numeric": [],
            "categorical": [],
            "text": [],
            "datetime": [],
        }

        # ID-like column detection: high cardinality or name heuristic → drop
        _id_keywords = {"id", "uuid", "guid", "key", "rowid", "row_id", "index",
                        "record_id", "customer_id", "user_id", "order_id", "transaction_id"}
        id_cols = []

        for col in feature_cols:
            dtype    = df[col].dtype
            n_unique = df[col].nunique()
            col_lower = col.lower().replace("-", "_").replace(" ", "_")
            n_rows    = len(df)

            # Heuristic 1: column name is or ends with a known ID keyword
            is_id_name = (
                col_lower in _id_keywords
                or any(col_lower == kw or col_lower.endswith(f"_{kw}") for kw in _id_keywords)
            )
            # Heuristic 2: near-unique NON-NUMERIC values (>90% unique) → useless string ID
            # CRITICAL: Do NOT drop weak numeric features — Feature Engineering can use them
            is_string_high_cardinality = (
                not pd.api.types.is_numeric_dtype(df[col])
                and (n_unique / max(n_rows, 1)) > 0.90
            )
            # Heuristic 3: constant / near-constant columns (zero variance)
            is_constant = n_unique <= 1

            if is_id_name or is_string_high_cardinality or is_constant:
                id_cols.append(col)
                col_types.setdefault("id", []).append(col)
                continue  # skip further classification

            if pd.api.types.is_datetime64_any_dtype(dtype):
                col_types["datetime"].append(col)
            elif pd.api.types.is_numeric_dtype(dtype):
                col_types["numeric"].append(col)
            elif pd.api.types.is_object_dtype(dtype):
                avg_len = df[col].dropna().astype(str).str.len().mean()
                if avg_len > 50 or n_unique / max(n_rows, 1) > 0.8:
                    col_types["text"].append(col)
                else:
                    col_types["categorical"].append(col)
            else:
                col_types["categorical"].append(col)

        if id_cols:
            logger.info(f"ID/high-cardinality columns detected and excluded: {id_cols}")
        logger.info(f"Column types detected: { {k: len(v) for k, v in col_types.items()} }")

        # Safety guard: ensure at least one usable feature remains
        usable_features = (
            col_types.get("numeric", []) +
            col_types.get("categorical", []) +
            col_types.get("text", []) +
            col_types.get("datetime", [])
        )
        if len(usable_features) == 0:
            raise ValueError(
                "No usable features after ingestion — check data pipeline. "
                "All columns were classified as ID/constant or no feature columns exist."
            )

        return col_types

    def profile(self, df: pd.DataFrame) -> Dict:
        """
        Generate a dataset summary/profile.

        Args:
            df: Input DataFrame.

        Returns:
            Dictionary containing dataset statistics.
        """
        profile = {
            "shape": df.shape,
            "dtypes": df.dtypes.astype(str).to_dict(),
            "missing_values": df.isnull().sum().to_dict(),
            "missing_pct": (df.isnull().mean() * 100).round(2).to_dict(),
            "unique_counts": df.nunique().to_dict(),
            "numeric_stats": df.describe().to_dict(),
        }

        logger.info("Dataset profile generated.")
        logger.info(f"  Shape: {profile['shape']}")
        logger.info(f"  Total missing: {df.isnull().sum().sum()}")

        return profile

    def run(
        self, file_path: str, target_col: str
    ) -> Tuple[pd.DataFrame, Dict[str, list], Dict]:
        """
        Full ingestion pipeline: load → validate → detect types → profile.

        Args:
            file_path: Path to dataset file.
            target_col: Target column name.

        Returns:
            Tuple of (DataFrame, column_types, profile).
        """
        df = self.load(file_path)
        df = self.validate(df, target_col)
        col_types = self.detect_column_types(df, target_col)
        profile = self.profile(df)
        return df, col_types, profile
