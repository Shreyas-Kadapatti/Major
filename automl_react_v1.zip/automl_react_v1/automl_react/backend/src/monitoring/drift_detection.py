"""
Drift Detection Module — Post-Deployment Monitoring (SR 11-7 Aligned)
======================================================================

Runs AFTER deployment, NOT during training.

Methods:
  - PSI  (Population Stability Index) for numeric features
  - KS   (Kolmogorov-Smirnov test)     for numeric features
  - Chi-square                          for categorical features

Output:
    {
        "drift_status":    "OK | WARNING | CRITICAL",
        "drifted_features": [...],
        "severity_scores":  {...},
        "recommendation":  "monitor | retrain",
        "feature_details": {...},
    }

POLICY:
  - DO NOT auto-retrain
  - Only alert and recommend
"""

import warnings
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")

try:
    from src.utils.logger import get_logger
    logger = get_logger(__name__)
except Exception:
    import logging
    logger = logging.getLogger(__name__)


# ── PSI helpers ───────────────────────────────────────────────────────────────

def _compute_psi(reference: np.ndarray, current: np.ndarray, n_bins: int = 10) -> float:
    """
    Compute Population Stability Index between reference and current distributions.

    PSI interpretation:
        < 0.10  — stable (no drift)
        0.10–0.25 — slight drift (monitor)
        > 0.25  — significant drift (retrain candidate)
    """
    # Use reference percentile edges so bins are consistent
    quantiles = np.linspace(0, 100, n_bins + 1)
    bin_edges = np.percentile(reference, quantiles)
    bin_edges = np.unique(bin_edges)  # remove duplicates

    if len(bin_edges) < 2:
        return 0.0  # degenerate distribution

    ref_counts, _ = np.histogram(reference, bins=bin_edges)
    cur_counts, _ = np.histogram(current, bins=bin_edges)

    # Avoid division by zero / log(0) with small epsilon
    ref_pct = (ref_counts + 1e-9) / (len(reference) + 1e-9 * len(ref_counts))
    cur_pct = (cur_counts + 1e-9) / (len(current) + 1e-9 * len(cur_counts))

    psi = float(np.sum((cur_pct - ref_pct) * np.log(cur_pct / ref_pct)))
    return round(psi, 6)


def _psi_severity(psi: float) -> str:
    if psi < 0.10:
        return "OK"
    if psi < 0.25:
        return "WARNING"
    return "CRITICAL"


# ── Main class ────────────────────────────────────────────────────────────────

class DriftDetectionEngine:
    """
    Post-deployment drift detector.

    Usage:
        engine = DriftDetectionEngine()
        engine.fit(training_df)                   # called once after training
        report = engine.detect(new_production_df) # called post-deployment
    """

    PSI_WARN     = 0.10
    PSI_CRITICAL = 0.25

    def __init__(self, significance_level: float = 0.05, n_bins: int = 10):
        self.significance_level = significance_level
        self.n_bins = n_bins
        self._reference: Dict[str, Dict] = {}
        self.last_report: Dict = {}

    # ── Fit ──────────────────────────────────────────────────────────────────

    def fit(self, df: pd.DataFrame) -> None:
        """
        Store training baseline statistics.

        Args:
            df: Training / reference DataFrame (feature columns only, no target).
        """
        self._reference = {}
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                vals = df[col].dropna().values.astype(float)
                self._reference[col] = {
                    "type":   "numeric",
                    "values": vals,
                    "mean":   float(np.mean(vals)),
                    "std":    float(np.std(vals)),
                    "min":    float(np.min(vals)) if len(vals) else 0.0,
                    "max":    float(np.max(vals)) if len(vals) else 0.0,
                }
            else:
                vc = df[col].value_counts(normalize=True)
                self._reference[col] = {
                    "type":         "categorical",
                    "distribution": vc.to_dict(),
                    "categories":   set(df[col].dropna().unique()),
                }
        logger.info(
            f"DriftDetectionEngine fitted: {len(df):,} rows, {len(self._reference)} features."
        )

    # ── Detect ────────────────────────────────────────────────────────────────

    def detect(self, df_new: pd.DataFrame) -> Dict:
        """
        Compare new production data against the training baseline.

        Args:
            df_new: New / production DataFrame (feature columns).

        Returns:
            Structured drift report dict.
        """
        if not self._reference:
            raise RuntimeError("Call fit() before detect().")

        feature_details: Dict[str, Dict] = {}
        severity_scores: Dict[str, float] = {}
        drifted_features: List[str] = []

        for col in df_new.columns:
            if col not in self._reference:
                continue

            ref  = self._reference[col]
            new_vals = df_new[col].dropna()

            if ref["type"] == "numeric":
                new_arr = new_vals.values.astype(float)
                if len(new_arr) == 0:
                    continue

                psi = _compute_psi(ref["values"], new_arr, n_bins=self.n_bins)
                ks_stat, ks_p = stats.ks_2samp(ref["values"], new_arr)
                sev = _psi_severity(psi)
                drifted = sev != "OK"

                feature_details[col] = {
                    "type":       "numeric",
                    "psi":        psi,
                    "psi_status": sev,
                    "ks_stat":    round(float(ks_stat), 6),
                    "ks_p_value": round(float(ks_p), 6),
                    "ks_drifted": bool(ks_p < self.significance_level),
                    "ref_mean":   ref["mean"],
                    "new_mean":   float(np.mean(new_arr)),
                    "ref_std":    ref["std"],
                    "new_std":    float(np.std(new_arr)),
                    "drifted":    drifted,
                }
                severity_scores[col] = psi

            else:  # categorical
                new_cats = set(new_vals.unique())
                unseen   = new_cats - ref["categories"]
                new_dist = new_vals.value_counts(normalize=True)
                ref_dist = pd.Series(ref["distribution"])
                all_cats = list(ref["categories"] | new_cats)
                ref_c    = np.array([ref_dist.get(c, 1e-9) for c in all_cats])
                new_c    = np.array([new_dist.get(c, 1e-9) for c in all_cats])

                try:
                    chi2_s, chi2_p = stats.chisquare(new_c, f_exp=ref_c)
                except Exception:
                    chi2_s, chi2_p = 0.0, 1.0

                drifted = bool(chi2_p < self.significance_level) or len(unseen) > 0
                sev = "CRITICAL" if len(unseen) > 0 else ("WARNING" if drifted else "OK")
                # Approximate PSI-like score for categorical using JS divergence
                psi_approx = float(np.sum(np.abs(new_c - ref_c)))
                feature_details[col] = {
                    "type":              "categorical",
                    "chi2_stat":         round(float(chi2_s), 6),
                    "chi2_p_value":      round(float(chi2_p), 6),
                    "unseen_categories": list(unseen),
                    "psi_approx":        round(psi_approx, 6),
                    "psi_status":        sev,
                    "drifted":           drifted,
                }
                severity_scores[col] = psi_approx

            if feature_details[col]["drifted"]:
                drifted_features.append(col)

        # ── Overall status ─────────────────────────────────────────────────
        n_total   = len(feature_details)
        n_drifted = len(drifted_features)
        drift_pct = n_drifted / n_total if n_total > 0 else 0.0

        critical_features = [
            c for c, d in feature_details.items()
            if d.get("psi_status") == "CRITICAL"
        ]
        warning_features = [
            c for c, d in feature_details.items()
            if d.get("psi_status") == "WARNING"
        ]

        if critical_features or drift_pct > 0.5:
            drift_status = "CRITICAL"
            recommendation = "retrain"
        elif warning_features or drift_pct > 0.2:
            drift_status = "WARNING"
            recommendation = "monitor"
        else:
            drift_status = "OK"
            recommendation = "monitor"

        report = {
            "drift_status":      drift_status,
            "drifted_features":  drifted_features,
            "critical_features": critical_features,
            "warning_features":  warning_features,
            "severity_scores":   severity_scores,
            "recommendation":    recommendation,
            "feature_details":   feature_details,
            "n_features_checked": n_total,
            "n_drifted":          n_drifted,
            "drift_pct":          round(drift_pct, 4),
            "note": (
                "Drift detected — review before next deployment cycle. "
                "DO NOT auto-retrain without human review (SR 11-7)."
            ) if drift_status != "OK" else "No significant drift detected.",
        }

        # Log summary
        if drift_status == "CRITICAL":
            logger.warning(
                f"CRITICAL DRIFT: {n_drifted}/{n_total} features drifted. "
                f"Recommendation: {recommendation}"
            )
        elif drift_status == "WARNING":
            logger.warning(
                f"WARNING DRIFT: {n_drifted}/{n_total} features show moderate drift."
            )
        else:
            logger.info(f"No significant drift detected. {n_drifted}/{n_total} features affected.")

        self.last_report = report
        return report

    def summary_dataframe(self) -> pd.DataFrame:
        """Return per-feature drift report as a tidy DataFrame."""
        rows = []
        for col, d in self.last_report.get("feature_details", {}).items():
            row = {
                "feature":    col,
                "type":       d.get("type"),
                "psi_status": d.get("psi_status"),
                "drifted":    d.get("drifted"),
            }
            if d.get("type") == "numeric":
                row["psi"]        = d.get("psi")
                row["ks_p_value"] = d.get("ks_p_value")
                row["ref_mean"]   = d.get("ref_mean")
                row["new_mean"]   = d.get("new_mean")
            else:
                row["chi2_p_value"] = d.get("chi2_p_value")
                row["unseen_cats"]  = len(d.get("unseen_categories", []))
            rows.append(row)
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).sort_values("drifted", ascending=False)
