"""
Dynamic Configuration Manager
Builds pipeline configuration AFTER hypothesis testing, using only
statistically significant features.
"""

import copy
from typing import Any, Dict, List, Optional

from src.utils.logger import get_logger

logger = get_logger(__name__)

# Default model pool available for dynamic selection
DEFAULT_MODEL_POOL = [
    "logistic_regression",
    "random_forest",
    "gradient_boosting",
    "decision_tree",
    "knn",
    "extra_trees",
]

# Default hyperparameter search spaces per model
DEFAULT_HYPERPARAMS: Dict[str, Dict] = {
    "logistic_regression": {"C": 1.0, "max_iter": 1000, "solver": "lbfgs"},
    "random_forest":       {"n_estimators": 100, "max_depth": None, "random_state": 42},
    "gradient_boosting":   {"n_estimators": 100, "learning_rate": 0.1, "max_depth": 3},
    "decision_tree":       {"max_depth": None, "random_state": 42},
    "knn":                 {"n_neighbors": 5, "weights": "uniform"},
    "extra_trees":         {"n_estimators": 100, "random_state": 42},
}


class ConfigManager:
    """
    Builds a dynamic pipeline configuration that respects:
      - only statistically significant features (from HypothesisEngine output)
      - user-supplied base config (config.yaml values)
      - toggles for each pipeline stage

    Args:
        base_config: The raw YAML-loaded config dict.
    """

    def __init__(self, base_config: Dict):
        self.base_config = copy.deepcopy(base_config)
        self.dynamic_config: Dict = {}

    def build(
        self,
        significant_features: List[str],
        hypothesis_report: Optional[Dict] = None,
        model_override: Optional[List[str]] = None,
    ) -> Dict:
        """
        Construct the dynamic pipeline config.

        Args:
            significant_features: Feature names selected by HypothesisEngine.
            hypothesis_report:    Full report dict from HypothesisEngine (optional).
            model_override:       If supplied, use these model names instead of defaults.

        Returns:
            Dynamic config dict used by downstream pipeline stages.
        """
        logger.info("=== Config Manager: Building Dynamic Configuration ===")

        if not significant_features:
            logger.warning(
                "No significant features supplied to ConfigManager — "
                "falling back to ALL features from base config."
            )

        # ── Feature selection ─────────────────────────────────────────────
        selected_features = significant_features if significant_features else None

        # ── Model selection ───────────────────────────────────────────────
        base_models = self.base_config.get("models", {}).get("enabled", DEFAULT_MODEL_POOL)
        models_to_train = model_override if model_override else base_models

        # ── Cross-validation strategy ─────────────────────────────────────
        cv_folds = self.base_config.get("models", {}).get("cross_validation_folds", 5)
        random_state = self.base_config.get("project", {}).get("random_state", 42)

        # ── Hyperparameters ───────────────────────────────────────────────
        hyperparams: Dict[str, Dict] = {}
        for m in models_to_train:
            hyperparams[m] = copy.deepcopy(DEFAULT_HYPERPARAMS.get(m, {}))

        # ── Pipeline toggles ──────────────────────────────────────────────
        toggles = {
            "enable_hypothesis_testing":   True,
            "enable_feature_engineering":  True,
            "enable_mcnemar_test":         True,
            "enable_tuning":               self.base_config.get("tuning", {}).get("enabled", True),
            "enable_shap":                 self.base_config.get("explainability", {}).get("shap_enabled", True),
        }

        # ── Assemble ──────────────────────────────────────────────────────
        self.dynamic_config = {
            "selected_features": selected_features,
            "n_significant_features": len(significant_features),
            "models": models_to_train,
            "hyperparams": hyperparams,
            "cv": {
                "strategy": "stratified_kfold",
                "folds": cv_folds,
                "random_state": random_state,
            },
            "toggles": toggles,
            "hypothesis_summary": {
                "n_total":       hypothesis_report.get("n_features_total", "N/A") if hypothesis_report else "N/A",
                "n_significant": hypothesis_report.get("n_significant", "N/A") if hypothesis_report else "N/A",
                "alpha":         hypothesis_report.get("alpha", 0.05) if hypothesis_report else 0.05,
            },
            # Pass through the rest of base config for lower-level modules
            "_base": self.base_config,
        }

        logger.info(
            f"Dynamic config built: "
            f"{len(significant_features)} features, "
            f"{len(models_to_train)} models, "
            f"cv_folds={cv_folds}"
        )
        for key, val in toggles.items():
            logger.info(f"  toggle: {key} = {val}")

        return self.dynamic_config

    def get_selected_features(self) -> Optional[List[str]]:
        return self.dynamic_config.get("selected_features")

    def get_models(self) -> List[str]:
        return self.dynamic_config.get("models", [])

    def get_cv_config(self) -> Dict:
        return self.dynamic_config.get("cv", {})

    def is_enabled(self, toggle: str) -> bool:
        return bool(self.dynamic_config.get("toggles", {}).get(toggle, True))

    def summary(self) -> Dict:
        return {
            "selected_features":    self.dynamic_config.get("selected_features"),
            "models":               self.dynamic_config.get("models"),
            "cv_strategy":          self.dynamic_config.get("cv", {}).get("strategy"),
            "cv_folds":             self.dynamic_config.get("cv", {}).get("folds"),
            "toggles":              self.dynamic_config.get("toggles"),
            "hypothesis_summary":   self.dynamic_config.get("hypothesis_summary"),
        }
