"""
Model Comparison Module — McNemar Test
MUST run AFTER model training and prediction generation.

Steps:
  1. Build contingency table from two models' predictions on the same test set.
  2. Apply McNemar's test (with continuity correction).
  3. Optionally compare all pairwise combinations.
  4. Output: statistic, p-value, conclusion.
"""

import warnings
from itertools import combinations
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from src.utils.logger import get_logger

warnings.filterwarnings("ignore")
logger = get_logger(__name__)


# ── Core McNemar implementation ───────────────────────────────────────────────

def build_contingency_table(
    y_true: np.ndarray,
    preds_a: np.ndarray,
    preds_b: np.ndarray,
) -> Dict[str, int]:
    """
    Build the 2×2 McNemar contingency table.

    Returns:
        Dict with keys: both_correct, only_a_correct, only_b_correct, both_wrong.
    """
    correct_a = preds_a == y_true
    correct_b = preds_b == y_true
    return {
        "both_correct":    int(np.sum(correct_a & correct_b)),
        "only_a_correct":  int(np.sum(correct_a & ~correct_b)),
        "only_b_correct":  int(np.sum(~correct_a & correct_b)),
        "both_wrong":      int(np.sum(~correct_a & ~correct_b)),
    }


def mcnemar_test(
    y_true: np.ndarray,
    preds_a: np.ndarray,
    preds_b: np.ndarray,
    model_a_name: str = "Model A",
    model_b_name: str = "Model B",
    alpha: float = 0.05,
) -> Dict:
    """
    McNemar's test comparing two classifiers on the same test set.

    Args:
        y_true:       Ground-truth labels.
        preds_a:      Predictions from model A.
        preds_b:      Predictions from model B.
        model_a_name: Display name for model A.
        model_b_name: Display name for model B.
        alpha:        Significance threshold.

    Returns:
        Dict with statistic, p_value, contingency table, and conclusion.
    """
    ct = build_contingency_table(y_true, preds_a, preds_b)
    b = ct["only_a_correct"]   # A correct, B wrong
    c = ct["only_b_correct"]   # A wrong, B correct

    if (b + c) == 0:
        return {
            "model_a":     model_a_name,
            "model_b":     model_b_name,
            "statistic":   0.0,
            "p_value":     1.0,
            "b":           b,
            "c":           c,
            "contingency": ct,
            "significant": False,
            "conclusion":  "Identical predictions — no difference.",
        }

    # McNemar chi-square with continuity correction
    statistic = float((abs(b - c) - 1) ** 2 / (b + c))
    p_value = float(stats.chi2.sf(statistic, df=1))
    significant = p_value < alpha

    if significant:
        better = model_a_name if b > c else model_b_name
        conclusion = (
            f"Statistically significant difference (p={p_value:.4f} < α={alpha}). "
            f"{better} makes fewer errors."
        )
    else:
        conclusion = (
            f"No statistically significant difference (p={p_value:.4f} ≥ α={alpha}). "
            "Models perform equivalently."
        )

    result = {
        "model_a":     model_a_name,
        "model_b":     model_b_name,
        "statistic":   round(statistic, 6),
        "p_value":     round(p_value, 6),
        "b":           b,
        "c":           c,
        "contingency": ct,
        "alpha":       alpha,
        "significant": significant,
        "conclusion":  conclusion,
    }

    logger.info(
        f"McNemar [{model_a_name} vs {model_b_name}]: "
        f"chi2={statistic:.4f}  p={p_value:.4f}  "
        f"{'✅ significant' if significant else '❌ not significant'}"
    )
    return result


# ── High-level orchestrator ───────────────────────────────────────────────────

class ModelComparator:
    """
    Orchestrates McNemar tests across all trained models (post-training).

    Usage:
        comparator = ModelComparator(alpha=0.05)
        results = comparator.run(trained_models, X_test, y_test)
    """

    def __init__(self, alpha: float = 0.05):
        self.alpha = alpha
        self.results: Dict = {}
        self.pairwise_results: List[Dict] = []

    def run(
        self,
        trained_models: Dict[str, Any],
        X_test: np.ndarray,
        y_test: np.ndarray,
        reference_model: Optional[str] = None,
    ) -> Dict:
        """
        Run McNemar test for all model pairs.

        Args:
            trained_models:  Dict of model_name → fitted model.
            X_test:          Test feature array.
            y_test:          Test labels.
            reference_model: If set, only compare other models vs this one.

        Returns:
            Dict with pairwise results and summary DataFrame.
        """
        logger.info("=== Model Comparator: McNemar Tests (Post-Training) ===")

        names = list(trained_models.keys())
        if len(names) < 2:
            logger.warning("Need ≥2 models for McNemar test.")
            self.results = {"error": "Need at least 2 trained models."}
            return self.results

        # Generate predictions for every model once
        predictions: Dict[str, np.ndarray] = {}
        for name, model in trained_models.items():
            try:
                predictions[name] = model.predict(X_test)
            except Exception as e:
                logger.warning(f"  Prediction failed for {name}: {e}")

        # Determine pairs to compare
        if reference_model and reference_model in predictions:
            pairs = [
                (reference_model, other)
                for other in names
                if other != reference_model and other in predictions
            ]
        else:
            pairs = [
                (a, b)
                for a, b in combinations(names, 2)
                if a in predictions and b in predictions
            ]

        self.pairwise_results = []
        for a, b in pairs:
            res = mcnemar_test(
                y_true=y_test,
                preds_a=predictions[a],
                preds_b=predictions[b],
                model_a_name=a,
                model_b_name=b,
                alpha=self.alpha,
            )
            self.pairwise_results.append(res)

        # Build summary
        summary_rows = [
            {
                "pair":         f"{r['model_a']} vs {r['model_b']}",
                "model_a":      r["model_a"],
                "model_b":      r["model_b"],
                "chi2":         r["statistic"],
                "p_value":      r["p_value"],
                "significant":  r["significant"],
                "conclusion":   r["conclusion"],
            }
            for r in self.pairwise_results
        ]
        summary_df = pd.DataFrame(summary_rows)

        self.results = {
            "alpha":            self.alpha,
            "n_pairs_tested":   len(self.pairwise_results),
            "pairwise":         self.pairwise_results,
            "summary":          summary_df,
            "significant_pairs": [
                r for r in self.pairwise_results if r["significant"]
            ],
        }

        n_sig = len(self.results["significant_pairs"])
        logger.info(
            f"McNemar complete: {len(self.pairwise_results)} pairs tested, "
            f"{n_sig} significant differences found."
        )
        return self.results

    def summary_dataframe(self) -> pd.DataFrame:
        return self.results.get("summary", pd.DataFrame())

    def significant_pairs(self) -> List[Dict]:
        return self.results.get("significant_pairs", [])
