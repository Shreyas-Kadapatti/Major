"""
Hypothesis Engine Module
Data-Level Statistical Testing — runs BEFORE configuration.

Tests:
  - Pearson Correlation   (numeric feature vs numeric target)
  - Chi-Square Test       (categorical feature vs categorical target)
  - ANOVA / t-Test        (numeric feature vs categorical target)

Outputs:
  - significant_features  list
  - insignificant_features list
  - JSON-serialisable report
"""

import json
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from src.utils.logger import get_logger

warnings.filterwarnings("ignore")
logger = get_logger(__name__)


# ── Low-level test functions ──────────────────────────────────────────────────

def _pearson_test(series: pd.Series, target: pd.Series) -> Dict:
    """Pearson correlation between a numeric feature and a numeric target."""
    try:
        valid = series.notna() & target.notna()
        corr, p_value = stats.pearsonr(series[valid], target[valid])
        return {
            "test": "pearson",
            "statistic": round(float(corr), 6),
            "p_value": round(float(p_value), 6),
        }
    except Exception as exc:
        return {"test": "pearson", "error": str(exc), "p_value": 1.0}


def _chi_square_test(series: pd.Series, target: pd.Series) -> Dict:
    """Chi-square test of independence between two categorical series."""
    try:
        contingency = pd.crosstab(series.fillna("__NA__"), target.fillna("__NA__"))
        chi2, p_value, dof, _ = stats.chi2_contingency(contingency)
        return {
            "test": "chi_square",
            "statistic": round(float(chi2), 6),
            "dof": int(dof),
            "p_value": round(float(p_value), 6),
        }
    except Exception as exc:
        return {"test": "chi_square", "error": str(exc), "p_value": 1.0}


def _anova_test(series: pd.Series, target: pd.Series) -> Dict:
    """One-way ANOVA (or t-test for 2 groups) of a numeric feature across target classes."""
    try:
        groups = [series[target == cls].dropna().values for cls in target.unique()]
        groups = [g for g in groups if len(g) >= 2]
        if len(groups) < 2:
            return {"test": "anova", "error": "Not enough groups", "p_value": 1.0}
        if len(groups) == 2:
            stat, p_value = stats.ttest_ind(groups[0], groups[1])
            test_name = "t_test"
        else:
            stat, p_value = stats.f_oneway(*groups)
            test_name = "anova"
        return {
            "test": test_name,
            "statistic": round(float(stat), 6),
            "p_value": round(float(p_value), 6),
            "n_groups": len(groups),
        }
    except Exception as exc:
        return {"test": "anova", "error": str(exc), "p_value": 1.0}


# ── Main class ────────────────────────────────────────────────────────────────

class HypothesisEngine:
    """
    Performs per-feature statistical hypothesis tests against the target
    BEFORE configuration is built.

    Args:
        alpha:     significance threshold (default 0.05)
        min_significant_ratio: fraction of features that must be significant
                               before feature engineering is triggered (default 0.3)
    """

    def __init__(self, alpha: float = 0.05, min_significant_ratio: float = 0.3):
        self.alpha = alpha
        self.min_significant_ratio = min_significant_ratio
        self.report: Dict = {}
        self.significant_features: List[str] = []
        self.insignificant_features: List[str] = []

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _infer_type(series: pd.Series, nunique_threshold: int = 10) -> str:
        if pd.api.types.is_numeric_dtype(series):
            return "numeric"
        if series.nunique() <= nunique_threshold:
            return "categorical"
        return "categorical"

    # ── Public API ────────────────────────────────────────────────────────────

    def run(
        self,
        df: pd.DataFrame,
        target_col: str,
        numeric_cols: Optional[List[str]] = None,
        categorical_cols: Optional[List[str]] = None,
    ) -> Dict:
        """
        Run hypothesis tests for every feature against the target.

        Args:
            df:               Input DataFrame (may contain the target column).
            target_col:       Name of the target column.
            numeric_cols:     Pre-classified numeric feature names (optional).
            categorical_cols: Pre-classified categorical feature names (optional).

        Returns:
            Full report dict with significant / insignificant feature lists.
        """
        logger.info("=== Hypothesis Engine: Data-Level Testing ===")

        target = df[target_col].copy()
        feature_df = df.drop(columns=[target_col])

        # Auto-detect feature types if not supplied
        if numeric_cols is None:
            numeric_cols = [
                c for c in feature_df.columns
                if pd.api.types.is_numeric_dtype(feature_df[c])
            ]
        if categorical_cols is None:
            categorical_cols = [
                c for c in feature_df.columns
                if c not in numeric_cols
            ]

        target_is_numeric = pd.api.types.is_numeric_dtype(target)
        feature_results: Dict[str, Dict] = {}

        # ── Test each feature ─────────────────────────────────────────────
        for col in feature_df.columns:
            feat = feature_df[col]
            is_numeric_feat = col in numeric_cols

            if is_numeric_feat and target_is_numeric:
                result = _pearson_test(feat, target)
            elif not is_numeric_feat:
                result = _chi_square_test(feat, target)
            else:
                # numeric feature, categorical target
                result = _anova_test(feat, target)

            p = result.get("p_value", 1.0)
            result["significant"] = bool(p < self.alpha)
            result["feature"] = col
            feature_results[col] = result

            sig_label = "✅ significant" if result["significant"] else "❌ insignificant"
            logger.info(f"  {col}: {result['test']} p={p:.4f}  {sig_label}")

        # ── Partition ─────────────────────────────────────────────────────
        self.significant_features = [
            c for c, r in feature_results.items() if r["significant"]
        ]
        self.insignificant_features = [
            c for c, r in feature_results.items() if not r["significant"]
        ]

        n_total = len(feature_results)
        n_sig = len(self.significant_features)
        ratio = n_sig / n_total if n_total > 0 else 0.0
        trigger_engineering = ratio < self.min_significant_ratio

        logger.info(
            f"Significant: {n_sig}/{n_total}  "
            f"(ratio={ratio:.2f}, threshold={self.min_significant_ratio})  "
            f"trigger_engineering={trigger_engineering}"
        )

        self.report = {
            "alpha": self.alpha,
            "target_column": target_col,
            "n_features_total": n_total,
            "n_significant": n_sig,
            "n_insignificant": len(self.insignificant_features),
            "significant_ratio": round(ratio, 4),
            "trigger_feature_engineering": trigger_engineering,
            "significant_features": self.significant_features,
            "insignificant_features": self.insignificant_features,
            "feature_results": feature_results,
        }

        return self.report

    def save_report(self, path: str = "models/hypothesis_report.json") -> None:
        """Persist the JSON report to disk."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        def _serial(obj):
            if isinstance(obj, (np.integer, np.int64)):
                return int(obj)
            if isinstance(obj, (np.floating, np.float64)):
                return float(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return str(obj)

        with open(path, "w") as fh:
            json.dump(self.report, fh, indent=2, default=_serial)
        logger.info(f"Hypothesis report saved → {path}")

    def should_trigger_engineering(self) -> bool:
        """Return True if feature engineering should be triggered."""
        return bool(self.report.get("trigger_feature_engineering", False))

    def get_significant_features(self) -> List[str]:
        return list(self.significant_features)

    def summary_dataframe(self) -> pd.DataFrame:
        """Return a tidy DataFrame of per-feature test results."""
        rows = []
        for col, r in self.report.get("feature_results", {}).items():
            rows.append({
                "feature": col,
                "test": r.get("test"),
                "statistic": r.get("statistic"),
                "p_value": r.get("p_value"),
                "significant": r.get("significant"),
            })
        return pd.DataFrame(rows)
