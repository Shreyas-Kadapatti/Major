"""
Model Registry — 20 Classification Models
Provides a unified interface for all supported classifiers.

Core (always available):
  1.  logistic_regression    — sklearn
  2.  decision_tree          — sklearn
  3.  random_forest          — sklearn
  4.  extra_trees            — sklearn
  5.  gradient_boosting      — sklearn
  6.  knn                    — sklearn
  7.  naive_bayes            — sklearn (GaussianNB)
  8.  svm                    — sklearn
  9.  mlp                    — sklearn

NEW (+8):
  10. adaboost               — sklearn AdaBoost
  11. bagging                — sklearn Bagging
  12. lda                    — Linear Discriminant Analysis
  13. qda                    — Quadratic Discriminant Analysis
  14. ridge_classifier        — sklearn RidgeClassifier
  15. sgd                    — sklearn SGDClassifier
  16. passive_aggressive      — sklearn PassiveAggressiveClassifier
  17. bernoulli_nb            — sklearn BernoulliNB

Optional (install separately):
  18. xgboost                — xgboost
  19. lightgbm               — lightgbm
  20. catboost               — catboost
"""
from typing import Any, Dict, List

from sklearn.calibration import CalibratedClassifierCV
from sklearn.discriminant_analysis import (
    LinearDiscriminantAnalysis,
    QuadraticDiscriminantAnalysis,
)
from sklearn.ensemble import (
    AdaBoostClassifier,
    BaggingClassifier,
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
    VotingClassifier,
)
from sklearn.linear_model import (
    LogisticRegression,
    RidgeClassifier,
    SGDClassifier,
)
from sklearn.naive_bayes import (
    BernoulliNB,
    ComplementNB,
    GaussianNB,
    MultinomialNB,
)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import LinearSVC, SVC
from sklearn.tree import DecisionTreeClassifier, ExtraTreeClassifier

from src.utils.logger import get_logger

logger = get_logger(__name__)

# ── Optional heavy boosting libs ──────────────────────────────────────────────
try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    logger.warning("XGBoost not installed — model skipped.")

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False
    logger.warning("LightGBM not installed — model skipped.")

try:
    from catboost import CatBoostClassifier
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False
    logger.warning("CatBoost not installed — model skipped.")

# ── Core registry (always available) ─────────────────────────────────────────
MODEL_REGISTRY: Dict[str, Any] = {
    # 1. Logistic Regression
    "logistic_regression": LogisticRegression(max_iter=1000, random_state=42),
    # 2. Decision Tree
    "decision_tree": DecisionTreeClassifier(random_state=42),
    # 3. Random Forest
    "random_forest": RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    # 4. Extra Trees  ← NEW
    "extra_trees": ExtraTreesClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    # 5. Gradient Boosting (sklearn)  ← NEW
    "gradient_boosting": GradientBoostingClassifier(n_estimators=100, random_state=42),
    # 6. K-Nearest Neighbours  ← NEW
    "knn": KNeighborsClassifier(n_neighbors=5, n_jobs=-1),
    # 7. Gaussian Naive Bayes  ← NEW
    "naive_bayes": GaussianNB(),
    # 8. SVM
    "svm": SVC(probability=True, random_state=42),
    # 9. MLP Neural Network
    "mlp": MLPClassifier(max_iter=500, random_state=42),

    # ── NEW MODELS (+8) ──────────────────────────────────────────────────────
    # 10. AdaBoost
    "adaboost": AdaBoostClassifier(
        n_estimators=100, learning_rate=1.0, random_state=42
    ),
    # 11. Bagging Classifier
    "bagging": BaggingClassifier(
        n_estimators=50, random_state=42, n_jobs=-1
    ),
    # 12. Linear Discriminant Analysis
    "lda": LinearDiscriminantAnalysis(),
    # 13. Quadratic Discriminant Analysis
    "qda": QuadraticDiscriminantAnalysis(),
    # 14. Ridge Classifier — wrapped with Platt scaling for predict_proba
    "ridge_classifier": CalibratedClassifierCV(
        RidgeClassifier(), cv=3, method="sigmoid"
    ),
    # 15. SGD Classifier (log_loss gives probabilities)
    "sgd": SGDClassifier(
        loss="log_loss", max_iter=1000, random_state=42, n_jobs=-1
    ),
    # 16. Passive Aggressive → SGD equivalent (sklearn 1.8+ compatible)
    "passive_aggressive": SGDClassifier(
        loss="hinge", penalty=None, learning_rate="pa1", eta0=1.0,
        max_iter=1000, random_state=42, n_jobs=-1
    ),
    # 17. Bernoulli Naive Bayes
    "bernoulli_nb": BernoulliNB(),
}

# ── Optional boosting models ──────────────────────────────────────────────────
if XGBOOST_AVAILABLE:   # 10
    MODEL_REGISTRY["xgboost"] = XGBClassifier(
        eval_metric="logloss", random_state=42, n_jobs=-1, verbosity=0
    )

if LIGHTGBM_AVAILABLE:  # 11
    MODEL_REGISTRY["lightgbm"] = LGBMClassifier(
        random_state=42, n_jobs=-1, verbose=-1
    )

if CATBOOST_AVAILABLE:  # 12
    MODEL_REGISTRY["catboost"] = CatBoostClassifier(random_state=42, verbose=0)


# ── Public helpers ────────────────────────────────────────────────────────────
def get_model(name: str):
    """
    Retrieve a fresh model instance by name.

    Args:
        name: Model key from MODEL_REGISTRY.

    Returns:
        Sklearn-compatible estimator (cloned to avoid state leakage).
    """
    from sklearn.base import clone
    if name not in MODEL_REGISTRY:
        raise ValueError(
            f"Model '{name}' not found. Available: {list(MODEL_REGISTRY.keys())}"
        )
    return clone(MODEL_REGISTRY[name])


def get_available_models() -> List[str]:
    """Return list of all registered model names."""
    return list(MODEL_REGISTRY.keys())


# ── Optuna hyperparameter search spaces ──────────────────────────────────────
# Format per param:
#   ("float",  low, high, log?)
#   ("int",    low, high)
#   ("categorical", [choices])
SEARCH_SPACES: Dict[str, Any] = {
    "logistic_regression": {
        "C":        ("float", 1e-3, 10.0, True),
        "solver":   ("categorical", ["lbfgs", "saga"]),
        "max_iter": ("int", 200, 2000),
    },
    "decision_tree": {
        "max_depth":        ("int", 2, 30),
        "min_samples_split":("int", 2, 20),
        "min_samples_leaf": ("int", 1, 10),
        "criterion":        ("categorical", ["gini", "entropy"]),
    },
    "random_forest": {
        "n_estimators":      ("int", 50, 500),
        "max_depth":         ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf":  ("int", 1, 10),
        "max_features":      ("categorical", ["sqrt", "log2"]),
    },
    "extra_trees": {
        "n_estimators":      ("int", 50, 500),
        "max_depth":         ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf":  ("int", 1, 10),
        "max_features":      ("categorical", ["sqrt", "log2"]),
    },
    "gradient_boosting": {
        "n_estimators":   ("int", 50, 300),
        "max_depth":      ("int", 2, 8),
        "learning_rate":  ("float", 1e-3, 0.3, True),
        "subsample":      ("float", 0.5, 1.0, False),
        "min_samples_leaf":("int", 1, 10),
    },
    "knn": {
        "n_neighbors": ("int", 1, 30),
        "weights":     ("categorical", ["uniform", "distance"]),
        "metric":      ("categorical", ["euclidean", "manhattan", "minkowski"]),
        "p":           ("int", 1, 3),
    },
    "naive_bayes": {
        "var_smoothing": ("float", 1e-12, 1e-6, True),
    },
    "svm": {
        "C":      ("float", 1e-2, 100.0, True),
        "kernel": ("categorical", ["rbf", "poly", "sigmoid"]),
        "gamma":  ("categorical", ["scale", "auto"]),
    },
    "mlp": {
        "hidden_layer_sizes_n":      ("int", 50, 256),
        "hidden_layer_sizes_layers": ("int", 1, 3),
        "activation":    ("categorical", ["relu", "tanh"]),
        "alpha":         ("float", 1e-5, 1e-1, True),
        "learning_rate": ("categorical", ["constant", "adaptive"]),
    },
    "xgboost": {
        "n_estimators":     ("int", 50, 500),
        "max_depth":        ("int", 2, 10),
        "learning_rate":    ("float", 1e-3, 0.3, True),
        "subsample":        ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "gamma":            ("float", 0.0, 5.0, False),
        "reg_alpha":        ("float", 1e-3, 10.0, True),
        "reg_lambda":       ("float", 1e-3, 10.0, True),
    },
    "lightgbm": {
        "n_estimators":     ("int", 50, 500),
        "max_depth":        ("int", 2, 30),
        "learning_rate":    ("float", 1e-3, 0.3, True),
        "num_leaves":       ("int", 20, 150),
        "subsample":        ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "reg_alpha":        ("float", 1e-3, 10.0, True),
        "reg_lambda":       ("float", 1e-3, 10.0, True),
    },
    "catboost": {
        "iterations":     ("int", 50, 500),
        "depth":          ("int", 2, 10),
        "learning_rate":  ("float", 1e-3, 0.3, True),
        "l2_leaf_reg":    ("float", 1e-3, 10.0, True),
    },
    # ── New models ────────────────────────────────────────────────────────────
    "adaboost": {
        "n_estimators":  ("int", 50, 500),
        "learning_rate": ("float", 1e-3, 2.0, True),
    },
    "bagging": {
        "n_estimators":  ("int", 10, 200),
        "max_samples":   ("float", 0.5, 1.0, False),
        "max_features":  ("float", 0.5, 1.0, False),
    },
    "lda": {
        "solver": ("categorical", ["svd", "lsqr", "eigen"]),
    },
    "qda": {
        "reg_param": ("float", 0.0, 1.0, False),
    },
    "ridge_classifier": {
        "alpha": ("float", 1e-3, 100.0, True),
    },
    "sgd": {
        "alpha":        ("float", 1e-5, 1e-1, True),
        "max_iter":     ("int", 500, 2000),
        "learning_rate":("categorical", ["optimal", "invscaling", "adaptive"]),
        "eta0":         ("float", 1e-4, 1.0, True),
    },
    "passive_aggressive": {
        "C":        ("float", 1e-3, 10.0, True),
        "max_iter": ("int", 500, 2000),
    },
    "bernoulli_nb": {
        "alpha":     ("float", 1e-3, 2.0, True),
        "binarize":  ("float", 0.0, 1.0, False),
    },
}

# ── Model metadata (for UI display) ──────────────────────────────────────────
MODEL_DESCRIPTIONS: Dict[str, str] = {
    "logistic_regression": "Linear model, fast baseline, interpretable coefficients.",
    "decision_tree":       "Single tree, fully interpretable, prone to overfitting.",
    "random_forest":       "Ensemble of trees, robust, great general-purpose model.",
    "extra_trees":         "Like Random Forest but with extra randomness — often faster.",
    "gradient_boosting":   "Sequential boosting (sklearn), strong on tabular data.",
    "knn":                 "Instance-based learner, no training phase, distance-based.",
    "naive_bayes":         "Probabilistic, very fast, assumes feature independence.",
    "svm":                 "Support vectors, works well in high-dimensional spaces.",
    "mlp":                 "Multi-layer perceptron neural network, flexible non-linear.",
    "xgboost":             "Extreme Gradient Boosting, top competition model.",
    "lightgbm":            "Light GBM, leaf-wise trees, very fast on large datasets.",
    "catboost":            "CatBoost, handles categoricals natively, minimal tuning.",
    # New models
    "adaboost":            "AdaBoost: sequential boosting of weak learners, robust to noise.",
    "bagging":             "Bagging: bootstrap aggregation reduces variance, good for high-variance models.",
    "lda":                 "Linear Discriminant Analysis: assumes Gaussian classes, fast & interpretable.",
    "qda":                 "Quadratic Discriminant Analysis: relaxes LDA's equal-covariance assumption.",
    "ridge_classifier":    "Ridge Classifier: regularised linear model, very fast training.",
    "sgd":                 "SGD Classifier: scalable linear model trained with stochastic gradient descent.",
    "passive_aggressive":  "Passive Aggressive: large-margin online learner, good for streaming data.",
    "bernoulli_nb":        "Bernoulli NB: Naive Bayes for binary/boolean features.",
}
