"""
Training Pipeline — Hypothesis-Driven Explainable AutoML
=========================================================

STRICT EXECUTION ORDER:
  1.  Data Ingestion
  2.  Hypothesis Testing Engine  (data-level, PRE-config)
  3.  Feature Engineering Engine (conditional trigger)
  4.  Re-run Hypothesis Testing  (if FE was triggered)
  5.  Dynamic Configuration Layer
  6.  Preprocessing
  7.  Train / Test Split
  8.  Hyperparameter Tuning
  9.  Model Training with Stratified K-Fold CV
  10. Model Evaluation
  11. McNemar Test               (POST-training)
  12. MLflow Logging Service     (internal only)
  13. SHAP Explainability
  14. Return results → Dashboard / UI
"""

import json
import os
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# ── Existing infrastructure ───────────────────────────────────────────────────
from src.evaluation.evaluator import ModelEvaluator
from src.explainability.shap_explainer import ExplainabilityEngine
from src.ingestion.data_loader import DataIngestion
from src.models.registry import get_available_models
from src.models.selector import ModelSelector
from src.models.trainer import ModelTrainer
from src.preprocessing.pipeline import PreprocessingPipeline
from src.tuning.optuna_tuner import HyperparameterTuner
from src.utils.config_loader import load_config
from src.utils.logger import get_logger

# ── New hypothesis-driven modules ─────────────────────────────────────────────
from src.hypothesis.hypothesis_engine import HypothesisEngine
from src.feature_engineering.feature_engineering import FeatureEngineeringEngine
from src.config.config_manager import ConfigManager
from src.comparison.model_comparison import ModelComparator
from src.logging_service.logger import MLflowLogger   # ONLY gateway to MLflow

logger = get_logger(__name__)


class TrainingPipeline:
    """
    End-to-end Hypothesis-Driven Explainable AutoML pipeline.

    Config toggles (read from config.yaml or dynamic config):
        enable_hypothesis_testing   - default True
        enable_feature_engineering  - default True
        enable_mcnemar_test         - default True
        enable_tuning               - default True
        enable_shap                 - default True
    """

    def __init__(self, config_path: str = "config/config.yaml"):
        self.config = load_config(config_path)

        # Core infrastructure
        self.ingestion    = DataIngestion(self.config)
        self.preprocessor = PreprocessingPipeline(self.config)
        self.trainer      = ModelTrainer(self.config)
        self.tuner        = HyperparameterTuner(self.config)
        self.evaluator    = ModelEvaluator(self.config)
        self.selector     = ModelSelector(self.config)
        self.explainer    = ExplainabilityEngine(self.config)

        # New hypothesis-driven modules
        self.hypothesis_engine = HypothesisEngine(
            alpha=self.config.get("hypothesis", {}).get("alpha", 0.05),
            min_significant_ratio=self.config.get("hypothesis", {}).get(
                "min_significant_ratio", 0.3
            ),
        )
        self.fe_engine     = FeatureEngineeringEngine(config=self.config)
        self.config_mgr    = ConfigManager(self.config)
        self.comparator    = ModelComparator(
            alpha=self.config.get("hypothesis", {}).get("alpha", 0.05)
        )
        self.mlflow_logger = MLflowLogger(self.config)   # INTERNAL ONLY

        # State
        self.df: Optional[pd.DataFrame]           = None
        self.col_types: Optional[Dict]            = None
        self.profile: Optional[Dict]              = None
        self.X_train = self.X_test                = None
        self.y_train = self.y_test                = None
        self.trained_models: Dict[str, Any]       = {}
        self.leaderboard: Optional[pd.DataFrame]  = None
        self.best_model_name: Optional[str]       = None
        self.best_model: Optional[Any]            = None
        self.class_names: Optional[List[str]]     = None
        self.feature_names: Optional[List[str]]   = None

        # Pipeline artefacts exposed to UI / dashboard
        self.hypothesis_report: Dict              = {}
        self.fe_summary: Dict                     = {}
        self.dynamic_cfg: Dict                    = {}
        self.comparison_results: Dict             = {}
        self.fe_triggered: bool                   = False

        os.makedirs("models", exist_ok=True)
        os.makedirs("logs",   exist_ok=True)

    # -------------------------------------------------------------------------
    # Public entry-point
    # -------------------------------------------------------------------------

    def run(
        self,
        file_path: str,
        target_col: str,
        model_names: Optional[List[str]] = None,
        tune: bool = True,
        progress_callback: Optional[Callable[[str, int], None]] = None,
    ) -> Dict[str, Any]:
        """
        Execute the full hypothesis-driven pipeline.

        Args:
            file_path:         Path to dataset (CSV / XLSX / Parquet).
            target_col:        Name of the target column.
            model_names:       Models to train (None = use dynamic config defaults).
            tune:              Whether to run Optuna tuning.
            progress_callback: Optional callback(message: str, pct: int).

        Returns:
            Result dict with leaderboard, models, hypothesis report,
            McNemar results, feature names, etc.
        """
        def _p(msg: str, pct: int) -> None:
            logger.info(f"[{pct:3d}%] {msg}")
            if progress_callback:
                progress_callback(msg, pct)

        # STEP 1: Data Ingestion
        _p("Loading and validating data ...", 5)
        self.df, self.col_types, self.profile = self.ingestion.run(
            file_path, target_col
        )
        numeric_cols     = self.col_types.get("numeric", [])
        categorical_cols = self.col_types.get("categorical", [])
        _raw_df = self.df.copy()

        # STEP 2: Hypothesis Testing Engine (PRE-CONFIG)
        _p("Running Hypothesis Testing Engine (pre-config) ...", 10)
        self.hypothesis_report = self.hypothesis_engine.run(
            df=self.df,
            target_col=target_col,
            numeric_cols=numeric_cols,
            categorical_cols=categorical_cols,
        )
        self.hypothesis_engine.save_report("models/hypothesis_report.json")

        # STEP 3: Feature Engineering (conditional)
        self.fe_triggered = self.hypothesis_engine.should_trigger_engineering()

        if self.fe_triggered:
            _p("Feature Engineering triggered — generating new features ...", 18)
            self.df = self.fe_engine.run(
                df=self.df,
                target_col=target_col,
                numeric_cols=numeric_cols,
                categorical_cols=categorical_cols,
            )
            self.fe_summary = self.fe_engine.get_summary()

            # STEP 4: Re-run Hypothesis Testing on enriched dataset
            _p("Re-running Hypothesis Testing after Feature Engineering ...", 25)
            new_numeric = [
                c for c in self.df.columns
                if c != target_col and pd.api.types.is_numeric_dtype(self.df[c])
            ]
            new_categorical = [
                c for c in self.df.columns
                if c != target_col and c not in new_numeric
            ]
            self.hypothesis_report = self.hypothesis_engine.run(
                df=self.df,
                target_col=target_col,
                numeric_cols=new_numeric,
                categorical_cols=new_categorical,
            )
            self.hypothesis_engine.save_report("models/hypothesis_report_post_fe.json")
        else:
            _p("Sufficient significant features found — skipping Feature Engineering.", 18)
            self.fe_summary = {
                "new_features": [],
                "n_new_features": 0,
                "techniques_applied": [],
            }

        # STEP 5: Dynamic Configuration Layer
        _p("Building Dynamic Configuration from hypothesis results ...", 30)
        significant_features = self.hypothesis_engine.get_significant_features()

        self.dynamic_cfg = self.config_mgr.build(
            significant_features=significant_features,
            hypothesis_report=self.hypothesis_report,
            model_override=model_names,
        )

        final_model_names = self.dynamic_cfg.get("models") or get_available_models()
        selected_features = self.dynamic_cfg.get("selected_features")

        # Filter DataFrame to significant features + target
        if selected_features:
            available = [f for f in selected_features if f in self.df.columns]
            if not available:
                logger.warning("Selected features not found — using all features.")
                working_df = self.df
            else:
                working_df = self.df[available + [target_col]]
                logger.info(
                    f"Feature subset applied: {len(available)} / "
                    f"{len(self.df.columns)-1} features used."
                )
        else:
            working_df = self.df

        w_numeric = [
            c for c in working_df.columns
            if c != target_col and pd.api.types.is_numeric_dtype(working_df[c])
        ]
        w_categorical = [
            c for c in working_df.columns
            if c != target_col and c not in w_numeric
        ]

        # STEP 6: Preprocessing
        _p("Preprocessing features ...", 38)
        X_transformed, y_encoded = self.preprocessor.fit_transform(
            working_df, target_col, w_numeric, w_categorical
        )
        self.class_names   = [str(c) for c in self.preprocessor.label_encoder.classes_]
        self.feature_names = self.preprocessor.feature_names_out
        self.preprocessor.save("models/preprocessor.pkl")

        # STEP 7: Train / Test Split
        test_size    = self.config["data"].get("test_size", 0.2)
        random_state = self.config["project"].get("random_state", 42)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_transformed, y_encoded,
            test_size=test_size,
            random_state=random_state,
            stratify=y_encoded,
        )

        best_params: Dict[str, Dict] = {}

        # STEP 8: Hyperparameter Tuning
        do_tune = tune and self.dynamic_cfg.get("toggles", {}).get("enable_tuning", True)
        if do_tune:
            _p("Tuning hyperparameters with Optuna ...", 45)
            best_params = self.tuner.tune_all(
                self.X_train, self.y_train, final_model_names
            )
            with open("models/best_params.json", "w") as fh:
                json.dump(best_params, fh, indent=2, default=str)

        # STEP 9: Model Training with Stratified K-Fold CV
        _p("Training models with Stratified K-Fold cross-validation ...", 58)
        self.trained_models = self.trainer.train_all(
            self.X_train, self.y_train, final_model_names, best_params
        )

        # STEP 10: Model Evaluation
        _p("Evaluating models ...", 72)
        self.leaderboard = self.evaluator.compare_models(
            self.trained_models, self.X_test, self.y_test
        )

        _p("Selecting best model ...", 78)
        self.best_model_name, self.best_model = self.selector.select(
            self.trained_models, self.leaderboard
        )
        self.selector.save("models/best_model.pkl")

        # STEP 11: McNemar Test (POST-TRAINING — NEVER before this point)
        do_mcnemar = self.dynamic_cfg.get("toggles", {}).get("enable_mcnemar_test", True)
        if do_mcnemar and len(self.trained_models) >= 2:
            _p("Running McNemar statistical model comparison (post-training) ...", 83)
            self.comparison_results = self.comparator.run(
                trained_models=self.trained_models,
                X_test=self.X_test,
                y_test=self.y_test,
                reference_model=self.best_model_name,
            )
        else:
            _p("Skipping McNemar test (disabled or fewer than 2 models).", 83)
            self.comparison_results = {}

        # STEP 12: MLflow Logging Service (INTERNAL ONLY — never exposed to UI)
        _p("Logging experiment artefacts via MLflow ...", 88)
        self._log_to_mlflow(
            best_params=best_params,
            raw_df=_raw_df,
            source_name=os.path.basename(file_path),
        )

        # STEP 13: SHAP Explainability
        do_shap = self.dynamic_cfg.get("toggles", {}).get("enable_shap", True)
        if do_shap:
            _p("Computing SHAP explanations ...", 95)
            try:
                self.explainer.compute_shap(
                    self.best_model,
                    self.X_test,
                    feature_names=self.feature_names,
                )
            except Exception as exc:
                logger.warning(f"SHAP computation failed: {exc}")

        _p("Pipeline complete!", 100)

        # STEP 14: Return results to Dashboard / UI
        return self._build_result()

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _log_to_mlflow(
        self,
        best_params: Dict,
        raw_df: pd.DataFrame,
        source_name: str,
    ) -> None:
        """All MLflow interactions go through MLflowLogger — never directly."""

        # Pipeline-level metadata run
        self.mlflow_logger.start_run(run_name="pipeline_metadata")
        try:
            self.mlflow_logger.log_hypothesis_results(self.hypothesis_report)
            if self.fe_triggered:
                self.mlflow_logger.log_feature_engineering_summary(self.fe_summary)
            if self.comparison_results:
                self.mlflow_logger.log_mcnemar_results(self.comparison_results)
        finally:
            self.mlflow_logger.end_run()

        # Per-model runs
        for name, model in self.trained_models.items():
            row = self.leaderboard[self.leaderboard["model"] == name]
            metrics = row.iloc[0].to_dict() if not row.empty else {}
            self.mlflow_logger.log_model_run(
                model_name=name,
                model=model,
                params=best_params.get(name, {}),
                metrics={k: v for k, v in metrics.items() if k != "model"},
                tags={
                    "pipeline":     "automl_hypothesis_driven",
                    "best":         str(name == self.best_model_name),
                    "fe_triggered": str(self.fe_triggered),
                },
                df=raw_df,
                source_name=source_name,
            )

    def _build_result(self) -> Dict[str, Any]:
        """Assemble the final result dict returned to the dashboard / UI."""
        mcnemar_summary = None
        if self.comparison_results:
            summary_df = self.comparison_results.get("summary")
            if isinstance(summary_df, pd.DataFrame):
                mcnemar_summary = summary_df.to_dict(orient="records")

        return {
            # Core ML outputs
            "leaderboard":            self.leaderboard,
            "best_model_name":        self.best_model_name,
            "best_model":             self.best_model,
            "class_names":            self.class_names,
            "feature_names":          self.feature_names,
            "trained_models":         self.trained_models,
            # Hypothesis-driven outputs
            "hypothesis_report":      self.hypothesis_report,
            "significant_features":   self.hypothesis_engine.get_significant_features(),
            "insignificant_features": self.hypothesis_engine.insignificant_features,
            "fe_triggered":           self.fe_triggered,
            "fe_summary":             self.fe_summary,
            "dynamic_config":         self.dynamic_cfg,
            # Statistical model comparison (post-training)
            "mcnemar_results":        self.comparison_results,
            "mcnemar_summary":        mcnemar_summary,
            # Data profile
            "profile":                self.profile,
        }

    # -------------------------------------------------------------------------
    # Prediction
    # -------------------------------------------------------------------------

    def predict(self, input_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generate predictions using the best trained model.

        Args:
            input_df: DataFrame with the same feature columns as training (minus target).

        Returns:
            Dict with predictions, probabilities, class names.
        """
        if self.best_model is None or self.preprocessor.pipeline is None:
            raise RuntimeError("Pipeline not trained. Call pipeline.run() first.")

        X = self.preprocessor.transform(input_df)
        preds = self.best_model.predict(X)
        labels = self.preprocessor.label_encoder.inverse_transform(preds)
        probs = None
        if hasattr(self.best_model, "predict_proba"):
            probs = self.best_model.predict_proba(X).tolist()

        return {
            "predictions":   labels.tolist(),
            "encoded":       preds.tolist(),
            "probabilities": probs,
            "class_names":   self.class_names,
            "model_used":    self.best_model_name,
        }
