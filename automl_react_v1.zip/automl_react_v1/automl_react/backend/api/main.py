"""
AutoML Classification System — FastAPI Backend
================================================
Full pipeline API with hypothesis-driven training, drift monitoring,
and prediction service.

Endpoints:
  POST /upload-data       — upload CSV/XLSX dataset
  POST /run-pipeline      — run full AutoML pipeline
  GET  /hypothesis        — get hypothesis test results
  GET  /models            — get trained model info + leaderboard
  GET  /comparison        — get McNemar comparison results
  GET  /drift             — run drift detection on new data
  POST /predict           — single row prediction
  POST /batch-predict     — CSV file batch prediction
  GET  /pipeline-status   — current pipeline run status
  GET  /health            — health check
"""

import io
import json
import os
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import uvicorn
from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from api.prediction_service import PredictionService
from api.pipeline_state import PipelineState
from src.utils.logger import get_logger

logger = get_logger(__name__)

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="AutoML Classification API",
    description="Hypothesis-driven AutoML with React frontend",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global state ──────────────────────────────────────────────────────────────
state = PipelineState()
prediction_service = PredictionService()


# ── Schemas ───────────────────────────────────────────────────────────────────
class PipelineConfig(BaseModel):
    target_col: str
    models: Optional[List[str]] = None
    tune: bool = True
    test_size: float = 0.2
    cv_folds: int = 5
    scaler: str = "standard"
    numeric_imputer: str = "median"
    categorical_imputer: str = "most_frequent"
    encoding: str = "onehot"
    imbalance_method: str = "none"
    hypothesis_alpha: float = 0.05
    hypothesis_min_ratio: float = 0.3
    optimization_metric: str = "f1_weighted"
    enable_tuning: bool = True
    enable_leakage_detection: bool = True
    n_tuning_trials: int = 30
    tuning_timeout: int = 120


class SinglePredictRequest(BaseModel):
    input: Dict[str, Any] = Field(..., description="Feature name → value mapping")
    model_name: Optional[str] = Field(None, description="Model to use (None = best model)")
    explain: bool = False

    class Config:
        json_schema_extra = {
            "example": {
                "input": {"age": 35, "income": 55000, "education": "Bachelor"},
                "model_name": None,
                "explain": False,
            }
        }


class DriftRequest(BaseModel):
    significance_level: float = 0.05
    n_bins: int = 10


def _safe_json(obj):
    """Recursively make objects JSON-serializable."""
    if isinstance(obj, dict):
        return {k: _safe_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_safe_json(v) for v in obj]
    if isinstance(obj, pd.DataFrame):
        return obj.where(pd.notnull(obj), None).to_dict(orient="records")
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
        return None
    return obj


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
async def health():
    return {
        "status": "healthy",
        "pipeline_trained": state.is_trained,
        "model_name": state.best_model_name,
        "data_loaded": state.data_loaded,
        "version": "2.0.0",
    }


# ── Data Upload ───────────────────────────────────────────────────────────────
@app.post("/upload-data", tags=["Data"])
async def upload_data(file: UploadFile = File(...)):
    """Upload CSV or Excel dataset. Returns column info and preview."""
    allowed = {".csv", ".xlsx", ".xls", ".parquet"}
    ext = Path(file.filename).suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type: {ext}. Use: {allowed}")

    content = await file.read()
    os.makedirs("data/raw", exist_ok=True)
    save_path = f"data/raw/_upload{ext}"

    with open(save_path, "wb") as f:
        f.write(content)

    # Parse for preview
    try:
        if ext == ".parquet":
            df = pd.read_parquet(save_path)
        elif ext in {".xlsx", ".xls"}:
            df = pd.read_excel(save_path)
        else:
            df = pd.read_csv(save_path)
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")

    state.upload_path = save_path
    state.data_loaded = True
    state.data_shape = df.shape
    state.column_info = _get_column_info(df)
    state.is_trained = False  # reset on new upload

    return {
        "filename": file.filename,
        "rows": int(df.shape[0]),
        "cols": int(df.shape[1]),
        "columns": state.column_info,
        "preview": _safe_json(df.head(5).where(pd.notnull(df.head(5)), None).to_dict(orient="records")),
        "save_path": save_path,
    }


def _get_column_info(df: pd.DataFrame) -> List[Dict]:
    info = []
    for col in df.columns:
        dtype = str(df[col].dtype)
        is_num = pd.api.types.is_numeric_dtype(df[col])
        n_unique = int(df[col].nunique())
        null_pct = round(float(df[col].isnull().mean() * 100), 2)
        info.append({
            "name": col,
            "dtype": dtype,
            "is_numeric": is_num,
            "n_unique": n_unique,
            "null_pct": null_pct,
            "sample_values": [str(v) for v in df[col].dropna().head(3).tolist()],
        })
    return info


# ── Run Pipeline ──────────────────────────────────────────────────────────────
@app.post("/run-pipeline", tags=["Pipeline"])
async def run_pipeline(
    config: PipelineConfig,
    background_tasks: BackgroundTasks,
):
    """Trigger the full AutoML pipeline. Returns run_id; poll /pipeline-status."""
    if not state.data_loaded or not state.upload_path:
        raise HTTPException(400, "No dataset uploaded. Call /upload-data first.")

    run_id = str(uuid.uuid4())[:8]
    state.run_id = run_id
    state.running = True
    state.progress = 0
    state.progress_log = []
    state.error = None

    background_tasks.add_task(_run_pipeline_task, config, run_id)
    return {"run_id": run_id, "status": "started", "message": "Pipeline started in background"}


async def _run_pipeline_task(config: PipelineConfig, run_id: str):
    """Background task that runs the full ML pipeline."""
    import asyncio
    try:
        from pipeline.training_pipeline import TrainingPipeline

        # Build config dict
        pipeline_config = _build_pipeline_config(config)

        def progress_cb(msg: str, pct: int):
            state.progress = pct
            state.progress_log.append({"pct": pct, "msg": msg})
            logger.info(f"[{run_id}] [{pct}%] {msg}")

        pipeline = TrainingPipeline.__new__(TrainingPipeline)
        pipeline.__init__.__func__(pipeline, "config/config.yaml") if hasattr(TrainingPipeline.__init__, '__func__') else None

        # Re-init with merged config
        _write_temp_config(pipeline_config)
        pipeline = TrainingPipeline("config/config.yaml")

        result = pipeline.run(
            file_path=state.upload_path,
            target_col=config.target_col,
            model_names=config.models,
            tune=config.tune,
            progress_callback=progress_cb,
        )

        # Store results in state
        state.pipeline_result = result
        state.is_trained = True
        state.best_model_name = result.get("best_model_name", "")
        state.feature_names = result.get("feature_names", [])
        state.class_names = result.get("class_names", [])
        state.trained_models = list(result.get("trained_models", {}).keys())

        # Wire prediction service to trained pipeline
        prediction_service.load_from_pipeline(pipeline)

        state.running = False
        state.progress = 100
        state.progress_log.append({"pct": 100, "msg": "Pipeline complete!"})
        logger.info(f"[{run_id}] Pipeline completed successfully.")

    except Exception as exc:
        import traceback
        state.error = str(exc)
        state.running = False
        state.progress_log.append({"pct": -1, "msg": f"ERROR: {exc}"})
        logger.error(f"[{run_id}] Pipeline failed: {traceback.format_exc()}")


def _build_pipeline_config(config: PipelineConfig) -> dict:
    return {
        "project": {"name": "AutoML", "version": "2.0.0", "random_state": 42},
        "data": {
            "raw_path": "data/raw",
            "processed_path": "data/processed",
            "test_size": config.test_size,
        },
        "preprocessing": {
            "numeric_imputer": config.numeric_imputer,
            "categorical_imputer": config.categorical_imputer,
            "scaler": config.scaler,
            "encoding": config.encoding,
        },
        "missing_values": {
            "numeric_strategy": config.numeric_imputer,
            "categorical_strategy": config.categorical_imputer,
        },
        "text_analysis": {"enabled": False, "text_cols": [], "tfidf_max_features": 100},
        "class_imbalance": {
            "method": config.imbalance_method,
            "enabled": config.imbalance_method != "none",
        },
        "leakage_detection": {"enabled": config.enable_leakage_detection},
        "models": {
            "enabled": config.models or [],
            "cross_validation_folds": config.cv_folds,
        },
        "tuning": {
            "enabled": config.enable_tuning,
            "n_trials": config.n_tuning_trials,
            "timeout": config.tuning_timeout,
            "metric": config.optimization_metric,
        },
        "evaluation": {
            "metrics": ["accuracy", "f1_weighted", "precision_weighted", "recall_weighted"],
            "threshold": 0.5,
        },
        "explainability": {"shap_enabled": True, "lime_enabled": True, "max_display_features": 20},
        "tracking": {
            "mlflow": {
                "enabled": True,
                "tracking_uri": "mlruns",
                "experiment_name": "automl_classification",
            }
        },
        "deployment": {"api": {"host": "0.0.0.0", "port": 8000}},
        "logging": {"level": "INFO"},
        "hypothesis": {
            "alpha": config.hypothesis_alpha,
            "min_significant_ratio": config.hypothesis_min_ratio,
            "enable_hypothesis_testing": True,
            "enable_feature_engineering": True,
            "enable_mcnemar_test": True,
        },
    }


def _write_temp_config(cfg: dict):
    import yaml
    Path("config").mkdir(exist_ok=True)
    with open("config/config.yaml", "w") as f:
        yaml.dump(cfg, f, default_flow_style=False)


# ── Pipeline Status ───────────────────────────────────────────────────────────
@app.get("/pipeline-status", tags=["Pipeline"])
async def pipeline_status():
    return {
        "run_id": state.run_id,
        "running": state.running,
        "progress": state.progress,
        "log": state.progress_log[-20:],  # last 20 messages
        "trained": state.is_trained,
        "error": state.error,
    }


# ── Hypothesis ────────────────────────────────────────────────────────────────
@app.get("/hypothesis", tags=["Results"])
async def get_hypothesis():
    if not state.is_trained or not state.pipeline_result:
        raise HTTPException(400, "Pipeline not yet run.")

    r = state.pipeline_result
    hyp = r.get("hypothesis_report", {})
    fe = r.get("fe_summary", {})

    return _safe_json({
        "hypothesis_report": hyp,
        "significant_features": r.get("significant_features", []),
        "insignificant_features": r.get("insignificant_features", []),
        "fe_triggered": r.get("fe_triggered", False),
        "fe_summary": fe,
        "n_significant": hyp.get("n_significant", 0),
        "n_features_total": hyp.get("n_features_total", 0),
        "significant_ratio": hyp.get("significant_ratio", 0),
        "feature_results": hyp.get("feature_results", {}),
        "alpha": hyp.get("alpha", 0.05),
    })


# ── Models / Leaderboard ──────────────────────────────────────────────────────
@app.get("/models", tags=["Results"])
async def get_models():
    if not state.is_trained or not state.pipeline_result:
        raise HTTPException(400, "Pipeline not yet run.")

    r = state.pipeline_result
    lb = r.get("leaderboard")
    lb_records = []
    if lb is not None and isinstance(lb, pd.DataFrame):
        lb_records = _safe_json(lb.where(pd.notnull(lb), None).to_dict(orient="records"))

    leakage_report = r.get("leakage_report")
    leakage_data = None
    if leakage_report is not None:
        try:
            leakage_df = leakage_report.to_dataframe()
            leakage_data = {
                "blocked": len(leakage_report.blocked),
                "warnings": len(leakage_report.warnings),
                "clean": len(leakage_report.clean),
                "details": _safe_json(leakage_df.to_dict(orient="records")),
            }
        except Exception:
            pass

    return _safe_json({
        "best_model_name": r.get("best_model_name", ""),
        "class_names": r.get("class_names", []),
        "feature_names": r.get("feature_names", []),
        "leaderboard": lb_records,
        "trained_models": list(r.get("trained_models", {}).keys()),
        "leakage_report": leakage_data,
        "cv_results": r.get("cv_results", {}),
        "test_metrics": r.get("test_metrics", {}),
        "train_metrics": r.get("train_metrics", {}),
        "dynamic_config": r.get("dynamic_config", {}),
    })


# ── Available models list ─────────────────────────────────────────────────────
@app.get("/available-models", tags=["Config"])
async def get_available_models():
    from src.models.registry import get_available_models as _get, MODEL_DESCRIPTIONS
    models = _get()
    return {
        "models": [
            {"name": m, "description": MODEL_DESCRIPTIONS.get(m, "")}
            for m in models
        ]
    }


# ── Comparison (McNemar) ──────────────────────────────────────────────────────
@app.get("/comparison", tags=["Results"])
async def get_comparison():
    if not state.is_trained or not state.pipeline_result:
        raise HTTPException(400, "Pipeline not yet run.")

    r = state.pipeline_result
    mc = r.get("mcnemar_results", {})
    summary = mc.get("summary")
    summary_records = []
    if isinstance(summary, pd.DataFrame):
        summary_records = _safe_json(
            summary.where(pd.notnull(summary), None).to_dict(orient="records")
        )
    pairwise = mc.get("pairwise", [])

    return _safe_json({
        "mcnemar_summary": summary_records,
        "pairwise": pairwise,
        "n_pairs_tested": mc.get("n_pairs_tested", 0),
        "reference_model": mc.get("reference_model", ""),
        "alpha": mc.get("alpha", 0.05),
    })


# ── Drift Detection ───────────────────────────────────────────────────────────
@app.post("/drift", tags=["Monitoring"])
async def run_drift(
    file: UploadFile = File(...),
    significance_level: float = Form(0.05),
):
    """Upload new production data CSV → detect distribution drift."""
    if not state.is_trained or not state.pipeline_result:
        raise HTTPException(400, "Pipeline not yet run. Train a model first.")

    content = await file.read()
    ext = Path(file.filename).suffix.lower()
    try:
        if ext in {".xlsx", ".xls"}:
            new_df = pd.read_excel(io.BytesIO(content))
        else:
            new_df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")

    try:
        from src.monitoring.drift_detection import DriftDetectionEngine
        from src.utils.config_loader import load_config

        original_df_path = state.upload_path
        ext_orig = Path(original_df_path).suffix.lower()
        if ext_orig == ".parquet":
            orig_df = pd.read_parquet(original_df_path)
        elif ext_orig in {".xlsx", ".xls"}:
            orig_df = pd.read_excel(original_df_path)
        else:
            orig_df = pd.read_csv(original_df_path)

        target_col = state.pipeline_result.get("target_col", "")
        feature_cols = [c for c in orig_df.columns if c != target_col]
        common = [c for c in feature_cols if c in new_df.columns]

        engine = DriftDetectionEngine(significance_level=significance_level)
        engine.fit(orig_df[common])
        report = engine.detect(new_df[common])
        report = _safe_json(report)

    except Exception as exc:
        raise HTTPException(500, f"Drift detection failed: {exc}")

    return report


# ── Predict (Single) ──────────────────────────────────────────────────────────
@app.post("/predict", tags=["Predictions"])
async def predict_single(request: SinglePredictRequest):
    """Single-row prediction using trained pipeline (no retraining)."""
    if not state.is_trained:
        raise HTTPException(400, "No trained model available. Run pipeline first.")

    try:
        result = prediction_service.predict_single(
            features=request.input,
            model_name=request.model_name,
        )
    except Exception as exc:
        raise HTTPException(422, f"Prediction failed: {exc}")

    return _safe_json(result)


# ── Batch Predict ─────────────────────────────────────────────────────────────
@app.post("/batch-predict", tags=["Predictions"])
async def batch_predict(
    file: UploadFile = File(...),
    model_name: Optional[str] = Form(None),
):
    """Upload CSV → return predictions for all rows."""
    if not state.is_trained:
        raise HTTPException(400, "No trained model available. Run pipeline first.")

    content = await file.read()
    ext = Path(file.filename).suffix.lower()
    try:
        if ext in {".xlsx", ".xls"}:
            df = pd.read_excel(io.BytesIO(content))
        else:
            df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")

    try:
        result = prediction_service.predict_batch(df, model_name=model_name)
    except Exception as exc:
        raise HTTPException(422, f"Batch prediction failed: {exc}")

    return _safe_json(result)


# ── Download batch results as CSV ─────────────────────────────────────────────
@app.post("/batch-predict/download", tags=["Predictions"])
async def batch_predict_download(
    file: UploadFile = File(...),
    model_name: Optional[str] = Form(None),
):
    """Same as /batch-predict but returns a downloadable CSV."""
    if not state.is_trained:
        raise HTTPException(400, "No trained model available. Run pipeline first.")

    content = await file.read()
    ext = Path(file.filename).suffix.lower()
    df = pd.read_csv(io.BytesIO(content)) if ext == ".csv" else pd.read_excel(io.BytesIO(content))

    result = prediction_service.predict_batch(df, model_name=model_name)
    out_df = df.copy()
    out_df["_prediction"] = result["predictions"]
    if result.get("probabilities"):
        probs = result["probabilities"]
        for cls in (result.get("class_names") or []):
            out_df[f"_prob_{cls}"] = [p.get(cls, 0) for p in probs]

    csv_str = out_df.to_csv(index=False)
    return StreamingResponse(
        io.StringIO(csv_str),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=predictions.csv"},
    )


# ── Feature schema for prediction form ───────────────────────────────────────
@app.get("/predict/schema", tags=["Predictions"])
async def get_prediction_schema():
    """Returns feature names + types for building the prediction form."""
    if not state.is_trained:
        raise HTTPException(400, "Pipeline not yet run.")

    r = state.pipeline_result
    feature_info = prediction_service.get_feature_schema()
    return {
        "features": feature_info,
        "class_names": r.get("class_names", []),
        "trained_models": list(r.get("trained_models", {}).keys()),
        "best_model": r.get("best_model_name", ""),
    }


# ── Startup: try to load saved artifacts ─────────────────────────────────────
@app.on_event("startup")
async def startup():
    try:
        prediction_service.try_load_from_disk()
        if prediction_service.is_ready:
            state.is_trained = True
            state.best_model_name = prediction_service.best_model_name
            state.feature_names = prediction_service.feature_names
            state.class_names = prediction_service.class_names
            logger.info("Loaded saved model artifacts on startup.")
    except Exception as e:
        logger.info(f"No saved artifacts found on startup: {e}")


if __name__ == "__main__":
    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=True)
