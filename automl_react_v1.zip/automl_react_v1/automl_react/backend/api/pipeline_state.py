"""
Pipeline State — shared in-memory state for the FastAPI server.
Single source of truth for pipeline results, progress, and model info.
"""
from typing import Any, Dict, List, Optional


class PipelineState:
    """Thread-safe-ish pipeline state container."""

    def __init__(self):
        # Data
        self.upload_path: Optional[str] = None
        self.data_loaded: bool = False
        self.data_shape: Optional[tuple] = None
        self.column_info: List[Dict] = []

        # Run state
        self.run_id: Optional[str] = None
        self.running: bool = False
        self.progress: int = 0
        self.progress_log: List[Dict] = []
        self.error: Optional[str] = None

        # Pipeline results
        self.is_trained: bool = False
        self.pipeline_result: Optional[Dict[str, Any]] = None
        self.best_model_name: Optional[str] = None
        self.feature_names: List[str] = []
        self.class_names: List[str] = []
        self.trained_models: List[str] = []

    def reset(self):
        self.__init__()
