"""
Prediction Service
==================
Uses the SAME trained pipeline (preprocessor + model) for inference.
Zero retraining. Supports:
  - Single prediction
  - Batch prediction (DataFrame input)
  - Multi-model selection
  - Feature schema introspection for dynamic form generation

All preprocessing (feature engineering transforms, encoding, scaling,
feature selection) is replicated exactly as during training via the
saved PreprocessingPipeline object.
"""
import os
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


class PredictionService:
    """
    Wraps trained models and the preprocessing pipeline.
    Called after TrainingPipeline.run() completes — never triggers retraining.
    """

    def __init__(self):
        self._pipeline = None            # reference to TrainingPipeline instance
        self._preprocessor = None       # PreprocessingPipeline
        self._trained_models: Dict[str, Any] = {}
        self._best_model_name: Optional[str] = None
        self._best_model = None
        self._class_names: List[str] = []
        self._feature_names: List[str] = []
        self._original_columns: List[Dict] = []   # name + dtype info
        self._label_encoder = None

    # ── Wiring ────────────────────────────────────────────────────────────────

    def load_from_pipeline(self, pipeline) -> None:
        """
        Called by the API after TrainingPipeline.run() completes.
        Stores references — does NOT copy model weights.
        """
        self._pipeline = pipeline
        self._preprocessor = pipeline.preprocessor
        self._trained_models = pipeline.trained_models or {}
        self._best_model_name = pipeline.best_model_name
        self._best_model = pipeline.best_model
        self._class_names = pipeline.class_names or []
        self._feature_names = pipeline.feature_names or []
        self._label_encoder = pipeline.preprocessor.label_encoder

        # Build feature schema from the working DataFrame
        if pipeline.df is not None:
            target = None
            # Infer target col by exclusion (df has target, feature_names don't)
            all_cols = list(pipeline.df.columns)
            non_feature = [c for c in all_cols if c not in self._feature_names]
            # The original feature columns (before OHE expansion)
            self._original_columns = _infer_original_columns(pipeline.df, non_feature)

        logger.info(
            f"PredictionService ready: model={self._best_model_name}, "
            f"features={len(self._feature_names)}, classes={self._class_names}"
        )

    def try_load_from_disk(self) -> None:
        """Attempt to load persisted artifacts from models/ directory."""
        model_path = os.getenv("MODEL_PATH", "models/best_model.pkl")
        prep_path = os.getenv("PREPROCESSOR_PATH", "models/preprocessor.pkl")

        if not Path(model_path).exists() or not Path(prep_path).exists():
            raise FileNotFoundError("Saved artifacts not found on disk.")

        from src.models.selector import ModelSelector
        from src.preprocessing.pipeline import PreprocessingPipeline

        name, model = ModelSelector.load(model_path)
        self._best_model_name = name
        self._best_model = model
        self._trained_models = {name: model}

        self._preprocessor = PreprocessingPipeline.load(prep_path)
        self._feature_names = self._preprocessor.feature_names_out or []
        self._label_encoder = self._preprocessor.label_encoder
        if self._label_encoder:
            self._class_names = [str(c) for c in self._label_encoder.classes_]

        logger.info(f"Loaded artifacts from disk: {name}")

    @property
    def is_ready(self) -> bool:
        return self._best_model is not None and self._preprocessor is not None

    @property
    def best_model_name(self) -> str:
        return self._best_model_name or ""

    @property
    def feature_names(self) -> List[str]:
        return self._feature_names

    @property
    def class_names(self) -> List[str]:
        return self._class_names

    # ── Core prediction helpers ───────────────────────────────────────────────

    def _get_model(self, model_name: Optional[str]):
        if model_name and model_name in self._trained_models:
            return model_name, self._trained_models[model_name]
        return self._best_model_name, self._best_model

    def _transform(self, df: pd.DataFrame) -> np.ndarray:
        """Apply the SAME preprocessing pipeline used during training."""
        if self._preprocessor is None:
            raise RuntimeError("Preprocessor not loaded.")
        return self._preprocessor.transform(df)

    def _decode_predictions(self, encoded: np.ndarray) -> List[str]:
        if self._label_encoder is not None:
            return [str(v) for v in self._label_encoder.inverse_transform(encoded)]
        return [str(v) for v in encoded]

    def _build_proba_dict(self, proba_row: np.ndarray) -> Dict[str, float]:
        return {
            self._class_names[i]: round(float(p), 6)
            for i, p in enumerate(proba_row)
        }

    # ── Single prediction ─────────────────────────────────────────────────────

    def predict_single(
        self,
        features: Dict[str, Any],
        model_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Single-row prediction.

        Args:
            features: {feature_name: value} dict from the UI form.
            model_name: Optional — defaults to best model.

        Returns:
            {
                "prediction": "class_label",
                "probability": 0.87,          # max class probability
                "probabilities": {cls: prob},  # all class probs
                "model_used": "extra_trees",
                "class_names": [...],
            }
        """
        if not self.is_ready:
            raise RuntimeError("No trained model. Run pipeline first.")

        df = pd.DataFrame([features])
        X = self._transform(df)

        name, model = self._get_model(model_name)
        encoded = model.predict(X)
        labels = self._decode_predictions(encoded)
        label = labels[0]

        probs = None
        max_prob = None
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X)[0]
            probs = self._build_proba_dict(proba)
            max_prob = round(float(proba.max()), 6)

        return {
            "prediction": label,
            "prediction_encoded": int(encoded[0]),
            "probability": max_prob,
            "probabilities": probs,
            "model_used": name,
            "class_names": self._class_names,
        }

    # ── Batch prediction ──────────────────────────────────────────────────────

    def predict_batch(
        self,
        df: pd.DataFrame,
        model_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Batch prediction for a DataFrame.

        Returns:
            {
                "predictions": ["cls1", "cls2", ...],
                "probabilities": [{cls: prob}, ...],
                "count": N,
                "model_used": "...",
                "class_names": [...],
                "records": [{...original cols + _prediction + _prob_*}],
            }
        """
        if not self.is_ready:
            raise RuntimeError("No trained model. Run pipeline first.")

        X = self._transform(df)
        name, model = self._get_model(model_name)
        encoded = model.predict(X)
        labels = self._decode_predictions(encoded)

        probs = None
        if hasattr(model, "predict_proba"):
            prob_arr = model.predict_proba(X)
            probs = [self._build_proba_dict(row) for row in prob_arr]

        # Build enriched records for table display
        records = df.where(pd.notnull(df), None).to_dict(orient="records")
        for i, rec in enumerate(records):
            rec["_prediction"] = labels[i]
            if probs:
                rec["_confidence"] = round(float(max(probs[i].values())), 4)

        return {
            "predictions": labels,
            "probabilities": probs,
            "count": len(labels),
            "model_used": name,
            "class_names": self._class_names,
            "records": records,
        }

    # ── Feature schema ────────────────────────────────────────────────────────

    def get_feature_schema(self) -> List[Dict]:
        """
        Return feature info needed to generate the prediction form dynamically.
        Uses the original (pre-OHE) columns so the form shows sensible inputs.
        """
        if self._original_columns:
            return self._original_columns

        # Fallback: return post-processed feature names
        return [{"name": f, "dtype": "float64", "is_numeric": True} for f in self._feature_names]


# ── Helpers ────────────────────────────────────────────────────────────────────

def _infer_original_columns(df: pd.DataFrame, exclude: List[str]) -> List[Dict]:
    """Extract name + type info for all non-target columns."""
    result = []
    for col in df.columns:
        if col in exclude:
            continue
        dtype = str(df[col].dtype)
        is_num = pd.api.types.is_numeric_dtype(df[col])
        unique_vals = df[col].dropna().unique().tolist()
        result.append({
            "name": col,
            "dtype": dtype,
            "is_numeric": is_num,
            "unique_values": (
                [str(v) for v in unique_vals[:20]]   # cap at 20 for dropdowns
                if not is_num and len(unique_vals) <= 20
                else None
            ),
            "min": float(df[col].min()) if is_num and len(df[col].dropna()) > 0 else None,
            "max": float(df[col].max()) if is_num and len(df[col].dropna()) > 0 else None,
            "mean": float(df[col].mean()) if is_num and len(df[col].dropna()) > 0 else None,
        })
    return result
