/**
 * API Service Layer
 * All communication with the FastAPI backend.
 * No MLflow. No direct DB calls. Clean JSON in/out.
 */

const BASE = '/api'

async function request(method, path, body, isForm = false) {
  const opts = { method, headers: {} }
  if (body && !isForm) {
    opts.headers['Content-Type'] = 'application/json'
    opts.body = JSON.stringify(body)
  } else if (isForm) {
    opts.body = body  // FormData — browser sets content-type with boundary
  }
  const res = await fetch(`${BASE}${path}`, opts)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  return res.json()
}

// ── Data ──────────────────────────────────────────────────────────────────────
export const uploadData = (file) => {
  const fd = new FormData()
  fd.append('file', file)
  return request('POST', '/upload-data', fd, true)
}

// ── Pipeline ──────────────────────────────────────────────────────────────────
export const runPipeline = (config) => request('POST', '/run-pipeline', config)

export const getPipelineStatus = () => request('GET', '/pipeline-status')

// ── Results ───────────────────────────────────────────────────────────────────
export const getHypothesis  = () => request('GET', '/hypothesis')
export const getModels      = () => request('GET', '/models')
export const getComparison  = () => request('GET', '/comparison')

export const getAvailableModels = () => request('GET', '/available-models')

// ── Predictions ───────────────────────────────────────────────────────────────
/**
 * Single prediction
 * @param {{ feature1: value1, ... }} features
 * @param {string|null} modelName
 * @returns {{ prediction, probability, probabilities, model_used }}
 */
export const predict = (features, modelName = null) =>
  request('POST', '/predict', { input: features, model_name: modelName })

/**
 * Batch prediction — uploads a CSV file
 * @param {File} file
 * @param {string|null} modelName
 */
export const batchPredict = (file, modelName = null) => {
  const fd = new FormData()
  fd.append('file', file)
  if (modelName) fd.append('model_name', modelName)
  return request('POST', '/batch-predict', fd, true)
}

/**
 * Get feature schema for building prediction form
 */
export const getPredictSchema = () => request('GET', '/predict/schema')

// ── Monitoring / Drift ────────────────────────────────────────────────────────
/**
 * Upload production CSV → drift report
 * @param {File} file
 * @param {number} significanceLevel
 */
export const runDrift = (file, significanceLevel = 0.05) => {
  const fd = new FormData()
  fd.append('file', file)
  fd.append('significance_level', significanceLevel)
  return request('POST', '/drift', fd, true)
}

// ── Health ────────────────────────────────────────────────────────────────────
export const getHealth = () => request('GET', '/health')
