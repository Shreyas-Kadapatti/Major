import React from 'react'
import { Loader2, AlertCircle, Info } from 'lucide-react'
import clsx from 'clsx'

// ── Page header ────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="flex items-start justify-between mb-8">
      <div>
        <h1 className="text-2xl font-bold text-white">{title}</h1>
        {subtitle && <p className="text-slate-400 text-sm mt-1 max-w-2xl">{subtitle}</p>}
      </div>
      {children && <div className="shrink-0 ml-4">{children}</div>}
    </div>
  )
}

// ── Section divider ────────────────────────────────────────────────────────
export function Section({ title, subtitle, children, className }) {
  return (
    <div className={clsx('mb-8', className)}>
      {title && (
        <div className="mb-4">
          <h2 className="text-base font-semibold text-white">{title}</h2>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
      )}
      {children}
    </div>
  )
}

// ── Stat card ──────────────────────────────────────────────────────────────
export function StatCard({ label, value, sub, color = 'default', icon: Icon }) {
  const colors = {
    default: 'text-white',
    green:   'text-emerald-400',
    yellow:  'text-amber-400',
    red:     'text-red-400',
    blue:    'text-blue-400',
    purple:  'text-purple-400',
  }
  return (
    <div className="stat-card">
      <div className="flex items-center justify-between mb-2">
        <span className="stat-label">{label}</span>
        {Icon && <Icon size={16} className="text-slate-500" />}
      </div>
      <div className={clsx('stat-value', colors[color])}>{value ?? '—'}</div>
      {sub && <div className="text-xs text-slate-500 mt-0.5">{sub}</div>}
    </div>
  )
}

// ── Data table ─────────────────────────────────────────────────────────────
export function DataTable({ columns, rows, maxRows, emptyText = 'No data' }) {
  const displayRows = maxRows ? rows.slice(0, maxRows) : rows
  if (!rows?.length) return (
    <div className="card flex items-center justify-center py-12 text-slate-500 text-sm">
      {emptyText}
    </div>
  )
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            {columns.map(c => (
              <th key={c.key ?? c}>{c.label ?? c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {displayRows.map((row, i) => (
            <tr key={i}>
              {columns.map(c => {
                const key = c.key ?? c
                const val = row[key]
                return (
                  <td key={key}>
                    {c.render ? c.render(val, row) : String(val ?? '—')}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {maxRows && rows.length > maxRows && (
        <div className="px-4 py-2 text-xs text-slate-500 bg-surface-muted">
          Showing {maxRows} of {rows.length} rows
        </div>
      )}
    </div>
  )
}

// ── Alert banners ──────────────────────────────────────────────────────────
export function Alert({ type = 'info', title, children }) {
  const styles = {
    info:    'bg-blue-950/60 border-blue-700/50 text-blue-300',
    success: 'bg-emerald-950/60 border-emerald-700/50 text-emerald-300',
    warning: 'bg-amber-950/60 border-amber-700/50 text-amber-300',
    error:   'bg-red-950/60 border-red-700/50 text-red-300',
  }
  const icons = { info: Info, success: Info, warning: AlertCircle, error: AlertCircle }
  const Icon = icons[type]
  return (
    <div className={clsx('flex gap-3 p-4 rounded-xl border text-sm', styles[type])}>
      <Icon size={16} className="shrink-0 mt-0.5" />
      <div>
        {title && <div className="font-semibold mb-0.5">{title}</div>}
        {children}
      </div>
    </div>
  )
}

// ── Loading spinner ────────────────────────────────────────────────────────
export function Spinner({ size = 20, className }) {
  return <Loader2 size={size} className={clsx('animate-spin text-brand-400', className)} />
}

// ── Empty state ────────────────────────────────────────────────────────────
export function EmptyState({ icon: Icon, title, sub, action }) {
  return (
    <div className="card flex flex-col items-center justify-center py-16 text-center">
      {Icon && <Icon size={40} className="text-slate-600 mb-4" strokeWidth={1.2} />}
      <h3 className="text-slate-300 font-medium mb-1">{title}</h3>
      {sub && <p className="text-slate-500 text-sm max-w-xs">{sub}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

// ── Progress bar ───────────────────────────────────────────────────────────
export function ProgressBar({ value, label, color = 'brand' }) {
  const colors = {
    brand:   'bg-brand-600',
    green:   'bg-emerald-500',
    yellow:  'bg-amber-500',
    red:     'bg-red-500',
  }
  return (
    <div>
      {label && (
        <div className="flex justify-between text-xs text-slate-400 mb-1">
          <span>{label}</span>
          <span>{Math.round(value)}%</span>
        </div>
      )}
      <div className="h-2 bg-surface rounded-full overflow-hidden">
        <div
          className={clsx('h-full rounded-full transition-all duration-500', colors[color])}
          style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
        />
      </div>
    </div>
  )
}

// ── Badge ─────────────────────────────────────────────────────────────────
export function Badge({ label, color = 'blue' }) {
  const map = { blue: 'badge-blue', green: 'badge-green', yellow: 'badge-yellow', red: 'badge-red', purple: 'badge-purple' }
  return <span className={map[color] ?? 'badge-blue'}>{label}</span>
}

// ── Collapsible card ──────────────────────────────────────────────────────
export function Collapse({ title, badge, children, defaultOpen = false }) {
  const [open, setOpen] = React.useState(defaultOpen)
  return (
    <div className="card">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between text-left"
      >
        <span className="font-medium text-white">{title}</span>
        <div className="flex items-center gap-2">
          {badge}
          <span className="text-slate-500 text-xs">{open ? '▲' : '▼'}</span>
        </div>
      </button>
      {open && <div className="mt-4 border-t border-surface-border pt-4">{children}</div>}
    </div>
  )
}
