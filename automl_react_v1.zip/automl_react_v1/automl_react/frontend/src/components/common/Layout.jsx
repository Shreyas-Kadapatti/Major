import React, { useEffect } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import {
  Database, FlaskConical, Settings2, Cpu, BarChart3,
  Zap, Activity, Brain, CheckCircle2, Circle, Loader2,
} from 'lucide-react'
import { usePipeline } from '../../hooks/usePipeline.jsx'
import clsx from 'clsx'

const NAV = [
  { to: '/data',          label: 'Data',                  icon: Database     },
  
  { to: '/configuration', label: 'Configuration',         icon: Settings2    },
  { to: '/hypothesis',    label: 'Hypothesis',            icon: FlaskConical  },
  { to: '/training',      label: 'Training',              icon: Cpu          },
  { to: '/evaluation',    label: 'Evaluation',            icon: BarChart3    },
  { to: '/monitoring',    label: 'Monitoring',            icon: Activity     },
]

export default function Layout({ children }) {
  const { isTrained, isRunning, uploadInfo, refreshHealth, health } = usePipeline()
  const location = useLocation()

  useEffect(() => {
    refreshHealth().catch(() => {})
    // eslint-disable-next-line
  }, [])

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── Sidebar ──────────────────────────────────────────────── */}
      <aside className="w-60 shrink-0 flex flex-col bg-surface-card border-r border-surface-border overflow-y-auto">
        {/* Logo */}
        <div className="px-5 py-6 border-b border-surface-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center">
              <Brain size={18} className="text-white" />
            </div>
            <div>
              <div className="font-bold text-white text-sm leading-tight">AutoML</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-widest">Classification v2</div>
            </div>
          </div>
        </div>

        {/* Nav links */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                clsx(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150',
                  isActive
                    ? 'bg-brand-600/20 text-brand-400 border border-brand-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-surface-muted'
                )
              }
            >
              <Icon size={16} strokeWidth={1.8} />
              {label}
              {to === '/training' && isRunning && (
                <Loader2 size={12} className="ml-auto animate-spin text-amber-400" />
              )}
              {to === '/predictions' && isTrained && (
                <span className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-400" />
              )}
            </NavLink>
          ))}
        </nav>

        {/* Status footer */}
        <div className="p-4 border-t border-surface-border space-y-2">
          <StatusRow
            label="Dataset"
            value={uploadInfo ? `${uploadInfo.rows?.toLocaleString()} rows` : 'Not loaded'}
            ok={!!uploadInfo}
          />
          <StatusRow
            label="Model"
            value={health?.model_name || (isTrained ? 'Ready' : 'Not trained')}
            ok={isTrained}
            loading={isRunning}
          />
          <StatusRow
            label="API"
            value={health?.status === 'healthy' ? 'Connected' : 'Checking...'}
            ok={health?.status === 'healthy'}
          />
        </div>
      </aside>

      {/* ── Main content ─────────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto bg-surface">
        <div className="max-w-6xl mx-auto px-8 py-8 fade-in">
          {children}
        </div>
      </main>
    </div>
  )
}

function StatusRow({ label, value, ok, loading }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-slate-500">{label}</span>
      <span className={clsx('flex items-center gap-1', ok ? 'text-emerald-400' : 'text-slate-500')}>
        {loading
          ? <Loader2 size={10} className="animate-spin text-amber-400" />
          : ok
            ? <CheckCircle2 size={10} />
            : <Circle size={10} />
        }
        {value}
      </span>
    </div>
  )
}
