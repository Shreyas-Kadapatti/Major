import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/common/Layout.jsx'
import DataPage from './pages/DataPage.jsx'
import HypothesisPage from './pages/HypothesisPage.jsx'
import ConfigurationPage from './pages/ConfigurationPage.jsx'
import TrainingPage from './pages/TrainingPage.jsx'
import EvaluationPage from './pages/EvaluationPage.jsx'
import PredictionsPage from './pages/PredictionsPage.jsx'
import MonitoringPage from './pages/MonitoringPage.jsx'
import { PipelineProvider } from './hooks/usePipeline.jsx'

export default function App() {
  return (
    <PipelineProvider>
      <Layout>
        <Routes>
          <Route path="/"              element={<Navigate to="/data" replace />} />
          <Route path="/data"          element={<DataPage />} />
          <Route path="/configuration" element={<ConfigurationPage />} />
          <Route path="/hypothesis"    element={<HypothesisPage />} />
          <Route path="/training"      element={<TrainingPage />} />
          <Route path="/evaluation"    element={<EvaluationPage />} />
          <Route path="/monitoring"    element={<MonitoringPage />} />
          <Route path="*"              element={<Navigate to="/data" replace />} />
        </Routes>
      </Layout>
    </PipelineProvider>
  )
}
