import React, { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Upload, FileText, Table2, CheckCircle2 } from 'lucide-react'
import { PageHeader, Section, StatCard, DataTable, Alert, Spinner } from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'

export default function DataPage() {
  const { uploadFile, uploadInfo } = usePipeline()
  const [dragging, setDragging]   = useState(false)
  const [loading,  setLoading]    = useState(false)
  const [error,    setError]      = useState(null)
  const navigate = useNavigate()

  const handleFile = useCallback(async (file) => {
    setError(null)
    setLoading(true)
    try {
      await uploadFile(file)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [uploadFile])

  const onDrop = (e) => {
    e.preventDefault(); setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }

  const onInput = (e) => {
    const file = e.target.files[0]
    if (file) handleFile(file)
  }

  const colCols = [
    { key: 'name',         label: 'Column' },
    { key: 'dtype',        label: 'Type' },
    { key: 'null_pct',     label: 'Null %', render: v => `${v}%` },
    { key: 'n_unique',     label: 'Unique' },
    { key: 'sample_values',label: 'Samples', render: v => (v || []).join(', ') },
  ]

  return (
    <div>
      <PageHeader
        title="Data"
        subtitle="Upload a CSV or Excel dataset to begin the AutoML pipeline."
      />

      {/* Upload zone */}
      <Section title="Upload Dataset">
        <label
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={`
            flex flex-col items-center justify-center gap-4 p-12 rounded-xl border-2 border-dashed
            cursor-pointer transition-all duration-200
            ${dragging
              ? 'border-brand-500 bg-brand-600/10'
              : 'border-surface-border hover:border-brand-600/60 hover:bg-surface-muted/40'
            }
          `}
        >
          <input type="file" className="hidden" accept=".csv,.xlsx,.xls,.parquet" onChange={onInput} />
          {loading
            ? <Spinner size={40} />
            : <Upload size={40} className="text-slate-500" strokeWidth={1.2} />
          }
          <div className="text-center">
            <div className="font-medium text-slate-200">
              {loading ? 'Uploading...' : 'Drop your dataset here'}
            </div>
            <div className="text-xs text-slate-500 mt-1">CSV, Excel, Parquet · No size limit</div>
          </div>
        </label>
      </Section>

      {error && <Alert type="error" title="Upload failed">{error}</Alert>}

      {/* Result */}
      {uploadInfo && (
        <div className="fade-in space-y-6">
          <Alert type="success" title="Dataset loaded successfully">
            {uploadInfo.filename} — {uploadInfo.rows?.toLocaleString()} rows × {uploadInfo.cols} columns
          </Alert>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard label="Rows"    value={uploadInfo.rows?.toLocaleString()}  icon={Table2}   />
            <StatCard label="Columns" value={uploadInfo.cols}                     icon={FileText} />
            <StatCard
              label="Numeric"
              value={uploadInfo.columns?.filter(c => c.is_numeric).length}
              color="blue"
            />
            <StatCard
              label="Categorical"
              value={uploadInfo.columns?.filter(c => !c.is_numeric).length}
              color="purple"
            />
          </div>

          {/* Column info */}
          <Section title="Column Overview">
            <DataTable columns={colCols} rows={uploadInfo.columns || []} maxRows={30} />
          </Section>

          {/* Preview */}
          {uploadInfo.preview?.length > 0 && (
            <Section title="Data Preview (first 5 rows)">
              <DataTable
                columns={Object.keys(uploadInfo.preview[0]).map(k => ({ key: k, label: k }))}
                rows={uploadInfo.preview}
              />
            </Section>
          )}

          <div className="flex justify-end">
            <button className="btn-primary" onClick={() => navigate('/configuration')}>
              Continue to Configuration →
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
