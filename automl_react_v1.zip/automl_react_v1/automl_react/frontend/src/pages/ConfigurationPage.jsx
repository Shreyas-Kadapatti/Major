import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Settings2 } from 'lucide-react'
import { PageHeader, Section, Alert, EmptyState, Spinner } from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'
import { getAvailableModels } from '../services/api.js'

const SCALERS       = ['standard', 'minmax', 'robust']
const IMPUTERS      = ['median', 'mean', 'most_frequent']
const CAT_IMPUTERS  = ['most_frequent', 'constant']
const IMBALANCE     = ['none', 'random_over', 'random_under', 'smote']
const OPT_METRICS   = ['f1_weighted', 'accuracy', 'roc_auc', 'precision_weighted', 'recall_weighted']
const CV_FOLDS      = [3, 5, 10]

export default function ConfigurationPage() {
  const { uploadInfo, setPipelineConfig, pipelineConfig } = usePipeline()
  const navigate = useNavigate()
  const [availableModels, setAvailableModels] = useState([])
  const [loadingModels, setLoadingModels]     = useState(false)

  const [cfg, setCfg] = useState(pipelineConfig || {
    target_col:            '',
    models:                [],
    tune:                  true,
    test_size:             0.2,
    cv_folds:              5,
    scaler:                'standard',
    numeric_imputer:       'median',
    categorical_imputer:   'most_frequent',
    encoding:              'onehot',
    imbalance_method:      'none',
    hypothesis_alpha:      0.05,
    hypothesis_min_ratio:  0.3,
    optimization_metric:   'f1_weighted',
    enable_tuning:         true,
    enable_leakage_detection: true,
    n_tuning_trials:       30,
    tuning_timeout:        120,
  })

  useEffect(() => {
    setLoadingModels(true)
    getAvailableModels()
      .then(r => {
        setAvailableModels(r.models || [])
        if (!cfg.models.length) {
          const defaults = ['random_forest', 'extra_trees', 'gradient_boosting',
                            'adaboost', 'lda', 'logistic_regression']
          setCfg(c => ({ ...c, models: defaults.filter(d => (r.models||[]).some(m => m.name === d)) }))
        }
      })
      .catch(() => {})
      .finally(() => setLoadingModels(false))
  }, [])

  const set = (k, v) => setCfg(c => ({ ...c, [k]: v }))

  const toggleModel = (name) =>
    setCfg(c => ({
      ...c,
      models: c.models.includes(name)
        ? c.models.filter(m => m !== name)
        : [...c.models, name],
    }))

  const save = () => {
    setPipelineConfig(cfg)
    navigate('/training')
  }

  if (!uploadInfo) return (
    <div>
      <PageHeader title="Configuration" />
      <EmptyState
        icon={Settings2}
        title="No dataset loaded"
        sub="Upload a dataset first before configuring the pipeline."
        action={<button className="btn-primary" onClick={() => navigate('/data')}>Go to Data →</button>}
      />
    </div>
  )

  const targetCols = uploadInfo.columns?.map(c => c.name) || []

  return (
    <div>
      <PageHeader
        title="Configuration"
        subtitle="Configure the pipeline before training. All settings feed into the hypothesis-driven AutoML pipeline."
      />

      <div className="space-y-6">
        {/* Target column */}
        <Section title="Target Column" subtitle="The column your model will predict.">
          <div className="card">
            <label className="label">Select target column *</label>
            <select className="select max-w-xs" value={cfg.target_col} onChange={e => set('target_col', e.target.value)}>
              <option value="">— choose —</option>
              {targetCols.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </Section>

        {/* Model selection */}
        <Section title="Models to Train" subtitle={`${cfg.models.length} of ${availableModels.length} selected`}>
          <div className="card">
            {loadingModels
              ? <Spinner />
              : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {availableModels.map(({ name, description }) => {
                    const selected = cfg.models.includes(name)
                    return (
                      <button
                        key={name}
                        onClick={() => toggleModel(name)}
                        title={description}
                        className={`
                          text-left px-3 py-2.5 rounded-lg border text-sm transition-all
                          ${selected
                            ? 'border-brand-500 bg-brand-600/20 text-brand-300'
                            : 'border-surface-border text-slate-400 hover:border-slate-500 hover:text-slate-200'
                          }
                        `}
                      >
                        <div className="font-medium truncate">{name.replace(/_/g, ' ')}</div>
                        <div className="text-[10px] text-slate-500 truncate mt-0.5">{description?.slice(0, 45)}</div>
                      </button>
                    )
                  })}
                </div>
              )
            }
          </div>
        </Section>

        {/* Preprocessing */}
        <Section title="Preprocessing">
          <div className="card grid grid-cols-2 sm:grid-cols-4 gap-5">
            <div>
              <label className="label">Scaler</label>
              <select className="select" value={cfg.scaler} onChange={e => set('scaler', e.target.value)}>
                {SCALERS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Numeric Imputer</label>
              <select className="select" value={cfg.numeric_imputer} onChange={e => set('numeric_imputer', e.target.value)}>
                {IMPUTERS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Categorical Imputer</label>
              <select className="select" value={cfg.categorical_imputer} onChange={e => set('categorical_imputer', e.target.value)}>
                {CAT_IMPUTERS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Imbalance Handling</label>
              <select className="select" value={cfg.imbalance_method} onChange={e => set('imbalance_method', e.target.value)}>
                {IMBALANCE.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </Section>

        {/* Hypothesis */}
        <Section title="Hypothesis Testing">
          <div className="card grid grid-cols-2 gap-5">
            <div>
              <label className="label">Alpha (significance level)</label>
              <input className="input" type="number" step="0.01" min="0.01" max="0.1"
                value={cfg.hypothesis_alpha}
                onChange={e => set('hypothesis_alpha', parseFloat(e.target.value))} />
            </div>
            <div>
              <label className="label">Min Significant Ratio (trigger FE below)</label>
              <input className="input" type="number" step="0.05" min="0" max="1"
                value={cfg.hypothesis_min_ratio}
                onChange={e => set('hypothesis_min_ratio', parseFloat(e.target.value))} />
            </div>
          </div>
        </Section>

        {/* Training */}
        <Section title="Training & Tuning">
          <div className="card grid grid-cols-2 sm:grid-cols-4 gap-5">
            <div>
              <label className="label">Test Size</label>
              <input className="input" type="number" step="0.05" min="0.1" max="0.4"
                value={cfg.test_size} onChange={e => set('test_size', parseFloat(e.target.value))} />
            </div>
            <div>
              <label className="label">CV Folds</label>
              <select className="select" value={cfg.cv_folds} onChange={e => set('cv_folds', parseInt(e.target.value))}>
                {CV_FOLDS.map(n => <option key={n}>{n}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Optimization Metric</label>
              <select className="select" value={cfg.optimization_metric} onChange={e => set('optimization_metric', e.target.value)}>
                {OPT_METRICS.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Tuning Trials</label>
              <input className="input" type="number" min="5" max="200"
                value={cfg.n_tuning_trials} onChange={e => set('n_tuning_trials', parseInt(e.target.value))} />
            </div>
          </div>
          <div className="card mt-3 flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer text-sm">
              <input type="checkbox" className="w-4 h-4 accent-brand-500"
                checked={cfg.enable_tuning} onChange={e => set('enable_tuning', e.target.checked)} />
              <span className="text-slate-300">Enable Hyperparameter Tuning</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer text-sm">
              <input type="checkbox" className="w-4 h-4 accent-brand-500"
                checked={cfg.enable_leakage_detection} onChange={e => set('enable_leakage_detection', e.target.checked)} />
              <span className="text-slate-300">Enable Leakage Detection</span>
            </label>
          </div>
        </Section>

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <button className="btn-secondary" onClick={() => navigate('/data')}>← Back</button>
          <button
            className="btn-primary"
            disabled={!cfg.target_col || cfg.models.length === 0}
            onClick={save}
          >
            Save & Go to Training →
          </button>
        </div>
      </div>
    </div>
  )
}
