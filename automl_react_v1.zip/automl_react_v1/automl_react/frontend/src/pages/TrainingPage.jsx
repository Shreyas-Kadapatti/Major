import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Cpu, Play, Trophy } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell
} from 'recharts'
import {
  PageHeader, Section, StatCard, DataTable, Alert,
  EmptyState, ProgressBar, Badge, Collapse, Spinner,
} from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'

const METRIC_COLS = [
  { key: 'model', label: 'Model' },
  { key: 'accuracy',           label: 'Accuracy',   render: v => fmt(v) },
  { key: 'f1_weighted',        label: 'F1',         render: v => fmt(v) },
  { key: 'precision_weighted', label: 'Precision',  render: v => fmt(v) },
  { key: 'recall_weighted',    label: 'Recall',     render: v => fmt(v) },
]
const fmt = v => (typeof v === 'number' ? v.toFixed(4) : v ?? '—')

const CHART_COLORS = ['#6366f1','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16']

export default function TrainingPage() {
  const { pipelineConfig, status, isTrained, isRunning, modelsData,
          hypothesisData, comparisonData, startPipeline, uploadInfo } = usePipeline()
  const [launching, setLaunching] = useState(false)
  const [error,     setError]     = useState(null)
  const navigate = useNavigate()

  const launch = async () => {
    if (!pipelineConfig) return
    setError(null); setLaunching(true)
    try { await startPipeline(pipelineConfig) }
    catch (e) { setError(e.message) }
    finally { setLaunching(false) }
  }

  const lb = modelsData?.leaderboard || []
  const bestName = modelsData?.best_model_name || ''
  const chartData = lb.map((r, i) => ({
    name: r.model?.replace(/_/g, ' ') || '',
    f1: typeof r.f1_weighted === 'number' ? parseFloat(r.f1_weighted.toFixed(4)) : 0,
    color: CHART_COLORS[i % CHART_COLORS.length],
    best: r.model === bestName,
  }))

  const leakageData = modelsData?.leakage_report

  return (
    <div>
      <PageHeader
        title="Training"
        subtitle="Run the full hypothesis-driven AutoML pipeline: Hypothesis → Feature Engineering → Training → McNemar."
      >
        {isTrained && (
          <button className="btn-secondary" onClick={() => navigate('/evaluation')}>
            View Evaluation →
          </button>
        )}
      </PageHeader>

      {!pipelineConfig && (
        <EmptyState
          icon={Cpu}
          title="No configuration"
          sub="Configure the pipeline before training."
          action={<button className="btn-primary" onClick={() => navigate('/configuration')}>Go to Configuration →</button>}
        />
      )}

      {pipelineConfig && (
        <div className="space-y-6">
          {/* Config summary */}
          <Section title="Pipeline Configuration">
            <div className="card grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
              <div><span className="text-slate-500">Target</span><div className="text-white font-medium">{pipelineConfig.target_col}</div></div>
              <div><span className="text-slate-500">Models</span><div className="text-white font-medium">{pipelineConfig.models?.length || 0}</div></div>
              <div><span className="text-slate-500">CV Folds</span><div className="text-white font-medium">{pipelineConfig.cv_folds}</div></div>
              <div><span className="text-slate-500">Tuning</span><div className="text-white font-medium">{pipelineConfig.enable_tuning ? 'Enabled' : 'Disabled'}</div></div>
            </div>
          </Section>

          {/* Launch button */}
          {!isTrained && (
            <button
              className="btn-primary w-full py-4 text-base flex items-center justify-center gap-2"
              onClick={launch}
              disabled={isRunning || launching}
            >
              {(isRunning || launching) ? <Spinner size={18} /> : <Play size={18} />}
              {isRunning ? 'Pipeline Running...' : launching ? 'Starting...' : 'Run AutoML Pipeline'}
            </button>
          )}

          {error && <Alert type="error">{error}</Alert>}

          {/* Live progress */}
          {(isRunning || (status && !isTrained)) && (
            <Section title="Pipeline Progress">
              <div className="card space-y-4">
                <ProgressBar value={status?.progress || 0} label={`${status?.progress || 0}%`} />
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {(status?.log || []).slice().reverse().map((entry, i) => (
                    <div key={i} className={`text-xs flex gap-2 ${entry.pct === -1 ? 'text-red-400' : 'text-slate-400'}`}>
                      <span className="text-slate-600 shrink-0 w-8">{entry.pct >= 0 ? `${entry.pct}%` : 'ERR'}</span>
                      <span>{entry.msg}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Section>
          )}

          {/* Results after training */}
          {isTrained && modelsData && (
            <div className="space-y-5 fade-in">
              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <StatCard label="Champion"   value={bestName?.replace(/_/g,' ')} color="green" icon={Trophy} />
                <StatCard label="Models Trained" value={lb.length} icon={Cpu} />
                <StatCard label="Features"   value={modelsData.feature_names?.length} />
                <StatCard label="Classes"    value={modelsData.class_names?.join(', ') || '—'} />
              </div>

              {/* Feature Engineering */}
              {hypothesisData?.fe_triggered && (
                <Collapse
                  title={`Feature Engineering — ${hypothesisData.fe_summary?.n_new_features || 0} new features created`}
                  badge={<Badge label="Triggered" color="yellow" />}
                  defaultOpen
                >
                  <div className="text-sm text-slate-400 space-y-1">
                    <div>Techniques: {(hypothesisData.fe_summary?.techniques_applied || []).join(', ') || 'n/a'}</div>
                    {(hypothesisData.fe_summary?.new_features || []).slice(0, 12).map(f => (
                      <span key={f} className="inline-block mr-2 mb-1 px-2 py-0.5 bg-surface rounded text-xs text-slate-300">{f}</span>
                    ))}
                  </div>
                </Collapse>
              )}

              {/* Hypothesis */}
              {hypothesisData && (
                <Collapse
                  title={`Hypothesis Testing — ${hypothesisData.n_significant}/${hypothesisData.n_features_total} features significant`}
                  badge={<Badge label={`p<${hypothesisData.alpha}`} color="blue" />}
                  defaultOpen
                >
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="text-center"><div className="text-emerald-400 text-xl font-bold">{hypothesisData.n_significant}</div><div className="text-slate-500 text-xs">Significant</div></div>
                    <div className="text-center"><div className="text-slate-400 text-xl font-bold">{hypothesisData.n_features_total - hypothesisData.n_significant}</div><div className="text-slate-500 text-xs">Insignificant</div></div>
                    <div className="text-center"><div className="text-brand-400 text-xl font-bold">{((hypothesisData.significant_ratio || 0)*100).toFixed(0)}%</div><div className="text-slate-500 text-xs">Ratio</div></div>
                  </div>
                </Collapse>
              )}

              {/* Leakage scan */}
              {leakageData !== undefined && (
                <Collapse
                  title={`Leakage Scan — ${leakageData?.blocked ?? 0} blocked, ${leakageData?.warnings ?? 0} warnings, ${leakageData?.clean ?? 0} clean`}
                  badge={<Badge label={leakageData?.blocked > 0 ? 'Issues Found' : 'All Clean'} color={leakageData?.blocked > 0 ? 'red' : 'green'} />}
                  defaultOpen
                >
                  {(leakageData?.details || []).length > 0
                    ? <DataTable
                        columns={[
                          { key: 'feature', label: 'Feature' },
                          { key: 'severity', label: 'Severity', render: v => <Badge label={v} color={v==='BLOCK'?'red':'yellow'} /> },
                          { key: 'reason',   label: 'Reason' },
                          { key: 'detail',   label: 'Detail' },
                        ]}
                        rows={leakageData.details}
                      />
                    : <div className="text-sm text-emerald-400">✓ No leakage detected</div>
                  }
                </Collapse>
              )}

              {/* McNemar */}
              {comparisonData?.mcnemar_summary?.length > 0 && (
                <Collapse
                  title={`McNemar Test — ${comparisonData.n_pairs_tested} model pairs compared`}
                  badge={<Badge label="Post-training" color="purple" />}
                  defaultOpen
                >
                  <DataTable
                    columns={[
                      { key: 'model_a',    label: 'Model A' },
                      { key: 'model_b',    label: 'Model B' },
                      { key: 'p_value',    label: 'p-value',    render: v => (typeof v==='number' ? v.toExponential(3) : v) },
                      { key: 'significant',label: 'Significant', render: v => <Badge label={v ? 'Yes' : 'No'} color={v ? 'green' : 'yellow'} /> },
                    ]}
                    rows={comparisonData.mcnemar_summary}
                  />
                </Collapse>
              )}

              {/* Leaderboard */}
              <Section title="Model Performance Leaderboard">
                {/* Chart */}
                {chartData.length > 0 && (
                  <div className="card mb-4" style={{ height: 240 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
                        <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                        <YAxis domain={[0, 1]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                        <Tooltip
                          contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }}
                          labelStyle={{ color: '#e2e8f0' }}
                        />
                        <Bar dataKey="f1" radius={[4, 4, 0, 0]}>
                          {chartData.map((d, i) => (
                            <Cell key={i} fill={d.best ? '#10b981' : d.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
                <DataTable columns={METRIC_COLS} rows={lb.map(r => ({
                  ...r,
                  model: r.model === bestName ? `⭐ ${r.model}` : r.model,
                }))} />
              </Section>

              <div className="flex justify-end gap-3">
                <button className="btn-secondary" onClick={() => navigate('/evaluation')}>View Full Evaluation →</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
