import React, { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Zap, Upload, RefreshCw, ChevronDown, CheckCircle2, AlertCircle } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell,
} from 'recharts'
import {
  PageHeader, Section, StatCard, DataTable,
  Alert, EmptyState, Spinner, Badge, ProgressBar,
} from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'
import { predict, batchPredict, getPredictSchema } from '../services/api.js'

// ── Sub-components ────────────────────────────────────────────────────────────

function ModelSelector({ models, best, value, onChange }) {
  return (
    <div>
      <label className="label">Model</label>
      <select className="select max-w-xs" value={value || ''} onChange={e => onChange(e.target.value || null)}>
        <option value="">⭐ Best model ({best})</option>
        {models.map(m => <option key={m} value={m}>{m.replace(/_/g, ' ')}</option>)}
      </select>
    </div>
  )
}

function PredictionResultCard({ result }) {
  if (!result) return null
  const { prediction, probability, probabilities, model_used, class_names } = result

  const probData = probabilities
    ? Object.entries(probabilities).map(([cls, prob]) => ({ cls, prob })).sort((a, b) => b.prob - a.prob)
    : []

  const COLORS = ['#6366f1','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4']

  return (
    <div className="card border-brand-600/30 bg-brand-950/20 fade-in">
      <div className="flex items-start gap-5">
        {/* Main result */}
        <div className="flex-1">
          <div className="text-xs text-brand-400 uppercase tracking-wider font-medium mb-1">Prediction</div>
          <div className="text-3xl font-bold text-white mb-1">{prediction}</div>
          {probability != null && (
            <div className="mb-3">
              <div className="text-xs text-slate-500 mb-1">Confidence</div>
              <ProgressBar value={(probability || 0) * 100} color="brand" />
              <div className="text-right text-xs text-brand-400 mt-0.5">{((probability || 0) * 100).toFixed(1)}%</div>
            </div>
          )}
          <div className="text-xs text-slate-500">Model: {model_used?.replace(/_/g, ' ')}</div>
        </div>

        {/* Probability breakdown */}
        {probData.length > 1 && (
          <div className="w-48 shrink-0">
            <div className="text-xs text-slate-500 mb-2">Class probabilities</div>
            <div style={{ height: probData.length * 34 + 20 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={probData} layout="vertical" margin={{ left: 0, right: 10 }}>
                  <XAxis type="number" domain={[0, 1]} hide />
                  <YAxis type="category" dataKey="cls" tick={{ fill: '#94a3b8', fontSize: 10 }} width={56} />
                  <Tooltip
                    contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }}
                    formatter={v => [`${(v * 100).toFixed(1)}%`]}
                  />
                  <Bar dataKey="prob" radius={[0, 4, 4, 0]}>
                    {probData.map((d, i) => (
                      <Cell key={i} fill={d.cls === prediction ? '#10b981' : COLORS[i % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function PredictionForm({ schema, models, best, onResult }) {
  const [values,    setValues]    = useState({})
  const [modelSel,  setModelSel]  = useState(null)
  const [loading,   setLoading]   = useState(false)
  const [error,     setError]     = useState(null)
  const [result,    setResult]    = useState(null)

  // Initialise defaults from schema
  useEffect(() => {
    if (!schema?.length) return
    const defaults = {}
    schema.forEach(f => {
      defaults[f.name] = f.mean != null ? String(f.mean.toFixed(2))
        : f.unique_values?.length ? f.unique_values[0]
        : ''
    })
    setValues(defaults)
  }, [schema])

  const set = (name, val) => setValues(v => ({ ...v, [name]: val }))

  const submit = async () => {
    setLoading(true); setError(null)
    try {
      // Convert to appropriate types
      const input = {}
      schema.forEach(f => {
        const raw = values[f.name]
        input[f.name] = f.is_numeric ? (raw === '' ? null : Number(raw)) : (raw || null)
      })
      const res = await predict(input, modelSel)
      setResult(res)
      onResult && onResult(res)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  if (!schema?.length) return <div className="text-slate-500 text-sm">Loading feature schema...</div>

  return (
    <div className="space-y-5">
      <ModelSelector models={models} best={best} value={modelSel} onChange={setModelSel} />

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {schema.map(f => (
          <div key={f.name}>
            <label className="label text-xs">{f.name}</label>
            {f.unique_values ? (
              <select className="select text-xs" value={values[f.name] ?? ''} onChange={e => set(f.name, e.target.value)}>
                <option value="">—</option>
                {f.unique_values.map(v => <option key={v}>{v}</option>)}
              </select>
            ) : (
              <input
                className="input text-xs"
                type={f.is_numeric ? 'number' : 'text'}
                step={f.is_numeric ? 'any' : undefined}
                placeholder={f.mean != null ? `e.g. ${f.mean.toFixed(2)}` : ''}
                value={values[f.name] ?? ''}
                onChange={e => set(f.name, e.target.value)}
              />
            )}
            {f.min != null && (
              <div className="text-[10px] text-slate-600 mt-0.5">
                min {f.min.toFixed(1)} · max {f.max.toFixed(1)}
              </div>
            )}
          </div>
        ))}
      </div>

      {error && <Alert type="error">{error}</Alert>}

      <button className="btn-primary flex items-center gap-2" onClick={submit} disabled={loading}>
        {loading ? <Spinner size={16} /> : <Zap size={16} />}
        {loading ? 'Predicting...' : 'Predict'}
      </button>

      {result && <PredictionResultCard result={result} />}
    </div>
  )
}

function BatchUpload({ models, best }) {
  const [file,    setFile]    = useState(null)
  const [modelSel,setModelSel]= useState(null)
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState(null)
  const [result,  setResult]  = useState(null)

  const run = async () => {
    if (!file) return
    setLoading(true); setError(null)
    try {
      const res = await batchPredict(file, modelSel)
      setResult(res)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const batchCols = result?.records?.length
    ? Object.keys(result.records[0]).map(k => ({ key: k, label: k,
        render: k === '_prediction'
          ? v => <Badge label={v} color="green" />
          : k === '_confidence'
            ? v => <span className="text-brand-400">{(v*100).toFixed(1)}%</span>
            : v => String(v ?? '—')
      }))
    : []

  return (
    <div className="space-y-5">
      <ModelSelector models={models} best={best} value={modelSel} onChange={setModelSel} />

      {/* File zone */}
      <label className="flex flex-col items-center gap-3 p-8 border-2 border-dashed border-surface-border rounded-xl cursor-pointer hover:border-brand-600/60 hover:bg-surface-muted/30 transition-all">
        <input type="file" className="hidden" accept=".csv,.xlsx" onChange={e => { setFile(e.target.files[0]); setResult(null) }} />
        <Upload size={28} className="text-slate-500" strokeWidth={1.5} />
        <div className="text-center">
          <div className="text-slate-300 font-medium text-sm">{file ? file.name : 'Upload CSV or Excel'}</div>
          <div className="text-xs text-slate-500 mt-0.5">Same schema as training data (no target column needed)</div>
        </div>
      </label>

      {error && <Alert type="error">{error}</Alert>}

      <button className="btn-primary flex items-center gap-2" onClick={run} disabled={!file || loading}>
        {loading ? <Spinner size={16} /> : <Zap size={16} />}
        {loading ? `Predicting ${file?.name}...` : 'Run Batch Prediction'}
      </button>

      {result && (
        <div className="space-y-4 fade-in">
          <div className="grid grid-cols-3 gap-4">
            <StatCard label="Records"   value={result.count}                        />
            <StatCard label="Model"     value={result.model_used?.replace(/_/g,' ')} />
            <StatCard label="Classes"   value={(result.class_names||[]).join(' · ')} />
          </div>

          {/* Distribution summary */}
          {result.predictions && (
            <div className="card">
              <div className="text-sm font-medium text-white mb-3">Prediction Distribution</div>
              <div className="flex gap-3 flex-wrap">
                {Object.entries(
                  result.predictions.reduce((acc, p) => { acc[p] = (acc[p]||0)+1; return acc }, {})
                ).map(([cls, cnt]) => (
                  <div key={cls} className="card flex-1 min-w-24 text-center bg-surface-muted">
                    <div className="text-lg font-bold text-white">{cnt}</div>
                    <div className="text-xs text-slate-500">{cls}</div>
                    <div className="text-xs text-brand-400">{((cnt/result.count)*100).toFixed(1)}%</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Table */}
          {result.records && (
            <Section title={`Results Table (${result.count} rows)`}>
              <DataTable columns={batchCols} rows={result.records} maxRows={100} />
            </Section>
          )}
        </div>
      )}
    </div>
  )
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function PredictionsPage() {
  const { isTrained, modelsData } = usePipeline()
  const navigate = useNavigate()
  const [schema,  setSchema]  = useState(null)
  const [tab,     setTab]     = useState('single')   // 'single' | 'batch'
  const [loading, setLoading] = useState(false)

  const models  = modelsData?.trained_models || []
  const best    = modelsData?.best_model_name || ''

  useEffect(() => {
    if (!isTrained) return
    setLoading(true)
    getPredictSchema()
      .then(r => setSchema(r.features || []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [isTrained])

  if (!isTrained) return (
    <div>
      <PageHeader title="Predictions" />
      <EmptyState
        icon={Zap}
        title="No trained model"
        sub="Run the AutoML pipeline to enable predictions."
        action={<button className="btn-primary" onClick={() => navigate('/training')}>Go to Training →</button>}
      />
    </div>
  )

  return (
    <div>
      <PageHeader
        title="Predictions"
        subtitle="Use the trained model for single or batch inference. The same preprocessing pipeline is applied automatically — no retraining."
      />

      {/* Model info strip */}
      <div className="card mb-6 flex items-center gap-4 bg-brand-950/30 border-brand-700/30">
        <div className="w-10 h-10 rounded-lg bg-brand-600/20 flex items-center justify-center">
          <Zap size={18} className="text-brand-400" />
        </div>
        <div>
          <div className="text-xs text-brand-400 uppercase tracking-wider">Active Model</div>
          <div className="font-semibold text-white">{best.replace(/_/g, ' ')}</div>
        </div>
        <div className="ml-auto text-right text-sm text-slate-500">
          {models.length} model{models.length !== 1 ? 's' : ''} available ·
          {' '}{modelsData?.feature_names?.length || 0} features ·
          {' '}{(modelsData?.class_names || []).join(', ')}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-surface-muted rounded-lg p-1 w-fit">
        {[
          { id: 'single', label: '⚡ Single Prediction' },
          { id: 'batch',  label: '📂 Batch Prediction' },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-5 py-2 rounded-md text-sm font-medium transition-all ${
              tab === t.id
                ? 'bg-brand-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="card">
        {tab === 'single' && (
          <div>
            <div className="text-sm font-semibold text-white mb-5">
              Single Prediction
              <span className="ml-2 text-xs font-normal text-slate-500">Fill in the feature values below</span>
            </div>
            {loading
              ? <Spinner />
              : <PredictionForm schema={schema || []} models={models} best={best} />
            }
          </div>
        )}
        {tab === 'batch' && (
          <div>
            <div className="text-sm font-semibold text-white mb-5">
              Batch Prediction
              <span className="ml-2 text-xs font-normal text-slate-500">Upload a CSV to predict all rows at once</span>
            </div>
            <BatchUpload models={models} best={best} />
          </div>
        )}
      </div>
    </div>
  )
}
