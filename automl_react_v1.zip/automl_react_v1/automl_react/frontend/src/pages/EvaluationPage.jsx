import React from 'react'
import { useNavigate } from 'react-router-dom'
import { BarChart3 } from 'lucide-react'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, Legend,
} from 'recharts'
import {
  PageHeader, Section, StatCard, DataTable,
  EmptyState, Badge, Collapse,
} from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'

const COLORS = ['#6366f1','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16']
const fmt = v => (typeof v === 'number' ? v.toFixed(4) : '—')

export default function EvaluationPage() {
  const { modelsData, comparisonData, isTrained } = usePipeline()
  const navigate = useNavigate()

  if (!isTrained || !modelsData) return (
    <div>
      <PageHeader title="Evaluation & Comparison" />
      <EmptyState
        icon={BarChart3}
        title="No evaluation data"
        sub="Run the training pipeline first."
        action={<button className="btn-primary" onClick={() => navigate('/training')}>Go to Training →</button>}
      />
    </div>
  )

  const lb        = modelsData.leaderboard || []
  const bestName  = modelsData.best_model_name || ''
  const features  = modelsData.feature_names  || []
  const classes   = modelsData.class_names    || []

  // Multi-metric radar data for top 5 models
  const METRICS = ['accuracy', 'f1_weighted', 'precision_weighted', 'recall_weighted']
  const radarData = METRICS.map(m => {
    const obj = { metric: m.replace('_weighted','').replace('_',' ') }
    lb.slice(0, 5).forEach(r => { obj[r.model] = typeof r[m] === 'number' ? parseFloat(r[m].toFixed(4)) : 0 })
    return obj
  })

  const top5 = lb.slice(0, 5)

  // McNemar
  const mcRows   = comparisonData?.mcnemar_summary || []
  const nPairs   = comparisonData?.n_pairs_tested  || 0
  const refModel = comparisonData?.reference_model || bestName

  return (
    <div>
      <PageHeader
        title="Evaluation & Comparison"
        subtitle="Model leaderboard, multi-metric radar, and McNemar statistical model comparison."
      >
        
      </PageHeader>

      {/* Champion card */}
      <div className="card mb-6 border-emerald-700/50 bg-emerald-950/20">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-600/20 flex items-center justify-center text-2xl">⭐</div>
          <div>
            <div className="text-xs text-emerald-500 uppercase tracking-wider font-medium">Champion Model</div>
            <div className="text-xl font-bold text-white">{bestName.replace(/_/g, ' ')}</div>
            {lb.find(r => r.model === bestName) && (
              <div className="text-sm text-slate-400 mt-0.5">
                F1: {fmt(lb.find(r => r.model === bestName)?.f1_weighted)} ·
                Accuracy: {fmt(lb.find(r => r.model === bestName)?.accuracy)}
              </div>
            )}
          </div>
          <div className="ml-auto text-right">
            <div className="text-xs text-slate-500">Features used</div>
            <div className="text-lg font-semibold text-white">{features.length}</div>
            <div className="text-xs text-slate-500 mt-1">Classes: {classes.join(', ')}</div>
          </div>
        </div>
      </div>

      {/* Leaderboard */}
      <Section title="Model Leaderboard">
        {/* Bar chart comparison */}
        <div className="card mb-4" style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={lb.map((r,i) => ({
              name: r.model?.replace(/_/g,' '),
              accuracy: typeof r.accuracy === 'number' ? parseFloat(r.accuracy.toFixed(4)) : 0,
              f1: typeof r.f1_weighted === 'number' ? parseFloat(r.f1_weighted.toFixed(4)) : 0,
              best: r.model === bestName,
              color: COLORS[i % COLORS.length],
            }))} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
              <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 9 }} />
              <YAxis domain={[0, 1]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
              <Tooltip contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }} />
              <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 11 }} />
              <Bar dataKey="f1" name="F1 Score" radius={[4,4,0,0]}>
                {lb.map((r,i) => <Cell key={i} fill={r.model===bestName ? '#10b981' : COLORS[i%COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <DataTable
          columns={[
            { key: 'model',              label: 'Model', render: (v,r) => r.model===bestName ? `⭐ ${v}` : v },
            { key: 'accuracy',           label: 'Accuracy',   render: fmt },
            { key: 'f1_weighted',        label: 'F1',         render: fmt },
            { key: 'precision_weighted', label: 'Precision',  render: fmt },
            { key: 'recall_weighted',    label: 'Recall',     render: fmt },
          ]}
          rows={lb}
        />
      </Section>

      {/* Radar chart */}
      {top5.length > 1 && (
        <Section title="Multi-Metric Radar (Top 5 Models)">
          <div className="card" style={{ height: 320 }}>
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#2d2d4a" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <PolarRadiusAxis angle={90} domain={[0, 1]} tick={{ fill: '#64748b', fontSize: 9 }} />
                {top5.map((r, i) => (
                  <Radar
                    key={r.model}
                    name={r.model.replace(/_/g,' ')}
                    dataKey={r.model}
                    stroke={COLORS[i % COLORS.length]}
                    fill={COLORS[i % COLORS.length]}
                    fillOpacity={0.08}
                    strokeWidth={r.model === bestName ? 2.5 : 1.5}
                  />
                ))}
                <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </Section>
      )}

      {/* McNemar */}
      <Section title="McNemar Statistical Comparison" subtitle={`Reference model: ${refModel}`}>
        {mcRows.length === 0
          ? <div className="card text-slate-500 text-sm">McNemar test was not run or fewer than 2 models trained.</div>
          : (
            <Collapse
              title={`${nPairs} model pairs compared against ${refModel}`}
              badge={<Badge label="Post-training" color="purple" />}
              defaultOpen
            >
              <DataTable
                columns={[
                  { key: 'model_a',    label: 'Model A' },
                  { key: 'model_b',    label: 'Model B' },
                  { key: 'statistic',  label: 'χ² stat', render: v => (typeof v==='number' ? v.toFixed(4) : v) },
                  { key: 'p_value',    label: 'p-value',  render: v => (typeof v==='number' ? v.toExponential(3) : v) },
                  { key: 'significant',label: 'Significant', render: v => <Badge label={v?'Yes':'No'} color={v?'green':'yellow'} /> },
                ]}
                rows={mcRows}
              />
            </Collapse>
          )
        }
      </Section>

      {/* Feature list */}
      <Section title="Features Used in Training">
        <div className="card">
          <div className="flex flex-wrap gap-1.5">
            {features.map(f => (
              <span key={f} className="px-2 py-0.5 bg-surface rounded text-xs text-slate-400 font-mono">{f}</span>
            ))}
          </div>
        </div>
      </Section>
    </div>
  )
}
