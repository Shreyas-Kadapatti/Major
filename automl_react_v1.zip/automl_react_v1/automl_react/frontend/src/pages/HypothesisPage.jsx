import React from 'react'
import { useNavigate } from 'react-router-dom'
import { FlaskConical } from 'lucide-react'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Cell,
} from 'recharts'
import {
  PageHeader, Section, StatCard, DataTable,
  Alert, EmptyState, Badge,
} from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'

export default function HypothesisPage() {
  const { hypothesisData, isTrained } = usePipeline()
  const navigate = useNavigate()

  if (!isTrained || !hypothesisData) return (
    <div>
      <PageHeader title="Hypothesis Testing" />
      <EmptyState
        icon={FlaskConical}
        title="No hypothesis results yet"
        sub="Run the AutoML pipeline to see statistical significance tests."
        action={<button className="btn-primary" onClick={() => navigate('/training')}>Go to Training →</button>}
      />
    </div>
  )

  const { hypothesis_report: rpt, significant_features: sig, insignificant_features: insig,
          fe_triggered, fe_summary, n_significant, n_features_total, alpha, feature_results } = hypothesisData

  const featRows = Object.entries(feature_results || {}).map(([name, d]) => ({
    name, test: d.test, statistic: d.statistic, p_value: d.p_value, significant: d.significant,
  })).sort((a, b) => a.p_value - b.p_value)

  const chartData = featRows.map(r => ({
    name: r.name.length > 14 ? r.name.slice(0, 13) + '…' : r.name,
    full: r.name,
    p_value: typeof r.p_value === 'number' ? parseFloat(Math.min(r.p_value, 1).toFixed(6)) : 1,
    significant: r.significant,
  }))

  return (
    <div>
      <PageHeader
        title="Hypothesis Testing"
        subtitle="Statistical significance testing (Pearson, Chi-square, ANOVA/t-test) run before training."
      />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard label="Features Tested"  value={n_features_total}     />
        <StatCard label="Significant"      value={n_significant}         color="green"  />
        <StatCard label="Insignificant"    value={(n_features_total||0) - (n_significant||0)} color="yellow" />
        <StatCard label="Significance α"   value={alpha}                 color="blue"   />
      </div>

      {/* FE trigger */}
      <div className="mb-6">
        {fe_triggered
          ? <Alert type="warning" title="Feature Engineering was triggered">
              Only {n_significant}/{n_features_total} features were significant (below threshold).
              {' '}{fe_summary?.n_new_features || 0} new features were auto-generated: {(fe_summary?.techniques_applied || []).join(', ')}.
            </Alert>
          : <Alert type="success" title="Feature Engineering skipped">
              Sufficient significant features found. Pipeline proceeded directly to feature selection.
            </Alert>
        }
      </div>

      {/* Significant / insignificant lists */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="card">
          <div className="text-sm font-semibold text-emerald-400 mb-3">Significant Features ({(sig||[]).length})</div>
          <div className="space-y-1">
            {(sig||[]).length === 0
              ? <div className="text-slate-500 text-sm">None</div>
              : (sig||[]).map(f => <div key={f} className="text-sm text-slate-300 font-mono">• {f}</div>)
            }
          </div>
        </div>
        <div className="card">
          <div className="text-sm font-semibold text-slate-400 mb-3">Insignificant Features ({(insig||[]).length})</div>
          <div className="space-y-1 max-h-52 overflow-y-auto">
            {(insig||[]).length === 0
              ? <div className="text-slate-500 text-sm">None</div>
              : (insig||[]).map(f => <div key={f} className="text-sm text-slate-500 font-mono">• {f}</div>)
            }
          </div>
        </div>
      </div>

      {/* p-value chart */}
      {chartData.length > 0 && (
        <Section title="Feature p-values" subtitle="Lower p-value = more statistically significant">
          <div className="card" style={{ height: Math.max(260, chartData.length * 26) }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical" margin={{ left: 30, right: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
                <XAxis type="number" domain={[0, 1]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <YAxis type="category" dataKey="name" tick={{ fill: '#94a3b8', fontSize: 10 }} width={110} />
                <Tooltip
                  contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }}
                  formatter={(v, _, p) => [v.toFixed(6), `p-value (${p.payload.full})`]}
                />
                <ReferenceLine x={alpha} stroke="#f59e0b" strokeDasharray="4 2"
                  label={{ value: `α=${alpha}`, fill: '#f59e0b', fontSize: 10 }} />
                <Bar dataKey="p_value" radius={[0, 4, 4, 0]}>
                  {chartData.map((d, i) => (
                    <Cell key={i} fill={d.significant ? '#10b981' : '#475569'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Section>
      )}

      {/* Feature results table */}
      <Section title="Per-Feature Test Results">
        <DataTable
          columns={[
            { key: 'name',       label: 'Feature' },
            { key: 'test',       label: 'Test Applied' },
            { key: 'statistic',  label: 'Statistic', render: v => (typeof v === 'number' ? v.toFixed(4) : v) },
            { key: 'p_value',    label: 'p-value',   render: v => (typeof v === 'number' ? v.toFixed(6) : v) },
            { key: 'significant',label: 'Significant', render: v => <Badge label={v ? 'Yes' : 'No'} color={v ? 'green' : 'yellow'} /> },
          ]}
          rows={featRows}
        />
      </Section>
    </div>
  )
}
