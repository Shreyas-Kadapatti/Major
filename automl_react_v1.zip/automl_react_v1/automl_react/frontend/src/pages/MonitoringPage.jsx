import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Activity, Upload, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, ReferenceLine,
} from 'recharts'
import {
  PageHeader, Section, StatCard, DataTable,
  Alert, EmptyState, Spinner, Badge,
} from '../components/common/UI.jsx'
import { usePipeline } from '../hooks/usePipeline.jsx'
import { runDrift } from '../services/api.js'

const STATUS_STYLES = {
  OK:       { color: 'text-emerald-400', bg: 'bg-emerald-950/40 border-emerald-700/40', icon: CheckCircle2 },
  WARNING:  { color: 'text-amber-400',   bg: 'bg-amber-950/40 border-amber-700/40',     icon: AlertTriangle },
  CRITICAL: { color: 'text-red-400',     bg: 'bg-red-950/40 border-red-700/40',         icon: XCircle },
}

export default function MonitoringPage() {
  const { isTrained } = usePipeline()
  const navigate = useNavigate()
  const [file,       setFile]       = useState(null)
  const [alpha,      setAlpha]      = useState(0.05)
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState(null)
  const [report,     setReport]     = useState(null)

  if (!isTrained) return (
    <div>
      <PageHeader title="Monitoring & Drift" />
      <EmptyState
        icon={Activity}
        title="No trained model"
        sub="Train a model first to enable drift monitoring."
        action={<button className="btn-primary" onClick={() => navigate('/training')}>Go to Training →</button>}
      />
    </div>
  )

  const run = async () => {
    if (!file) return
    setLoading(true); setError(null)
    try {
      const r = await runDrift(file, alpha)
      setReport(r)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const status  = report?.drift_status || 'OK'
  const style   = STATUS_STYLES[status] || STATUS_STYLES.OK
  const Icon    = style.icon

  // Chart data for PSI
  const numDetails = Object.entries(report?.feature_details || {})
    .filter(([, d]) => d.type === 'numeric')
    .map(([name, d]) => ({ name, psi: d.psi || 0, status: d.psi_status, drifted: d.drifted }))
    .sort((a, b) => b.psi - a.psi)

  const catDetails = Object.entries(report?.feature_details || {})
    .filter(([, d]) => d.type === 'categorical')
    .map(([name, d]) => ({ name, chi2_p: d.chi2_p_value, status: d.psi_status, drifted: d.drifted }))

  const barColor = (d) => d.status === 'CRITICAL' ? '#ef4444' : d.status === 'WARNING' ? '#f59e0b' : '#10b981'

  return (
    <div>
      <PageHeader
        title="Monitoring & Drift"
        subtitle="Post-deployment drift detection using PSI + KS test (numeric) and Chi-square (categorical). SR 11-7 aligned — alert only, no auto-retrain."
      />

      {/* Upload zone */}
      <Section title="Upload Production Data" subtitle="Compare incoming data against training baseline.">
        <div className="card space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* File */}
            <div>
              <label className="label">Production dataset (CSV / Excel)</label>
              <label className="flex items-center gap-3 px-4 py-3 border border-dashed border-surface-border rounded-lg cursor-pointer hover:border-brand-600/60 transition-all">
                <input type="file" className="hidden" accept=".csv,.xlsx" onChange={e => { setFile(e.target.files[0]); setReport(null) }} />
                <Upload size={16} className="text-slate-500" />
                <span className="text-sm text-slate-400">{file ? file.name : 'Choose file…'}</span>
              </label>
            </div>
            {/* Alpha */}
            <div>
              <label className="label">Significance Level (α)</label>
              <input className="input" type="number" step="0.01" min="0.01" max="0.1"
                value={alpha} onChange={e => setAlpha(parseFloat(e.target.value))} />
              <div className="text-xs text-slate-600 mt-1">PSI &lt; 0.10 stable · 0.10–0.25 monitor · &gt; 0.25 critical</div>
            </div>
          </div>
          <button className="btn-primary flex items-center gap-2" onClick={run} disabled={!file || loading}>
            {loading ? <Spinner size={16} /> : <Activity size={16} />}
            {loading ? 'Analysing drift...' : 'Run Drift Analysis'}
          </button>
          {error && <Alert type="error">{error}</Alert>}
        </div>
      </Section>

      {/* Report */}
      {report && (
        <div className="space-y-6 fade-in">
          {/* Status banner */}
          <div className={`card flex items-center gap-4 border ${style.bg}`}>
            <Icon size={32} className={style.color} />
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">Drift Status</div>
              <div className={`text-2xl font-bold ${style.color}`}>{status}</div>
              <div className="text-sm text-slate-400 mt-0.5">{report.note}</div>
            </div>
            <div className="ml-auto text-right">
              <div className="text-xs text-slate-500">Recommendation</div>
              <div className={`font-bold text-lg ${report.recommendation === 'retrain' ? 'text-red-400' : 'text-amber-400'}`}>
                {(report.recommendation || 'monitor').toUpperCase()}
              </div>
              <div className="text-xs text-slate-600 mt-1">SR 11-7: Human review required</div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard label="Features Checked" value={report.n_features_checked}                           />
            <StatCard label="Drifted"           value={report.n_drifted}           color={report.n_drifted > 0 ? 'red' : 'green'} />
            <StatCard label="Critical"          value={(report.critical_features||[]).length} color="red"  />
            <StatCard label="Drift %"           value={`${((report.drift_pct||0)*100).toFixed(1)}%`}       />
          </div>

          {/* Drifted features */}
          {(report.drifted_features||[]).length > 0 && (
            <Alert type="warning" title="Drifted Features">
              {report.drifted_features.map(f => (
                <span key={f} className="inline-block mr-2 mb-1 px-2 py-0.5 bg-amber-900/30 rounded text-xs font-mono">{f}</span>
              ))}
            </Alert>
          )}

          {/* PSI chart */}
          {numDetails.length > 0 && (
            <Section title="PSI by Feature (Numeric)">
              <div className="card" style={{ height: Math.max(200, numDetails.length * 32 + 40) }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={numDetails} layout="vertical" margin={{ left: 20, right: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
                    <XAxis type="number" domain={[0, Math.max(0.3, ...numDetails.map(d => d.psi))]}
                      tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis type="category" dataKey="name" tick={{ fill: '#94a3b8', fontSize: 10 }} width={100} />
                    <Tooltip contentStyle={{ background: '#1a1a2e', border: '1px solid #2d2d4a', borderRadius: 8 }}
                      formatter={v => [v.toFixed(4), 'PSI']} />
                    <ReferenceLine x={0.10} stroke="#f59e0b" strokeDasharray="4 2" label={{ value: 'Monitor', fill: '#f59e0b', fontSize: 9 }} />
                    <ReferenceLine x={0.25} stroke="#ef4444" strokeDasharray="4 2" label={{ value: 'Critical', fill: '#ef4444', fontSize: 9 }} />
                    <Bar dataKey="psi" radius={[0, 4, 4, 0]}>
                      {numDetails.map((d, i) => <Cell key={i} fill={barColor(d)} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Section>
          )}

          {/* Detail tables */}
          <div className="grid grid-cols-1 gap-4">
            {numDetails.length > 0 && (
              <Section title="Numeric Feature Details">
                <DataTable
                  columns={[
                    { key: 'name',     label: 'Feature' },
                    { key: 'psi',      label: 'PSI',        render: v => typeof v === 'number' ? v.toFixed(4) : '—' },
                    { key: 'status',   label: 'Status',     render: v => <Badge label={v} color={v==='CRITICAL'?'red':v==='WARNING'?'yellow':'green'} /> },
                    { key: 'ks_p_value',label: 'KS p-value', render: v => typeof v === 'number' ? v.toFixed(4) : '—' },
                    { key: 'ref_mean', label: 'Train Mean',  render: v => typeof v === 'number' ? v.toFixed(3) : '—' },
                    { key: 'new_mean', label: 'New Mean',    render: v => typeof v === 'number' ? v.toFixed(3) : '—' },
                    { key: 'drifted',  label: 'Drifted',     render: v => <Badge label={v ? 'Yes' : 'No'} color={v ? 'red' : 'green'} /> },
                  ]}
                  rows={Object.entries(report.feature_details || {})
                    .filter(([,d]) => d.type === 'numeric')
                    .map(([name, d]) => ({ name, ...d }))
                  }
                />
              </Section>
            )}
            {catDetails.length > 0 && (
              <Section title="Categorical Feature Details">
                <DataTable
                  columns={[
                    { key: 'name',         label: 'Feature' },
                    { key: 'chi2_p_value', label: 'Chi² p-value', render: v => typeof v === 'number' ? v.toFixed(4) : '—' },
                    { key: 'psi_approx',   label: 'PSI (approx)', render: v => typeof v === 'number' ? v.toFixed(4) : '—' },
                    { key: 'psi_status',   label: 'Status',       render: v => <Badge label={v} color={v==='CRITICAL'?'red':v==='WARNING'?'yellow':'green'} /> },
                    { key: 'unseen_categories', label: 'Unseen Cats', render: v => (v||[]).length > 0 ? <Badge label={`${v.length} new`} color="red" /> : '—' },
                    { key: 'drifted',      label: 'Drifted',      render: v => <Badge label={v ? 'Yes' : 'No'} color={v ? 'red' : 'green'} /> },
                  ]}
                  rows={Object.entries(report.feature_details || {})
                    .filter(([,d]) => d.type === 'categorical')
                    .map(([name, d]) => ({ name, ...d }))
                  }
                />
              </Section>
            )}
          </div>

          <Alert type="info" title="SR 11-7 Policy">
            Automated retraining is disabled. Drift alerts require human review before any model update.
            Recommendation: <strong>{(report.recommendation || 'monitor').toUpperCase()}</strong>
          </Alert>
        </div>
      )}
    </div>
  )
}
