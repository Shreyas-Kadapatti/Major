import React, { createContext, useContext, useState, useCallback, useRef } from 'react'
import * as api from '../services/api.js'

const PipelineContext = createContext(null)

export function PipelineProvider({ children }) {
  const [uploadInfo,      setUploadInfo]      = useState(null)   // file upload response
  const [pipelineConfig,  setPipelineConfig]  = useState(null)   // config sent to run-pipeline
  const [status,          setStatus]          = useState(null)   // /pipeline-status response
  const [hypothesisData,  setHypothesisData]  = useState(null)
  const [modelsData,      setModelsData]      = useState(null)
  const [comparisonData,  setComparisonData]  = useState(null)
  const [health,          setHealth]          = useState(null)
  const [error,           setError]           = useState(null)
  const pollRef = useRef(null)

  const isTrained    = status?.trained === true
  const isRunning    = status?.running === true

  // ── Upload ───────────────────────────────────────────────────────────────
  const uploadFile = useCallback(async (file) => {
    setError(null)
    const info = await api.uploadData(file)
    setUploadInfo(info)
    // Reset downstream data on new upload
    setHypothesisData(null)
    setModelsData(null)
    setComparisonData(null)
    setStatus(prev => prev ? { ...prev, trained: false } : null)
    return info
  }, [])

  // ── Run pipeline ──────────────────────────────────────────────────────────
  const startPipeline = useCallback(async (config) => {
    setError(null)
    setPipelineConfig(config)
    const res = await api.runPipeline(config)
    setStatus({ running: true, progress: 0, log: [], trained: false, error: null })
    _startPolling()
    return res
  }, [])

  const _startPolling = () => {
    if (pollRef.current) clearInterval(pollRef.current)
    pollRef.current = setInterval(async () => {
      try {
        const s = await api.getPipelineStatus()
        setStatus(s)
        if (!s.running) {
          clearInterval(pollRef.current)
          if (s.trained && !s.error) {
            // Auto-fetch results
            Promise.all([
              api.getHypothesis().then(setHypothesisData).catch(() => {}),
              api.getModels().then(setModelsData).catch(() => {}),
              api.getComparison().then(setComparisonData).catch(() => {}),
            ])
          }
          if (s.error) setError(s.error)
        }
      } catch (e) {
        console.error('Polling error:', e)
      }
    }, 1500)
  }

  // ── Manual refresh ────────────────────────────────────────────────────────
  const refreshResults = useCallback(async () => {
    const [h, m, c] = await Promise.all([
      api.getHypothesis(),
      api.getModels(),
      api.getComparison(),
    ])
    setHypothesisData(h)
    setModelsData(m)
    setComparisonData(c)
  }, [])

  const refreshHealth = useCallback(async () => {
    const h = await api.getHealth()
    setHealth(h)
    // If backend says trained but we don't have data yet, fetch it
    if (h.pipeline_trained && !modelsData) {
      refreshResults().catch(() => {})
    }
    return h
  }, [modelsData, refreshResults])

  return (
    <PipelineContext.Provider value={{
      uploadInfo, setUploadInfo,
      pipelineConfig, setPipelineConfig,
      status, isTrained, isRunning,
      hypothesisData, setHypothesisData,
      modelsData,     setModelsData,
      comparisonData, setComparisonData,
      health,
      error, setError,
      uploadFile,
      startPipeline,
      refreshResults,
      refreshHealth,
    }}>
      {children}
    </PipelineContext.Provider>
  )
}

export function usePipeline() {
  const ctx = useContext(PipelineContext)
  if (!ctx) throw new Error('usePipeline must be used inside PipelineProvider')
  return ctx
}
