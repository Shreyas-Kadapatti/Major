"""
Hyperparameter Tuning Module
Uses Optuna for config-driven Bayesian optimization.
"""
import warnings
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import optuna
from sklearn.model_selection import StratifiedKFold, cross_val_score

from src.models.registry import SEARCH_SPACES, get_model
from src.utils.logger import get_logger

optuna.logging.set_verbosity(optuna.logging.WARNING)
warnings.filterwarnings("ignore")

logger = get_logger(__name__)


def _suggest_params(trial: optuna.Trial, space: Dict) -> Dict:
    """
    Build hyperparameter dict from Optuna trial and search space.

    Args:
        trial: Optuna Trial object.
        space: Search space definition dict.

    Returns:
        Dictionary of suggested hyperparameters.
    """
    params = {}
    for param_name, spec in space.items():
        if spec[0] == "float":
            log = len(spec) > 3 and spec[3]
            params[param_name] = trial.suggest_float(param_name, spec[1], spec[2], log=log)
        elif spec[0] == "int":
            params[param_name] = trial.suggest_int(param_name, spec[1], spec[2])
        elif spec[0] == "categorical":
            params[param_name] = trial.suggest_categorical(param_name, spec[1])
    return params


class HyperparameterTuner:
    """
    Tunes hyperparameters for each model using Optuna.
    """

    def __init__(self, config: Dict):
        self.config = config
        tuning_cfg = config.get("tuning", {})
        self.n_trials = tuning_cfg.get("n_trials", 50)
        self.timeout = tuning_cfg.get("timeout", 300)
        self.metric = tuning_cfg.get("metric", "f1_weighted")
        self.cv_folds = config.get("models", {}).get("cross_validation_folds", 5)
        self.random_state = config.get("project", {}).get("random_state", 42)
        self.best_params: Dict[str, Dict] = {}

    def _make_objective(
        self, model_name: str, X: np.ndarray, y: np.ndarray
    ) -> Callable[[optuna.Trial], float]:
        """Create Optuna objective function for a given model."""
        space = SEARCH_SPACES.get(model_name, {})
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)

        def objective(trial: optuna.Trial) -> float:
            params = _suggest_params(trial, space)

            # Special handling for MLP hidden layer sizes
            if model_name == "mlp" and "hidden_layer_sizes_n" in params:
                n = params.pop("hidden_layer_sizes_n")
                layers = params.pop("hidden_layer_sizes_layers")
                params["hidden_layer_sizes"] = tuple([n] * layers)

            model = get_model(model_name)
            try:
                model.set_params(**params)
            except Exception:
                return 0.0

            scores = cross_val_score(
                model, X, y,
                cv=cv,
                scoring=self.metric,
                n_jobs=-1,
                error_score=0.0,
            )
            return float(np.mean(scores))

        return objective

    def tune_model(
        self, model_name: str, X: np.ndarray, y: np.ndarray
    ) -> Dict[str, Any]:
        """
        Run Optuna study for a single model.

        Args:
            model_name: Model name key.
            X: Feature array.
            y: Target array.

        Returns:
            Best hyperparameter dictionary.
        """
        if model_name not in SEARCH_SPACES:
            logger.warning(f"No search space for '{model_name}', skipping tuning.")
            return {}

        logger.info(f"Tuning {model_name} ({self.n_trials} trials, {self.timeout}s timeout)...")

        study = optuna.create_study(
            direction="maximize",
            sampler=optuna.samplers.TPESampler(seed=self.random_state),
            pruner=optuna.pruners.MedianPruner(n_startup_trials=5, n_warmup_steps=3),
        )

        objective = self._make_objective(model_name, X, y)
        study.optimize(
            objective,
            n_trials=self.n_trials,
            timeout=self.timeout,
            show_progress_bar=False,
        )

        best = study.best_params.copy()

        # Reconstruct MLP hidden layer sizes
        if model_name == "mlp" and "hidden_layer_sizes_n" in best:
            n = best.pop("hidden_layer_sizes_n")
            layers = best.pop("hidden_layer_sizes_layers")
            best["hidden_layer_sizes"] = tuple([n] * layers)

        logger.info(f"  Best {self.metric}: {study.best_value:.4f} | Params: {best}")
        self.best_params[model_name] = best
        return best

    def tune_all(
        self, X: np.ndarray, y: np.ndarray, model_names: Optional[List[str]] = None
    ) -> Dict[str, Dict]:
        """
        Tune all specified models.

        Args:
            X: Feature array.
            y: Target array.
            model_names: Models to tune. Defaults to all in SEARCH_SPACES.

        Returns:
            Dict of model_name → best_params.
        """
        model_names = model_names or list(SEARCH_SPACES.keys())

        for name in model_names:
            try:
                self.tune_model(name, X, y)
            except Exception as e:
                logger.error(f"Tuning failed for {name}: {e}")
                self.best_params[name] = {}

        return self.best_params
