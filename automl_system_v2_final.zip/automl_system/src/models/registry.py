"""
Model Registry
Provides a unified interface for all supported ML classifiers.
"""
from typing import Any, Dict, List

from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from src.utils.logger import get_logger

logger = get_logger(__name__)

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    logger.warning("XGBoost not available.")

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False
    logger.warning("LightGBM not available.")

try:
    from catboost import CatBoostClassifier
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False
    logger.warning("CatBoost not available.")


MODEL_REGISTRY: Dict[str, Any] = {
    "logistic_regression": LogisticRegression(max_iter=1000, random_state=42),
    "decision_tree": DecisionTreeClassifier(random_state=42),
    "random_forest": RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    "svm": SVC(probability=True, random_state=42),
    "mlp": MLPClassifier(max_iter=500, random_state=42),
}

if XGBOOST_AVAILABLE:
    MODEL_REGISTRY["xgboost"] = XGBClassifier(
        use_label_encoder=False, eval_metric="logloss", random_state=42, n_jobs=-1
    )

if LIGHTGBM_AVAILABLE:
    MODEL_REGISTRY["lightgbm"] = LGBMClassifier(random_state=42, n_jobs=-1, verbose=-1)

if CATBOOST_AVAILABLE:
    MODEL_REGISTRY["catboost"] = CatBoostClassifier(random_state=42, verbose=0)


def get_model(name: str):
    """
    Retrieve a model instance by name.

    Args:
        name: Model key from MODEL_REGISTRY.

    Returns:
        Sklearn-compatible estimator instance.
    """
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Model '{name}' not found. Available: {list(MODEL_REGISTRY.keys())}")
    return MODEL_REGISTRY[name]


def get_available_models() -> List[str]:
    """Return list of all registered model names."""
    return list(MODEL_REGISTRY.keys())


# Hyperparameter search spaces for Optuna
SEARCH_SPACES: Dict[str, Any] = {
    "logistic_regression": {
        "C": ("float", 1e-3, 10.0, True),
        "solver": ("categorical", ["lbfgs", "saga"]),
        "max_iter": ("int", 200, 2000),
    },
    "decision_tree": {
        "max_depth": ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf": ("int", 1, 10),
        "criterion": ("categorical", ["gini", "entropy"]),
    },
    "random_forest": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf": ("int", 1, 10),
        "max_features": ("categorical", ["sqrt", "log2"]),
    },
    "xgboost": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int", 2, 10),
        "learning_rate": ("float", 1e-3, 0.3, True),
        "subsample": ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "gamma": ("float", 0.0, 5.0, False),
        "reg_alpha": ("float", 1e-3, 10.0, True),
        "reg_lambda": ("float", 1e-3, 10.0, True),
    },
    "lightgbm": {
        "n_estimators": ("int", 50, 500),
        "max_depth": ("int", 2, 30),
        "learning_rate": ("float", 1e-3, 0.3, True),
        "num_leaves": ("int", 20, 150),
        "subsample": ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "reg_alpha": ("float", 1e-3, 10.0, True),
        "reg_lambda": ("float", 1e-3, 10.0, True),
    },
    "catboost": {
        "iterations": ("int", 50, 500),
        "depth": ("int", 2, 10),
        "learning_rate": ("float", 1e-3, 0.3, True),
        "l2_leaf_reg": ("float", 1e-3, 10.0, True),
    },
    "svm": {
        "C": ("float", 1e-2, 100.0, True),
        "kernel": ("categorical", ["rbf", "poly", "sigmoid"]),
        "gamma": ("categorical", ["scale", "auto"]),
    },
    "mlp": {
        "hidden_layer_sizes_n": ("int", 50, 256),
        "hidden_layer_sizes_layers": ("int", 1, 3),
        "activation": ("categorical", ["relu", "tanh"]),
        "alpha": ("float", 1e-5, 1e-1, True),
        "learning_rate": ("categorical", ["constant", "adaptive"]),
    },
}
