"""
AutoML Streamlit Dashboard — v1.1 (All bugs fixed)

FIXES IN THIS VERSION:
  [F1] sys.path + os.chdir so 'src' is always importable regardless of launch dir
  [F2] describe() statistics: only numeric cols formatted (no ValueError on str cols)
  [F3] All use_container_width warnings resolved (correct API per widget type)
  [F4] SHAP values always collapsed to 2D (fixes "Per-column arrays must be 1-dimensional")
  [F5] Arrow serialisation: safe_df() casts all columns to native Python types
  [F6] Leaderboard style.format() only touches numeric columns (no Arrow crash)
  [F7] Info banner explains why F1 is the ranking metric vs ROC-AUC
"""
import json
import os
import sys
import time
import warnings
from pathlib import Path
from typing import Dict, List, Optional

warnings.filterwarnings("ignore")

# ── [F1] Always find 'src' package regardless of launch directory ─────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
os.chdir(_PROJECT_ROOT)   # fixes relative paths: config/, models/, data/

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AutoML Studio",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
html,body,[class*="css"]{font-family:'Space Grotesk',sans-serif;}
.stApp{background:linear-gradient(135deg,#0d0f14 0%,#111520 100%);}
.metric-card{background:linear-gradient(145deg,#161b27,#1a2035);border:1px solid #2a3450;
  border-radius:12px;padding:20px;text-align:center;transition:transform .2s,box-shadow .2s;}
.metric-card:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(99,179,237,.15);}
.metric-value{font-size:2.2rem;font-weight:700;color:#63b3ed;font-family:'JetBrains Mono',monospace;}
.metric-label{font-size:.85rem;color:#8899bb;text-transform:uppercase;letter-spacing:.08em;margin-top:4px;}
.page-header{background:linear-gradient(135deg,#1a2035 0%,#0f1624 100%);
  border:1px solid #2a3450;border-left:4px solid #63b3ed;
  border-radius:8px;padding:18px 24px;margin-bottom:24px;}
.page-header h2{color:#e8f0fe;margin:0;font-size:1.5rem;font-weight:600;}
.page-header p{color:#8899bb;margin:4px 0 0;font-size:.9rem;}
.sidebar-section{background:#161b27;border:1px solid #2a3450;border-radius:8px;padding:14px;margin-bottom:14px;}
.log-box{background:#0a0d14;border:1px solid #2a3450;border-radius:8px;padding:16px;
  font-family:'JetBrains Mono',monospace;font-size:.82rem;color:#a0b0cc;
  max-height:300px;overflow-y:auto;line-height:1.7;}
div[data-testid="stSidebar"]{background:#0f1320;border-right:1px solid #1e2840;}
.stButton>button{background:linear-gradient(135deg,#3182ce,#2b6cb0);color:#fff;
  border:none;border-radius:8px;font-weight:600;font-family:'Space Grotesk',sans-serif;transition:all .2s;}
.stButton>button:hover{background:linear-gradient(135deg,#4299e1,#3182ce);
  transform:translateY(-1px);box-shadow:0 4px 15px rgba(99,179,237,.3);}
h1,h2,h3{color:#e8f0fe!important;}
p,li{color:#b0c0d8;}
label{color:#8899bb!important;}
</style>
""", unsafe_allow_html=True)

# ── Session state init ────────────────────────────────────────────────────────
_DEFAULTS = {
    "df": None, "file_name": None, "target_col": None,
    "col_types": None, "trained": False, "training_logs": [],
    "leaderboard": None, "best_model_name": None, "best_model": None,
    "preprocessor": None, "class_names": [], "feature_names": [],
    "shap_values": None, "shap_sample": None,
    "X_test": None, "y_test": None, "X_train": None,
    "trained_models": {}, "selected_models": [], "tune_enabled": True,
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="text-align:center;padding:20px 0 16px;">
      <div style="font-size:2.5rem;">🤖</div>
      <div style="font-size:1.3rem;font-weight:700;color:#e8f0fe;margin-top:6px;">AutoML Studio</div>
      <div style="font-size:.78rem;color:#8899bb;margin-top:2px;">v1.1 — Classification</div>
    </div>""", unsafe_allow_html=True)
    st.divider()

    page = st.radio("Nav", [
        "📂 Data Upload", "⚙️ Configuration", "🚀 Training",
        "📈 Model Performance", "🔍 Explainability",
        "🔮 Predictions", "📦 Model Registry",
    ], label_visibility="collapsed")

    st.divider()
    data_ok  = st.session_state.df is not None
    train_ok = st.session_state.trained
    st.markdown("**Pipeline Status**")
    st.markdown(f"""
    <div class="sidebar-section">
      <div style="color:#8899bb;font-size:.82rem;margin-bottom:8px;">
        📊 Dataset: <span style="color:{'#48bb78' if data_ok else '#f6ad55'}">
        {'✅ Loaded' if data_ok else '⏳ No data'}</span>
      </div>
      <div style="color:#8899bb;font-size:.82rem;margin-bottom:8px;">
        🎯 Target: <span style="color:#63b3ed">{st.session_state.target_col or '—'}</span>
      </div>
      <div style="color:#8899bb;font-size:.82rem;">
        🤖 Training: <span style="color:{'#48bb78' if train_ok else '#f6ad55'}">
        {'✅ Complete' if train_ok else '⏳ Not trained'}</span>
      </div>
    </div>""", unsafe_allow_html=True)

    if train_ok and st.session_state.best_model_name:
        st.markdown(f"""
        <div class="sidebar-section">
          <div style="color:#8899bb;font-size:.78rem;margin-bottom:6px;">BEST MODEL</div>
          <div style="color:#63b3ed;font-weight:600;">{st.session_state.best_model_name}</div>
        </div>""", unsafe_allow_html=True)

# ── Utility helpers ───────────────────────────────────────────────────────────
def page_header(icon, title, subtitle=""):
    st.markdown(f"""
    <div class="page-header">
      <h2>{icon} {title}</h2>
      {"<p>"+subtitle+"</p>" if subtitle else ""}
    </div>""", unsafe_allow_html=True)

def metric_card(value, label, col):
    col.markdown(f"""
    <div class="metric-card">
      <div class="metric-value">{value}</div>
      <div class="metric-label">{label}</div>
    </div>""", unsafe_allow_html=True)

def plotly_dark(fig):
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(22,27,39,.6)",
        font=dict(family="Space Grotesk", color="#b0c0d8"),
        margin=dict(t=40, b=40, l=40, r=40),
    )
    return fig

def safe_df(df: pd.DataFrame) -> pd.DataFrame:
    """[F5] Cast all columns to Arrow-safe native Python types."""
    out = df.copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].astype(str)
        elif pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].astype(float)
        elif pd.api.types.is_integer_dtype(out[col]):
            out[col] = out[col].astype(int)
        elif pd.api.types.is_bool_dtype(out[col]):
            out[col] = out[col].astype(bool)
    return out

def shap_to_2d(raw) -> np.ndarray:
    """[F4] Collapse any SHAP output to shape (n_samples, n_features)."""
    if isinstance(raw, list):
        # list of arrays → one per class; mean absolute value across classes
        arrays = [np.array(a) for a in raw]
        sv = np.mean([np.abs(a) for a in arrays], axis=0)
    else:
        sv = np.array(raw)

    if sv.ndim == 3:
        # (n_classes, n_samples, n_features)  OR  (n_samples, n_features, n_classes)
        if sv.shape[0] < sv.shape[1]:
            sv = np.abs(sv).mean(axis=0)
        else:
            sv = np.abs(sv).mean(axis=2)

    return sv.astype(float)   # guaranteed 2-D

# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — DATA UPLOAD
# ══════════════════════════════════════════════════════════════════════════════
if page == "📂 Data Upload":
    page_header("📂", "Data Upload", "Upload your dataset and explore its structure.")
    col_up, col_info = st.columns([1, 2])

    with col_up:
        st.markdown("#### Upload Dataset")
        uploaded = st.file_uploader("Drag & drop CSV / Excel / Parquet",
                                    type=["csv", "xlsx", "xls", "parquet"])
        if uploaded:
            try:
                ext = Path(uploaded.name).suffix.lower()
                if   ext == ".csv":     df = pd.read_csv(uploaded)
                elif ext in [".xlsx",".xls"]: df = pd.read_excel(uploaded)
                elif ext == ".parquet": df = pd.read_parquet(uploaded)
                else: raise ValueError(f"Unsupported: {ext}")
                st.session_state.df        = df
                st.session_state.file_name = uploaded.name
                Path("data/raw").mkdir(parents=True, exist_ok=True)
                df.to_csv(f"data/raw/{uploaded.name}", index=False)
                st.success(f"✅ **{uploaded.name}** loaded!")
            except Exception as e:
                st.error(f"Failed to load: {e}")

        st.divider()
        st.markdown("**Or use sample data:**")
        if st.button("📊 Load Iris Dataset", use_container_width=True):
            from sklearn.datasets import load_iris
            iris = load_iris(as_frame=True)
            df   = iris.frame.copy()
            df["target"] = iris.target_names[iris.target]
            st.session_state.df        = df
            st.session_state.file_name = "iris_sample.csv"
            st.success("✅ Iris loaded!")
            st.rerun()

        if st.button("🏦 Load Breast Cancer Dataset", use_container_width=True):
            from sklearn.datasets import load_breast_cancer
            bc = load_breast_cancer(as_frame=True)
            df = bc.frame.copy()
            df["target"] = bc.target_names[bc.target]
            st.session_state.df        = df
            st.session_state.file_name = "breast_cancer_sample.csv"
            st.success("✅ Breast Cancer loaded!")
            st.rerun()

    with col_info:
        if st.session_state.df is not None:
            df = st.session_state.df
            c1, c2, c3, c4 = st.columns(4)
            metric_card(f"{df.shape[0]:,}",          "Rows",       c1)
            metric_card(f"{df.shape[1]:,}",          "Columns",    c2)
            metric_card(f"{df.isnull().sum().sum():,}","Missing",   c3)
            metric_card(f"{df.duplicated().sum():,}", "Duplicates", c4)
            st.markdown("<br>", unsafe_allow_html=True)

            t1, t2, t3 = st.tabs(["🔍 Preview", "📊 Statistics", "❓ Missing Values"])
            with t1:
                st.dataframe(safe_df(df.head(20)), use_container_width=True, height=350)
            with t2:
                # [F2] reset_index + safe_df avoids format() crash on mixed-type describe
                desc = df.describe(include="all").T.reset_index().rename(columns={"index":"column"})
                st.dataframe(safe_df(desc), use_container_width=True)
            with t3:
                miss = df.isnull().sum().reset_index()
                miss.columns = ["Column","Missing Count"]
                miss["Missing %"] = (miss["Missing Count"] / len(df) * 100).round(2)
                miss = miss[miss["Missing Count"] > 0]
                if miss.empty:
                    st.success("🎉 No missing values!")
                else:
                    fig = px.bar(miss, x="Column", y="Missing %",
                                 color="Missing %",
                                 color_continuous_scale=["#63b3ed","#fc8181"],
                                 title="Missing Value % by Column")
                    st.plotly_chart(plotly_dark(fig), use_container_width=True)
                    st.dataframe(safe_df(miss), use_container_width=True)
        else:
            st.info("👆 Upload a dataset to get started.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
elif page == "⚙️ Configuration":
    page_header("⚙️", "Configuration", "Configure your AutoML pipeline settings.")
    if st.session_state.df is None:
        st.warning("⚠️ Upload a dataset first.")
        st.stop()

    df = st.session_state.df
    cl, cr = st.columns(2)

    with cl:
        st.markdown("#### 🎯 Target & Problem")
        target_col = st.selectbox("Target Column", df.columns.tolist(),
                                  index=len(df.columns)-1)
        st.session_state.target_col = target_col
        if target_col:
            vc = df[target_col].value_counts()
            fig = px.bar(x=vc.index.astype(str), y=vc.values,
                         labels={"x":"Class","y":"Count"},
                         title="Class Distribution",
                         color=vc.values,
                         color_continuous_scale=["#3182ce","#63b3ed"])
            st.plotly_chart(plotly_dark(fig), use_container_width=True)

        st.markdown("#### 🔧 Preprocessing")
        scaler      = st.selectbox("Scaler",             ["standard","minmax","robust"])
        num_imputer = st.selectbox("Numeric Imputer",    ["median","mean","most_frequent"])
        cat_imputer = st.selectbox("Categorical Imputer",["most_frequent","constant"])
        encoding    = st.selectbox("Categorical Encoding",["onehot","label"])
        test_size   = st.slider("Test Set Size (%)", 10, 40, 20, 5)

    with cr:
        st.markdown("#### 🤖 Model Selection")
        from src.models.registry import get_available_models
        avail = get_available_models()
        selected_models = st.multiselect("Models to Train", options=avail,
                                         default=avail[:5] if len(avail)>=5 else avail)

        st.markdown("#### 🔬 Hyperparameter Tuning")
        tune_en  = st.checkbox("Enable Optuna Tuning", value=True)
        n_trials = st.slider("Trials per Model",    5, 100, 30, 5,  disabled=not tune_en)
        timeout  = st.slider("Timeout per Model (s)",30, 600,120, 30, disabled=not tune_en)
        cv_folds = st.slider("CV Folds", 3, 10, 5)

        if st.button("💾 Apply & Save Config", use_container_width=True, type="primary"):
            import yaml
            cfg = {
                "project":{"name":"AutoML","version":"1.0.0","random_state":42},
                "data":{"raw_path":"data/raw","processed_path":"data/processed",
                        "test_size":test_size/100},
                "preprocessing":{"numeric_imputer":num_imputer,
                                  "categorical_imputer":cat_imputer,
                                  "scaler":scaler,"encoding":encoding},
                "models":{"enabled":selected_models,"cross_validation_folds":cv_folds},
                "tuning":{"enabled":tune_en,"n_trials":n_trials,
                          "timeout":timeout,"metric":"f1_weighted"},
                "evaluation":{"metrics":["accuracy","f1_weighted",
                                         "precision_weighted","recall_weighted"],
                              "threshold":0.5},
                "explainability":{"shap_enabled":True,"lime_enabled":False,
                                  "max_display_features":20},
                "tracking":{"mlflow":{"enabled":True,"tracking_uri":"mlruns",
                                       "experiment_name":"automl_classification"}},
                "deployment":{"api":{"host":"0.0.0.0","port":8000}},
                "logging":{"level":"INFO"},
            }
            Path("config").mkdir(exist_ok=True)
            with open("config/config.yaml","w") as f:
                yaml.dump(cfg, f, default_flow_style=False)
            st.session_state["dash_config"]     = cfg
            st.session_state["selected_models"] = selected_models
            st.session_state["tune_enabled"]    = tune_en
            st.success("✅ Configuration saved!")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — TRAINING
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🚀 Training":
    page_header("🚀", "Training", "Launch the AutoML training pipeline.")
    if st.session_state.df is None or st.session_state.target_col is None:
        st.warning("⚠️ Upload data and configure first.")
        st.stop()

    col_ctrl, col_logs = st.columns([1, 2])
    with col_ctrl:
        st.markdown("#### Pipeline Settings")
        target_col      = st.session_state.target_col
        selected_models = st.session_state.get("selected_models", [])
        tune            = st.session_state.get("tune_enabled", True)

        from src.models.registry import get_available_models
        if not selected_models:
            selected_models = get_available_models()[:4]

        st.info(f"🎯 Target: **{target_col}**")
        st.info(f"📊 Dataset: **{st.session_state.df.shape[0]:,} rows × {st.session_state.df.shape[1]:,} cols**")
        st.markdown(f"**Models:** {', '.join(selected_models)}")
        st.markdown(f"**Tuning:** {'✅ Enabled' if tune else '❌ Disabled'}")
        st.divider()

        if st.button("🚀 Start Training", use_container_width=True, type="primary"):
            st.session_state.training_logs = []
            st.session_state.trained = False

            config_path = "config/config.yaml"
            if not Path(config_path).exists():
                import yaml
                _dcfg = {
                    "project":{"name":"AutoML","version":"1.0.0","random_state":42},
                    "data":{"raw_path":"data/raw","processed_path":"data/processed","test_size":0.2},
                    "preprocessing":{"numeric_imputer":"median","categorical_imputer":"most_frequent",
                                     "scaler":"standard","encoding":"onehot"},
                    "models":{"enabled":selected_models,"cross_validation_folds":5},
                    "tuning":{"enabled":tune,"n_trials":20,"timeout":60,"metric":"f1_weighted"},
                    "evaluation":{"metrics":["accuracy","f1_weighted"],"threshold":0.5},
                    "explainability":{"shap_enabled":True,"lime_enabled":False,"max_display_features":20},
                    "tracking":{"mlflow":{"enabled":True,"tracking_uri":"mlruns",
                                          "experiment_name":"automl_classification"}},
                    "deployment":{"api":{"host":"0.0.0.0","port":8000}},
                    "logging":{"level":"INFO"},
                }
                Path("config").mkdir(exist_ok=True)
                with open(config_path,"w") as f:
                    yaml.dump(_dcfg, f)

            try:
                tmp_path = "data/raw/_dashboard_upload.csv"
                Path("data/raw").mkdir(parents=True, exist_ok=True)
                st.session_state.df.to_csv(tmp_path, index=False)

                from src.utils.config_loader    import load_config
                config = load_config(config_path)

                pbar         = st.progress(0)
                status_txt   = st.empty()
                log_ph       = st.empty()
                logs: List[str] = []

                def cb(msg, pct):
                    logs.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
                    pbar.progress(pct / 100)
                    status_txt.markdown(f"**{msg}**")
                    log_ph.markdown(
                        '<div class="log-box">' +
                        "<br>".join(f"<span style='color:#48bb78'>▶</span> {l}" for l in logs[-15:]) +
                        "</div>", unsafe_allow_html=True)

                from src.ingestion.data_loader    import DataIngestion
                from src.preprocessing.pipeline  import PreprocessingPipeline
                from src.models.trainer          import ModelTrainer
                from src.models.selector         import ModelSelector
                from src.evaluation.evaluator    import ModelEvaluator
                from src.tracking.mlflow_tracker import ExperimentTracker
                from sklearn.model_selection     import train_test_split

                cb("Loading and validating data...", 5)
                ingestion = DataIngestion(config)
                df_in, col_types, _ = ingestion.run(tmp_path, target_col)

                cb("Building preprocessing pipeline...", 15)
                preprocessor    = PreprocessingPipeline(config)
                numeric_cols    = col_types.get("numeric", [])
                categorical_cols= col_types.get("categorical", [])
                X, y = preprocessor.fit_transform(df_in, target_col, numeric_cols, categorical_cols)
                preprocessor.save("models/preprocessor.pkl")
                class_names = [str(c) for c in preprocessor.label_encoder.classes_]

                ts_val = config.get("data",{}).get("test_size", 0.2)
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=ts_val, random_state=42, stratify=y)

                best_params: Dict = {}
                if tune:
                    cb("Tuning hyperparameters with Optuna...", 30)
                    from src.tuning.optuna_tuner import HyperparameterTuner
                    tuner = HyperparameterTuner(config)
                    best_params = tuner.tune_all(X_train, y_train, selected_models)
                    Path("models").mkdir(exist_ok=True)
                    with open("models/best_params.json","w") as f:
                        json.dump(best_params, f, indent=2, default=str)

                cb("Training models...", 55)
                trainer = ModelTrainer(config)
                trained_models = trainer.train_all(X_train, y_train, selected_models, best_params)

                cb("Evaluating models...", 72)
                evaluator  = ModelEvaluator(config)
                leaderboard = evaluator.compare_models(trained_models, X_test, y_test)

                cb("Selecting best model...", 82)
                selector = ModelSelector(config)
                best_name, best_model = selector.select(trained_models, leaderboard)
                selector.save("models/best_model.pkl")

                cb("Logging to MLflow...", 90)
                tracker = ExperimentTracker(config)
                for name, model in trained_models.items():
                    row = leaderboard[leaderboard["model"] == name]
                    metrics = row.iloc[0].to_dict() if not row.empty else {}
                    tracker.log_full_run(
                        model_name=name, model=model,
                        params=best_params.get(name,{}),
                        metrics={k:v for k,v in metrics.items() if k!="model"},
                        tags={"best":str(name==best_name)})

                cb("✅ Training complete!", 100)
                st.session_state.update({
                    "trained":True, "leaderboard":leaderboard,
                    "best_model_name":best_name, "best_model":best_model,
                    "preprocessor":preprocessor, "class_names":class_names,
                    "feature_names":preprocessor.feature_names_out,
                    "X_test":X_test, "y_test":y_test, "X_train":X_train,
                    "trained_models":trained_models, "training_logs":logs,
                })
                st.success(f"🎉 Done! Best model: **{best_name}**")

            except Exception as e:
                import traceback
                st.error(f"❌ Training failed: {e}")
                st.code(traceback.format_exc())

    with col_logs:
        st.markdown("#### Training Logs")
        logs = st.session_state.training_logs
        html = "<br>".join(f"<span style='color:#48bb78'>▶</span> {l}" for l in logs) if logs else \
               "<span style='color:#8899bb'>Logs will appear here during training…</span>"
        st.markdown(f'<div class="log-box">{html}</div>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — MODEL PERFORMANCE
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📈 Model Performance":
    page_header("📈", "Model Performance",
                "Leaderboard, metrics comparison, confusion matrix, ROC curves.")
    if not st.session_state.trained:
        st.warning("⚠️ Train the pipeline first.")
        st.stop()

    leaderboard = st.session_state.leaderboard
    best_name   = st.session_state.best_model_name
    class_names = st.session_state.class_names
    best_row    = leaderboard[leaderboard["model"] == best_name].iloc[0]

    c1,c2,c3,c4,c5 = st.columns(5)
    metric_card(best_name,                                       "Best Model",  c1)
    metric_card(f"{best_row.get('accuracy',0):.4f}",             "Accuracy",    c2)
    metric_card(f"{best_row.get('f1_weighted',0):.4f}",          "F1 Score",    c3)
    metric_card(f"{best_row.get('precision_weighted',0):.4f}",   "Precision",   c4)
    metric_card(f"{best_row.get('recall_weighted',0):.4f}",      "Recall",      c5)

    # [F7] explain ranking
    st.info(
        "ℹ️ **Why is this model ranked #1?** "
        "Models are sorted by **F1 (weighted)** — a balance of precision & recall across all classes. "
        "ROC-AUC reflects probability ranking quality but is **not** the primary sort key here. "
        "To rank by ROC-AUC instead, edit `tuning → metric: roc_auc_ovr` in `config/config.yaml`."
    )
    st.markdown("<br>", unsafe_allow_html=True)

    tab1, tab2, tab3, tab4 = st.tabs(
        ["🏆 Leaderboard", "📊 Metric Comparison", "🟦 Confusion Matrix", "📈 ROC Curve"])

    with tab1:
        # [F6] only format numeric cols to avoid Arrow/style crash
        num_cols = [c for c in leaderboard.columns
                    if c != "model" and pd.api.types.is_numeric_dtype(leaderboard[c])]
        def _hl(row):
            return (["background-color:rgba(99,179,237,.12);font-weight:bold"] * len(row)
                    if row["model"] == best_name else [""]*len(row))
        styled = leaderboard.style.apply(_hl, axis=1).format({c:"{:.4f}" for c in num_cols})
        st.dataframe(styled, use_container_width=True, height=300)

    with tab2:
        m_cols = ["accuracy","f1_weighted","precision_weighted","recall_weighted"]
        avail  = [c for c in m_cols if c in leaderboard.columns]
        melt   = leaderboard[["model"]+avail].melt(id_vars="model",
                                                    var_name="Metric", value_name="Score")
        fig = px.bar(melt, x="model", y="Score", color="Metric", barmode="group",
                     title="Metric Comparison",
                     color_discrete_sequence=["#63b3ed","#48bb78","#f6ad55","#fc8181"])
        fig.update_xaxes(tickangle=20)
        st.plotly_chart(plotly_dark(fig), use_container_width=True)

        fig2 = go.Figure()
        for _, row in leaderboard.iterrows():
            vals = [row.get(m,0) for m in avail]
            if vals:
                fig2.add_trace(go.Scatterpolar(
                    r=vals+[vals[0]], theta=avail+[avail[0]],
                    fill="toself", name=row["model"], opacity=0.7))
        fig2.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0,1])),
                           title="Radar Chart")
        st.plotly_chart(plotly_dark(fig2), use_container_width=True)

    with tab3:
        trained_models = st.session_state.get("trained_models", {})
        X_test = st.session_state.X_test
        y_test = st.session_state.y_test
        mc = st.selectbox("Select Model", leaderboard["model"].tolist(), key="cm_model")
        if mc in trained_models and X_test is not None:
            from sklearn.metrics import confusion_matrix as _cm
            y_pred = trained_models[mc].predict(X_test)
            cm     = _cm(y_test, y_pred)
            labels = class_names or [str(i) for i in range(cm.shape[0])]
            fig = px.imshow(cm, x=labels, y=labels,
                            color_continuous_scale="Blues",
                            labels=dict(x="Predicted",y="Actual",color="Count"),
                            title=f"Confusion Matrix — {mc}", text_auto=True)
            st.plotly_chart(plotly_dark(fig), use_container_width=True)

    with tab4:
        trained_models = st.session_state.get("trained_models", {})
        X_test = st.session_state.X_test
        y_test = st.session_state.y_test
        mr = st.selectbox("Select Model", leaderboard["model"].tolist(), key="roc_model")
        if mr in trained_models and X_test is not None:
            from sklearn.metrics import roc_curve, auc
            from sklearn.preprocessing import label_binarize
            model = trained_models[mr]
            if hasattr(model, "predict_proba"):
                y_prob    = model.predict_proba(X_test)
                n_classes = y_prob.shape[1]
                labels    = class_names or [str(i) for i in range(n_classes)]
                fig = go.Figure()
                if n_classes == 2:
                    fpr, tpr, _ = roc_curve(y_test, y_prob[:,1])
                    fig.add_trace(go.Scatter(x=fpr, y=tpr,
                                            name=f"AUC={auc(fpr,tpr):.3f}",
                                            line=dict(color="#63b3ed",width=2)))
                else:
                    classes = np.unique(y_test)
                    y_bin   = label_binarize(y_test, classes=classes)
                    colors  = px.colors.qualitative.Set2
                    for i, cls in enumerate(classes):
                        fpr, tpr, _ = roc_curve(y_bin[:,i], y_prob[:,i])
                        lbl = labels[i] if i < len(labels) else str(cls)
                        fig.add_trace(go.Scatter(x=fpr, y=tpr,
                                                  name=f"{lbl} (AUC={auc(fpr,tpr):.3f})",
                                                  line=dict(color=colors[i%len(colors)],width=2)))
                fig.add_trace(go.Scatter(x=[0,1], y=[0,1], name="Random",
                                          line=dict(color="#8899bb",dash="dash")))
                fig.update_layout(title=f"ROC Curve — {mr}",
                                   xaxis_title="FPR", yaxis_title="TPR")
                st.plotly_chart(plotly_dark(fig), use_container_width=True)
            else:
                st.info("This model does not support predict_proba.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 5 — EXPLAINABILITY
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔍 Explainability":
    page_header("🔍", "Explainability",
                "Understand model decisions with SHAP and feature importance.")
    if not st.session_state.trained:
        st.warning("⚠️ Train the pipeline first.")
        st.stop()

    best_model    = st.session_state.best_model
    X_test        = st.session_state.X_test
    feature_names = st.session_state.feature_names
    class_names   = st.session_state.class_names

    tab1, tab2, tab3 = st.tabs(
        ["📊 Feature Importance", "🌐 SHAP Analysis", "🔍 Instance Explanation"])

    with tab1:
        st.markdown("#### Feature Importance")
        try:
            fi    = None
            names = feature_names or [f"feature_{i}" for i in range(500)]
            if hasattr(best_model, "feature_importances_"):
                fi = np.array(best_model.feature_importances_)
            elif hasattr(best_model, "coef_"):
                coef = np.array(best_model.coef_)
                fi   = np.abs(coef).mean(axis=0) if coef.ndim > 1 else np.abs(coef.flatten())
            if fi is not None:
                n     = min(len(fi), len(names), 25)
                df_fi = pd.DataFrame({"Feature":[str(x) for x in names[:n]],
                                      "Importance":fi[:n].astype(float)})
                df_fi = df_fi.sort_values("Importance", ascending=True).tail(20)
                fig   = px.bar(df_fi, x="Importance", y="Feature", orientation="h",
                               title=f"Feature Importances — {st.session_state.best_model_name}",
                               color="Importance",
                               color_continuous_scale=["#3182ce","#63b3ed"])
                st.plotly_chart(plotly_dark(fig), use_container_width=True)
            else:
                st.info("Not available for this model type. Try SHAP Analysis.")
        except Exception as e:
            st.error(f"Error: {e}")

    with tab2:
        st.markdown("#### SHAP Analysis")
        try:
            import shap as _shap
            SHAP_OK = True
        except ImportError:
            SHAP_OK = False
            st.warning("SHAP not installed: `pip install shap`")

        if SHAP_OK and X_test is not None:
            if st.button("🔬 Compute SHAP Values", use_container_width=True):
                with st.spinner("Computing SHAP values…"):
                    try:
                        import shap
                        sample     = X_test[:min(100, len(X_test))]
                        mtype      = type(best_model).__name__.lower()
                        if any(t in mtype for t in ["xgb","lgbm","catboost","forest","tree"]):
                            expl = shap.TreeExplainer(best_model)
                        elif "logistic" in mtype or "linear" in mtype:
                            expl = shap.LinearExplainer(best_model, sample)
                        else:
                            fn   = best_model.predict_proba if hasattr(best_model,"predict_proba") else best_model.predict
                            expl = shap.KernelExplainer(fn, shap.sample(sample, 50))

                        raw  = expl.shap_values(sample)
                        sv2d = shap_to_2d(raw)    # [F4] always 2-D

                        st.session_state.shap_values = sv2d
                        st.session_state.shap_sample = sample
                        st.success("✅ SHAP values computed!")
                    except Exception as e:
                        import traceback
                        st.error(f"SHAP failed: {e}")
                        st.code(traceback.format_exc())

            if st.session_state.shap_values is not None:
                sv2d  = st.session_state.shap_values
                names = feature_names or [f"feature_{i}" for i in range(sv2d.shape[1])]
                n     = min(sv2d.shape[1], len(names))
                msv   = np.abs(sv2d).mean(axis=0)[:n].astype(float)

                df_shap = pd.DataFrame({
                    "Feature":     [str(x) for x in names[:n]],
                    "Mean |SHAP|": msv,
                }).sort_values("Mean |SHAP|", ascending=True).tail(20)

                fig = px.bar(df_shap, x="Mean |SHAP|", y="Feature", orientation="h",
                             title="SHAP Feature Importance (Global)",
                             color="Mean |SHAP|",
                             color_continuous_scale=["#553c9a","#b794f4"])
                st.plotly_chart(plotly_dark(fig), use_container_width=True)

    with tab3:
        st.markdown("#### Instance-Level Explanation")
        if X_test is not None and st.session_state.shap_values is not None:
            sv2d  = st.session_state.shap_values
            idx   = st.slider("Select test instance", 0, len(X_test)-1, 0)
            names = feature_names or [f"feature_{i}" for i in range(sv2d.shape[1])]
            n     = min(sv2d.shape[1], len(names))
            isv   = sv2d[idx, :n].astype(float)

            df_inst = pd.DataFrame({
                "Feature":    [str(x) for x in names[:n]],
                "SHAP Value": isv,
                "Direction":  ["Positive" if v>=0 else "Negative" for v in isv],
            }).sort_values("SHAP Value", key=abs, ascending=True).tail(15)

            fig = px.bar(df_inst, x="SHAP Value", y="Feature", orientation="h",
                         color="Direction",
                         color_discrete_map={"Positive":"#48bb78","Negative":"#fc8181"},
                         title=f"SHAP Values — Instance #{idx}")
            st.plotly_chart(plotly_dark(fig), use_container_width=True)

            y_pred     = best_model.predict(X_test[idx:idx+1])
            pred_class = class_names[y_pred[0]] if class_names and y_pred[0]<len(class_names) else str(y_pred[0])
            st.markdown(f"**Predicted:** `{pred_class}`")
            if st.session_state.y_test is not None:
                ti  = st.session_state.y_test[idx]
                tc  = class_names[ti] if class_names and ti<len(class_names) else str(ti)
                st.markdown(f"**Actual:** `{tc}` {'✅' if str(pred_class)==str(tc) else '❌'}")
        else:
            st.info("Compute SHAP values first (SHAP Analysis tab).")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 6 — PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔮 Predictions":
    page_header("🔮", "Predictions", "Make predictions on new data.")
    if not st.session_state.trained:
        st.warning("⚠️ Train the pipeline first.")
        st.stop()

    best_model    = st.session_state.best_model
    preprocessor  = st.session_state.preprocessor
    class_names   = st.session_state.class_names
    df_original   = st.session_state.df
    target_col    = st.session_state.target_col
    feature_cols  = [c for c in df_original.columns if c != target_col]

    tab1, tab2 = st.tabs(["✏️ Manual Input", "📁 Batch Upload"])

    with tab1:
        st.markdown("#### Manual Feature Input")
        with st.form("manual_pred"):
            inputs: Dict = {}
            rows = [feature_cols[i:i+3] for i in range(0, len(feature_cols), 3)]
            for row_cols in rows:
                fcols = st.columns(len(row_cols))
                for fc, col in zip(row_cols, fcols):
                    sv = df_original[fc].dropna()
                    if pd.api.types.is_numeric_dtype(df_original[fc]):
                        inputs[fc] = col.number_input(fc,
                                                       value=float(sv.median()) if len(sv)>0 else 0.0,
                                                       key=f"inp_{fc}")
                    else:
                        opts = [str(v) for v in sv.unique().tolist()[:20]]
                        inputs[fc] = col.selectbox(fc, options=opts or [""], key=f"inp_{fc}")
            submitted = st.form_submit_button("🔮 Predict", use_container_width=True, type="primary")

        if submitted:
            try:
                X_new     = preprocessor.transform(pd.DataFrame([inputs]))
                pred      = best_model.predict(X_new)
                pred_lbl  = class_names[pred[0]] if class_names and pred[0]<len(class_names) else str(pred[0])
                c1, c2    = st.columns(2)
                c1.success(f"### 🎯 Prediction: **{pred_lbl}**")
                if hasattr(best_model, "predict_proba"):
                    probs   = best_model.predict_proba(X_new)[0].astype(float)
                    pdf     = pd.DataFrame({"Class":class_names or [str(i) for i in range(len(probs))],
                                            "Probability":probs}).sort_values("Probability",ascending=True)
                    fig     = px.bar(pdf, x="Probability", y="Class", orientation="h",
                                     title="Class Probabilities",
                                     color="Probability",
                                     color_continuous_scale=["#3182ce","#48bb78"])
                    c2.plotly_chart(plotly_dark(fig), use_container_width=True)
            except Exception as e:
                st.error(f"Prediction failed: {e}")

    with tab2:
        st.markdown("#### Batch Prediction from File")
        tf = st.file_uploader("Upload test CSV (no target column)", type=["csv","xlsx"])
        if tf:
            try:
                ext     = Path(tf.name).suffix.lower()
                test_df = pd.read_csv(tf) if ext==".csv" else pd.read_excel(tf)
                st.markdown(f"**{len(test_df):,} rows loaded**")
                st.dataframe(safe_df(test_df.head(5)), use_container_width=True)
                if st.button("🔮 Run Batch Predictions", use_container_width=True, type="primary"):
                    with st.spinner("Predicting…"):
                        X_b    = preprocessor.transform(test_df)
                        preds  = best_model.predict(X_b)
                        lbls   = [class_names[p] if class_names and p<len(class_names) else str(p)
                                  for p in preds]
                        res_df = test_df.copy()
                        res_df["prediction"] = lbls
                        if hasattr(best_model,"predict_proba"):
                            probs = best_model.predict_proba(X_b).astype(float)
                            for i, cn in enumerate(class_names or range(probs.shape[1])):
                                res_df[f"prob_{cn}"] = probs[:,i]
                        st.success(f"✅ Predicted {len(res_df):,} rows")
                        st.dataframe(safe_df(res_df.head(20)), use_container_width=True)
                        st.download_button("⬇️ Download CSV",
                                            data=res_df.to_csv(index=False).encode(),
                                            file_name="predictions.csv", mime="text/csv")
            except Exception as e:
                st.error(f"Batch prediction failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 7 — MODEL REGISTRY
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📦 Model Registry":
    page_header("📦", "Model Registry", "Browse MLflow experiments and compare runs.")
    try:
        import mlflow
        from src.utils.config_loader import load_config
        config   = load_config("config/config.yaml")
        t_cfg    = config.get("tracking",{}).get("mlflow",{})
        mlflow.set_tracking_uri(t_cfg.get("tracking_uri","mlruns"))
        exp_name = t_cfg.get("experiment_name","automl_classification")
        exp      = mlflow.get_experiment_by_name(exp_name)
    except Exception as e:
        st.error(f"MLflow unavailable: {e}")
        st.stop()

    if exp is None:
        st.info("No MLflow experiment yet. Train a model first.")
        st.stop()

    runs_df = mlflow.search_runs(experiment_ids=[exp.experiment_id],
                                  order_by=["metrics.f1_weighted DESC"],
                                  max_results=50)
    if runs_df.empty:
        st.info("No runs logged yet.")
        st.stop()

    m_cols       = [c for c in runs_df.columns if c.startswith("metrics.")]
    disp_cols    = ["tags.mlflow.runName","start_time","status"] + m_cols[:5]
    disp_cols    = [c for c in disp_cols if c in runs_df.columns]

    c1,c2,c3 = st.columns(3)
    metric_card(str(len(runs_df)), "Total Runs", c1)
    if "metrics.f1_weighted" in runs_df.columns:
        metric_card(f"{runs_df['metrics.f1_weighted'].max():.4f}", "Best F1", c2)
    if "metrics.accuracy" in runs_df.columns:
        metric_card(f"{runs_df['metrics.accuracy'].max():.4f}", "Best Accuracy", c3)

    st.markdown("<br>", unsafe_allow_html=True)
    tab1, tab2 = st.tabs(["📋 All Runs","📊 Run Comparison"])

    with tab1:
        st.dataframe(safe_df(runs_df[disp_cols].head(30)), use_container_width=True, height=350)

    with tab2:
        avail = [c.replace("metrics.","") for c in m_cols
                 if any(k in c for k in ["f1","accuracy","roc","precision","recall"])]
        if avail:
            sel = st.selectbox("Metric to compare", avail)
            fc  = f"metrics.{sel}"
            if fc in runs_df.columns:
                pf = runs_df[["tags.mlflow.runName",fc]].dropna()
                pf.columns = ["Run", sel]
                fig = px.bar(pf.sort_values(sel, ascending=True),
                             x=sel, y="Run", orientation="h",
                             title=f"Experiment Comparison — {sel}",
                             color=sel,
                             color_continuous_scale=["#3182ce","#48bb78"])
                st.plotly_chart(plotly_dark(fig), use_container_width=True)
