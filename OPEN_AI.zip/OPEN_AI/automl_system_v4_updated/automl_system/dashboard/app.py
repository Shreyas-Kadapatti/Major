"""
AutoML Classification Framework — Dashboard v3.0

Architecture change from v2.0:
  - Navigation: Data Upload, Configuration, Training, Hypothesis Testing, Predictions, Model Registry
  - Training page executes pipeline then renders ALL results inline on the same page:
      Model Performance, Explainability (SHAP + LIME), Hyperparameter Log, Model Card (auto)
  - AIF360 fairness metrics section added (with graceful fallback if not installed)
  - LIME local explanations added alongside SHAP
  - Zero emojis throughout
  - All artifacts auto-downloaded from Training results section
"""

import io
import json
import os
import pickle
import sys
import time
import warnings
from pathlib import Path
from typing import Dict, List, Optional

warnings.filterwarnings("ignore")

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
os.chdir(_PROJECT_ROOT)

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(
    page_title="AutoML Classification Framework",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

.stApp { background-color: #0c0e14; }

div[data-testid="stSidebar"] {
    background-color: #0f1118;
    border-right: 1px solid #1e2535;
}
div[data-testid="stSidebar"] * { color: #a0aec0 !important; }

.page-header {
    border-left: 3px solid #4a90d9;
    padding: 12px 18px;
    margin-bottom: 28px;
    background: #111520;
    border-radius: 0 6px 6px 0;
}
.page-header h2 { color: #e2e8f0 !important; font-size: 1.25rem; font-weight: 600; margin: 0; letter-spacing: -0.01em; }
.page-header p { color: #64748b !important; font-size: 0.82rem; margin: 4px 0 0; }

.results-header {
    border-left: 3px solid #38a169;
    padding: 10px 16px;
    margin: 32px 0 20px;
    background: #0d1a14;
    border-radius: 0 6px 6px 0;
}
.results-header h3 { color: #a3e4b8 !important; font-size: 1.05rem; font-weight: 600; margin: 0; }
.results-header p { color: #4a6a5a !important; font-size: 0.78rem; margin: 3px 0 0; }

.sub-header {
    border-left: 2px solid #7c6fc9;
    padding: 8px 14px;
    margin: 24px 0 14px;
    background: #110f1e;
    border-radius: 0 4px 4px 0;
}
.sub-header h4 { color: #c4b8f0 !important; font-size: 0.95rem; font-weight: 600; margin: 0; }

.metric-card {
    background: #111520;
    border: 1px solid #1e2535;
    border-radius: 8px;
    padding: 18px 20px;
    text-align: center;
}
.metric-value {
    font-size: 1.6rem;
    font-weight: 700;
    color: #4a90d9;
    font-family: 'JetBrains Mono', monospace;
    letter-spacing: -0.02em;
}
.metric-label {
    font-size: 0.72rem;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-top: 5px;
}

.section-label {
    font-size: 0.7rem;
    font-weight: 600;
    color: #4a5568;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    margin: 20px 0 8px;
}

.log-box {
    background: #080a0f;
    border: 1px solid #1e2535;
    border-radius: 6px;
    padding: 14px 16px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.78rem;
    color: #8ba0bb;
    max-height: 280px;
    overflow-y: auto;
    line-height: 1.75;
}

.insight-box {
    background: #111520;
    border: 1px solid #1e2535;
    border-left: 3px solid #7c6fc9;
    border-radius: 0 6px 6px 0;
    padding: 10px 14px;
    margin: 8px 0;
    font-size: 0.82rem;
    color: #a0aec0;
    line-height: 1.65;
}

.fairness-box {
    background: #0d1520;
    border: 1px solid #1e3050;
    border-left: 3px solid #0ea5e9;
    border-radius: 0 6px 6px 0;
    padding: 10px 14px;
    margin: 8px 0;
    font-size: 0.82rem;
    color: #90c0d8;
    line-height: 1.65;
}

.champion-banner {
    background: #0d1a14;
    border: 1px solid #1e4030;
    border-left: 3px solid #38a169;
    border-radius: 0 6px 6px 0;
    padding: 14px 18px;
}
.champion-name { font-size: 1.1rem; font-weight: 700; color: #38a169; font-family: 'JetBrains Mono', monospace; }
.champion-sub { font-size: 0.75rem; color: #4a6a5a; margin-top: 3px; text-transform: uppercase; letter-spacing: 0.08em; }

.status-ok   { display:inline-block; padding:2px 10px; background:#0d1a14; border:1px solid #1e4030; color:#38a169; border-radius:12px; font-size:0.75rem; font-weight:500; }
.status-warn { display:inline-block; padding:2px 10px; background:#1a140d; border:1px solid #4a3010; color:#d97706; border-radius:12px; font-size:0.75rem; font-weight:500; }

.artifact-card {
    background: #0f1118;
    border: 1px solid #1e2535;
    border-radius: 8px;
    padding: 14px 16px;
    margin-bottom: 10px;
}
.artifact-title { font-size: 0.85rem; font-weight: 600; color: #cbd5e0; }
.artifact-desc  { font-size: 0.75rem; color: #4a5568; margin-top: 3px; }

.stButton > button {
    background: #1a2540; color: #90b8e0; border: 1px solid #2a3a5a;
    border-radius: 6px; font-size: 0.84rem; font-weight: 500; transition: all 0.15s;
}
.stButton > button:hover { background: #223060; border-color: #4a90d9; color: #b0cff0; }
.stButton > button[kind="primary"] { background: #1c3a6e; color: #90c0f0; border-color: #2a5a9e; }
.stButton > button[kind="primary"]:hover { background: #2a4a8e; }

.dataframe { font-size: 0.82rem !important; }

.stTabs [data-baseweb="tab-list"] { gap: 0; border-bottom: 1px solid #1e2535; }
.stTabs [data-baseweb="tab"] { font-size: 0.82rem; font-weight: 500; color: #64748b !important; padding: 8px 16px; border: none; }
.stTabs [aria-selected="true"] { color: #4a90d9 !important; border-bottom: 2px solid #4a90d9 !important; }

h1, h2, h3 { color: #e2e8f0 !important; }
h4 { color: #cbd5e0 !important; font-size: 0.92rem !important; font-weight: 600 !important; margin: 0 0 12px !important; }
p, li { color: #8892a4; }
label { color: #64748b !important; font-size: 0.8rem !important; }
hr { border-color: #1e2535 !important; }
div[data-testid="stRadio"] label { font-size: 0.83rem !important; font-weight: 500; }
div[data-testid="stRadio"] label:hover { color: #90b8e0 !important; }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
_DEFAULTS: Dict = {
    "df": None, "file_name": None, "target_col": None, "col_types": None,
    "trained": False, "training_logs": [],
    "leaderboard": None, "best_model_name": None, "best_model": None,
    "preprocessor": None, "class_names": [], "feature_names": [],
    "shap_values": None, "shap_sample": None, "shap_explainer_obj": None,
    "leakage_report": None, "leakage_overridden": False, "guardrail_warnings": [],
    "openai_api_key": os.getenv("OPENAI_API_KEY", ""), "sr117_risk_tier": None, "sr117_narrative": "",
    "ai_performance_insights": "", "monitoring_report": None,
    "X_test": None, "y_test": None, "X_train": None, "X_val": None,
    "y_train": None, "y_val": None,
    "trained_models": {}, "selected_models": [], "tune_enabled": True,
    "train_metrics": {}, "val_metrics": {}, "test_metrics": {},
    "best_params": {}, "tuner_obj": None, "model_card_md": None,
    "hypothesis_results": None, "artifact_path": None,
    "dash_config": None, "fairness_results": None, "df_cleaned": None,
    "imb_method_key": "none",
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding: 18px 4px 6px;">
      <div style="font-size: 1.05rem; font-weight: 700; color: #e2e8f0; letter-spacing: -0.01em;">AutoML Classification</div>
      <div style="font-size: 0.7rem; color: #4a5568; margin-top: 3px; text-transform: uppercase; letter-spacing: 0.1em;">Framework v4.0 &mdash; SR 11-7 Ready &mdash; AI-Powered</div>
    </div>""", unsafe_allow_html=True)
    st.divider()

    page = st.radio("Navigation", [
        "Data Upload",
        "Configuration",
        "Training",
        "Hypothesis Testing",
        "Predictions",
        "Model Registry",
        "Monitoring & Drift",
    ], label_visibility="collapsed")

    st.divider()

    # ── OpenAI API Key — loaded from backend .env (OPENAI_API_KEY) ──
    with st.expander("🤖 AI Insights", expanded=False):
        _env_key = os.getenv("OPENAI_API_KEY", "")
        if _env_key:
            st.session_state["openai_api_key"] = _env_key
        if st.session_state.get("openai_api_key"):
            st.markdown(
                '<span style="color:#38a169;font-size:0.8rem;">✅ OpenAI API key loaded from backend</span>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<span style="color:#e05252;font-size:0.78rem;">⚠️ No API key found — set '                '<code>OPENAI_API_KEY</code> in your <code>.env</code> file to enable AI insights.</span>',
                unsafe_allow_html=True,
            )

    st.divider()

    data_ok  = st.session_state.df is not None
    train_ok = st.session_state.trained
    tgt      = st.session_state.target_col or "Not selected"
    d_pill   = '<span class="status-ok">Loaded</span>'    if data_ok  else '<span class="status-warn">No data</span>'
    tr_pill  = '<span class="status-ok">Complete</span>'  if train_ok else '<span class="status-warn">Pending</span>'

    st.markdown(f"""
    <div style="background:#0f1118;border:1px solid #1e2535;border-radius:6px;padding:12px 14px;font-size:0.78rem;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px;">
        <span style="color:#4a5568;">Dataset</span>{d_pill}
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px;">
        <span style="color:#4a5568;">Target</span>
        <span style="color:#7c6fc9;font-family:'JetBrains Mono',monospace;font-size:0.75rem;">{tgt}</span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="color:#4a5568;">Training</span>{tr_pill}
      </div>
    </div>""", unsafe_allow_html=True)

    if train_ok and st.session_state.best_model_name:
        st.markdown(f"""
        <div style="margin-top:10px;">
          <div class="champion-banner">
            <div class="champion-sub">Champion Model</div>
            <div class="champion-name">{st.session_state.best_model_name.replace('_',' ').title()}</div>
          </div>
        </div>""", unsafe_allow_html=True)

# ── Helpers ────────────────────────────────────────────────────────────────────
def page_header(title: str, subtitle: str = ""):
    sub = f"<p>{subtitle}</p>" if subtitle else ""
    st.markdown(f'<div class="page-header"><h2>{title}</h2>{sub}</div>', unsafe_allow_html=True)

def results_header(title: str, subtitle: str = ""):
    sub = f"<p>{subtitle}</p>" if subtitle else ""
    st.markdown(f'<div class="results-header"><h3>{title}</h3>{sub}</div>', unsafe_allow_html=True)

def sub_header(title: str):
    st.markdown(f'<div class="sub-header"><h4>{title}</h4></div>', unsafe_allow_html=True)

def metric_card(value: str, label: str, col):
    col.markdown(
        f'<div class="metric-card"><div class="metric-value">{value}</div>'
        f'<div class="metric-label">{label}</div></div>', unsafe_allow_html=True)

def insight(text: str):
    st.markdown(f'<div class="insight-box">{text}</div>', unsafe_allow_html=True)

def fairness_note(text: str):
    st.markdown(f'<div class="fairness-box">{text}</div>', unsafe_allow_html=True)

def section(label: str):
    st.markdown(f'<div class="section-label">{label}</div>', unsafe_allow_html=True)

def apply_theme(fig):
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(17,21,32,0.8)",
        font=dict(family="Inter", color="#8892a4", size=12),
        margin=dict(t=44, b=36, l=44, r=24),
        title_font=dict(size=13, color="#cbd5e0"),
    )
    return fig

def safe_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object: out[c] = out[c].astype(str)
        elif pd.api.types.is_float_dtype(out[c]): out[c] = out[c].astype(float)
        elif pd.api.types.is_integer_dtype(out[c]): out[c] = out[c].astype(int)
    return out

def pkl_download(model, name: str, label: str = "Download Champion Model (PKL)"):
    buf = io.BytesIO()
    pickle.dump({"model": model, "model_name": name}, buf)
    buf.seek(0)
    st.download_button(label, data=buf, file_name=f"{name}_champion.pkl",
                       mime="application/octet-stream", use_container_width=True)

def compute_metrics(model, X, y):
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
    yp  = model.predict(X)
    res = {
        "accuracy":           round(accuracy_score(y, yp), 4),
        "f1_weighted":        round(f1_score(y, yp, average="weighted", zero_division=0), 4),
        "precision_weighted": round(precision_score(y, yp, average="weighted", zero_division=0), 4),
        "recall_weighted":    round(recall_score(y, yp, average="weighted", zero_division=0), 4),
    }
    if hasattr(model, "predict_proba"):
        try:
            ypr = model.predict_proba(X)
            res["roc_auc"] = round(
                roc_auc_score(y, ypr, multi_class="ovr", average="weighted")
                if len(np.unique(y)) > 2 else roc_auc_score(y, ypr[:, 1]), 4)
        except Exception:
            pass
    return res

def _compute_shap(bm, Xt, fn, force_recompute: bool = False):
    """
    Compute SHAP values using the model-aware ExplainabilityEngine with caching.

    Returns (sv_2d_signed, sample, explainer_obj).
    Values are SIGNED so beeswarm plots show direction of impact.

    WHY CACHING: SHAP is the single most expensive step in the pipeline.
    Caching ensures the dashboard never recomputes on repeated UI interactions,
    keeping explainability latency low even on large datasets with slow models.
    """
    from src.explainability.shap_explainer import ExplainabilityEngine, get_cached_shap, _model_fingerprint

    cache_key = _model_fingerprint(bm, Xt)
    if not force_recompute:
        cached = get_cached_shap(cache_key)
        if cached is not None:
            sv  = cached["shap_values"]
            smp = cached.get("sample", Xt[:min(200, len(Xt))])
            return sv, smp, cached["explainer"]

    engine = ExplainabilityEngine({"explainability": {"shap_enabled": True, "max_display_features": 20}})
    sv = engine.compute_shap(bm, Xt, feature_names=fn, force_recompute=force_recompute)
    smp = Xt[:min(200, len(Xt))]
    if sv is None:
        raise RuntimeError("SHAP computation returned None — check model compatibility.")
    return sv, smp, engine.explainer


def _get_resampler(method_key: str):
    """
    Return an imbalanced-learn resampler instance for the given key,
    or None if method is 'none' / imblearn not installed.
    """
    if method_key == "none":
        return None
    try:
        if method_key == "smote":
            from imblearn.over_sampling import SMOTE
            return SMOTE(random_state=42)
        elif method_key == "adasyn":
            from imblearn.over_sampling import ADASYN
            return ADASYN(random_state=42)
        elif method_key == "random_over":
            from imblearn.over_sampling import RandomOverSampler
            return RandomOverSampler(random_state=42)
        elif method_key == "random_under":
            from imblearn.under_sampling import RandomUnderSampler
            return RandomUnderSampler(random_state=42)
        elif method_key == "smoteenn":
            from imblearn.combine import SMOTEENN
            return SMOTEENN(random_state=42)
        elif method_key == "smotetomek":
            from imblearn.combine import SMOTETomek
            return SMOTETomek(random_state=42)
    except ImportError:
        return None
    return None

# ──────────────────────────────────────────────────────────────────────────────

def _apply_missing_value_handling(
    df: pd.DataFrame,
    target_col: str,
    numeric_strategy: str = "median",
    categorical_strategy: str = "most_frequent",
) -> pd.DataFrame:
    """
    Impute missing values in the raw DataFrame using configured strategies.
    - Numeric columns      : mean | median | most_frequent
    - Categorical columns  : most_frequent | constant ('missing')
    - Target column        : rows with null target are dropped (never imputed)
    Returns a new clean DataFrame with no missing values in feature columns.
    """
    df = df.copy()

    # Drop rows where target itself is null — labels cannot be imputed
    if target_col in df.columns:
        df = df.dropna(subset=[target_col]).reset_index(drop=True)

    for col in df.columns:
        if col == target_col:
            continue
        if df[col].isnull().sum() == 0:
            continue  # already clean

        if pd.api.types.is_numeric_dtype(df[col]):
            if numeric_strategy == "mean":
                fill_val = df[col].mean()
            elif numeric_strategy == "most_frequent":
                fill_val = df[col].mode().iloc[0] if not df[col].mode().empty else 0
            elif numeric_strategy == "zero":
                fill_val = 0
            else:                                      # default: median
                fill_val = df[col].median()
            df[col] = df[col].fillna(fill_val)
        else:
            # Categorical / object / mixed
            if categorical_strategy == "constant":
                fill_val = "missing"
            else:                                      # default: most_frequent
                fill_val = df[col].mode().iloc[0] if not df[col].mode().empty else "missing"
            df[col] = df[col].fillna(fill_val)

    return df


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — DATA UPLOAD
# ══════════════════════════════════════════════════════════════════════════════
if page == "Data Upload":
    page_header("Data Upload",
                "Upload a CSV, Parquet, or Excel file — or connect to a database. "
                "Statistics are computed automatically on load.")

    src_tab, db_tab = st.tabs(["File Upload", "Database Connection"])

    with src_tab:
        col_up, col_prev = st.columns([1, 2])
        with col_up:
            section("Source")
            uploaded = st.file_uploader("CSV, Parquet, or Excel",
                                        type=["csv", "xlsx", "xls", "parquet"],
                                        label_visibility="collapsed")
            if uploaded:
                try:
                    ext = Path(uploaded.name).suffix.lower()
                    df  = (pd.read_csv(uploaded) if ext == ".csv" else
                           pd.read_excel(uploaded) if ext in [".xlsx", ".xls"] else
                           pd.read_parquet(uploaded))
                    st.session_state.df        = df
                    st.session_state.file_name = uploaded.name
                    st.session_state.col_types = None
                    Path("data/raw").mkdir(parents=True, exist_ok=True)
                    df.to_csv(f"data/raw/{uploaded.name}", index=False)
                    st.success(f"Loaded {uploaded.name} — {len(df):,} rows x {len(df.columns)} columns")
                except Exception as e:
                    st.error(f"Failed to load file: {e}")

            st.divider()
            section("Sample Datasets")
            from sklearn import datasets as _sk_ds
            _samples = {
                "Iris (4 features, 3 classes)":        ("iris",          _sk_ds.load_iris),
                "Breast Cancer (30 features, binary)": ("breast_cancer", _sk_ds.load_breast_cancer),
                "Wine (13 features, 3 classes)":       ("wine",          _sk_ds.load_wine),
            }
            for lbl, (key, fn_) in _samples.items():
                if st.button(lbl, use_container_width=True, key=f"sample_{key}"):
                    ds = fn_(as_frame=True)
                    df = ds.frame.copy(); df["target"] = ds.target_names[ds.target]
                    st.session_state.df = df; st.session_state.file_name = f"{key}.csv"
                    st.session_state.col_types = None; st.rerun()

        with col_prev:
            if st.session_state.df is not None:
                df = st.session_state.df
                section("Dataset Overview")
                c1, c2, c3, c4 = st.columns(4)
                metric_card(f"{df.shape[0]:,}",                "Rows",        c1)
                metric_card(f"{df.shape[1]:,}",                "Columns",     c2)
                metric_card(f"{df.isnull().sum().sum():,}",     "Missing",     c3)
                metric_card(f"{df.duplicated().sum():,}",       "Duplicates",  c4)
                st.markdown("<br>", unsafe_allow_html=True)
                t1, t2, t3 = st.tabs(["Preview", "Statistics", "Missing Values"])
                with t1: st.dataframe(safe_df(df.head(20)), use_container_width=True, height=340)
                with t2:
                    desc = df.describe(include="all").T.reset_index().rename(columns={"index": "column"})
                    st.dataframe(safe_df(desc), use_container_width=True)
                with t3:
                    miss = df.isnull().sum().reset_index(); miss.columns = ["Column", "Count"]
                    miss["Percent"] = (miss["Count"] / len(df) * 100).round(2)
                    miss = miss[miss["Count"] > 0]
                    if miss.empty: st.success("No missing values detected.")
                    else:
                        st.plotly_chart(apply_theme(px.bar(miss, x="Column", y="Percent",
                            color="Percent", color_continuous_scale=["#4a90d9", "#e05252"],
                            title="Missing Value Rate (%)")), use_container_width=True)
                        st.dataframe(safe_df(miss), use_container_width=True)
            else:
                st.info("Upload a file or select a sample dataset to begin.")

    with db_tab:
        section("Connection Settings")
        dc1, dc2 = st.columns(2)
        with dc1:
            db_type = st.selectbox("Database Type", ["postgresql", "mysql", "sqlite", "mssql", "oracle", "generic"])
            if db_type == "sqlite":
                db_path  = st.text_input("SQLite File Path", placeholder=":memory: or path/to/db.sqlite")
                host = port = username = password = ""; database = db_path
            elif db_type == "generic":
                raw_url  = st.text_input("SQLAlchemy URL", placeholder="dialect+driver://user:pass@host/db")
                host = port = username = password = database = ""
            else:
                host     = st.text_input("Host", "localhost")
                port     = st.number_input("Port", value={"postgresql":5432,"mysql":3306,"mssql":1433,"oracle":1521}.get(db_type,5432), min_value=1, max_value=65535)
                database = st.text_input("Database"); username = st.text_input("Username"); password = st.text_input("Password", type="password")
        with dc2:
            qmode = st.radio("Load Method", ["SQL Query", "Table Name"], horizontal=True)
            sql_q = st.text_area("SQL Query", value="SELECT * FROM my_table LIMIT 50000", height=100) if qmode == "SQL Query" else None
            if qmode == "Table Name":
                tbl  = st.text_input("Table Name"); rlim = st.number_input("Row Limit", value=50000, min_value=100, step=1000)
            if st.button("Connect and Load", use_container_width=True, type="primary"):
                try:
                    from src.ingestion.db_connector import DatabaseConnector
                    conn = (DatabaseConnector(db_type="sqlite", database=database) if db_type=="sqlite" else
                            DatabaseConnector(db_type="generic", connection_string=raw_url) if db_type=="generic" else
                            DatabaseConnector(db_type=db_type, host=host, port=int(port), database=database, username=username, password=password))
                    with st.spinner("Connecting..."):
                        df = conn.query(sql_q) if qmode=="SQL Query" else conn.read_table(tbl, limit=int(rlim))
                    st.session_state.df = df; st.session_state.file_name = f"db_{db_type}"
                    st.success(f"Loaded {len(df):,} rows x {len(df.columns)} columns"); conn.disconnect()
                except Exception as e: st.error(f"Connection failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
elif page == "Configuration":
    page_header("Configuration",
                "Configure preprocessing, class imbalance handling, model selection, and tuning. "
                "After saving you can preview and download the cleaned and processed datasets.")

    if st.session_state.df is None:
        st.warning("Upload a dataset first."); st.stop()

    df = st.session_state.df
    cl, cr = st.columns(2)

    # ── Left column ───────────────────────────────────────────────────────────
    with cl:
        section("Target Column")
        tc = st.selectbox("Target Column", df.columns.tolist(),
                          index=len(df.columns)-1, label_visibility="collapsed")
        st.session_state.target_col = tc

        if tc:
            vc = df[tc].value_counts()
            fig_cls = apply_theme(px.bar(
                x=vc.index.astype(str), y=vc.values,
                labels={"x": "Class", "y": "Count"},
                title="Class Distribution (Raw)",
                color=vc.values,
                color_continuous_scale=["#2a5a9e", "#4a90d9"],
            ))
            st.plotly_chart(fig_cls, use_container_width=True)

            # Imbalance ratio warning
            if len(vc) >= 2:
                ratio = vc.iloc[0] / vc.iloc[-1]
                if ratio >= 3:
                    st.markdown(
                        f'<div class="insight-box" style="border-left-color:#d97706;">'
                        f'Imbalance detected — majority class is <strong>{ratio:.1f}x</strong> larger than '
                        f'minority class. Consider enabling class imbalance handling below.</div>',
                        unsafe_allow_html=True
                    )

        section("Preprocessing and Missing Value Handling")
        st.caption(
            "The selected fill strategy is applied uniformly across the entire pipeline — "
            "raw data cleaning and the sklearn preprocessing pipeline used during model training."
        )

        mv_num_raw = st.selectbox(
            "Numeric Missing Values — Fill Strategy",
            ["median", "mean", "most_frequent", "zero"],
            index=0,
            key="mv_num_raw",
            help="Applied to all numeric columns throughout the pipeline. "
                 "median = fill with column median (robust to outliers). "
                 "mean = fill with column mean. "
                 "most_frequent = fill with the most common value. "
                 "zero = fill with 0."
        )
        mv_cat_raw = st.selectbox(
            "Categorical Missing Values — Fill Strategy",
            ["most_frequent", "constant (label: 'missing')"],
            index=0,
            key="mv_cat_raw",
            help="Applied to all categorical/text columns throughout the pipeline. "
                 "most_frequent = fill with the most common category. "
                 "constant = fill with the string 'missing' (keeps missingness as a signal)."
        )
        mv_cat_key = "most_frequent" if mv_cat_raw.startswith("most_frequent") else "constant"

        # Unified: sklearn pipeline mirrors the same strategy — no separate controls needed
        ni  = mv_num_raw if mv_num_raw != "zero" else "median"
        ci_ = mv_cat_key

        scaler = st.selectbox("Numeric Scaler", ["standard", "minmax", "robust"])
        enc    = st.selectbox("Categorical Encoding", ["onehot", "label"])

        # ── Text & Sentiment Analysis ─────────────────────────────────────────
        section("Text and Sentiment Analysis")
        _all_feat_cols = [c for c in df.columns if c != tc]
        _text_candidates = [
            c for c in _all_feat_cols
            if not pd.api.types.is_numeric_dtype(df[c])
            and df[c].dropna().astype(str).str.split().str.len().median() > 3
        ]
        if _text_candidates:
            st.caption(
                "Free-text columns detected. Enable sentiment analysis to extract TF-IDF features "
                "and sentiment polarity scores, then use them as numeric features during training."
            )
            enable_sentiment = st.checkbox("Enable Text / Sentiment Analysis", value=True, key="enable_sentiment")
            if enable_sentiment:
                text_col_sel = st.multiselect(
                    "Text Column(s) to Analyse",
                    _text_candidates,
                    default=_text_candidates[:1],
                    key="sentiment_text_cols",
                    help="Columns containing free text (e.g. reviews, comments). "
                         "TF-IDF bag-of-words features and TextBlob sentiment polarity/subjectivity "
                         "scores will be extracted and added as numeric input features."
                )
                tfidf_max_features = st.slider(
                    "TF-IDF Max Features (per text column)", 50, 500, 100, 50,
                    key="tfidf_max_features",
                    help="Number of top vocabulary terms to extract per text column via TF-IDF."
                )
                if text_col_sel:
                    st.markdown(
                        '<div class="insight-box" style="border-left-color:#38a169;margin-top:6px;">'
                        '<strong>What gets extracted per text column:</strong><br>'
                        '&bull; <strong>TF-IDF features</strong> — top N weighted vocabulary terms as sparse numeric features.<br>'
                        '&bull; <strong>Sentiment polarity</strong> — score from -1.0 (very negative) to +1.0 (very positive).<br>'
                        '&bull; <strong>Sentiment subjectivity</strong> — score from 0.0 (objective) to 1.0 (subjective).<br>'
                        'These are joined to the dataset as numeric columns before model training.</div>',
                        unsafe_allow_html=True
                    )
            else:
                text_col_sel = []
                tfidf_max_features = 100
        else:
            st.caption("No free-text columns detected in this dataset.")
            enable_sentiment = False
            text_col_sel = []
            tfidf_max_features = 100
        ts     = st.slider("Test Set Size (%)", 10, 40, 20, 5)

        # ── Feature Leakage Detection ──────────────────────────────────────────
        section("Feature Leakage Detection")
        enable_leakage_detection = st.checkbox(
            "Run leakage detection before training",
            value=st.session_state.get("enable_leakage_detection", True),
            key="enable_leakage_detection",
            help=(
                "Scans features for potential data leakage before training. "                "Disable if you are confident your features are clean and want to "                "avoid the performance overhead. Blocked features (high correlation with target) "                "are automatically removed; suspicious features are flagged with a warning."            ),
        )
        if enable_leakage_detection:
            st.markdown(
                '<div class="insight-box" style="border-left-color:#4a90d9;font-size:0.82rem;">'                '✅ <strong>Leakage detection enabled</strong> — features that perfectly predict the target '                '(correlation &gt; 0.95) will be blocked automatically. Suspicious features (0.7–0.95) will be flagged.'                '</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div class="insight-box" style="border-left-color:#d97706;font-size:0.82rem;">'                '⚠️ <strong>Leakage detection disabled</strong> — training will proceed without scanning features for leakage. '                'Only disable this if you have already validated your feature set.'                '</div>',
                unsafe_allow_html=True,
            )

        # ── Class Imbalance Handling ──────────────────────────────────────────
        section("Class Imbalance Handling")

        # Check imblearn availability
        try:
            import imblearn as _ibl_chk
            IMBLEARN_OK = True
        except ImportError:
            IMBLEARN_OK = False

        if not IMBLEARN_OK:
            st.markdown(
                '<div class="insight-box" style="border-left-color:#e05252;">'
                'imbalanced-learn is not installed. Run: '
                '<code>pip install imbalanced-learn</code> to enable resampling methods.'
                '</div>',
                unsafe_allow_html=True
            )
            imb_method = "None"
        else:
            imb_method = st.selectbox(
                "Resampling Method",
                ["None",
                 "SMOTE — Synthetic Minority Oversampling",
                 "ADASYN — Adaptive Synthetic Oversampling",
                 "RandomOverSampler — Duplicate Minority Samples",
                 "RandomUnderSampler — Reduce Majority Samples",
                 "SMOTEENN — SMOTE + Edited Nearest Neighbours (combined)",
                 "SMOTETomek — SMOTE + Tomek Links (combined)"],
                index=0,
                key="imb_method_cfg",
                help="Applied to the training split only — validation and test sets are never resampled."
            )

            # Description for the selected method
            _imb_desc = {
                "None": "",
                "SMOTE — Synthetic Minority Oversampling":
                    "Generates synthetic minority-class samples by interpolating between existing ones. "
                    "Good first choice for moderate imbalance (ratio up to ~10:1).",
                "ADASYN — Adaptive Synthetic Oversampling":
                    "Like SMOTE but focuses generation on harder-to-learn boundary regions. "
                    "Better when minority samples are scattered.",
                "RandomOverSampler — Duplicate Minority Samples":
                    "Simply duplicates random minority rows. Fast with no information added; "
                    "use when data is very small.",
                "RandomUnderSampler — Reduce Majority Samples":
                    "Randomly removes majority-class rows. Fastest approach but discards real data.",
                "SMOTEENN — SMOTE + Edited Nearest Neighbours (combined)":
                    "Oversamples minority then cleans noisy samples using ENN. "
                    "Good when class boundaries overlap heavily.",
                "SMOTETomek — SMOTE + Tomek Links (combined)":
                    "Oversamples minority then removes Tomek link pairs from both classes. "
                    "Produces cleaner decision boundaries.",
            }
            if imb_method != "None" and _imb_desc.get(imb_method):
                st.markdown(
                    f'<div class="insight-box">{_imb_desc[imb_method]}</div>',
                    unsafe_allow_html=True
                )
                st.caption("Resampling is applied only to X_train / y_train after the train/val/test split.")

    # ── Right column ──────────────────────────────────────────────────────────
    with cr:
        section("Model Selection")
        from src.models.registry import get_available_models, MODEL_DESCRIPTIONS
        avail = get_available_models()
        with st.expander("Available Models and Descriptions"):
            for m in avail:
                st.markdown(
                    f'<div style="background:#0f1118;border:1px solid #1e2535;border-radius:5px;'
                    f'padding:8px 12px;margin-bottom:5px;">'
                    f'<span style="color:#4a90d9;font-weight:600;font-size:0.83rem;">{m.replace("_"," ").title()}</span><br>'
                    f'<span style="color:#4a5568;font-size:0.75rem;">{MODEL_DESCRIPTIONS.get(m,"")}</span></div>',
                    unsafe_allow_html=True)
        sel = st.multiselect("Models to Train", avail, default=avail[:6] if len(avail) >= 6 else avail)
        st.caption(f"{len(sel)} of {len(avail)} selected")

        section("Hyperparameter Tuning (Optuna)")
        tune = st.checkbox("Enable Tuning", value=True)
        nt   = st.slider("Trials per Model",            5,  100, 30, 5,  disabled=not tune)
        to_  = st.slider("Timeout per Model (seconds)", 30, 600, 120, 30, disabled=not tune)
        cv   = st.slider("Cross-Validation Folds",      3,  10,  5)

        section("Optimization Metric")
        _metric_docs = {
            "f1_weighted":        "**F1 Weighted** — harmonic mean of precision & recall, weighted by class size. Best default for imbalanced datasets.",
            "accuracy":           "**Accuracy** — fraction of correct predictions. Misleading when classes are imbalanced.",
            "roc_auc":            "**ROC-AUC** — area under ROC curve. Threshold-independent; excellent for ranking/scoring tasks.",
            "precision_weighted": "**Precision Weighted** — minimises false positives. Use when false alarms are costly.",
            "recall_weighted":    "**Recall Weighted** — minimises false negatives. Use when missing a positive case is costly.",
        }
        metric_opt = st.selectbox(
            "Primary Metric",
            list(_metric_docs.keys()),
            help="Used for Optuna tuning and model selection. See descriptions below."
        )
        st.markdown(
            f'<div class="insight-box" style="border-left-color:#4a90d9;font-size:0.82rem;">'
            f'{_metric_docs.get(metric_opt, "")}</div>',
            unsafe_allow_html=True
        )

        st.markdown("<br>", unsafe_allow_html=True)

        if st.button("Save Configuration", use_container_width=True, type="primary"):
            import yaml

            # Map display name → short key stored in config
            _imb_key_map = {
                "None":                                                "none",
                "SMOTE — Synthetic Minority Oversampling":             "smote",
                "ADASYN — Adaptive Synthetic Oversampling":            "adasyn",
                "RandomOverSampler — Duplicate Minority Samples":      "random_over",
                "RandomUnderSampler — Reduce Majority Samples":        "random_under",
                "SMOTEENN — SMOTE + Edited Nearest Neighbours (combined)": "smoteenn",
                "SMOTETomek — SMOTE + Tomek Links (combined)":         "smotetomek",
            }
            imb_key = _imb_key_map.get(
                st.session_state.get("imb_method_cfg", "None"), "none")

            cfg = {
                "project":        {"name": "AutoML", "version": "3.0.0", "random_state": 42},
                "data":           {"raw_path": "data/raw", "processed_path": "data/processed",
                                   "test_size": ts / 100},
                "preprocessing":  {"numeric_imputer": ni, "categorical_imputer": ci_,
                                   "scaler": scaler, "encoding": enc},
                "missing_values": {"numeric_strategy": mv_num_raw,
                                   "categorical_strategy": mv_cat_key},
                "text_analysis":  {"enabled": st.session_state.get("enable_sentiment", False),
                                   "text_cols": st.session_state.get("sentiment_text_cols", []),
                                   "tfidf_max_features": st.session_state.get("tfidf_max_features", 100)},
                "class_imbalance":{"method": imb_key, "enabled": imb_key != "none"},
                "leakage_detection":{"enabled": st.session_state.get("enable_leakage_detection", True)},
                "models":         {"enabled": sel, "cross_validation_folds": cv},
                "tuning":         {"enabled": tune, "n_trials": nt, "timeout": to_,
                                   "metric": metric_opt},
                "evaluation":     {"metrics": ["accuracy","f1_weighted",
                                               "precision_weighted","recall_weighted"],
                                   "threshold": 0.5},
                "explainability": {"shap_enabled": True, "lime_enabled": True,
                                   "max_display_features": 20},
                "tracking":       {"mlflow": {"enabled": True, "tracking_uri": "mlruns",
                                              "experiment_name": "automl_classification"}},
                "deployment":     {"api": {"host": "0.0.0.0", "port": 8000}},
                "logging":        {"level": "INFO"},
            }
            Path("config").mkdir(exist_ok=True)
            with open("config/config.yaml", "w") as f:
                yaml.dump(cfg, f, default_flow_style=False)
            st.session_state.update({
                "dash_config": cfg,
                "selected_models": sel,
                "tune_enabled": tune,
                "imb_method_key": imb_key,
            })
            st.success(f"Configuration saved — {len(sel)} models, imbalance: {imb_key}.")

    # ── Post-Save: Cleaned & Processed data preview + downloads ──────────────
    if st.session_state.get("dash_config") and st.session_state.df is not None:
        st.divider()
        st.markdown(
            '<div class="results-header"><h3>Dataset Previews and Downloads</h3>'
            '<p>Generated from the current dataset using the saved configuration. '
            'Cleaned = duplicates and null-target rows removed. '
            'Processed = imputed, encoded, and scaled according to preprocessing settings.</p>'
            '</div>',
            unsafe_allow_html=True
        )

        tc_saved = st.session_state.target_col
        cfg_saved = st.session_state.dash_config

        if tc_saved and tc_saved in df.columns:
            # Pull imputation strategies from saved config
            _mv_cfg      = cfg_saved.get("missing_values", {})
            _num_strat   = _mv_cfg.get("numeric_strategy", "median")
            # zero is not a valid sklearn strategy — fall back to median for pipeline consistency
            _num_strat   = _num_strat if _num_strat != "zero" else "median"
            _cat_strat   = _mv_cfg.get("categorical_strategy", "most_frequent")

            # ── 1. Cleaned dataset: dedup + drop null target + impute missing ──
            df_cl = df.drop_duplicates()
            df_cl = _apply_missing_value_handling(
                df_cl, tc_saved,
                numeric_strategy=_num_strat,
                categorical_strategy=_cat_strat,
            )
            orig_r   = len(df)
            clean_r  = len(df_cl)
            removed  = orig_r - clean_r

            cv1, cv2, cv3, cv4 = st.columns(4)
            metric_card(f"{orig_r:,}",                        "Original Rows",     cv1)
            metric_card(f"{clean_r:,}",                       "Cleaned Rows",      cv2)
            metric_card(f"{removed:,}",                       "Rows Removed",      cv3)
            metric_card(f"{df_cl.isnull().sum().sum():,}",    "Remaining Missing", cv4)
            st.markdown("<br>", unsafe_allow_html=True)
            st.caption(
                f"Cleaning applied: duplicates removed, null-target rows dropped, "
                f"numeric missing filled with {_num_strat}, "
                f"categorical missing filled with {_cat_strat}."
            )

            tab_clean, tab_proc = st.tabs(["Cleaned Dataset", "Processed Dataset"])

            with tab_clean:
                st.caption(
                    f"Rows: {clean_r:,}  |  Columns: {df_cl.shape[1]}  |  "
                    f"Removed: {removed:,} ({removed/orig_r*100:.1f}% of original)"
                )
                st.dataframe(safe_df(df_cl.head(20)), use_container_width=True, height=300)
                st.download_button(
                    label="Download Cleaned Dataset (CSV)",
                    data=df_cl.to_csv(index=False).encode(),
                    file_name="cleaned_dataset.csv",
                    mime="text/csv",
                    key="dl_clean_cfg",
                )

            with tab_proc:
                st.caption(
                    "Full preprocessing applied: imputation, encoding, scaling. "
                    "The processed matrix is what the models receive during training."
                )
                with st.spinner("Applying preprocessing to generate preview..."):
                    try:
                        from src.preprocessing.pipeline import PreprocessingPipeline
                        from src.ingestion.data_loader import DataIngestion

                        _ing_cfg = cfg_saved.copy()
                        tmp_path = "data/raw/_cfg_preview.csv"
                        Path("data/raw").mkdir(parents=True, exist_ok=True)
                        df_cl.to_csv(tmp_path, index=False)
                        _ing = DataIngestion(_ing_cfg)
                        _df_in, _col_map, _ = _ing.run(tmp_path, tc_saved)

                        _pp = PreprocessingPipeline(_ing_cfg)
                        X_proc, y_proc = _pp.fit_transform(
                            _df_in, tc_saved,
                            _col_map.get("numeric", []),
                            _col_map.get("categorical", [])
                        )

                        fn_proc = [str(n) for n in (_pp.feature_names_out or [f"f{i}" for i in range(X_proc.shape[1])])]
                        cn_proc = [str(c) for c in _pp.label_encoder.classes_]

                        df_proc_display = pd.DataFrame(
                            X_proc[:200], columns=fn_proc
                        )
                        # y_proc may be numpy array — convert to plain Python int list
                        df_proc_display.insert(0, tc_saved,
                                               [int(v) for v in y_proc[:200]])

                        # Class distribution after resampling preview
                        imb_key_now = st.session_state.get("imb_method_key", "none")
                        if imb_key_now != "none":
                            try:
                                from sklearn.model_selection import train_test_split as _tts
                                _Xtv, _Xte, _ytv, _yte = _tts(
                                    X_proc, y_proc,
                                    test_size=cfg_saved["data"].get("test_size", 0.2),
                                    random_state=42, stratify=y_proc)
                                _Xtr, _Xv, _ytr, _yv = _tts(
                                    _Xtv, _ytv, test_size=0.15,
                                    random_state=42, stratify=_ytv)

                                _resampler = _get_resampler(imb_key_now)
                                if _resampler is not None:
                                    _Xr, _yr = _resampler.fit_resample(_Xtr, _ytr)
                                    _vc_before = pd.Series(_ytr).value_counts().sort_index()
                                    _vc_after  = pd.Series(_yr).value_counts().sort_index()

                                    imb_col1, imb_col2 = st.columns(2)
                                    with imb_col1:
                                        st.caption("Class distribution — BEFORE resampling (train split)")
                                        _df_bef = pd.DataFrame({
                                            "Class": [cn_proc[i] if i < len(cn_proc) else str(i) for i in _vc_before.index],
                                            "Count": _vc_before.values})
                                        st.plotly_chart(apply_theme(px.bar(
                                            _df_bef, x="Class", y="Count",
                                            color="Count",
                                            color_continuous_scale=["#e05252", "#4a90d9"],
                                            title="Before Resampling")),
                                            use_container_width=True)
                                    with imb_col2:
                                        st.caption("Class distribution — AFTER resampling (train split)")
                                        _df_aft = pd.DataFrame({
                                            "Class": [cn_proc[i] if i < len(cn_proc) else str(i) for i in _vc_after.index],
                                            "Count": _vc_after.values})
                                        st.plotly_chart(apply_theme(px.bar(
                                            _df_aft, x="Class", y="Count",
                                            color="Count",
                                            color_continuous_scale=["#38a169", "#4a90d9"],
                                            title="After Resampling")),
                                            use_container_width=True)

                                    ra1, ra2, ra3 = st.columns(3)
                                    metric_card(f"{len(_Xtr):,}", "Train rows (before)", ra1)
                                    metric_card(f"{len(_Xr):,}",  "Train rows (after)",  ra2)
                                    metric_card(f"{len(_Xr)-len(_Xtr):+,}", "Rows added/removed", ra3)
                                    st.markdown("<br>", unsafe_allow_html=True)
                            except Exception as imb_prev_err:
                                st.caption(f"Resampling preview skipped: {imb_prev_err}")

                        st.dataframe(safe_df(df_proc_display), use_container_width=True, height=300)
                        st.caption(
                            f"Showing first 200 rows. Full shape: {X_proc.shape[0]:,} rows x "
                            f"{X_proc.shape[1]:,} features  |  Classes: {', '.join(cn_proc)}"
                        )

                        # Download as CSV
                        df_proc_full = pd.DataFrame(X_proc, columns=fn_proc)
                        df_proc_full.insert(0, tc_saved, [int(v) for v in y_proc])
                        st.download_button(
                            label="Download Processed Dataset (CSV)",
                            data=df_proc_full.to_csv(index=False).encode(),
                            file_name="processed_dataset.csv",
                            mime="text/csv",
                            key="dl_proc_cfg",
                        )

                    except Exception as prev_err:
                        st.warning(f"Processed preview failed: {prev_err}")
                        st.caption("The processed data will still be generated correctly during training.")
        else:
            st.info("Select and save a target column to generate dataset previews.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — TRAINING  (+ all results rendered inline after run)
# ══════════════════════════════════════════════════════════════════════════════
elif page == "Training":
    page_header("Training",
                "Run the full AutoML pipeline. All results — performance, explainability, "
                "hyperparameter log, fairness metrics, and model card — render here after completion.")

    if st.session_state.df is None or st.session_state.target_col is None:
        st.warning("Upload data and set a target column in Configuration before training.")
        st.stop()

    # ── Pre-run controls ──────────────────────────────────────────────────────
    col_ctrl, col_log = st.columns([1, 2])
    with col_ctrl:
        tc   = st.session_state.target_col
        sel  = st.session_state.get("selected_models", [])
        tune = st.session_state.get("tune_enabled", True)
        from src.models.registry import get_available_models
        if not sel: sel = get_available_models()[:5]

        section("Pipeline Configuration")
        st.markdown(f"""
        <div style="background:#0f1118;border:1px solid #1e2535;border-radius:6px;padding:14px 16px;font-size:0.82rem;">
          <div style="display:flex;justify-content:space-between;margin-bottom:7px;">
            <span style="color:#4a5568;">Dataset</span>
            <span style="color:#a0aec0;">{st.session_state.df.shape[0]:,} x {st.session_state.df.shape[1]}</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:7px;">
            <span style="color:#4a5568;">Target Column</span>
            <span style="color:#7c6fc9;font-family:'JetBrains Mono',monospace;">{tc}</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:7px;">
            <span style="color:#4a5568;">Models Selected</span>
            <span style="color:#a0aec0;">{len(sel)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;">
            <span style="color:#4a5568;">Tuning</span>
            <span>{"<span class='status-ok'>Enabled</span>" if tune else "<span class='status-warn'>Disabled</span>"}</span>
          </div>
        </div>""", unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)
        st.caption("Models: " + ", ".join(sel))
        st.markdown("<br>", unsafe_allow_html=True)
        run_btn = st.button("Run AutoML Pipeline", use_container_width=True, type="primary")

    with col_log:
        section("Execution Log")
        logs     = st.session_state.training_logs
        log_html = ("<br>".join(f"<span style='color:#38a169'>+</span> {l}" for l in logs)
                    if logs else "<span style='color:#4a5568'>Pipeline output will appear here once training starts.</span>")
        log_placeholder = st.empty()
        log_placeholder.markdown(f'<div class="log-box">{log_html}</div>', unsafe_allow_html=True)

    # ── Pipeline execution ────────────────────────────────────────────────────
    if run_btn:
        st.session_state.update({
            "training_logs": [], "trained": False, "tuner_obj": None,
            "shap_values": None, "shap_sample": None, "shap_explainer_obj": None,
            "fairness_results": None, "model_card_md": None,
            "leakage_report": None, "guardrail_warnings": [],
            "shap_is_approximate": False, "shap_explainer_type": "",
            "data_lineage": {}, "id_cols_removed": [],
        })
        # Clear SHAP cache on new training run so stale values are not shown
        try:
            from src.explainability.shap_explainer import clear_shap_cache
            clear_shap_cache()
        except Exception:
            pass
        cp = "config/config.yaml"
        if not Path(cp).exists():
            import yaml; Path("config").mkdir(exist_ok=True)
            with open(cp, "w") as f:
                yaml.dump({"project":{"name":"AutoML","version":"3.0.0","random_state":42},
                    "data":{"raw_path":"data/raw","processed_path":"data/processed","test_size":0.2},
                    "preprocessing":{"numeric_imputer":"median","categorical_imputer":"most_frequent","scaler":"standard","encoding":"onehot"},
                    "missing_values":{"numeric_strategy":"median","categorical_strategy":"most_frequent"},
                    "text_analysis":{"enabled":False,"text_cols":[],"tfidf_max_features":100},
                    "models":{"enabled":sel,"cross_validation_folds":5},
                    "tuning":{"enabled":tune,"n_trials":20,"timeout":60,"metric":"f1_weighted"},
                    "evaluation":{"metrics":["accuracy","f1_weighted"],"threshold":0.5},
                    "explainability":{"shap_enabled":True,"lime_enabled":True,"max_display_features":20},
                    "tracking":{"mlflow":{"enabled":True,"tracking_uri":"mlruns","experiment_name":"automl_classification"}},
                    "deployment":{"api":{"host":"0.0.0.0","port":8000}},
                    "logging":{"level":"INFO"}}, f)

        try:
            tmp = "data/raw/_upload.csv"; Path("data/raw").mkdir(parents=True, exist_ok=True)
            st.session_state.df.to_csv(tmp, index=False)
            from src.utils.config_loader import load_config
            cfg = load_config(cp)
            pb = st.progress(0); stxt = st.empty(); logs = []

            def cb(msg, pct):
                logs.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
                pb.progress(pct / 100); stxt.markdown(f"**{msg}**")
                lh = "<br>".join(f"<span style='color:#38a169'>+</span> {l}" for l in logs[-15:])
                log_placeholder.markdown(f'<div class="log-box">{lh}</div>', unsafe_allow_html=True)

            from src.ingestion.data_loader import DataIngestion
            from src.preprocessing.pipeline import PreprocessingPipeline
            from src.models.trainer import ModelTrainer
            from src.models.selector import ModelSelector
            from src.evaluation.evaluator import ModelEvaluator
            from src.evaluation.artifact_exporter import save_model_artifact, build_performance_report
            from src.tracking.mlflow_tracker import ExperimentTracker
            from sklearn.model_selection import train_test_split

            cb("Ingesting data...", 5)
            ing = DataIngestion(cfg); df_in, col_type_map, _ = ing.run(tmp, tc)

            # ── Drop ID / high-cardinality columns detected by DataIngestion ─
            _id_cols_detected = col_type_map.get("id", [])
            if _id_cols_detected:
                df_in = df_in.drop(columns=[c for c in _id_cols_detected if c in df_in.columns], errors="ignore")
                logs.append(
                    f"[{time.strftime('%H:%M:%S')}] ID/high-cardinality columns removed "
                    f"(no predictive value): {_id_cols_detected}"
                )
                # Store for use in prediction page and lineage
                st.session_state["id_cols_removed"] = _id_cols_detected
            else:
                st.session_state["id_cols_removed"] = []

            # Apply raw missing value imputation (before sklearn preprocessing)
            _mv_cfg_tr = cfg.get("missing_values", {})
            df_in = _apply_missing_value_handling(
                df_in, tc,
                numeric_strategy=_mv_cfg_tr.get("numeric_strategy", "median"),
                categorical_strategy=_mv_cfg_tr.get("categorical_strategy", "most_frequent"),
            )
            # Store cleaned dataset for download (post-imputation, pre-encoding)
            st.session_state.df_cleaned = df_in.copy()
            logs.append(f"[{time.strftime('%H:%M:%S')}] Missing values handled — "
                        f"remaining: {df_in.isnull().sum().sum()}")

            # ══════════════════════════════════════════════════════════════
            # GUARDRAIL CHECK — Run before any training
            # ══════════════════════════════════════════════════════════════
            _guardrail_warnings = []

            # G1: Dataset size
            if len(df_in) < 100:
                _guardrail_warnings.append(
                    "⚠️ **Very small dataset** — fewer than 100 rows. "
                    "Model performance estimates will be highly unreliable. "
                    "Cross-validation results may not generalise."
                )
            elif len(df_in) < 500:
                _guardrail_warnings.append(
                    "⚠️ **Small dataset** — fewer than 500 rows. "
                    "Consider collecting more data before drawing production conclusions."
                )

            # G2: Class imbalance — only warn if user has NOT already enabled resampling
            _vc = df_in[tc].value_counts()
            _imb_method_active = cfg.get("class_imbalance", {}).get("method", "none")
            if len(_vc) >= 2:
                _imb_ratio = _vc.iloc[0] / _vc.iloc[-1]
                if _imb_ratio > 20 and _imb_method_active == "none":
                    _guardrail_warnings.append(
                        f"⚠️ **Severe class imbalance** — majority class is {_imb_ratio:.0f}× the minority. "
                        "Accuracy will be misleading. Use F1-weighted or ROC-AUC as your primary metric "
                        "and enable SMOTE or another resampling method in Configuration."
                    )
                elif _imb_ratio > 5 and _imb_method_active == "none":
                    _guardrail_warnings.append(
                        f"⚠️ **Moderate class imbalance** — ratio {_imb_ratio:.1f}:1. "
                        "Consider enabling class imbalance handling in Configuration."
                    )
                elif _imb_ratio > 5 and _imb_method_active != "none":
                    # Resampling is active — just log it, no warning needed
                    logs.append(
                        f"[{time.strftime('%H:%M:%S')}] Class imbalance ratio {_imb_ratio:.1f}:1 "
                        f"— addressed by '{_imb_method_active}' resampling."
                    )

            # G3: Feature count vs rows (curse of dimensionality)
            _n_feat = len([c for c in df_in.columns if c != tc])
            if _n_feat > len(df_in) * 0.5:
                _guardrail_warnings.append(
                    f"⚠️ **High dimensionality** — {_n_feat} features vs {len(df_in)} rows. "
                    "Many models will overfit. Consider feature selection or regularisation."
                )

            st.session_state["guardrail_warnings"] = _guardrail_warnings

            # ── LEAKAGE DETECTION (controlled by config option) ────────────
            _leakage_report = None
            _run_leakage = cfg.get("leakage_detection", {}).get("enabled",
                st.session_state.get("enable_leakage_detection", True))
            if _run_leakage:
                cb("Scanning for feature leakage...", 8)
                try:
                    from src.leakage.detector import FeatureLeakageDetector
                    _leakage_detector = FeatureLeakageDetector()
                    _leakage_report   = _leakage_detector.detect(df_in, tc)
                    st.session_state["leakage_report"] = _leakage_report

                    if _leakage_report.has_blockers:
                        _blocked_cols = [d["feature"] for d in _leakage_report.blocked]
                        logs.append(
                            f"[{time.strftime('%H:%M:%S')}] [LEAKAGE] Blocked features removed: {_blocked_cols}"
                        )
                        df_in = df_in.drop(columns=[c for c in _blocked_cols if c in df_in.columns], errors="ignore")
                        for _lt in ("numeric", "categorical", "text"):
                            col_type_map[_lt] = [c for c in col_type_map.get(_lt, []) if c not in _blocked_cols]

                    if _leakage_report.has_warnings:
                        _warn_cols = [d["feature"] for d in _leakage_report.warnings]
                        logs.append(
                            f"[{time.strftime('%H:%M:%S')}] [LEAKAGE] Suspicious features (kept, review): {_warn_cols}"
                        )
                        _guardrail_warnings.append(
                            f"⚠️ **Potential leakage in {len(_warn_cols)} feature(s)**: "
                            + ", ".join(f"`{c}`" for c in _warn_cols)
                            + " — check whether these are truly available at inference time."
                        )

                    if not _leakage_report.has_blockers and not _leakage_report.has_warnings:
                        logs.append(f"[{time.strftime('%H:%M:%S')}] Leakage scan passed — all features clean.")

                except Exception as _le:
                    logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Leakage scan error: {_le}")
            else:
                logs.append(f"[{time.strftime('%H:%M:%S')}] Leakage detection skipped (disabled in configuration).")
                st.session_state["leakage_report"] = None

            cb("Building preprocessing pipeline...", 15)

            # ── Text / Sentiment feature extraction ───────────────────────────
            _txt_cfg = cfg.get("text_analysis", {})
            _txt_enabled = _txt_cfg.get("enabled", False)
            _txt_cols = _txt_cfg.get("text_cols", [])
            _tfidf_n  = int(_txt_cfg.get("tfidf_max_features", 100))
            _sentiment_vectorizers = {}  # saved for inference

            if _txt_enabled and _txt_cols:
                cb(f"Extracting text/sentiment features from {len(_txt_cols)} column(s)...", 13)
                try:
                    from sklearn.feature_extraction.text import TfidfVectorizer
                    from textblob import TextBlob

                    for _tcol in _txt_cols:
                        if _tcol not in df_in.columns:
                            logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Text column '{_tcol}' not found — skipped.")
                            continue
                        _series = df_in[_tcol].fillna("").astype(str)

                        # TF-IDF features
                        _vec = TfidfVectorizer(max_features=_tfidf_n, strip_accents="unicode",
                                               stop_words="english", ngram_range=(1, 2))
                        _tfidf_arr = _vec.fit_transform(_series).toarray()
                        _tfidf_cols = [f"{_tcol}_tfidf_{v}" for v in _vec.get_feature_names_out()]
                        _tfidf_df = pd.DataFrame(_tfidf_arr, columns=_tfidf_cols, index=df_in.index)
                        _sentiment_vectorizers[_tcol] = _vec

                        # Sentiment polarity + subjectivity via TextBlob
                        _sentiments = _series.apply(lambda t: TextBlob(t).sentiment)
                        df_in[f"{_tcol}_sentiment_polarity"]     = _sentiments.apply(lambda s: s.polarity)
                        df_in[f"{_tcol}_sentiment_subjectivity"] = _sentiments.apply(lambda s: s.subjectivity)

                        # Add TF-IDF columns and drop original raw text column
                        df_in = pd.concat([df_in, _tfidf_df], axis=1)
                        df_in.drop(columns=[_tcol], inplace=True)

                    logs.append(f"[{time.strftime('%H:%M:%S')}] Text features extracted — "
                                f"columns: {_txt_cols}, TF-IDF vocab per col: {_tfidf_n}")
                except ImportError as _te:
                    logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Text analysis skipped — missing package: {_te}. "
                                f"Run: pip install textblob && python -m textblob.download_corpora")
                except Exception as _te:
                    logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Text analysis error: {_te}")

            st.session_state["sentiment_vectorizers"] = _sentiment_vectorizers

            # ── Re-derive column lists from actual df_in state (post text-extraction) ──
            # This is the single source of truth — never rely on stale col_type_map after
            # text columns have been dropped and TF-IDF columns added.
            _feature_cols_actual = [c for c in df_in.columns if c != tc]
            _numeric_cols_final = [
                c for c in _feature_cols_actual
                if pd.api.types.is_numeric_dtype(df_in[c])
            ]
            _categorical_cols_final = [
                c for c in _feature_cols_actual
                if not pd.api.types.is_numeric_dtype(df_in[c])
            ]

            # Safety guard: if somehow both are empty, raise a clear human-readable error
            if not _numeric_cols_final and not _categorical_cols_final:
                st.error(
                    "**Pipeline Error:** No feature columns found after preprocessing.\n\n"
                    f"Target column: `{tc}`  |  Dataset columns: `{list(df_in.columns)}`\n\n"
                    "This usually means all columns were dropped during text extraction, "
                    "or the dataset has only one column (the target). "
                    "Please check your column selection and try again."
                )
                st.stop()

            logs.append(
                f"[{time.strftime('%H:%M:%S')}] Feature columns resolved — "
                f"numeric: {len(_numeric_cols_final)}, categorical: {len(_categorical_cols_final)}"
            )

            pp = PreprocessingPipeline(cfg)
            X, y = pp.fit_transform(df_in, tc, _numeric_cols_final, _categorical_cols_final)
            pp.save("models/preprocessor.pkl")
            cn = [str(c) for c in pp.label_encoder.classes_]

            ts_v = cfg.get("data",{}).get("test_size", 0.2)
            X_tv, X_test, y_tv, y_test   = train_test_split(X, y, test_size=ts_v,  random_state=42, stratify=y)
            X_train, X_val, y_train, y_val = train_test_split(X_tv, y_tv, test_size=0.15, random_state=42, stratify=y_tv)
            st.session_state.X_train = X_train; st.session_state.y_train = y_train
            st.session_state.X_val   = X_val;   st.session_state.y_val   = y_val
            st.session_state.X_test  = X_test;  st.session_state.y_test  = y_test

            # ── Class imbalance resampling (train split only) ─────────────────
            imb_key = cfg.get("class_imbalance", {}).get("method", "none")
            if imb_key and imb_key != "none":
                cb(f"Applying class imbalance resampling ({imb_key})...", 22)
                try:
                    _resampler = _get_resampler(imb_key)
                    if _resampler is not None:
                        _y_before = pd.Series(y_train).value_counts().sort_index().to_dict()
                        X_train, y_train = _resampler.fit_resample(X_train, y_train)
                        _y_after  = pd.Series(y_train).value_counts().sort_index().to_dict()
                        st.session_state.X_train = X_train
                        st.session_state.y_train = y_train
                        logs.append(
                            f"[{time.strftime('%H:%M:%S')}] Resampling complete — "
                            f"before: {_y_before}, after: {_y_after}, "
                            f"train rows: {len(X_train):,}"
                        )
                    else:
                        logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Resampler '{imb_key}' unavailable — skipped.")
                except Exception as imb_err:
                    logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Resampling failed: {imb_err}")

            bp = {}
            if tune:
                cb(f"Tuning {len(sel)} models with Optuna...", 28)
                from src.tuning.optuna_tuner import HyperparameterTuner
                tnr = HyperparameterTuner(cfg); bp = tnr.tune_all(X_train, y_train, sel)
                st.session_state.tuner_obj = tnr
                Path("models").mkdir(exist_ok=True)
                with open("models/best_params.json","w") as f: json.dump(bp, f, indent=2, default=str)

            cb(f"Training {len(sel)} models...", 55)
            tr = ModelTrainer(cfg); tms = tr.train_all(X_train, y_train, sel, bp)

            cb("Evaluating all models...", 72)
            ev = ModelEvaluator(cfg); lb = ev.compare_models(tms, X_test, y_test)

            cb("Selecting champion...", 82)
            sl_ = ModelSelector(cfg); bn, bm = sl_.select(tms, lb); sl_.save("models/best_model.pkl")
            tm_ = compute_metrics(bm, X_train, y_train)
            vm_ = compute_metrics(bm, X_val,   y_val)
            tsm = compute_metrics(bm, X_test,  y_test)

            cb("Exporting artifacts...", 87)
            meta = {"train_metrics":tm_,"val_metrics":vm_,"test_metrics":tsm,
                    "best_params":bp.get(bn,{}),"class_names":cn,
                    "feature_names":pp.feature_names_out[:50],"dataset_shape":df_in.shape,"model_version":"3.0"}
            ap = save_model_artifact(bm, pp, bn, meta, "models/champion_artifact.joblib")
            pr_html = build_performance_report(bn, lb, tm_, vm_, tsm, bp.get(bn,{}), cn)
            with open("models/performance_report.html","w",encoding="utf-8") as f: f.write(pr_html)

            cb("Logging to MLflow...", 91)
            tk = ExperimentTracker(cfg)
            _dataset_name = st.session_state.get("file_name", "uploaded_dataset")
            _dataset_rows = int(df_in.shape[0])
            _dataset_cols = int(df_in.shape[1])

            for nm, mo in tms.items():
                row = lb[lb["model"]==nm]; met = row.iloc[0].to_dict() if not row.empty else {}

                # Log full run with dataset metadata embedded as params + tags
                if not tk.enabled:
                    continue
                run_id = tk.start_run(run_name=nm)
                if {"best": str(nm==bn)}:
                    import mlflow as _mlf
                    _mlf.set_tags({"best": str(nm==bn)})

                # Dataset info as params — this populates the Dataset column in MLflow UI
                _mlf.log_params({
                    "dataset_name":    str(_dataset_name),
                    "dataset_rows":    str(_dataset_rows),
                    "dataset_cols":    str(_dataset_cols),
                    "dataset_target":  str(tc),
                    "imbalance_method": str(cfg.get("class_imbalance",{}).get("method","none")),
                })
                tk.log_params(bp.get(nm, {}))
                tk.log_metrics({k: v for k, v in met.items() if k != "model"})

                # Log dataset CSV as artifact so it appears under Dataset column
                try:
                    _dataset_csv_path = "data/raw/_upload.csv"
                    if Path(_dataset_csv_path).exists():
                        _mlf.log_artifact(_dataset_csv_path, artifact_path="dataset")
                        # Use mlflow.data if available (MLflow >= 2.4)
                        try:
                            import mlflow.data
                            _src_df = pd.read_csv(_dataset_csv_path, nrows=5)
                            _mlf_ds = mlflow.data.from_pandas(
                                df_in,
                                source=_dataset_csv_path,
                                name=_dataset_name,
                                targets=tc,
                            )
                            _mlf.log_input(_mlf_ds, context="training")
                        except Exception:
                            pass  # mlflow.data not available, artifact logged above
                except Exception:
                    pass

                tk.log_model(mo, nm)
                tk.end_run()

            cb("Computing SHAP values...", 93)
            try:
                import shap as _shap_chk
                sv, smp, expl_obj = _compute_shap(bm, X_test, pp.feature_names_out)
                st.session_state.shap_values        = sv
                st.session_state.shap_sample        = smp
                st.session_state.shap_explainer_obj = expl_obj
                # Store explainer metadata for UI guardrail messaging
                from src.explainability.shap_explainer import _model_family
                _shap_family = _model_family(bm)
                _shap_is_approx = _shap_family == "kernel"
                st.session_state["shap_explainer_type"]  = type(expl_obj).__name__ if expl_obj else "Unknown"
                st.session_state["shap_is_approximate"]  = _shap_is_approx
                if _shap_is_approx:
                    _guardrail_warnings.append(
                        f"ℹ️ **SHAP explanations are approximate** for `{bn}` "
                        f"(KernelExplainer used — model type `{type(bm).__name__}` has no native SHAP support). "
                        "Feature importance rankings are reliable; individual SHAP magnitudes may vary slightly."
                    )
                logs.append(
                    f"[{time.strftime('%H:%M:%S')}] SHAP computed — {sv.shape[1]} features, "
                    f"explainer: {type(expl_obj).__name__}, approximate: {_shap_is_approx}"
                )
            except Exception as shap_err:
                logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] SHAP skipped: {shap_err}")
                st.session_state.shap_values = None
                st.session_state.shap_sample = None
                st.session_state.shap_explainer_obj = None

            # ── Data Lineage Record (C3 Compliance) ─────────────────────
            # Built here so it is available for AI insights + model card below.
            _lineage_record = {
                "raw_columns":          [c for c in st.session_state.df.columns if c != tc],
                "id_cols_removed":      _id_cols_detected,
                "text_cols_extracted":  _txt_cols if _txt_enabled else [],
                "tfidf_max_features":   _tfidf_n if _txt_enabled else 0,
                "missing_strategy_num": cfg.get("missing_values", {}).get("numeric_strategy", "median"),
                "missing_strategy_cat": cfg.get("missing_values", {}).get("categorical_strategy", "most_frequent"),
                "scaler":               cfg.get("preprocessing", {}).get("scaler", "standard"),
                "encoding":             cfg.get("preprocessing", {}).get("encoding", "onehot"),
                "leakage_blocked":      [d["feature"] for d in _leakage_report.blocked]
                                        if _leakage_report and _leakage_report.blocked else [],
                "feature_names_out":    pp.feature_names_out,
                "pipeline_version":     "v4",
                "sklearn_pipeline_persisted": True,
            }

                        # ── SR 11-7 Risk Tier Assessment ──────────────────────────────
            cb("Assessing SR 11-7 model risk tier...", 94)
            try:
                from src.monitoring.drift_monitor import assign_sr117_risk_tier
                _test_f1 = float(tsm.get("f1_weighted", tsm.get("f1", 0.0)))
                _sr117_tier = assign_sr117_risk_tier(
                    n_rows=len(df_in),
                    n_classes=len(cn) if cn else 2,
                    intended_use=cfg.get("intended_use",
                        "AutoML classification pipeline for tabular data."),
                    test_f1=_test_f1,
                    has_fairness_analysis=bool(st.session_state.get("fairness_results")),
                )
                st.session_state["sr117_risk_tier"] = _sr117_tier
                logs.append(
                    f"[{time.strftime('%H:%M:%S')}] SR 11-7 Risk Tier: "
                    f"{_sr117_tier['tier']} (score={_sr117_tier['score']})"
                )
            except Exception as _se:
                _sr117_tier = {}
                logs.append(f"[{time.strftime('%H:%M:%S')}] SR 11-7 tier assessment skipped: {_se}")

            # ── OpenAI AI Insights ──────────────────────────────────────────
            _ai_key = st.session_state.get("openai_api_key", "")
            _ai_perf_insights = ""
            _sr117_narrative  = ""
            if _ai_key:
                cb("Generating AI insights (Claude)...", 96)
                try:
                    from src.monitoring.ai_insights import AIInsightsEngine
                    _ai_engine = AIInsightsEngine(api_key=_ai_key)
                    if _ai_engine.available:
                        _ai_perf_insights = _ai_engine.model_performance_insights(
                            model_name=bn,
                            test_metrics=tsm,
                            train_metrics=tm_,
                            class_names=cn or [],
                            n_rows=len(df_in),
                            guardrail_warnings=_guardrail_warnings,
                            leakage_blocked=[d["feature"] for d in _leakage_report.blocked]
                                if _leakage_report else [],
                        )
                        _sr117_narrative = _ai_engine.sr117_compliance_narrative(
                            risk_tier=_sr117_tier,
                            model_name=bn,
                            test_metrics=tsm,
                            lineage=_lineage_record,
                            has_shap=bool(sv is not None),
                            has_fairness=bool(st.session_state.get("fairness_results")),
                            guardrail_warnings=_guardrail_warnings,
                        )
                        st.session_state["ai_performance_insights"] = _ai_perf_insights
                        st.session_state["sr117_narrative"] = _sr117_narrative
                        logs.append(f"[{time.strftime('%H:%M:%S')}] AI insights generated via OpenAI GPT-4o.")
                except Exception as _ae:
                    logs.append(f"[{time.strftime('%H:%M:%S')}] AI insights error: {_ae}")
            else:
                logs.append(f"[{time.strftime('%H:%M:%S')}] AI insights skipped — no OpenAI API key.")

            cb("Generating model card...", 96)
            try:
                from src.evaluation.model_card import ModelCardGenerator
                mcg = ModelCardGenerator()
                tnr_obj  = st.session_state.get("tuner_obj")
                ti_info  = tnr_obj.best_trial_info.get(bn, {}) if tnr_obj else {}
                # Build responsible-AI model card with guardrail context
                _guardrail_str = " | ".join(
                    [w.replace("⚠️", "WARNING:").replace("ℹ️", "INFO:").replace("**", "")
                     for w in st.session_state.get("guardrail_warnings", [])]
                ) or "None"
                _leakage_str = (
                    f"{len(st.session_state['leakage_report'].blocked)} features removed by leakage scan"
                    if st.session_state.get("leakage_report") and st.session_state["leakage_report"].blocked
                    else "Leakage scan passed"
                )
                _shap_str = (
                    f"Approximate (KernelExplainer — {type(bm).__name__} has no native SHAP support)"
                    if st.session_state.get("shap_is_approximate")
                    else f"Exact ({st.session_state.get('shap_explainer_type', 'TreeExplainer/LinearExplainer')})"
                )
                mcg.build(
                    model_name=bn, model_type=type(bm).__name__,
                    dataset_name=st.session_state.get("file_name","uploaded_dataset"),
                    target_col=tc, feature_names=pp.feature_names_out, class_names=cn,
                    train_metrics=tm_, val_metrics=vm_, test_metrics=tsm,
                    best_params=bp.get(bn,{}), dataset_shape=df_in.shape,
                    n_trials_run=ti_info.get("n_trials_run",0),
                    best_trial_number=ti_info.get("trial_number",0),
                    tuning_metric=ti_info.get("metric","f1_weighted"),
                    intended_use=(
                        "Binary or multiclass tabular classification on structured data. "
                        "Suitable for production use when guardrail warnings have been reviewed "
                        "and addressed, leakage scan is clean, and the dataset is representative "
                        "of the inference population."
                    ),
                    limitations=(
                        f"Performance may degrade on out-of-distribution data. "
                        f"Guardrails: {_guardrail_str}. "
                        f"Data integrity: {_leakage_str}. "
                        f"SHAP explainability: {_shap_str}."
                    ),
                    ethical_notes=(
                        "Ensure training data is free of harmful bias before production deployment. "
                        "Run fairness analysis (see Fairness tab) across protected attributes. "
                        "Monitor for distribution shift post-deployment using the Monitoring tab."
                    ),
                    sr117_risk_tier=st.session_state.get("sr117_risk_tier", {}),
                    sr117_narrative=st.session_state.get("sr117_narrative", ""),
                    ai_performance_insights=st.session_state.get("ai_performance_insights", ""),
                    data_lineage=_lineage_record,
                    shap_explainer_type=st.session_state.get("shap_explainer_type", ""),
                    shap_is_approximate=st.session_state.get("shap_is_approximate", False),
                    guardrail_warnings=_guardrail_warnings,
                )
                st.session_state.model_card_md = mcg.to_markdown()
            except Exception as mc_err:
                logs.append(f"[{time.strftime('%H:%M:%S')}] [WARN] Model card failed: {mc_err}")

            cb("Pipeline complete.", 100)

            st.session_state.update({
                "trained": True, "leaderboard": lb, "best_model_name": bn, "best_model": bm,
                "preprocessor": pp, "class_names": cn, "feature_names": pp.feature_names_out,
                "trained_models": tms, "training_logs": logs,
                "best_params": bp, "train_metrics": tm_, "val_metrics": vm_, "test_metrics": tsm,
                "artifact_path": ap,
                "text_analysis_cfg": cfg.get("text_analysis", {}),
                "sentiment_vectorizers": _sentiment_vectorizers,
                "data_lineage": _lineage_record,
                "guardrail_warnings": _guardrail_warnings,
                "id_cols_removed": _id_cols_detected,
            })
            st.success(f"Training complete. Champion: {bn.replace('_',' ').title()}")
            st.rerun()

        except Exception as e:
            import traceback; st.error(f"Pipeline error: {e}"); st.code(traceback.format_exc())

    # ══════════════════════════════════════════════════════════════════════════
    # RESULTS — rendered only after training is done
    # ══════════════════════════════════════════════════════════════════════════
    if not st.session_state.trained:
        st.stop()

    # ── Guardrail Warning Banner ──────────────────────────────────────────────
    _gw = st.session_state.get("guardrail_warnings", [])
    if _gw:
        with st.expander(f"⚠️  {len(_gw)} Production Guardrail Warning(s) — click to review", expanded=True):
            for _w in _gw:
                st.markdown(_w)
            st.caption(
                "These warnings are automatically generated to help non-expert users avoid "
                "common pitfalls. They do not block training but should be reviewed before "
                "deploying any model to production."
            )

    # ── SR 11-7 Risk Tier Banner ─────────────────────────────────────────────
    _rt = st.session_state.get("sr117_risk_tier")
    if _rt:
        _tier_colors = {"HIGH": "#c53030", "MEDIUM": "#d97706", "LOW": "#38a169"}
        _tier_icons  = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}
        _tc = _tier_colors.get(_rt.get("tier","MEDIUM"), "#4a90d9")
        _ti = _tier_icons.get(_rt.get("tier","MEDIUM"), "ℹ️")
        st.markdown(
            f'<div class="insight-box" style="border-left-color:{_tc};">'
            f'{_ti} <strong>SR 11-7 Risk Tier: {_rt.get("tier","?")}</strong> — '
            f'{_rt.get("description","")}'
            f'</div>',
            unsafe_allow_html=True
        )

    # ── AI Performance Insights ───────────────────────────────────────────────
    _ai_insights = st.session_state.get("ai_performance_insights", "")
    if _ai_insights:
        with st.expander("🤖 AI-Generated Performance Insights (Claude)", expanded=True):
            st.markdown(_ai_insights)
    elif not st.session_state.get("openai_api_key"):
        st.caption("💡 Add your OpenAI API key in the sidebar to enable AI-powered insights and SR 11-7 compliance narratives.")

    # ── Leakage Detection Report ──────────────────────────────────────────────
    _lr = st.session_state.get("leakage_report")
    if _lr is not None:
        _n_blocked  = len(_lr.blocked)
        _n_warned   = len(_lr.warnings)
        _n_clean    = len(_lr.clean)
        _label = (
            f"🛑 Leakage Scan — {_n_blocked} feature(s) auto-removed, {_n_warned} warning(s)"
            if _n_blocked or _n_warned
            else f"✅ Leakage Scan — all {_n_clean} features clean"
        )
        with st.expander(_label, expanded=(_n_blocked > 0)):
            c1, c2, c3 = st.columns(3)
            c1.metric("Blocked (auto-removed)", _n_blocked, delta=f"-{_n_blocked}" if _n_blocked else None,
                      delta_color="inverse")
            c2.metric("Warnings (kept — review)", _n_warned)
            c3.metric("Clean", _n_clean)
            _lr_df = _lr.to_dataframe()
            if not _lr_df.empty:
                st.dataframe(_lr_df, use_container_width=True)
            st.caption(
                "Leakage detection uses name heuristics, Pearson |r|, normalised mutual information, "
                "and eta-squared class separation. Blocked features were silently removed before training. "
                "Warned features were kept but may inflate performance if they are not available at inference time."
            )

    lb  = st.session_state.leaderboard
    bn  = st.session_state.best_model_name
    bm  = st.session_state.best_model
    cn  = st.session_state.class_names
    fn  = st.session_state.feature_names
    tms = st.session_state.get("trained_models", {})
    Xt  = st.session_state.X_test
    yt  = st.session_state.y_test
    br  = lb[lb["model"] == bn].iloc[0]
    tm_ = st.session_state.train_metrics
    vm_ = st.session_state.val_metrics
    tsm = st.session_state.test_metrics

    # ── Section A: Model Performance ─────────────────────────────────────────
    results_header("Model Performance", "Champion metrics, leaderboard, confusion matrix, ROC curves, calibration, and artifact downloads.")

    c1, c2, c3, c4, c5 = st.columns(5)
    metric_card(bn.replace("_"," ").title(),              "Champion",   c1)
    metric_card(f"{br.get('accuracy',0):.4f}",            "Accuracy",   c2)
    metric_card(f"{br.get('f1_weighted',0):.4f}",         "F1 Score",   c3)
    metric_card(f"{br.get('precision_weighted',0):.4f}",  "Precision",  c4)
    metric_card(f"{br.get('recall_weighted',0):.4f}",     "Recall",     c5)
    st.markdown("<br>", unsafe_allow_html=True)

    # Artifact downloads
    section("Artifact Downloads")
    # dl1, 
    dl2, dl3 = st.columns(2)
    # with dl1:
    #     st.markdown('<div class="artifact-card"><div class="artifact-title">Champion Model (PKL)</div><div class="artifact-desc">Pickle — model + name</div></div>', unsafe_allow_html=True)
    #     pkl_download(bm, bn)
    #     if Path("models/preprocessor.pkl").exists():
    #         with open("models/preprocessor.pkl","rb") as pf:
    #             st.download_button("Download Preprocessor (PKL)", data=pf.read(),
    #                                file_name="preprocessor.pkl", mime="application/octet-stream", use_container_width=True)
    with dl2:
        st.markdown('<div class="artifact-card"><div class="artifact-title">Full Artifact (Joblib)</div><div class="artifact-desc">Model + preprocessor + metrics + feature names</div></div>', unsafe_allow_html=True)
        ap = st.session_state.get("artifact_path","models/champion_artifact.joblib")
        if Path(ap).exists():
            with open(ap,"rb") as f:
                st.download_button("Download Joblib Artifact", data=f.read(), file_name="champion_artifact.joblib",
                                   mime="application/octet-stream", use_container_width=True)
        else: st.info("Retrain to generate.")
    with dl3:
        st.markdown('<div class="artifact-card"><div class="artifact-title">Performance Report (HTML)</div><div class="artifact-desc">Train/val/test metrics, leaderboard, hyperparameters</div></div>', unsafe_allow_html=True)
        if Path("models/performance_report.html").exists():
            with open("models/performance_report.html","r",encoding="utf-8",errors="replace") as f:
                st.download_button("Download Performance Report", data=f.read().encode(),
                                   file_name="performance_report.html", mime="text/html", use_container_width=True)
        else: st.info("Retrain to generate.")

    # Cleaned dataset download
    df_cleaned = st.session_state.get("df_cleaned")
    if df_cleaned is not None:
        orig_rows = len(st.session_state.df) if st.session_state.df is not None else 0
        clean_rows = len(df_cleaned)
        removed   = orig_rows - clean_rows
        section("Cleaned Dataset")
        cl1, cl2, cl3, cl4 = st.columns(4)
        metric_card(f"{orig_rows:,}",   "Original Rows",  cl1)
        metric_card(f"{clean_rows:,}",  "Cleaned Rows",   cl2)
        metric_card(f"{removed:,}",     "Rows Removed",   cl3)
        metric_card(f"{df_cleaned.isnull().sum().sum():,}", "Remaining Missing", cl4)
        st.markdown("<br>", unsafe_allow_html=True)
        st.caption(
            "Cleaning applied: duplicate rows removed, rows with null target dropped. "
            "Preprocessing (imputation, encoding, scaling) is applied separately during model training."
        )
        st.download_button(
            label="Download Cleaned Dataset (CSV)",
            data=df_cleaned.to_csv(index=False).encode(),
            file_name="cleaned_dataset.csv",
            mime="text/csv",
            use_container_width=False,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    tab_lb, tab_met, tab_cm, tab_roc, tab_cal = st.tabs([
        "Leaderboard", "Metric Comparison", "Confusion Matrix", "ROC Curves", "Calibration"])

    with tab_lb:
        nc = [c for c in lb.columns if c != "model" and pd.api.types.is_numeric_dtype(lb[c])]
        def _hl(r): return ["background-color:rgba(58,160,105,.12);font-weight:600;"]*len(r) if r["model"]==bn else [""]*len(r)
        st.dataframe(lb.style.apply(_hl,axis=1).format({c:"{:.4f}" for c in nc}), use_container_width=True, height=380)
        insight("Highlighted row is the champion. Ranking is by the primary metric selected in Configuration.")

    with tab_met:
        mc_list = ["accuracy","f1_weighted","precision_weighted","recall_weighted","roc_auc"]
        av = [c for c in mc_list if c in lb.columns]
        mt_df = lb[["model"]+av].melt(id_vars="model", var_name="Metric", value_name="Score")
        fig = apply_theme(px.bar(mt_df, x="model", y="Score", color="Metric", barmode="group",
            title="All Models — Metric Comparison",
            color_discrete_sequence=["#4a90d9","#38a169","#d97706","#e05252","#7c6fc9"]))
        fig.update_xaxes(tickangle=20); st.plotly_chart(fig, use_container_width=True)

        fig2 = go.Figure()
        for _, r in lb.iterrows():
            vals = [r.get(m,0) for m in av]
            if vals: fig2.add_trace(go.Scatterpolar(r=vals+[vals[0]], theta=av+[av[0]],
                fill="toself", name=r["model"], opacity=0.65))
        fig2.update_layout(polar=dict(radialaxis=dict(visible=True,range=[0,1])), title="Radar — Model Profiles")
        st.plotly_chart(apply_theme(fig2), use_container_width=True)
        insight("Radar chart: large area = balanced strength across all metrics.")

    with tab_cm:
        cm_sel = st.selectbox("Select Model", lb["model"].tolist(), key="cm_sel_tr")
        if cm_sel in tms and Xt is not None:
            from sklearn.metrics import confusion_matrix as _cm
            yp  = tms[cm_sel].predict(Xt); cm = _cm(yt, yp)
            lbs = cn or [str(i) for i in range(cm.shape[0])]
            st.plotly_chart(apply_theme(px.imshow(cm, x=lbs, y=lbs, color_continuous_scale="Blues",
                text_auto=True, labels=dict(x="Predicted",y="Actual"),
                title=f"Confusion Matrix — {cm_sel.replace('_',' ').title()}")), use_container_width=True)
            insight("Diagonal = correct predictions. Off-diagonal = misclassifications.")

    with tab_roc:
        roc_sel = st.selectbox("Select Model", lb["model"].tolist(), key="roc_sel_tr")
        if roc_sel in tms and Xt is not None:
            from sklearn.metrics import roc_curve, auc; from sklearn.preprocessing import label_binarize
            mo = tms[roc_sel]
            if hasattr(mo,"predict_proba"):
                ypr = mo.predict_proba(Xt); nc_ = ypr.shape[1]
                lbs = cn or [str(i) for i in range(nc_)]; fig = go.Figure()
                if nc_ == 2:
                    fpr,tpr,_ = roc_curve(yt,ypr[:,1]); fig.add_trace(go.Scatter(x=fpr,y=tpr,name=f"AUC={auc(fpr,tpr):.3f}",line=dict(color="#4a90d9",width=2)))
                else:
                    cls=np.unique(yt); yb=label_binarize(yt,classes=cls)
                    pal=["#4a90d9","#38a169","#d97706","#e05252","#7c6fc9","#0ea5e9"]
                    for i,c_ in enumerate(cls):
                        fpr,tpr,_=roc_curve(yb[:,i],ypr[:,i]); l=lbs[i] if i<len(lbs) else str(c_)
                        fig.add_trace(go.Scatter(x=fpr,y=tpr,name=f"{l}  AUC={auc(fpr,tpr):.3f}",line=dict(color=pal[i%len(pal)],width=2)))
                fig.add_trace(go.Scatter(x=[0,1],y=[0,1],name="Random Baseline",line=dict(color="#4a5568",dash="dash")))
                fig.update_layout(title=f"ROC Curves — {roc_sel.replace('_',' ').title()}",xaxis_title="FPR",yaxis_title="TPR")
                st.plotly_chart(apply_theme(fig), use_container_width=True)
                insight("AUC 1.0 = perfect, 0.5 = random. Top-left curves are better.")
            else: st.info("This model does not support predict_proba.")

    with tab_cal:
        cal_sel = st.selectbox("Select Model", lb["model"].tolist(), key="cal_sel_tr")
        if cal_sel in tms and Xt is not None:
            mo = tms[cal_sel]
            if hasattr(mo,"predict_proba"):
                from sklearn.calibration import calibration_curve
                ypr = mo.predict_proba(Xt)
                if ypr.shape[1] == 2:
                    fp,mp = calibration_curve(yt,ypr[:,1],n_bins=10,strategy="uniform")
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(x=mp,y=fp,name="Model",mode="lines+markers",line=dict(color="#4a90d9",width=2),marker=dict(size=7)))
                    fig.add_trace(go.Scatter(x=[0,1],y=[0,1],name="Perfect",line=dict(color="#38a169",dash="dash")))
                    fig.update_layout(title=f"Calibration — {cal_sel.replace('_',' ').title()}",xaxis_title="Mean Predicted Probability",yaxis_title="Fraction of Positives")
                    st.plotly_chart(apply_theme(fig), use_container_width=True)
                    insight("Perfect calibration follows the diagonal. Above = overconfident, below = underconfident.")
                else: st.info("Calibration shown for binary classification only.")
            else: st.info("Model does not support predict_proba.")

    # ── Section B: Explainability ─────────────────────────────────────────────
    results_header("Explainability", "Native feature importance, SHAP global and instance explanations, and LIME local explanations.")

    # SHAP explainer info + approximate warning (Guardrail #3 & #5)
    _shap_explainer_type = st.session_state.get("shap_explainer_type", "")
    _shap_is_approx      = st.session_state.get("shap_is_approximate", False)
    if _shap_explainer_type:
        _expl_color = "#d97706" if _shap_is_approx else "#38a169"
        _expl_icon  = "⚠️" if _shap_is_approx else "✅"
        _expl_msg   = (
            f"{_expl_icon} **SHAP Explainer: `{_shap_explainer_type}`** — "
            + ("**Approximate** — KernelExplainer is used because this model type has no native SHAP support. "
               "Feature rankings are reliable but individual magnitude values may vary by ±5–15%. "
               "Interpretation should focus on relative importance, not absolute SHAP values."
               if _shap_is_approx
               else "**Exact** — native explainer used. SHAP values are precise.")
        )
        st.markdown(
            f'<div class="insight-box" style="border-left-color:{_expl_color};">{_expl_msg}</div>',
            unsafe_allow_html=True
        )

    # Data Lineage expander (C3 Compliance)
    _lineage = st.session_state.get("data_lineage", {})
    if _lineage:
        with st.expander("🔍  Data Lineage & Preprocessing Audit Trail", expanded=False):
            st.caption(
                "Every transformation applied to raw data is recorded here so any output feature "
                "can be traced back to its raw data origin. Required for C3/regulatory compliance."
            )
            lc1, lc2 = st.columns(2)
            with lc1:
                st.markdown("**Raw → Processed transformations**")
                st.markdown(f"- Missing (numeric): `{_lineage.get('missing_strategy_num', '—')}`")
                st.markdown(f"- Missing (categorical): `{_lineage.get('missing_strategy_cat', '—')}`")
                st.markdown(f"- Scaler: `{_lineage.get('scaler', '—')}`")
                st.markdown(f"- Encoding: `{_lineage.get('encoding', '—')}`")
                st.markdown(f"- Pipeline version: `{_lineage.get('pipeline_version', '—')}`")
                st.markdown(f"- sklearn Pipeline persisted: `{_lineage.get('sklearn_pipeline_persisted', False)}`")
            with lc2:
                st.markdown("**Column origins**")
                _raw_cols   = _lineage.get("raw_columns", [])
                _txt_extr   = _lineage.get("text_cols_extracted", [])
                _blocked    = _lineage.get("leakage_blocked", [])
                _feat_out   = _lineage.get("feature_names_out", [])
                st.markdown(f"- Raw input columns: **{len(_raw_cols)}**")
                _id_removed = _lineage.get("id_cols_removed", [])
                st.markdown(f"- ID/high-cardinality cols removed: **{len(_id_removed)}** {('— ' + ', '.join(f'`{c}`' for c in _id_removed)) if _id_removed else ''}")
                st.markdown(f"- Text cols vectorised (TF-IDF): **{len(_txt_extr)}** {('— ' + ', '.join(f'`{c}`' for c in _txt_extr)) if _txt_extr else ''}")
                st.markdown(f"- Leakage-blocked (removed): **{len(_blocked)}** {('— ' + ', '.join(f'`{c}`' for c in _blocked)) if _blocked else ''}")
                st.markdown(f"- Output features (post-encode): **{len(_feat_out)}**")
            if _feat_out:
                with st.expander("View all output feature names"):
                    st.dataframe(
                        pd.DataFrame({"output_feature": _feat_out,
                                      "origin": [c.split("__")[1] if "__" in c else c for c in _feat_out]}),
                        use_container_width=True
                    )

    tab_fi, tab_shap_bar, tab_bee, tab_inst, tab_lime, tab_pdp = st.tabs([
        "Native Importance", "SHAP Global", "SHAP Beeswarm", "SHAP Instance", "LIME Instance", "PDP / ICE"])

    with tab_fi:
        insight("Model-native importance: split gain for tree models, absolute coefficient for linear models.")
        try:
            fi = None; names = fn or [f"f{i}" for i in range(500)]
            if hasattr(bm,"feature_importances_"):   fi = bm.feature_importances_
            elif hasattr(bm,"coef_"):
                c = bm.coef_; fi = abs(c).mean(axis=0) if c.ndim>1 else abs(c)
            if fi is not None:
                n = min(len(fi),len(names),30)
                df_fi = pd.DataFrame({"Feature":names[:n],"Importance":fi[:n]}).sort_values("Importance",ascending=True).tail(20)
                st.plotly_chart(apply_theme(px.bar(df_fi,x="Importance",y="Feature",orientation="h",
                    title=f"Feature Importance — {bn.replace('_',' ').title()}",
                    color="Importance",color_continuous_scale=["#1c3a6e","#4a90d9"])), use_container_width=True)
            else: st.info("Not available for this model type. Use SHAP tabs.")
        except Exception as e: st.error(str(e))

    with tab_shap_bar:
        insight("Mean absolute SHAP value per feature across test samples. Longer bars = greater average impact.")
        if st.session_state.get("shap_is_approximate"):
            st.markdown(
                '<div class="insight-box" style="border-left-color:#d97706;">'
                '⚠️ <strong>Approximate SHAP</strong> — KernelExplainer used. '
                'Values shown are statistically reliable for ranking features but not exact. '
                'Do not rely on the absolute magnitudes for critical decisions.</div>',
                unsafe_allow_html=True
            )
        sv = st.session_state.shap_values
        if sv is None:
            st.info("SHAP values could not be computed during training, or SHAP library is not installed.")
        else:
            names = fn or [f"f{i}" for i in range(sv.shape[1])]
            msv   = abs(sv).mean(axis=0)
            max_f = min(40, len(msv))
            topn  = st.slider("Top N Features", 5, max_f, min(20,max_f), key="shap_bar_tr") if max_f > 5 else max_f
            df_bar = (pd.DataFrame({"Feature":names,"Mean |SHAP|":msv})
                      .sort_values("Mean |SHAP|",ascending=False).head(topn).sort_values("Mean |SHAP|"))
            st.plotly_chart(apply_theme(px.bar(df_bar,x="Mean |SHAP|",y="Feature",orientation="h",
                title="SHAP Global Feature Importance",color="Mean |SHAP|",
                color_continuous_scale=["#2d1b69","#7c6fc9"])), use_container_width=True)

            # AI SHAP interpretation button
            _ai_key_shap = st.session_state.get("openai_api_key", "")
            if _ai_key_shap:
                if st.button("🤖 Explain these features with AI (GPT-4o)", key="ai_shap_btn"):
                    with st.spinner("Generating AI interpretation..."):
                        try:
                            from src.monitoring.ai_insights import AIInsightsEngine
                            _eng = AIInsightsEngine(api_key=_ai_key_shap)
                            _top_feats = [
                                {"feature": row["Feature"], "importance": float(row["Mean |SHAP|"])}
                                for _, row in df_bar.sort_values("Mean |SHAP|", ascending=False).head(10).iterrows()
                            ]
                            _shap_txt = _eng.shap_interpretation(
                                top_features=_top_feats,
                                model_name=st.session_state.best_model_name or "Champion",
                                target_col=st.session_state.target_col or "target",
                                is_approximate=st.session_state.get("shap_is_approximate", False),
                            )
                            if _shap_txt:
                                st.markdown(
                                    f'<div class="insight-box" style="border-left-color:#38a169;">'
                                    f'🤖 <strong>AI Feature Interpretation</strong><br><br>{_shap_txt}</div>',
                                    unsafe_allow_html=True
                                )
                        except Exception as _ae:
                            st.warning(f"AI interpretation error: {_ae}")
            else:
                st.caption("💡 Add OpenAI API key in the sidebar to get AI-powered feature explanations.")

    with tab_bee:
        insight(
            "Each dot = one test sample. Red = high feature value, Blue = low. "
            "Dots to the RIGHT increase the prediction; dots to the LEFT decrease it. "
            "Both negative and positive SHAP values are shown — if you only see one side "
            "it means the model assigns near-zero negative impact for that feature."
        )
        sv  = st.session_state.shap_values
        Xs  = st.session_state.shap_sample
        if sv is None:
            st.info("SHAP values not available.")
        else:
            import shap
            import matplotlib
            import matplotlib.pyplot as plt

            max_f = min(30, sv.shape[1])
            topn  = st.slider("Top N Features", 5, max_f, min(15, max_f), key="bee_tr") if max_f > 5 else max_f

            # Reset matplotlib to defaults so SHAP's own styling renders cleanly
            matplotlib.rcdefaults()
            plt.rcParams.update({
                "figure.facecolor": "white",
                "axes.facecolor":   "white",
                "axes.edgecolor":   "#333333",
                "text.color":       "#111111",
                "axes.labelcolor":  "#111111",
                "xtick.color":      "#111111",
                "ytick.color":      "#111111",
            })

            # Wide figure: left room for feature names, right room for colorbar
            fig, ax = plt.subplots(figsize=(14, max(5, topn * 0.45)))

            shap.summary_plot(
                sv,                              # signed values — both sides visible
                Xs,
                feature_names=list(fn) if fn else None,
                max_display=topn,
                plot_type="dot",
                show=False,
                plot_size=None,                  # we control figure size ourselves
                color_bar=True,
            )

            # Generous margins: left for labels, right for colorbar, prevents clipping
            plt.subplots_adjust(left=0.38, right=0.86, top=0.97, bottom=0.08)
            st.pyplot(fig, clear_figure=True)
            plt.close("all")

    with tab_inst:
        insight(
            "Waterfall chart for a single prediction — "
            "shows how each feature pushes the output from the baseline."
        )

        sv = st.session_state.shap_values
        if sv is None or Xt is None:
            st.info("SHAP values not available.")
        else:
            import shap
            import matplotlib.pyplot as plt

            idx = st.slider(
                "Test Instance Index",
                0,
                len(Xt) - 1,
                0,
                key="shap_inst_tr"
            )

            data_row = Xt.iloc[idx] if hasattr(Xt, "iloc") else Xt[idx]

            expl = shap.Explanation(
                values=sv[idx],
                base_values=0.0,
                data=data_row,
                feature_names=fn
            )

            # ✅ Reset matplotlib to default *light* theme
            plt.rcParams.update(plt.rcParamsDefault)

            plt.figure(figsize=(9, 5))
            shap.plots.waterfall(expl, max_display=15, show=False)

            plt.tight_layout()

            # ✅ DO NOT set dark backgrounds for SHAP
            st.pyplot(plt.gcf(), clear_figure=True)

            yp = bm.predict(Xt[idx:idx+1])
            pc = cn[yp[0]] if cn and yp[0] < len(cn) else str(yp[0])

            cp_, ca_ = st.columns(2)
            cp_.metric("Predicted Class", pc)

            if yt is not None:
                yt_v = yt[idx]
                tc_ = cn[yt_v] if cn and yt_v < len(cn) else str(yt_v)
                ca_.metric("Actual Class", tc_)


    with tab_pdp:
        insight(
            "Partial Dependence Plots (PDP) show the marginal effect of a feature on predictions, averaging over all other features. "
            "ICE (Individual Conditional Expectation) lines show per-sample effects — "
            "diverging ICE lines signal feature interactions."
        )
        try:
            from sklearn.inspection import PartialDependenceDisplay
            _pdp_fn  = st.session_state.feature_names or []
            _pdp_bm  = st.session_state.best_model
            _pdp_X   = st.session_state.shap_sample
            if _pdp_fn and _pdp_bm is not None and _pdp_X is not None:
                _num_feat_opts = [f for f in _pdp_fn if not f.startswith("categorical_")][:20] or _pdp_fn[:20]
                _pdp_sel = st.multiselect(
                    "Select 1–2 features for PDP/ICE",
                    _pdp_fn[:60],
                    default=_num_feat_opts[:2] if len(_num_feat_opts) >= 2 else _pdp_fn[:1],
                    max_selections=2,
                    key="pdp_features",
                )
                _pdp_kind = st.radio(
                    "Plot type", ["average", "individual", "both"],
                    horizontal=True, key="pdp_kind",
                    help="average=PDP only | individual=ICE lines only | both=PDP+ICE overlay"
                )
                if _pdp_sel and st.button("Generate PDP/ICE", key="gen_pdp", type="primary"):
                    with st.spinner("Computing PDP/ICE..."):
                        _pdp_idx = [_pdp_fn.index(f) for f in _pdp_sel if f in _pdp_fn]
                        if _pdp_idx:
                            import matplotlib
                            matplotlib.use("Agg")
                            import matplotlib.pyplot as plt
                            _fig, _axes = plt.subplots(
                                1, len(_pdp_idx),
                                figsize=(7 * len(_pdp_idx), 5),
                                facecolor="#0f172a"
                            )
                            if len(_pdp_idx) == 1:
                                _axes = [_axes]
                            for _ai, (_fi, _fn_) in enumerate(zip(_pdp_idx, _pdp_sel)):
                                try:
                                    PartialDependenceDisplay.from_estimator(
                                        _pdp_bm, _pdp_X,
                                        features=[_fi],
                                        feature_names=_pdp_fn,
                                        kind=_pdp_kind,
                                        ax=_axes[_ai],
                                        subsample=min(200, len(_pdp_X)),
                                        n_jobs=-1,
                                    )
                                    _axes[_ai].set_facecolor("#1e293b")
                                    _axes[_ai].tick_params(colors="#cbd5e1")
                                    _axes[_ai].set_title(f"PDP/ICE — {_fn_}", color="#e2e8f0", pad=10)
                                    for _sp in _axes[_ai].spines.values():
                                        _sp.set_edgecolor("#334155")
                                except Exception as _pe:
                                    _axes[_ai].text(0.5, 0.5, f"Error: {_pe}",
                                        transform=_axes[_ai].transAxes,
                                        ha="center", va="center", color="#f87171")
                            _fig.patch.set_facecolor("#0f172a")
                            plt.tight_layout()
                            st.pyplot(_fig, use_container_width=True)
                            plt.close(_fig)
                        else:
                            st.warning("Selected features not found in the feature list.")
            else:
                st.info("Run training first to enable PDP/ICE plots.")
        except Exception as _pe:
            st.warning(f"PDP/ICE error: {_pe}")

    with tab_lime:
        insight("LIME (Local Interpretable Model-agnostic Explanations) fits a local linear model around one instance "
                "to explain that specific prediction. Results may differ from SHAP because LIME perturbs the input space differently.")
        try:
            from lime.lime_tabular import LimeTabularExplainer
            LIME_OK = True
        except ImportError:
            LIME_OK = False

        if not LIME_OK:
            st.warning("LIME is not installed. Run: pip install lime")
        elif Xt is None or st.session_state.X_train is None:
            st.info("Training data not available for LIME background.")
        else:
            X_tr_np = st.session_state.X_train
            if hasattr(X_tr_np, "values"): X_tr_np = X_tr_np.values
            lime_idx = st.slider("Test Instance Index", 0, len(Xt)-1, 0, key="lime_inst_tr")
            if st.button("Run LIME Explanation", use_container_width=True, key="lime_run_tr"):
                with st.spinner("Computing LIME explanation..."):
                    try:
                        from lime.lime_tabular import LimeTabularExplainer
                        Xt_np = Xt.values if hasattr(Xt,"values") else Xt
                        lime_exp_obj = LimeTabularExplainer(
                            X_tr_np, feature_names=fn,
                            class_names=cn, discretize_continuous=True, random_state=42)
                        predict_fn = (bm.predict_proba if hasattr(bm,"predict_proba")
                                      else lambda x: np.column_stack([1-bm.predict(x), bm.predict(x)]))
                        exp = lime_exp_obj.explain_instance(
                            Xt_np[lime_idx], predict_fn, num_features=min(15, len(fn) if fn else 15), num_samples=500)
                        lime_list = exp.as_list()

                        # Prediction
                        yp_l = bm.predict(Xt[lime_idx:lime_idx+1])
                        pc_l = cn[yp_l[0]] if cn and yp_l[0]<len(cn) else str(yp_l[0])
                        st.markdown(f"**Predicted Class:** `{pc_l}`")

                        if lime_list:
                            df_lime = pd.DataFrame(lime_list, columns=["Feature Rule","LIME Weight"])
                            df_lime["Direction"] = df_lime["LIME Weight"].apply(lambda w: "Positive" if w>=0 else "Negative")
                            df_lime = df_lime.sort_values("LIME Weight", ascending=True)
                            fig = apply_theme(px.bar(df_lime, x="LIME Weight", y="Feature Rule", orientation="h",
                                color="Direction",
                                color_discrete_map={"Positive":"#38a169","Negative":"#e05252"},
                                title=f"LIME Local Explanation — Instance #{lime_idx}"))
                            st.plotly_chart(fig, use_container_width=True)
                            st.dataframe(safe_df(df_lime[["Feature Rule","LIME Weight"]].round(4)), use_container_width=True)
                    except Exception as lime_err:
                        import traceback; st.error(f"LIME failed: {lime_err}"); st.code(traceback.format_exc())
            else:
                st.info("Click 'Run LIME Explanation' to generate a local explanation for the selected instance.")

    # ── Section C: Hyperparameter Log ─────────────────────────────────────────
    results_header("Hyperparameter Log", "Full Optuna trial history — convergence curve and chosen parameters per model.")

    tnr = st.session_state.get("tuner_obj")
    if not st.session_state.get("tune_enabled",True) or tnr is None:
        bp_ = st.session_state.get("best_params",{})
        if bp_:
            st.info("Tuning was disabled or trial objects are unavailable. Showing best parameters only.")
            for mn_, p_ in bp_.items():
                with st.expander(mn_.replace("_"," ").title()):
                    if p_:
                        st.dataframe(safe_df(pd.DataFrame([{"Parameter":k,"Value":str(v)} for k,v in p_.items()])), use_container_width=True)
                    else: st.info("Default parameters used.")
        else: st.info("No tuning data available.")
    else:
        sub_header("Tuning Summary — All Models")
        sum_df = tnr.summary_dataframe()
        if not sum_df.empty:
            nc_s = [c for c in sum_df.columns if c!="model" and pd.api.types.is_numeric_dtype(sum_df[c])]
            st.dataframe(safe_df(sum_df).style.format({c:("{:.4f}" if "score" in c else "{}") for c in nc_s if c in sum_df.columns}), use_container_width=True)
            fig = apply_theme(px.bar(sum_df.sort_values("best_score",ascending=True),
                x="best_score", y="model", orientation="h",
                title="Best Tuned Score by Model", color="best_score",
                color_continuous_scale=["#1c3a6e","#38a169"]))
            st.plotly_chart(fig, use_container_width=True)

        models_with_trials = [m for m in tnr.all_trials if tnr.all_trials[m]]
        if models_with_trials:
            sub_header("Trial Detail by Model")
            sel_m = st.selectbox("Select Model", models_with_trials, key="hplog_model_tr")
            df_t  = tnr.trials_dataframe(sel_m)
            bi    = tnr.best_trial_info.get(sel_m, {})

            c1, c2, c3 = st.columns(3)
            metric_card(f"#{bi.get('trial_number','?')}", "Chosen Trial",  c1)
            metric_card(f"{bi.get('score',0):.4f}",       f"Best {bi.get('metric','Score')}", c2)
            metric_card(f"{bi.get('n_trials_run',0)}",    "Total Trials",  c3)
            st.markdown("<br>", unsafe_allow_html=True)

            if not df_t.empty:
                df_plot = df_t[df_t["score"].notna()].copy()
                if not df_plot.empty:
                    df_plot["best_so_far"] = df_plot["score"].cummax()
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(x=df_plot["trial"],y=df_plot["score"],name="Trial Score",
                        mode="markers",marker=dict(color="#4a90d9",size=5,opacity=0.65)))
                    fig.add_trace(go.Scatter(x=df_plot["trial"],y=df_plot["best_so_far"],name="Best So Far",
                        mode="lines",line=dict(color="#38a169",width=2)))
                    best_t   = bi.get("trial_number",0)
                    best_row = df_plot[df_plot["trial"]==best_t]
                    if not best_row.empty:
                        fig.add_trace(go.Scatter(x=best_row["trial"],y=best_row["score"],name="Chosen Trial",
                            mode="markers",marker=dict(color="#d97706",size=14,symbol="star")))
                    fig.update_layout(title=f"Optuna Convergence — {sel_m.replace('_',' ').title()}",
                                      xaxis_title="Trial Number",yaxis_title=bi.get("metric","Score"))
                    st.plotly_chart(apply_theme(fig), use_container_width=True)
                    insight("Blue dots = individual trial scores. Green line = running best. Gold star = chosen trial.")

                section(f"Chosen Trial #{bi.get('trial_number','?')} — Best Parameters")
                bp_d = bi.get("params",{})
                if bp_d:
                    cols_ = st.columns(min(len(bp_d),4))
                    for i,(k,v) in enumerate(bp_d.items()): cols_[i%len(cols_)].markdown(f"**`{k}`**\n\n`{v}`")
                else: st.info("Default parameters.")

                section("All Trials Table")
                def hl_best(row): return ["background-color:rgba(217,119,6,.15);font-weight:600;"]*len(row) if row.get("is_best") else [""]*len(row)
                nc_t = [c for c in df_t.columns if pd.api.types.is_numeric_dtype(df_t[c]) and c!="trial"]
                st.dataframe(safe_df(df_t).style.apply(hl_best,axis=1).format({c:"{:.4f}" for c in nc_t if "score" in c}),
                             use_container_width=True, height=300)
                st.download_button("Download Trial Log (CSV)", data=df_t.to_csv(index=False).encode(),
                                   file_name=f"{sel_m}_trials.csv", mime="text/csv")

    # ── Section D: Fairness Metrics (AIF360) ──────────────────────────────────
    results_header("Fairness Metrics",
                   "AIF360-based group fairness analysis. Measures whether the model treats demographic groups equitably.")

    fairness_note(
        "What is AIF360?  "
        "IBM's AI Fairness 360 (AIF360) is an open-source toolkit that measures and mitigates bias in machine learning models. "
        "It computes fairness metrics such as Disparate Impact, Statistical Parity Difference, Equal Opportunity Difference, "
        "and Average Odds Difference. A Disparate Impact close to 1.0 indicates equitable treatment; values below 0.8 or above 1.25 "
        "are commonly flagged as potential bias. These metrics only apply when a sensitive/protected attribute (e.g. gender, age group, "
        "race) is present in the dataset."
    )

    try:
        from aif360.datasets import BinaryLabelDataset
        from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric
        AIF360_OK = True
    except ImportError:
        AIF360_OK = False

    if not AIF360_OK:
        st.warning(
            "AIF360 is not installed in this environment. "
            "Install it with:  pip install aif360\n\n"
            "Once installed and after retraining, select a sensitive attribute column below "
            "to compute Disparate Impact, Statistical Parity Difference, Equal Opportunity Difference, "
            "and Average Odds Difference."
        )
    else:
        df_orig = st.session_state.df
        if df_orig is not None:
            non_target_cols = [c for c in df_orig.columns if c != st.session_state.target_col]
            # Exclude ID-like columns — unique identifiers are not valid sensitive attributes
            _id_keywords = {"id", "index", "uuid", "guid", "key", "row_id", "record_id", "sample_id"}
            def _is_id_col(col: str) -> bool:
                cl = col.lower().strip()
                return (cl in _id_keywords
                        or cl.endswith("_id") or cl.startswith("id_")
                        or cl == "id")
            cat_cols = [
                c for c in non_target_cols
                if (not pd.api.types.is_numeric_dtype(df_orig[c]) or df_orig[c].nunique() <= 10)
                and not _is_id_col(c)
            ]

            f1c, f2c = st.columns(2)
            sensitive_col = f1c.selectbox(
                "Sensitive Attribute Column",
                ["(None — skip)"] + cat_cols,
                key="fair_col_tr",
                help="Column representing a protected characteristic (e.g. gender, age_group). "
                     "Must be binary or will be binarized at the median/mode.")
            if sensitive_col != "(None — skip)":
                fav_val = f2c.selectbox(
                    "Privileged Group Value",
                    [str(v) for v in df_orig[sensitive_col].dropna().unique()[:20]],
                    key="fair_priv_tr",
                    help="The group considered 'privileged' — the reference group for all ratio metrics.")

                if st.button("Compute Fairness Metrics", use_container_width=True, key="fair_run_tr", type="primary"):
                    with st.spinner("Computing fairness metrics..."):
                        try:
                            bm_fair = st.session_state.best_model

                            # ── Build sensitive attribute vector aligned to test set ──
                            # Use the original dataframe index if Xt has an index,
                            # otherwise fall back to positional slicing
                            if hasattr(Xt, "index"):
                                df_test_raw = df_orig.loc[
                                    df_orig.index.isin(Xt.index)
                                ].copy()
                                # Re-order to match Xt row order
                                try:
                                    df_test_raw = df_test_raw.loc[Xt.index].reset_index(drop=True)
                                except Exception:
                                    df_test_raw = df_test_raw.reset_index(drop=True)
                            else:
                                n = len(Xt)
                                df_test_raw = df_orig.iloc[:n].copy().reset_index(drop=True)

                            # Binarize sensitive attribute: privileged=1, unprivileged=0
                            s_bin = (
                                df_test_raw[sensitive_col].astype(str) == str(fav_val)
                            ).astype(float).values  # float is required by AIF360

                            n_use = min(len(s_bin), len(yt))

                            # ── Binarize labels to strict {0.0, 1.0} ──────────────
                            # AIF360 BinaryLabelDataset requires that every value in
                            # the label column equals exactly favorable_label or
                            # unfavorable_label. Using int/numpy-int causes the
                            # "labels do not match" ValueError. Force Python float.
                            y_true_raw  = yt[:n_use]
                            y_pred_raw  = bm_fair.predict(Xt[:n_use])

                            unique_vals  = sorted(set(y_true_raw.tolist() + y_pred_raw.tolist()))
                            positive_cls = unique_vals[-1]          # largest int = positive

                            # Map everything to strict 1.0 / 0.0
                            y_true_bin = np.where(y_true_raw == positive_cls, 1.0, 0.0)
                            y_pred_bin = np.where(y_pred_raw == positive_cls, 1.0, 0.0)

                            # ── Build AIF360 DataFrames ───────────────────────────
                            gt_df = pd.DataFrame({
                                "label":     y_true_bin,
                                "sensitive": s_bin[:n_use],
                            })
                            pred_df = pd.DataFrame({
                                "label":     y_pred_bin,
                                "sensitive": s_bin[:n_use],
                            })

                            # Ensure no NaN rows
                            gt_df   = gt_df.dropna().reset_index(drop=True)
                            pred_df = pred_df.loc[gt_df.index].reset_index(drop=True)

                            gt_ds = BinaryLabelDataset(
                                df=gt_df,
                                label_names=["label"],
                                protected_attribute_names=["sensitive"],
                                favorable_label=1.0,
                                unfavorable_label=0.0,
                            )
                            pred_ds = BinaryLabelDataset(
                                df=pred_df,
                                label_names=["label"],
                                protected_attribute_names=["sensitive"],
                                favorable_label=1.0,
                                unfavorable_label=0.0,
                            )

                            cm_aif = ClassificationMetric(
                                gt_ds, pred_ds,
                                privileged_groups=[{"sensitive": 1.0}],
                                unprivileged_groups=[{"sensitive": 0.0}],
                            )

                            # Compute metrics safely (some can return NaN / inf)
                            def _safe_metric(fn):
                                try:
                                    v = fn()
                                    return round(float(v), 4) if np.isfinite(v) else None
                                except Exception:
                                    return None

                            fairness_res = {
                                "disparate_impact":              _safe_metric(cm_aif.disparate_impact),
                                "statistical_parity_difference": _safe_metric(cm_aif.statistical_parity_difference),
                                "equal_opportunity_difference":  _safe_metric(cm_aif.equal_opportunity_difference),
                                "average_odds_difference":       _safe_metric(cm_aif.average_odds_difference),
                                "theil_index":                   _safe_metric(cm_aif.theil_index),
                            }
                            st.session_state.fairness_results = {
                                "metrics": fairness_res,
                                "sensitive_col": sensitive_col,
                                "fav_val": fav_val,
                                "n_samples": n_use,
                                "positive_class": str(cn[positive_cls] if cn and positive_cls < len(cn) else positive_cls),
                            }
                            st.success(
                                f"Fairness metrics computed on {n_use:,} test samples. "
                                f"Positive class: {st.session_state.fairness_results['positive_class']}."
                            )
                        except Exception as fe:
                            import traceback
                            st.error(f"Fairness computation failed: {fe}")
                            st.code(traceback.format_exc())

                fr_state = st.session_state.get("fairness_results")
                if fr_state:
                    fr = fr_state.get("metrics", {})
                    _s_col = fr_state.get("sensitive_col", sensitive_col)
                    _f_val = fr_state.get("fav_val", fav_val)
                    _pos_c = fr_state.get("positive_class", "?")
                    _n_s   = fr_state.get("n_samples", 0)

                    st.caption(
                        f"Sensitive attribute: {_s_col}  |  Privileged group: {_f_val}  |  "
                        f"Positive class: {_pos_c}  |  Test samples: {_n_s:,}"
                    )

                    fa1, fa2, fa3, fa4, fa5 = st.columns(5)
                    def _fmt(v): return f"{v:.4f}" if v is not None else "N/A"
                    metric_card(_fmt(fr.get("disparate_impact")),              "Disparate Impact",     fa1)
                    metric_card(_fmt(fr.get("statistical_parity_difference")), "Stat. Parity Diff.",   fa2)
                    metric_card(_fmt(fr.get("equal_opportunity_difference")),  "Equal Opp. Diff.",     fa3)
                    metric_card(_fmt(fr.get("average_odds_difference")),       "Avg. Odds Diff.",      fa4)
                    metric_card(_fmt(fr.get("theil_index")),                   "Theil Index",          fa5)
                    st.markdown("<br>", unsafe_allow_html=True)

                    # Visual bar — only numeric values
                    fr_items = [(k.replace("_"," ").title(), v) for k, v in fr.items() if v is not None]
                    if fr_items:
                        fr_df = pd.DataFrame(fr_items, columns=["Metric", "Value"])
                        fig_f = apply_theme(px.bar(
                            fr_df, x="Metric", y="Value",
                            color="Value",
                            color_continuous_scale=["#e05252", "#d97706", "#38a169"],
                            title=f"Fairness Metrics — Sensitive: {_s_col} | Privileged: {_f_val}",
                        ))
                        fig_f.add_hline(y=0, line_dash="dash", line_color="#4a5568")
                        st.plotly_chart(fig_f, use_container_width=True)

                    fairness_note(
                        "Metric interpretation:  "
                        "Disparate Impact — ratio of positive outcome rates (privileged / unprivileged); "
                        "ideal = 1.0, values outside [0.8, 1.25] flag potential bias (the 80% rule).  "
                        "Statistical Parity Difference — difference in positive prediction rates; ideal = 0.  "
                        "Equal Opportunity Difference — difference in true positive rates; ideal = 0.  "
                        "Average Odds Difference — mean of TPR and FPR differences; ideal = 0.  "
                        "Theil Index — individual inequality measure; lower = more equitable."
                    )
            else:
                st.info("Select a sensitive attribute column to compute fairness metrics.")
        else:
            st.info("Dataset not available. Go to Data Upload first.")

    # ── Section E: Model Card ─────────────────────────────────────────────────
    results_header("Model Card", "Auto-generated documentation — data lineage, algorithm, metrics, intended use, limitations.")

    mc_md = st.session_state.get("model_card_md")
    if mc_md:
        dl_md_, dl_html_ = st.columns(2)
        with dl_md_:
            st.download_button("Download Model Card (Markdown)", data=mc_md.encode(),
                               file_name=f"{bn}_model_card.md", mime="text/markdown", use_container_width=True)
        # Build HTML version inline
        try:
            from src.evaluation.model_card import ModelCardGenerator
            _tmp_mcg = ModelCardGenerator(); _tmp_mcg.card_data = {"md": mc_md}
            html_text = _tmp_mcg.to_html()
        except Exception:
            html_text = f"<html><body><pre>{mc_md}</pre></body></html>"
        with dl_html_:
            st.download_button("Download Model Card (HTML)", data=html_text.encode(),
                               file_name=f"{bn}_model_card.html", mime="text/html", use_container_width=True)
        with st.expander("Preview Model Card", expanded=True):
            st.markdown(mc_md)
    else:
        st.info("Model card could not be generated automatically. Check logs above for warnings.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — HYPOTHESIS TESTING
# ══════════════════════════════════════════════════════════════════════════════
elif page == "Hypothesis Testing":
    page_header("Hypothesis Testing",
                "Statistical significance tests: McNemar, Wilcoxon Signed-Rank, Paired t-Test, and Friedman.")
    if not st.session_state.trained:
        st.warning("Run training first."); st.stop()

    tms = st.session_state.get("trained_models",{})
    if st.session_state.X_train is None or st.session_state.y_train is None:
        st.warning("Training split data not found. Retrain."); st.stop()
    if len(tms) < 2:
        st.warning("At least 2 trained models required."); st.stop()

    Xt  = st.session_state.X_test;  yt  = st.session_state.y_test
    Xt2 = st.session_state.X_train; yt2 = st.session_state.y_train
    bn  = st.session_state.best_model_name

    with st.expander("Test Reference Guide", expanded=False):
        st.markdown("""
| Test | Description | Assumption |
|---|---|---|
| McNemar | Error pattern differences between two classifiers | None |
| Wilcoxon | Paired CV fold scores differ (non-parametric) | No normality |
| Paired t-Test | Parametric version of Wilcoxon | Normality of differences |
| Friedman | All models equivalent (3+ models) | 3+ models |
| Cohen's d | Effect size beyond p-value | Accompanies any test |

Alpha = 0.05 by default. p < alpha = statistically significant difference.
""")

    c_ref, c_alpha = st.columns([2,1])
    ref_m = c_ref.selectbox("Reference Model", list(tms.keys()), index=list(tms.keys()).index(bn) if bn in tms else 0)
    alpha = c_alpha.slider("Significance Level (alpha)", 0.01, 0.10, 0.05, 0.01)

    if st.button("Run All Hypothesis Tests", use_container_width=True, type="primary"):
        with st.spinner("Running statistical tests..."):
            from src.evaluation.hypothesis_testing import HypothesisTester
            from src.utils.config_loader import load_config
            try: cfg = load_config("config/config.yaml")
            except: cfg = {"tuning":{"metric":"f1_weighted"},"models":{"cross_validation_folds":5},"project":{"random_state":42}}
            ht  = HypothesisTester(cfg, alpha=alpha)
            res = ht.run_all(tms, Xt, yt, Xt2, yt2, reference_model=ref_m)
            st.session_state.hypothesis_results = res; st.success("Tests complete.")

    res = st.session_state.get("hypothesis_results")
    if res:
        tab_sum, tab_mcn, tab_wil, tab_tt, tab_fri = st.tabs(["Summary","McNemar","Wilcoxon","Paired t-Test","Friedman"])

        with tab_sum:
            sum_df = res.get("summary", pd.DataFrame())
            if not sum_df.empty:
                def hl_sig(r): return ["background-color:rgba(58,161,105,.10);"]*len(r) if r.get("wilcoxon_sig")=="Yes" else [""]*len(r)
                nc_s = [c for c in sum_df.columns if pd.api.types.is_numeric_dtype(sum_df[c])]
                st.dataframe(safe_df(sum_df).style.apply(hl_sig,axis=1).format({c:"{:.4f}" for c in nc_s if c in sum_df.columns}), use_container_width=True)
                insight("Green rows = significant difference (p < alpha). effect_size = Cohen's d.")
                pw = res.get("wilcoxon",{})
                if pw:
                    pairs = list(pw.keys()); pvals = [pw[k].get("p_value",1) for k in pairs]
                    fig = apply_theme(px.bar(x=pairs,y=pvals,title="Wilcoxon p-values by Pair",
                        color=[0 if p<alpha else 1 for p in pvals],
                        color_discrete_map={0:"#38a169",1:"#e05252"},labels={"x":"Pair","y":"p-value"}))
                    fig.add_hline(y=alpha,line_dash="dash",line_color="#d97706",annotation_text=f"alpha={alpha}")
                    fig.update_xaxes(tickangle=30); st.plotly_chart(fig, use_container_width=True)

        with tab_mcn:
            insight("McNemar: counts disagreements. Significant = systematically different errors, not just accuracy.")
            for pair,r in res.get("mcnemar",{}).items():
                with st.expander(f"{pair}  p={r.get('p_value','?')}  {r.get('interpretation','')}"):
                    co1,co2 = st.columns(2); co1.metric("Statistic",f"{r.get('statistic',0):.4f}"); co2.metric("p-value",f"{r.get('p_value',1):.4f}")
                    ct = r.get("contingency")
                    if ct:
                        a_n,b_n = pair.split("_vs_")
                        st.dataframe(pd.DataFrame(ct,index=[f"{a_n} correct",f"{a_n} wrong"],columns=[f"{b_n} correct",f"{b_n} wrong"]))

        with tab_wil:
            insight("Non-parametric paired test for CV fold scores. No normality assumption.")
            for pair,r in res.get("wilcoxon",{}).items():
                if "error" in r: continue
                with st.expander(f"{pair}  p={r.get('p_value','?')}  {r.get('interpretation','')}  effect:{r.get('effect_label','?')}"):
                    c1_,c2_,c3_,c4_ = st.columns(4)
                    c1_.metric("Statistic",f"{r.get('statistic',0):.3f}"); c2_.metric("p-value",f"{r.get('p_value',1):.4f}")
                    c3_.metric("Cohen's d",f"{r.get('effect_size',0):.3f}"); c4_.metric("Effect",r.get("effect_label","?"))
                    c1_.metric("Mean A",f"{r.get('mean_A',0):.4f}"); c2_.metric("Mean B",f"{r.get('mean_B',0):.4f}")

        with tab_tt:
            insight("Parametric paired t-test. Assumes normal distribution of score differences.")
            for pair,r in res.get("paired_ttest",{}).items():
                if "error" in r: continue
                with st.expander(f"{pair}  p={r.get('p_value','?')}  {r.get('interpretation','')}"):
                    c1_,c2_,c3_ = st.columns(3)
                    c1_.metric("t-Statistic",f"{r.get('statistic',0):.3f}"); c2_.metric("p-value",f"{r.get('p_value',1):.4f}"); c3_.metric("Effect Size",f"{r.get('effect_size',0):.3f}")

        with tab_fri:
            insight("Friedman: tests if all models perform equivalently (null). Significant = at least one model differs.")
            fr = res.get("friedman",{})
            if "error" in (fr or {}): st.warning(fr["error"])
            elif fr:
                co1,co2 = st.columns(2); co1.metric("Chi-sq Statistic",f"{fr.get('statistic',0):.4f}"); co2.metric("p-value",f"{fr.get('p_value',1):.4f}")
                st.markdown(f"**Result:** {fr.get('interpretation','')}")
                ranks = fr.get("rankings",[])
                if ranks:
                    df_r = pd.DataFrame(ranks,columns=["Model","Mean CV Score"]); df_r["Rank"]=range(1,len(df_r)+1)
                    st.plotly_chart(apply_theme(px.bar(df_r,x="Mean CV Score",y="Model",orientation="h",
                        color="Mean CV Score",color_continuous_scale=["#1c3a6e","#38a169"],title="Model Rankings (Friedman)")), use_container_width=True)
                    st.dataframe(safe_df(df_r), use_container_width=True)
            else: st.info("At least 3 models required.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 5 — PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "Predictions":
    page_header("Predictions",
                "Run the champion model on new data — manual single prediction or batch file upload.")
    if not st.session_state.trained:
        st.warning("Run training first."); st.stop()

    bm   = st.session_state.best_model
    pp   = st.session_state.preprocessor
    cn   = st.session_state.class_names
    dfo  = st.session_state.df
    tc   = st.session_state.target_col

    # Exclude ID/high-cardinality columns that were removed during training
    _id_cols_removed = st.session_state.get("id_cols_removed", [])
    # Also auto-detect from the original df in case session was reloaded
    _auto_id_detected = []
    for _c in dfo.columns:
        if _c == tc:
            continue
        _cl = _c.lower().replace("-", "_").replace(" ", "_")
        _id_kws = {"id", "uuid", "guid", "key", "rowid", "row_id", "index",
                   "record_id", "customer_id", "user_id", "order_id", "transaction_id"}
        _is_id_name  = _cl in _id_kws or any(_cl == k or _cl.endswith(f"_{k}") for k in _id_kws)
        _is_high_card = dfo[_c].nunique() / max(len(dfo), 1) > 0.90
        if _is_id_name or _is_high_card:
            _auto_id_detected.append(_c)
    _all_excluded = set(_id_cols_removed) | set(_auto_id_detected)

    # Feature columns for prediction = original columns minus target and ID columns
    fcs  = [c for c in dfo.columns if c != tc and c not in _all_excluded]
    if _all_excluded:
        st.caption(
            f"ℹ️ Columns excluded from prediction (ID/high-cardinality — no predictive value): "
            + ", ".join(f"`{c}`" for c in sorted(_all_excluded))
        )

    # Retrieve text analysis config saved during training
    _pred_txt_cfg   = st.session_state.get("text_analysis_cfg", {})
    _pred_txt_en    = _pred_txt_cfg.get("enabled", False)
    _pred_txt_cols  = _pred_txt_cfg.get("text_cols", [])
    _pred_vecs      = st.session_state.get("sentiment_vectorizers", {})

    def _apply_text_transforms_for_inference(df_raw: pd.DataFrame) -> pd.DataFrame:
        """
        Apply the exact same TF-IDF + sentiment transforms used during training
        to a new raw input DataFrame, so the column layout matches what the model expects.
        Must be called before pp.transform().
        """
        if not _pred_txt_en or not _pred_txt_cols:
            return df_raw
        df_t = df_raw.copy()
        try:
            from textblob import TextBlob
            for _tcol in _pred_txt_cols:
                if _tcol not in df_t.columns:
                    continue
                _vec = _pred_vecs.get(_tcol)
                if _vec is None:
                    continue
                _series = df_t[_tcol].fillna("").astype(str)
                # TF-IDF using the FITTED vectorizer (same vocabulary as training)
                _tfidf_arr  = _vec.transform(_series).toarray()
                _tfidf_cols = [f"{_tcol}_tfidf_{v}" for v in _vec.get_feature_names_out()]
                _tfidf_df   = pd.DataFrame(_tfidf_arr, columns=_tfidf_cols, index=df_t.index)
                # Sentiment
                _sentiments = _series.apply(lambda t: TextBlob(t).sentiment)
                df_t[f"{_tcol}_sentiment_polarity"]     = _sentiments.apply(lambda s: s.polarity)
                df_t[f"{_tcol}_sentiment_subjectivity"] = _sentiments.apply(lambda s: s.subjectivity)
                # Add TF-IDF columns and drop original text column
                df_t = pd.concat([df_t, _tfidf_df], axis=1)
                df_t.drop(columns=[_tcol], inplace=True)
        except Exception as _te:
            st.warning(f"Text transform warning: {_te} — prediction may be inaccurate.")
        return df_t

    tab_manual, tab_batch = st.tabs(["Manual Input", "Batch File"])

    with tab_manual:
        section("Input Feature Values")
        # Separate text vs regular columns for appropriate input widgets
        _text_input_cols = [c for c in fcs if c in _pred_txt_cols] if _pred_txt_en else []
        _other_input_cols = [c for c in fcs if c not in _text_input_cols]

        if _text_input_cols:
            insight(
                f"Text column(s) **{', '.join(_text_input_cols)}** will be automatically converted to "
                f"TF-IDF + sentiment features before prediction — same as during training. "
                f"Numeric and categorical fields are shown below."
            )
        else:
            insight("Numeric fields default to the column median. Categorical fields list observed training values.")

        with st.form("manual_predict"):
            inputs = {}
            # Text columns — use text_area widgets
            if _text_input_cols:
                st.markdown("**Text Input(s)**")
                for tc_ in _text_input_cols:
                    inputs[tc_] = st.text_area(
                        tc_,
                        value="",
                        placeholder=f"Enter {tc_} here...",
                        key=f"mp_text_{tc_}",
                        height=100,
                    )
            # Regular columns — numeric inputs and selectboxes
            if _other_input_cols:
                st.markdown("**Feature Values**")
                for chunk in [_other_input_cols[i:i+3] for i in range(0, len(_other_input_cols), 3)]:
                    fcols_ = st.columns(len(chunk))
                    for fc_, col_ in zip(chunk, fcols_):
                        sv_ = dfo[fc_].dropna()
                        if pd.api.types.is_numeric_dtype(dfo[fc_]):
                            inputs[fc_] = col_.number_input(
                                fc_, value=float(sv_.median()) if len(sv_) > 0 else 0.0,
                                key=f"mp_{fc_}"
                            )
                        else:
                            opts = [str(v) for v in sv_.unique().tolist()[:20]]
                            inputs[fc_] = col_.selectbox(fc_, options=opts or [""], key=f"mp_{fc_}")

            submitted = st.form_submit_button("Predict", use_container_width=True, type="primary")

        if submitted:
            try:
                raw_df   = pd.DataFrame([inputs])
                # Apply the same text/TF-IDF/sentiment transforms used at training time
                trans_df = _apply_text_transforms_for_inference(raw_df)
                Xn       = pp.transform(trans_df)
                pred     = bm.predict(Xn)
                pl       = cn[pred[0]] if cn and pred[0] < len(cn) else str(pred[0])
                c_res_, c_prob_ = st.columns(2)
                with c_res_:
                    st.markdown(
                        f'<div class="champion-banner" style="text-align:center;">'
                        f'<div class="champion-sub">Predicted Class</div>'
                        f'<div class="champion-name" style="font-size:1.4rem;">{pl}</div></div>',
                        unsafe_allow_html=True
                    )
                with c_prob_:
                    if hasattr(bm, "predict_proba"):
                        probs = bm.predict_proba(Xn)[0].astype(float)
                        pf = pd.DataFrame({
                            "Class": cn or [str(i) for i in range(len(probs))],
                            "Probability": probs
                        }).sort_values("Probability", ascending=True)
                        st.plotly_chart(apply_theme(px.bar(
                            pf, x="Probability", y="Class", orientation="h",
                            color="Probability",
                            color_continuous_scale=["#1c3a6e", "#38a169"],
                            title="Class Probabilities"
                        )), use_container_width=True)
            except Exception as e:
                st.error(f"Prediction failed: {e}")
                import traceback; st.code(traceback.format_exc())

    with tab_batch:
        section("Upload Batch File")
        st.caption(
            "Upload a CSV/Excel file with the same columns as the training data "
            "(excluding the target column). "
            + (f"Text column(s) **{', '.join(_pred_txt_cols)}** will be automatically transformed."
               if _pred_txt_en and _pred_txt_cols else "")
        )
        tf = st.file_uploader("CSV or Excel file", type=["csv", "xlsx"])
        if tf:
            try:
                ext = Path(tf.name).suffix.lower()
                tdf = pd.read_csv(tf) if ext == ".csv" else pd.read_excel(tf)
                st.dataframe(safe_df(tdf.head(5)), use_container_width=True)
                st.caption(f"{len(tdf):,} rows × {tdf.shape[1]} columns loaded")
                if st.button("Run Batch Predictions", use_container_width=True, type="primary"):
                    # Drop ID columns from batch file if present (same as training)
                    _batch_drop = [c for c in _all_excluded if c in tdf.columns]
                    tdf_clean = tdf.drop(columns=_batch_drop, errors="ignore") if _batch_drop else tdf.copy()
                    if _batch_drop:
                        st.caption(f"Dropped ID/high-cardinality columns from batch file: {_batch_drop}")
                    # Apply text transforms then sklearn pipeline
                    tdf_transformed = _apply_text_transforms_for_inference(tdf_clean)
                    Xb    = pp.transform(tdf_transformed)
                    preds = bm.predict(Xb)
                    lbls  = [cn[p] if cn and p < len(cn) else str(p) for p in preds]
                    res_df = tdf.copy()
                    res_df["prediction"] = lbls
                    if hasattr(bm, "predict_proba"):
                        probs_b = bm.predict_proba(Xb).astype(float)
                        for i, c_ in enumerate(cn or range(probs_b.shape[1])):
                            res_df[f"prob_{c_}"] = probs_b[:, i]
                    st.success(f"Predictions complete — {len(res_df):,} rows")
                    st.dataframe(safe_df(res_df.head(20)), use_container_width=True)
                    st.download_button(
                        "Download Predictions (CSV)",
                        data=res_df.to_csv(index=False).encode(),
                        file_name="batch_predictions.csv",
                        mime="text/csv"
                    )
            except Exception as e:
                st.error(f"Batch prediction failed: {e}")
                import traceback; st.code(traceback.format_exc())


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 6 — MODEL REGISTRY
# ══════════════════════════════════════════════════════════════════════════════
elif page == "Monitoring & Drift":
    page_header(
        "Monitoring & Drift",
        "SR 11-7 ongoing monitoring — PSI feature drift, data quality, prediction shift, and performance degradation."
    )
    if not st.session_state.trained:
        st.warning("Run training first to enable monitoring."); st.stop()

    bm  = st.session_state.best_model
    pp  = st.session_state.preprocessor
    cn  = st.session_state.class_names
    dfo = st.session_state.df
    tc  = st.session_state.target_col
    fn  = st.session_state.feature_names or []

    # ── SR 11-7 Risk Tier summary ─────────────────────────────────────────
    _rt = st.session_state.get("sr117_risk_tier", {})
    if _rt:
        _tier_colors = {"HIGH": "#c53030", "MEDIUM": "#d97706", "LOW": "#38a169"}
        _tc2 = _tier_colors.get(_rt.get("tier", "MEDIUM"), "#4a90d9")
        section("SR 11-7 Model Risk Assessment")
        c1, c2, c3 = st.columns(3)
        c1.metric("Risk Tier", _rt.get("tier", "—"))
        c2.metric("Risk Score", _rt.get("score", "—"))
        c3.metric("Validation Required", "Independent" if _rt.get("tier") == "HIGH" else "Internal")
        st.markdown(
            f'<div class="insight-box" style="border-left-color:{_tc2};">'
            f'<strong>Risk Tier {_rt.get("tier","?")} — Required Steps:</strong><br>'
            + "<br>".join(f"• {s}" for s in _rt.get("required_steps", []))
            + "</div>",
            unsafe_allow_html=True
        )
        if _rt.get("reasons"):
            with st.expander("Risk scoring reasons"):
                for r in _rt["reasons"]:
                    st.markdown(f"- {r}")

    # # ── Drift Detection ───────────────────────────────────────────────────
    # section("Population Drift Detection")
    # st.caption(
    #     "Upload a new production dataset (same schema as training data) to detect feature distribution "
    #     "drift using Population Stability Index (PSI). PSI < 0.10 = stable, 0.10–0.20 = monitor, > 0.20 = alert."
    # )

    # _drift_file = st.file_uploader(
    #     "Upload production / new data sample (CSV or Excel)",
    #     type=["csv", "xlsx"],
    #     key="drift_upload"
    # )

    # if _drift_file:
    #     try:
    #         _ext = Path(_drift_file.name).suffix.lower()
    #         _new_df = pd.read_csv(_drift_file) if _ext == ".csv" else pd.read_excel(_drift_file)
    #         st.caption(f"Loaded: {len(_new_df):,} rows × {_new_df.shape[1]} columns")

    #         if st.button("Run Drift Analysis", key="run_drift", type="primary"):
    #             with st.spinner("Computing drift metrics..."):
    #                 try:
    #                     from src.monitoring.drift_monitor import ModelMonitor
    #                     # Use training data features (excluding target + ID cols)
    #                     _id_removed   = st.session_state.get("id_cols_removed", [])
    #                     _train_feats  = [c for c in dfo.columns if c != tc and c not in _id_removed]
    #                     _train_subset = dfo[_train_feats].copy()
    #                     _new_subset   = _new_df[[c for c in _train_feats if c in _new_df.columns]].copy()

    #                     _monitor = ModelMonitor(train_df=_train_subset, feature_names=_train_feats)
    #                     _drift_rpt = _monitor.run(new_df=_new_subset)
    #                     st.session_state["monitoring_report"] = _drift_rpt
    #                 except Exception as _de:
    #                     st.error(f"Drift analysis error: {_de}")

    #     except Exception as _fe:
    #         st.error(f"File read error: {_fe}")

    # # ── Display Drift Report ──────────────────────────────────────────────
    # _drpt = st.session_state.get("monitoring_report")
    # if _drpt:
    #     _summary = _drpt.get("summary", {})
    #     section("Drift Report")

    #     # Overall health
    #     _health_color = {"🟢 Healthy": "#38a169", "🟡 Monitor": "#d97706", "🔴 Action Required": "#c53030"}
    #     _health = _summary.get("overall_health", "Unknown")
    #     st.markdown(
    #         f'<div class="champion-banner" style="text-align:center;padding:14px;">'
    #         f'<div class="champion-sub">Overall Model Health</div>'
    #         f'<div class="champion-name" style="font-size:1.6rem;">{_health}</div>'
    #         f'</div>',
    #         unsafe_allow_html=True
    #     )

    #     mc1, mc2, mc3 = st.columns(3)
    #     mc1.metric("Feature Alerts (PSI > 0.20)", _summary.get("feature_alerts", 0),
    #                delta_color="inverse",
    #                delta=f"+{_summary.get('feature_alerts',0)}" if _summary.get("feature_alerts",0) > 0 else None)
    #     mc2.metric("Feature Warnings (PSI 0.10–0.20)", _summary.get("feature_warnings", 0))
    #     mc3.metric("Data Quality Issues", _summary.get("dq_issues", 0),
    #                delta_color="inverse",
    #                delta=f"+{_summary.get('dq_issues',0)}" if _summary.get("dq_issues",0) > 0 else None)

    #     # Feature Drift Table
    #     _fd = _drpt.get("feature_drift", {})
    #     if _fd:
    #         tab_drift, tab_dq = st.tabs(["Feature Drift (PSI)", "Data Quality"])

    #         with tab_drift:
    #             _fd_rows = []
    #             for col, info in _fd.items():
    #                 if "psi" in info:
    #                     _fd_rows.append({
    #                         "Feature":      col,
    #                         "PSI":          info.get("psi", 0),
    #                         "Status":       info.get("label", ""),
    #                         "Train Mean":   info.get("train_mean", "—"),
    #                         "New Mean":     info.get("new_mean", "—"),
    #                     })
    #                 else:
    #                     _fd_rows.append({
    #                         "Feature":      col,
    #                         "PSI":          "—",
    #                         "Status":       info.get("label", "🟢 Stable"),
    #                         "Train Mean":   "categorical",
    #                         "New Mean":     f"{len(info.get('new_categories',[]))} new cats" if info.get("new_categories") else "stable",
    #                     })
    #             if _fd_rows:
    #                 _fd_df = pd.DataFrame(_fd_rows).sort_values("PSI", ascending=False, key=lambda x: pd.to_numeric(x, errors="coerce").fillna(0))
    #                 st.dataframe(_fd_df, use_container_width=True)

    #                 # PSI bar chart (numeric only)
    #                 _psi_rows = [r for r in _fd_rows if isinstance(r["PSI"], float)]
    #                 if _psi_rows:
    #                     _psi_df = pd.DataFrame(_psi_rows).sort_values("PSI", ascending=True)
    #                     _fig_psi = px.bar(
    #                         _psi_df, x="PSI", y="Feature", orientation="h",
    #                         color="PSI",
    #                         color_continuous_scale=["#38a169", "#d97706", "#c53030"],
    #                         color_continuous_midpoint=0.15,
    #                         title="Feature Drift — PSI by Feature",
    #                     )
    #                     _fig_psi.add_vline(x=0.10, line_dash="dash", line_color="#d97706",
    #                                        annotation_text="Monitor (0.10)", annotation_position="top right")
    #                     _fig_psi.add_vline(x=0.20, line_dash="dash", line_color="#c53030",
    #                                        annotation_text="Alert (0.20)", annotation_position="top right")
    #                     st.plotly_chart(apply_theme(_fig_psi), use_container_width=True)

    #         with tab_dq:
    #             _dq = _drpt.get("data_quality", {})
    #             if _dq:
    #                 _dq_rows = [
    #                     {
    #                         "Feature": col,
    #                         "New Null %": f"{info.get('null_pct',0)*100:.1f}%",
    #                         "Baseline Null %": f"{info.get('baseline_null',0)*100:.1f}%",
    #                         "Out of Range": "⚠️ Yes" if info.get("out_of_range") else "✅ No",
    #                         "Issue": "🔴 Yes" if info.get("issue") else "🟢 No",
    #                     }
    #                     for col, info in _dq.items()
    #                 ]
    #                 st.dataframe(pd.DataFrame(_dq_rows), use_container_width=True)

    #     # AI Drift Analysis
    #     _ai_key_drift = st.session_state.get("openai_api_key", "")
    #     if _ai_key_drift and st.button("🤖 Explain drift with AI (Claude)", key="ai_drift_btn"):
    #         with st.spinner("Claude is analysing drift..."):
    #             try:
    #                 from src.monitoring.ai_insights import AIInsightsEngine
    #                 _eng = AIInsightsEngine(api_key=_ai_key_drift)
    #                 _drift_txt = _eng.drift_analysis_insights(
    #                     drift_report=_drpt,
    #                     model_name=st.session_state.best_model_name or "Champion",
    #                 )
    #                 if _drift_txt:
    #                     st.markdown(
    #                         f'<div class="insight-box" style="border-left-color:#4a90d9;">'
    #                         f'🤖 <strong>AI Drift Analysis</strong><br><br>{_drift_txt}</div>',
    #                         unsafe_allow_html=True
    #                     )
    #             except Exception as _ae:
    #                 st.warning(f"AI drift analysis error: {_ae}")

elif page == "Model Registry":
    page_header("Model Registry",
                "Browse all MLflow experiment runs. Compare metrics across runs and track training history.")
    try:
        import mlflow
        from src.utils.config_loader import load_config
        cfg  = load_config("config/config.yaml")
        tc_  = cfg.get("tracking",{}).get("mlflow",{})
        mlflow.set_tracking_uri(tc_.get("tracking_uri","mlruns"))
        exp  = mlflow.get_experiment_by_name(tc_.get("experiment_name","automl_classification"))
    except Exception as e:
        st.error(f"MLflow initialisation failed: {e}"); st.stop()

    if exp is None: st.info("No MLflow experiment found. Run training first."); st.stop()

    rdf = mlflow.search_runs(experiment_ids=[exp.experiment_id], order_by=["metrics.f1_weighted DESC"], max_results=100)
    if rdf.empty: st.info("No runs recorded yet."); st.stop()

    mc_cols = [c for c in rdf.columns if c.startswith("metrics.")]
    dc      = [c for c in ["tags.mlflow.runName","start_time","status"]+mc_cols[:6] if c in rdf.columns]

    c1,c2,c3 = st.columns(3)
    metric_card(str(len(rdf)), "Total Runs", c1)
    if "metrics.f1_weighted" in rdf.columns: metric_card(f"{rdf['metrics.f1_weighted'].max():.4f}","Best F1",c2)
    if "metrics.accuracy"    in rdf.columns: metric_card(f"{rdf['metrics.accuracy'].max():.4f}","Best Accuracy",c3)
    st.markdown("<br>", unsafe_allow_html=True)

    tab_runs, tab_cmp = st.tabs(["All Runs","Metric Comparison"])
    with tab_runs: st.dataframe(safe_df(rdf[dc].head(50)), use_container_width=True, height=400)
    with tab_cmp:
        avail = [c.replace("metrics.","") for c in mc_cols if any(k in c for k in ["f1","accuracy","roc","precision","recall"])]
        if avail:
            sel_met = st.selectbox("Select Metric", avail)
            fc      = f"metrics.{sel_met}"
            if fc in rdf.columns:
                pf = rdf[["tags.mlflow.runName",fc]].dropna(); pf.columns = ["Run",sel_met]
                fig = apply_theme(px.bar(pf.sort_values(sel_met,ascending=True),x=sel_met,y="Run",orientation="h",
                    color=sel_met,color_continuous_scale=["#1c3a6e","#38a169"],title=f"Run Comparison — {sel_met}"))
                st.plotly_chart(fig, use_container_width=True)
