from openai import OpenAI

client = OpenAI(api_key="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")

resp = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Say hello"}]
)

print(resp.choices[0].message.content)