# """
# Training Pipeline
# Orchestrates the full AutoML workflow end-to-end.
# """
# import json
# import os
# import pickle
# from pathlib import Path
# from typing import Any, Callable, Dict, List, Optional, Tuple

# import numpy as np
# import pandas as pd
# from sklearn.model_selection import train_test_split

# from src.evaluation.evaluator import ModelEvaluator
# from src.explainability.shap_explainer import ExplainabilityEngine
# from src.ingestion.data_loader import DataIngestion
# from src.models.registry import get_available_models
# from src.models.selector import ModelSelector
# from src.models.trainer import ModelTrainer
# from src.preprocessing.pipeline import PreprocessingPipeline
# from src.tracking.mlflow_tracker import ExperimentTracker
# from src.tuning.optuna_tuner import HyperparameterTuner
# from src.utils.config_loader import load_config
# from src.utils.logger import get_logger

# logger = get_logger(__name__)


# class TrainingPipeline:
#     """
#     End-to-end AutoML training pipeline.
#     """

#     def __init__(self, config_path: str = "config/config.yaml"):
#         self.config = load_config(config_path)
#         self.ingestion = DataIngestion(self.config)
#         self.preprocessor = PreprocessingPipeline(self.config)
#         self.trainer = ModelTrainer(self.config)
#         self.tuner = HyperparameterTuner(self.config)
#         self.evaluator = ModelEvaluator(self.config)
#         self.selector = ModelSelector(self.config)
#         self.tracker = ExperimentTracker(self.config)
#         self.explainer = ExplainabilityEngine(self.config)

#         self.df: Optional[pd.DataFrame] = None
#         self.col_types: Optional[Dict] = None
#         self.profile: Optional[Dict] = None
#         self.X_train: Optional[np.ndarray] = None
#         self.X_test: Optional[np.ndarray] = None
#         self.y_train: Optional[np.ndarray] = None
#         self.y_test: Optional[np.ndarray] = None
#         self.trained_models: Dict[str, Any] = {}
#         self.leaderboard: Optional[pd.DataFrame] = None
#         self.best_model_name: Optional[str] = None
#         self.best_model: Optional[Any] = None
#         self.class_names: Optional[List[str]] = None

#         os.makedirs("models", exist_ok=True)
#         os.makedirs("logs", exist_ok=True)

#     def run(
#         self,
#         file_path: str,
#         target_col: str,
#         model_names: Optional[List[str]] = None,
#         tune: bool = True,
#         progress_callback: Optional[Callable[[str, int], None]] = None,
#     ) -> Dict[str, Any]:
#         """
#         Execute the full training pipeline.

#         Args:
#             file_path: Path to the input dataset.
#             target_col: Target column name.
#             model_names: List of models to train. None = all.
#             tune: Whether to run hyperparameter tuning.
#             progress_callback: Optional callback(message, pct) for UI progress.

#         Returns:
#             Dictionary with pipeline results.
#         """
#         def _progress(msg: str, pct: int) -> None:
#             logger.info(f"[{pct}%] {msg}")
#             if progress_callback:
#                 progress_callback(msg, pct)

#         _progress("Loading and validating data...", 5)
#         self.df, self.col_types, self.profile = self.ingestion.run(file_path, target_col)

#         numeric_cols = self.col_types.get("numeric", [])
#         categorical_cols = self.col_types.get("categorical", [])

#         _progress("Preprocessing features...", 15)
#         X_transformed, y_encoded = self.preprocessor.fit_transform(
#             self.df, target_col, numeric_cols, categorical_cols
#         )
#         self.class_names = [str(c) for c in self.preprocessor.label_encoder.classes_]
#         self.preprocessor.save("models/preprocessor.pkl")

#         test_size = self.config.get("data", {}).get("test_size", 0.2)
#         random_state = self.config.get("project", {}).get("random_state", 42)
#         self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
#             X_transformed, y_encoded, test_size=test_size,
#             random_state=random_state, stratify=y_encoded
#         )

#         model_names = model_names or get_available_models()
#         best_params: Dict[str, Dict] = {}

#         if tune:
#             _progress("Tuning hyperparameters with Optuna...", 30)
#             best_params = self.tuner.tune_all(self.X_train, self.y_train, model_names)
#             with open("models/best_params.json", "w") as f:
#                 json.dump(best_params, f, indent=2, default=str)

#         _progress("Training models...", 55)
#         self.trained_models = self.trainer.train_all(
#             self.X_train, self.y_train, model_names, best_params
#         )

#         _progress("Evaluating models...", 70)
#         self.leaderboard = self.evaluator.compare_models(
#             self.trained_models, self.X_test, self.y_test
#         )

#         _progress("Selecting best model...", 80)
#         self.best_model_name, self.best_model = self.selector.select(
#             self.trained_models, self.leaderboard
#         )
#         self.selector.save("models/best_model.pkl")

#         _progress("Logging to MLflow...", 88)
#         for name, model in self.trained_models.items():
#             row = self.leaderboard[self.leaderboard["model"] == name]
#             metrics = row.iloc[0].to_dict() if not row.empty else {}
#             params = best_params.get(name, {})
#             self.tracker.log_full_run(
#                 model_name=name,
#                 model=model,
#                 params=params,
#                 metrics={k: v for k, v in metrics.items() if k != "model"},
#                 tags={"pipeline": "automl", "best": str(name == self.best_model_name)},
#             )

#         _progress("Computing SHAP explanations...", 95)
#         self.explainer.compute_shap(
#             self.best_model,
#             self.X_test,
#             feature_names=self.preprocessor.feature_names_out,
#         )

#         _progress("Pipeline complete!", 100)

#         return {
#             "leaderboard": self.leaderboard,
#             "best_model_name": self.best_model_name,
#             "best_model": self.best_model,
#             "class_names": self.class_names,
#             "feature_names": self.preprocessor.feature_names_out,
#             "profile": self.profile,
#         }

#     def predict(self, input_df: pd.DataFrame) -> Dict[str, Any]:
#         """
#         Generate predictions using the best model.

#         Args:
#             input_df: DataFrame with same columns as training (minus target).

#         Returns:
#             Dict with predictions, probabilities.
#         """
#         if self.best_model is None or self.preprocessor.pipeline is None:
#             raise RuntimeError("Pipeline not trained. Run pipeline.run() first.")

#         X = self.preprocessor.transform(input_df)
#         preds = self.best_model.predict(X)
#         labels = self.preprocessor.label_encoder.inverse_transform(preds)
#         probs = None
#         if hasattr(self.best_model, "predict_proba"):
#             probs = self.best_model.predict_proba(X).tolist()

#         return {
#             "predictions": labels.tolist(),
#             "encoded": preds.tolist(),
#             "probabilities": probs,
#             "class_names": self.class_names,
#         }
"""
Training Pipeline
Orchestrates the full AutoML workflow end-to-end.
"""

import json
import os
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

import mlflow
import mlflow.data

from src.evaluation.evaluator import ModelEvaluator
from src.explainability.shap_explainer import ExplainabilityEngine
from src.ingestion.data_loader import DataIngestion
from src.models.registry import get_available_models
from src.models.selector import ModelSelector
from src.models.trainer import ModelTrainer
from src.preprocessing.pipeline import PreprocessingPipeline
from src.tracking.mlflow_tracker import ExperimentTracker
from src.tuning.optuna_tuner import HyperparameterTuner
from src.utils.config_loader import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)


class TrainingPipeline:
    """
    End-to-end AutoML training pipeline.
    """

    def __init__(self, config_path: str = "config/config.yaml"):
        self.config = load_config(config_path)

        self.ingestion = DataIngestion(self.config)
        self.preprocessor = PreprocessingPipeline(self.config)
        self.trainer = ModelTrainer(self.config)
        self.tuner = HyperparameterTuner(self.config)
        self.evaluator = ModelEvaluator(self.config)
        self.selector = ModelSelector(self.config)
        self.tracker = ExperimentTracker(self.config)
        self.explainer = ExplainabilityEngine(self.config)

        self.df: Optional[pd.DataFrame] = None
        self.col_types: Optional[Dict] = None
        self.profile: Optional[Dict] = None

        self.X_train = self.X_test = None
        self.y_train = self.y_test = None

        self.trained_models: Dict[str, Any] = {}
        self.leaderboard: Optional[pd.DataFrame] = None
        self.best_model_name: Optional[str] = None
        self.best_model: Optional[Any] = None
        self.class_names: Optional[List[str]] = None

        os.makedirs("models", exist_ok=True)
        os.makedirs("logs", exist_ok=True)

    def run(
        self,
        file_path: str,
        target_col: str,
        model_names: Optional[List[str]] = None,
        tune: bool = True,
        progress_callback: Optional[Callable[[str, int], None]] = None,
    ) -> Dict[str, Any]:

        def _progress(msg: str, pct: int) -> None:
            logger.info(f"[{pct}%] {msg}")
            if progress_callback:
                progress_callback(msg, pct)

        # ── Data ingestion ─────────────────────────────────────────────
        _progress("Loading and validating data...", 5)
        self.df, self.col_types, self.profile = self.ingestion.run(file_path, target_col)

        # ✅ CREATE MLflow Dataset ONCE (post-cleaning, pre-transform)
        mlflow_dataset = mlflow.data.from_pandas(
            self.df,
            name="automl_training_dataset",
            source=os.path.basename(file_path),
        )

        numeric_cols = self.col_types.get("numeric", [])
        categorical_cols = self.col_types.get("categorical", [])

        # ── Preprocessing ─────────────────────────────────────────────
        _progress("Preprocessing features...", 15)
        X_transformed, y_encoded = self.preprocessor.fit_transform(
            self.df, target_col, numeric_cols, categorical_cols
        )

        self.class_names = [
            str(c) for c in self.preprocessor.label_encoder.classes_
        ]
        self.preprocessor.save("models/preprocessor.pkl")

        # ── Train/Test Split ──────────────────────────────────────────
        test_size = self.config["data"].get("test_size", 0.2)
        random_state = self.config["project"].get("random_state", 42)

        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_transformed,
            y_encoded,
            test_size=test_size,
            random_state=random_state,
            stratify=y_encoded,
        )

        model_names = model_names or get_available_models()
        best_params: Dict[str, Dict] = {}

        # ── Hyperparameter tuning ─────────────────────────────────────
        if tune:
            _progress("Tuning hyperparameters with Optuna...", 30)
            best_params = self.tuner.tune_all(
                self.X_train, self.y_train, model_names
            )
            with open("models/best_params.json", "w") as f:
                json.dump(best_params, f, indent=2, default=str)

        # ── Training ──────────────────────────────────────────────────
        _progress("Training models...", 55)
        self.trained_models = self.trainer.train_all(
            self.X_train, self.y_train, model_names, best_params
        )

        # ── Evaluation ────────────────────────────────────────────────
        _progress("Evaluating models...", 70)
        self.leaderboard = self.evaluator.compare_models(
            self.trained_models, self.X_test, self.y_test
        )

        # ── Model Selection ───────────────────────────────────────────
        _progress("Selecting best model...", 80)
        self.best_model_name, self.best_model = self.selector.select(
            self.trained_models, self.leaderboard
        )
        self.selector.save("models/best_model.pkl")

        # ── MLflow Logging (✅ DATASET LOGGED HERE) ─────────────────────
        _progress("Logging to MLflow...", 88)

        for name, model in self.trained_models.items():
            row = self.leaderboard[self.leaderboard["model"] == name]
            metrics = row.iloc[0].to_dict() if not row.empty else {}

            self.tracker.log_full_run(
                model_name=name,
                model=model,
                params=best_params.get(name, {}),
                metrics={k: v for k, v in metrics.items() if k != "model"},
                tags={
                    "pipeline": "automl",
                    "best": str(name == self.best_model_name),
                },
                dataset=mlflow_dataset,  # ✅ THIS ENABLES DATASET COLUMN
            )

        # ── Explainability ────────────────────────────────────────────
        _progress("Computing SHAP explanations...", 95)
        self.explainer.compute_shap(
            self.best_model,
            self.X_test,
            feature_names=self.preprocessor.feature_names_out,
        )

        _progress("Pipeline complete!", 100)

        return {
            "leaderboard": self.leaderboard,
            "best_model_name": self.best_model_name,
            "best_model": self.best_model,
            "class_names": self.class_names,
            "feature_names": self.preprocessor.feature_names_out,
            "profile": self.profile,
        }
