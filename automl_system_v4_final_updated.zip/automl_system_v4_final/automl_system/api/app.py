"""
FastAPI Deployment Module
REST API for serving predictions from the best trained model.
"""
import os
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from src.models.selector import ModelSelector
from src.preprocessing.pipeline import PreprocessingPipeline
from src.explainability.shap_explainer import ExplainabilityEngine
from src.utils.config_loader import load_config
from src.utils.logger import get_logger

logger = get_logger(__name__)

# ── App Setup ──────────────────────────────────────────────────────────────────
app = FastAPI(
    title="AutoML Classification API",
    description="Production-grade AutoML prediction service",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global State ───────────────────────────────────────────────────────────────
_model = None
_model_name: str = ""
_preprocessor: Optional[PreprocessingPipeline] = None
_config: Dict = {}
_class_names: List[str] = []
_feature_names: List[str] = []
_explainer: Optional[ExplainabilityEngine] = None


def load_artifacts():
    """Load model and preprocessor artifacts on startup."""
    global _model, _model_name, _preprocessor, _config, _class_names, _feature_names, _explainer

    config_path = os.getenv("CONFIG_PATH", "config/config.yaml")
    model_path = os.getenv("MODEL_PATH", "models/best_model.pkl")
    preprocessor_path = os.getenv("PREPROCESSOR_PATH", "models/preprocessor.pkl")

    try:
        _config = load_config(config_path)
    except Exception:
        _config = {}

    try:
        _model_name, _model = ModelSelector.load(model_path)
        logger.info(f"Model loaded: {_model_name}")
    except Exception as e:
        logger.error(f"Model not loaded: {e}")

    try:
        _preprocessor = PreprocessingPipeline.load(preprocessor_path)
        _feature_names = _preprocessor.feature_names_out
        if _preprocessor.label_encoder:
            _class_names = [str(c) for c in _preprocessor.label_encoder.classes_]
        logger.info("Preprocessor loaded.")
    except Exception as e:
        logger.error(f"Preprocessor not loaded: {e}")

    if _model and _config:
        _explainer = ExplainabilityEngine(_config)


@app.on_event("startup")
async def startup_event():
    load_artifacts()


# ── Schemas ────────────────────────────────────────────────────────────────────
class PredictionRequest(BaseModel):
    features: Dict[str, Any] = Field(..., description="Feature name → value mapping")
    explain: bool = Field(False, description="Return SHAP/LIME explanation")

    class Config:
        schema_extra = {
            "example": {
                "features": {"age": 35, "income": 55000, "education": "Bachelor"},
                "explain": False,
            }
        }


class PredictionResponse(BaseModel):
    prediction: str
    prediction_encoded: int
    probabilities: Optional[Dict[str, float]] = None
    explanation: Optional[Dict[str, float]] = None
    model_name: str


class BatchPredictionRequest(BaseModel):
    records: List[Dict[str, Any]] = Field(..., description="List of feature dicts")

    class Config:
        schema_extra = {
            "example": {
                "records": [
                    {"age": 35, "income": 55000, "education": "Bachelor"},
                    {"age": 28, "income": 42000, "education": "Master"},
                ]
            }
        }


class BatchPredictionResponse(BaseModel):
    predictions: List[str]
    probabilities: Optional[List[Dict[str, float]]] = None
    count: int
    model_name: str


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_name: str
    classes: List[str]
    n_features: int


# ── Helpers ────────────────────────────────────────────────────────────────────
def _check_ready():
    if _model is None:
        raise HTTPException(status_code=503, detail="Model not loaded. Train and deploy a model first.")
    if _preprocessor is None:
        raise HTTPException(status_code=503, detail="Preprocessor not loaded.")


def _predict_df(df: pd.DataFrame) -> Dict[str, Any]:
    X = _preprocessor.transform(df)
    preds_enc = _model.predict(X)
    preds = _preprocessor.label_encoder.inverse_transform(preds_enc)
    probs = None
    if hasattr(_model, "predict_proba"):
        prob_arr = _model.predict_proba(X)
        probs = [
            {_class_names[i]: float(p) for i, p in enumerate(row)}
            for row in prob_arr
        ]
    return {"preds": preds, "preds_enc": preds_enc, "probs": probs, "X": X}


# ── Endpoints ──────────────────────────────────────────────────────────────────
@app.get("/", tags=["Root"])
async def root():
    return {"message": "AutoML Classification API", "docs": "/docs"}


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health():
    return HealthResponse(
        status="healthy" if _model is not None else "model_not_loaded",
        model_loaded=_model is not None,
        model_name=_model_name,
        classes=_class_names,
        n_features=len(_feature_names),
    )


@app.post("/predict", response_model=PredictionResponse, tags=["Prediction"])
async def predict(request: PredictionRequest):
    """Single-row prediction with optional explanation."""
    _check_ready()
    df = pd.DataFrame([request.features])

    try:
        result = _predict_df(df)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Prediction failed: {str(e)}")

    pred_label = str(result["preds"][0])
    pred_enc = int(result["preds_enc"][0])
    probs = result["probs"][0] if result["probs"] else None

    explanation = None
    if request.explain and _explainer:
        try:
            explanation = _explainer.explain_instance_lime(
                _model,
                result["X"],
                result["X"][0],
                feature_names=_feature_names,
                class_names=_class_names,
            )
        except Exception as e:
            logger.warning(f"Explanation failed: {e}")

    return PredictionResponse(
        prediction=pred_label,
        prediction_encoded=pred_enc,
        probabilities=probs,
        explanation=explanation,
        model_name=_model_name,
    )


@app.post("/predict/batch", response_model=BatchPredictionResponse, tags=["Prediction"])
async def predict_batch(request: BatchPredictionRequest):
    """Batch prediction for multiple records."""
    _check_ready()
    if not request.records:
        raise HTTPException(status_code=422, detail="No records provided.")

    df = pd.DataFrame(request.records)
    try:
        result = _predict_df(df)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Batch prediction failed: {str(e)}")

    return BatchPredictionResponse(
        predictions=[str(p) for p in result["preds"]],
        probabilities=result["probs"],
        count=len(result["preds"]),
        model_name=_model_name,
    )


@app.get("/model/info", tags=["Model"])
async def model_info():
    """Return model metadata."""
    _check_ready()
    return {
        "model_name": _model_name,
        "model_type": type(_model).__name__,
        "classes": _class_names,
        "n_classes": len(_class_names),
        "features": _feature_names,
        "n_features": len(_feature_names),
        "has_predict_proba": hasattr(_model, "predict_proba"),
    }


@app.get("/model/classes", tags=["Model"])
async def get_classes():
    return {"classes": _class_names}


@app.post("/reload", tags=["Admin"])
async def reload_model():
    """Reload model artifacts from disk."""
    load_artifacts()
    return {"message": "Artifacts reloaded", "model_loaded": _model is not None}


if __name__ == "__main__":
    config = load_config("config/config.yaml")
    deploy_cfg = config.get("deployment", {}).get("api", {})
    uvicorn.run(
        "api.app:app",
        host=deploy_cfg.get("host", "0.0.0.0"),
        port=deploy_cfg.get("port", 8000),
        workers=1,
        reload=False,
    )
