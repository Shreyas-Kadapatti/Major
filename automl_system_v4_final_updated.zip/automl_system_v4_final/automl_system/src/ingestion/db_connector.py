"""
Database Connector Module
Supports loading datasets directly from SQL databases into a Pandas DataFrame.

Supported databases:
  - PostgreSQL  (via psycopg2 / sqlalchemy)
  - MySQL       (via pymysql / sqlalchemy)
  - SQLite      (built-in, no driver needed)
  - MSSQL       (via pyodbc / sqlalchemy)
  - Oracle       (via cx_Oracle / sqlalchemy)
  - Generic     (any SQLAlchemy connection string)

Usage:
    from src.ingestion.db_connector import DatabaseConnector

    conn = DatabaseConnector(db_type="postgresql",
                             host="localhost", port=5432,
                             database="mydb", username="user", password="pass")
    df = conn.query("SELECT * FROM customers LIMIT 10000")
"""
from typing import Any, Dict, Optional
from pathlib import Path

import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)

# ── SQLAlchemy availability check ─────────────────────────────────────────────
try:
    from sqlalchemy import create_engine, text
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False
    logger.warning("SQLAlchemy not installed. Database connections disabled. "
                   "Install with: pip install sqlalchemy")

# ── Driver availability map ───────────────────────────────────────────────────
DB_DRIVERS = {
    "postgresql": {"pkg": "psycopg2",  "install": "psycopg2-binary"},
    "mysql":      {"pkg": "pymysql",   "install": "pymysql"},
    "mssql":      {"pkg": "pyodbc",    "install": "pyodbc"},
    "oracle":     {"pkg": "cx_Oracle", "install": "cx_Oracle"},
    "sqlite":     {"pkg": None,        "install": None},   # built-in
    "generic":    {"pkg": None,        "install": None},
}


class DatabaseConnector:
    """
    Connects to a SQL database and loads query results into a Pandas DataFrame.

    Supports PostgreSQL, MySQL, SQLite, MSSQL, Oracle, or any SQLAlchemy URL.
    """

    def __init__(
        self,
        db_type: str = "sqlite",
        host: str = "localhost",
        port: Optional[int] = None,
        database: str = "",
        username: str = "",
        password: str = "",
        connection_string: Optional[str] = None,
        connect_args: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialise the connector.

        Args:
            db_type:           One of postgresql | mysql | sqlite | mssql | oracle | generic.
            host:              Database host.
            port:              Database port (optional — uses default if None).
            database:          Database name (or file path for SQLite).
            username:          Login username.
            password:          Login password.
            connection_string: Full SQLAlchemy URL — overrides all other params when provided.
            connect_args:      Extra kwargs passed to create_engine(connect_args=...).
        """
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError("SQLAlchemy is required. Install with: pip install sqlalchemy")

        self.db_type = db_type.lower()
        self.connection_string = connection_string or self._build_url(
            db_type, host, port, database, username, password
        )
        self.connect_args = connect_args or {}
        self.engine = None

    # ── URL builder ───────────────────────────────────────────────────────────
    def _build_url(
        self,
        db_type: str,
        host: str,
        port: Optional[int],
        database: str,
        username: str,
        password: str,
    ) -> str:
        """Construct a SQLAlchemy connection URL from parts."""
        db_type = db_type.lower()
        default_ports = {
            "postgresql": 5432,
            "mysql":      3306,
            "mssql":      1433,
            "oracle":     1521,
        }

        if db_type == "sqlite":
            # database = file path  (use :memory: for in-memory)
            db_path = database if database else ":memory:"
            return f"sqlite:///{db_path}"

        if db_type == "generic":
            return database  # treat database param as raw URL

        dialect_map = {
            "postgresql": "postgresql+psycopg2",
            "mysql":      "mysql+pymysql",
            "mssql":      "mssql+pyodbc",
            "oracle":     "oracle+cx_oracle",
        }
        dialect = dialect_map.get(db_type, db_type)
        effective_port = port or default_ports.get(db_type, "")
        port_str = f":{effective_port}" if effective_port else ""

        import urllib.parse
        safe_pw = urllib.parse.quote_plus(str(password))
        return f"{dialect}://{username}:{safe_pw}@{host}{port_str}/{database}"

    # ── Connection ────────────────────────────────────────────────────────────
    def connect(self) -> "DatabaseConnector":
        """Open SQLAlchemy engine (lazy — first call only)."""
        if self.engine is None:
            logger.info(f"Connecting to database [{self.db_type}]…")
            self.engine = create_engine(
                self.connection_string,
                connect_args=self.connect_args,
                pool_pre_ping=True,
            )
            # Test connection
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info("Database connection established.")
        return self

    def disconnect(self) -> None:
        """Dispose the connection pool."""
        if self.engine:
            self.engine.dispose()
            self.engine = None
            logger.info("Database connection closed.")

    # ── Query ─────────────────────────────────────────────────────────────────
    def query(
        self,
        sql: str,
        params: Optional[Dict[str, Any]] = None,
        chunksize: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Execute a SELECT query and return results as a DataFrame.

        Args:
            sql:       SQL query string (use :param_name for bound params).
            params:    Optional dict of bind parameters.
            chunksize: If set, returns an iterator of DataFrames (for large tables).

        Returns:
            pd.DataFrame with query results.
        """
        self.connect()
        logger.info(f"Executing query: {sql[:120]}{'…' if len(sql)>120 else ''}")

        try:
            with self.engine.connect() as conn:
                df = pd.read_sql(text(sql), conn, params=params)
            logger.info(f"Query returned {len(df):,} rows × {len(df.columns)} cols.")
            return df
        except Exception as e:
            logger.error(f"Query failed: {e}")
            raise

    def list_tables(self) -> list:
        """Return list of table names in the connected database."""
        self.connect()
        from sqlalchemy import inspect as sa_inspect
        inspector = sa_inspect(self.engine)
        tables = inspector.get_table_names()
        logger.info(f"Found {len(tables)} tables.")
        return tables

    def read_table(self, table_name: str, limit: Optional[int] = None) -> pd.DataFrame:
        """
        Read an entire table (with optional row limit).

        Args:
            table_name: Name of the table to read.
            limit:      Optional maximum number of rows.

        Returns:
            pd.DataFrame.
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        return self.query(f"SELECT * FROM {table_name}{limit_clause}")

    def table_schema(self, table_name: str) -> pd.DataFrame:
        """Return column names and types for a table as a DataFrame."""
        self.connect()
        from sqlalchemy import inspect as sa_inspect
        inspector = sa_inspect(self.engine)
        cols = inspector.get_columns(table_name)
        return pd.DataFrame([{"column": c["name"], "type": str(c["type"])} for c in cols])

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()

    def __repr__(self) -> str:
        masked = self.connection_string
        # Mask password in repr
        import re
        masked = re.sub(r":[^:@/]+@", ":***@", masked)
        return f"DatabaseConnector(url={masked})"


# ── Convenience factory ───────────────────────────────────────────────────────
def from_config(db_config: Dict[str, Any]) -> DatabaseConnector:
    """
    Build a DatabaseConnector from a config dict.

    Expected keys: db_type, host, port, database, username, password
    Optional key:  connection_string (overrides all others)
    """
    return DatabaseConnector(
        db_type=db_config.get("db_type", "sqlite"),
        host=db_config.get("host", "localhost"),
        port=db_config.get("port"),
        database=db_config.get("database", ""),
        username=db_config.get("username", ""),
        password=db_config.get("password", ""),
        connection_string=db_config.get("connection_string"),
    )
