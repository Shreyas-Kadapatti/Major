"""
Model Monitoring Module
Tracks prediction metrics, latency, and data quality in production.
"""
import json
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional

import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


class PredictionLog:
    """Stores a rolling window of prediction records."""

    def __init__(self, maxlen: int = 10000):
        self._records: Deque[Dict] = deque(maxlen=maxlen)

    def log(self, record: Dict) -> None:
        record["timestamp"] = datetime.utcnow().isoformat()
        self._records.append(record)

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(list(self._records))

    def __len__(self) -> int:
        return len(self._records)


class ModelMonitor:
    """
    Hooks into the prediction pipeline to monitor:
    - Prediction latency
    - Class distribution of predictions
    - Feature value ranges
    - Confidence score distribution
    - Optional: ground truth comparison
    """

    def __init__(self, model_name: str, log_dir: str = "logs/monitoring"):
        self.model_name = model_name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.prediction_log = PredictionLog(maxlen=10000)
        self._latency_buffer: List[float] = []

    def record_prediction(
        self,
        features: Dict[str, Any],
        prediction: str,
        probability: Optional[Dict[str, float]] = None,
        latency_ms: Optional[float] = None,
        ground_truth: Optional[str] = None,
    ) -> None:
        """
        Log a single prediction event.

        Args:
            features: Input feature dict.
            prediction: Predicted class label.
            probability: Class probability dict.
            latency_ms: Prediction latency in milliseconds.
            ground_truth: True label (if available for feedback loops).
        """
        record = {
            "model_name": self.model_name,
            "prediction": prediction,
            "confidence": max(probability.values()) if probability else None,
            "latency_ms": latency_ms,
            "correct": (str(prediction) == str(ground_truth)) if ground_truth else None,
        }

        if probability:
            for cls, prob in probability.items():
                record[f"prob_{cls}"] = prob

        self.prediction_log.log(record)

        if latency_ms is not None:
            self._latency_buffer.append(latency_ms)

    def get_stats(self) -> Dict:
        """
        Return current monitoring statistics.

        Returns:
            Dict with latency, prediction distribution, and confidence stats.
        """
        if len(self.prediction_log) == 0:
            return {"status": "no_data"}

        df = self.prediction_log.to_dataframe()
        stats: Dict[str, Any] = {
            "total_predictions": len(df),
            "model_name": self.model_name,
            "generated_at": datetime.utcnow().isoformat(),
        }

        # Prediction distribution
        if "prediction" in df.columns:
            dist = df["prediction"].value_counts(normalize=True).to_dict()
            stats["prediction_distribution"] = {str(k): round(v, 4) for k, v in dist.items()}

        # Confidence
        if "confidence" in df.columns and df["confidence"].notna().any():
            conf = df["confidence"].dropna()
            stats["confidence"] = {
                "mean": round(float(conf.mean()), 4),
                "min": round(float(conf.min()), 4),
                "max": round(float(conf.max()), 4),
                "p10": round(float(np.percentile(conf, 10)), 4),
                "p90": round(float(np.percentile(conf, 90)), 4),
            }
            low_conf_rate = float((conf < 0.6).mean())
            stats["low_confidence_rate"] = round(low_conf_rate, 4)
            if low_conf_rate > 0.2:
                logger.warning(f"High low-confidence rate: {low_conf_rate:.2%}")

        # Latency
        if self._latency_buffer:
            lat = np.array(self._latency_buffer)
            stats["latency_ms"] = {
                "mean": round(float(lat.mean()), 2),
                "p50": round(float(np.percentile(lat, 50)), 2),
                "p95": round(float(np.percentile(lat, 95)), 2),
                "p99": round(float(np.percentile(lat, 99)), 2),
                "max": round(float(lat.max()), 2),
            }

        # Accuracy (if ground truths available)
        if "correct" in df.columns and df["correct"].notna().any():
            stats["accuracy"] = round(float(df["correct"].mean()), 4)

        return stats

    def save_report(self, filename: Optional[str] = None) -> str:
        """Persist monitoring stats to JSON file."""
        stats = self.get_stats()
        fname = filename or f"monitor_{self.model_name}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        path = self.log_dir / fname
        with open(path, "w") as f:
            json.dump(stats, f, indent=2)
        logger.info(f"Monitoring report saved: {path}")
        return str(path)

    def save_predictions_csv(self, filename: Optional[str] = None) -> str:
        """Export full prediction log to CSV."""
        df = self.prediction_log.to_dataframe()
        fname = filename or f"predictions_{self.model_name}.csv"
        path = self.log_dir / fname
        df.to_csv(path, index=False)
        logger.info(f"Prediction log saved: {path}")
        return str(path)
