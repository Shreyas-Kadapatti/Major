"""
Data Drift Detection Module
Detects statistical drift between training and new inference data.
"""
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats

from src.utils.logger import get_logger

logger = get_logger(__name__)


class DriftDetector:
    """
    Detects feature-level and distribution-level data drift using
    statistical tests (KS test for numeric, Chi-square for categorical).
    """

    def __init__(self, significance_level: float = 0.05):
        self.significance_level = significance_level
        self.reference_stats: Dict = {}
        self.drift_report: Dict = {}

    def fit(self, df: pd.DataFrame) -> None:
        """
        Store reference dataset statistics.

        Args:
            df: Training/reference DataFrame.
        """
        self.reference_stats = {}
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                self.reference_stats[col] = {
                    "type": "numeric",
                    "values": df[col].dropna().values,
                    "mean": float(df[col].mean()),
                    "std": float(df[col].std()),
                    "min": float(df[col].min()),
                    "max": float(df[col].max()),
                }
            else:
                vc = df[col].value_counts(normalize=True)
                self.reference_stats[col] = {
                    "type": "categorical",
                    "distribution": vc.to_dict(),
                    "categories": set(df[col].dropna().unique()),
                }
        logger.info(f"Drift detector fitted on {len(df):,} samples, {len(df.columns)} features.")

    def detect(self, df_new: pd.DataFrame) -> Dict:
        """
        Compare new data against reference. Returns drift report.

        Args:
            df_new: New/production DataFrame.

        Returns:
            Dict with per-feature drift results and overall drift flag.
        """
        if not self.reference_stats:
            raise RuntimeError("Call fit() before detect().")

        report = {
            "overall_drift": False,
            "drifted_features": [],
            "features": {},
            "drift_score": 0.0,
        }
        n_drifted = 0

        for col in df_new.columns:
            if col not in self.reference_stats:
                continue

            ref = self.reference_stats[col]
            new_vals = df_new[col].dropna()

            if ref["type"] == "numeric":
                stat, p_value = stats.ks_2samp(ref["values"], new_vals.values)
                drifted = p_value < self.significance_level
                result = {
                    "type": "numeric",
                    "test": "KS",
                    "statistic": float(stat),
                    "p_value": float(p_value),
                    "drifted": drifted,
                    "new_mean": float(new_vals.mean()),
                    "ref_mean": ref["mean"],
                    "mean_shift": float(abs(new_vals.mean() - ref["mean"])),
                }
            else:
                new_cats = set(new_vals.unique())
                new_dist = new_vals.value_counts(normalize=True)
                ref_dist = pd.Series(ref["distribution"])

                all_cats = list(ref["categories"] | new_cats)
                ref_counts = [ref_dist.get(c, 1e-9) for c in all_cats]
                new_counts = [new_dist.get(c, 1e-9) for c in all_cats]

                chi2_stat, p_value = stats.chisquare(new_counts, f_exp=ref_counts)
                drifted = p_value < self.significance_level
                unseen = new_cats - ref["categories"]
                result = {
                    "type": "categorical",
                    "test": "Chi-square",
                    "statistic": float(chi2_stat),
                    "p_value": float(p_value),
                    "drifted": drifted,
                    "unseen_categories": list(unseen),
                }

            report["features"][col] = result
            if drifted:
                n_drifted += 1
                report["drifted_features"].append(col)

        total = len(report["features"])
        report["drift_score"] = round(n_drifted / total, 3) if total > 0 else 0.0
        report["overall_drift"] = report["drift_score"] > 0.3

        if report["overall_drift"]:
            logger.warning(
                f"DATA DRIFT DETECTED! {n_drifted}/{total} features drifted. "
                f"Score: {report['drift_score']:.2f}"
            )
        else:
            logger.info(
                f"No significant drift. {n_drifted}/{total} features drifted slightly. "
                f"Score: {report['drift_score']:.2f}"
            )

        self.drift_report = report
        return report

    def summary(self) -> pd.DataFrame:
        """Return drift report as a DataFrame."""
        if not self.drift_report:
            return pd.DataFrame()
        rows = []
        for feature, result in self.drift_report.get("features", {}).items():
            rows.append({
                "feature": feature,
                "type": result.get("type"),
                "test": result.get("test"),
                "p_value": result.get("p_value"),
                "drifted": result.get("drifted"),
                "statistic": result.get("statistic"),
            })
        return pd.DataFrame(rows).sort_values("p_value")
