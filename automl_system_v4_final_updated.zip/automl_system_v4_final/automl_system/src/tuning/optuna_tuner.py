"""
Hyperparameter Tuning Module — v2
Uses Optuna for Bayesian optimisation.
Stores FULL trial history (every trial's params + score) for the UI log viewer.
"""
import warnings
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import optuna
import pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_val_score

from src.models.registry import SEARCH_SPACES, get_model
from src.utils.logger import get_logger

optuna.logging.set_verbosity(optuna.logging.WARNING)
warnings.filterwarnings("ignore")

logger = get_logger(__name__)


def _suggest_params(trial: optuna.Trial, space: Dict) -> Dict:
    params = {}
    for param_name, spec in space.items():
        if spec[0] == "float":
            log = len(spec) > 3 and spec[3]
            params[param_name] = trial.suggest_float(param_name, spec[1], spec[2], log=log)
        elif spec[0] == "int":
            params[param_name] = trial.suggest_int(param_name, spec[1], spec[2])
        elif spec[0] == "categorical":
            params[param_name] = trial.suggest_categorical(param_name, spec[1])
    return params


class HyperparameterTuner:
    """
    Tunes hyperparameters for each model using Optuna.
    After tuning, `all_trials` contains the full history for every model.
    """

    def __init__(self, config: Dict):
        self.config = config
        tuning_cfg = config.get("tuning", {})
        self.n_trials = tuning_cfg.get("n_trials", 50)
        self.timeout = tuning_cfg.get("timeout", 300)
        self.metric = tuning_cfg.get("metric", "f1_weighted")
        self.cv_folds = config.get("models", {}).get("cross_validation_folds", 5)
        self.random_state = config.get("project", {}).get("random_state", 42)
        self.best_params: Dict[str, Dict] = {}
        # Full trial history: model_name → list of trial dicts
        self.all_trials: Dict[str, List[Dict]] = {}
        # Best trial info per model
        self.best_trial_info: Dict[str, Dict] = {}

    def _make_objective(self, model_name: str, X: np.ndarray, y: np.ndarray) -> Callable:
        space = SEARCH_SPACES.get(model_name, {})
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True,
                             random_state=self.random_state)

        def objective(trial: optuna.Trial) -> float:
            params = _suggest_params(trial, space)
            if model_name == "mlp" and "hidden_layer_sizes_n" in params:
                n = params.pop("hidden_layer_sizes_n")
                layers = params.pop("hidden_layer_sizes_layers")
                params["hidden_layer_sizes"] = tuple([n] * layers)

            model = get_model(model_name)
            try:
                model.set_params(**params)
            except Exception:
                return 0.0

            scores = cross_val_score(
                model, X, y, cv=cv, scoring=self.metric,
                n_jobs=-1, error_score=0.0,
            )
            return float(np.mean(scores))

        return objective

    def tune_model(self, model_name: str, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """
        Run Optuna study for a single model. Stores full trial log in self.all_trials.
        """
        if model_name not in SEARCH_SPACES:
            logger.warning(f"No search space for '{model_name}', skipping tuning.")
            return {}

        logger.info(f"Tuning {model_name} ({self.n_trials} trials, {self.timeout}s timeout)…")

        study = optuna.create_study(
            direction="maximize",
            sampler=optuna.samplers.TPESampler(seed=self.random_state),
            pruner=optuna.pruners.MedianPruner(n_startup_trials=5, n_warmup_steps=3),
        )

        study.optimize(
            self._make_objective(model_name, X, y),
            n_trials=self.n_trials,
            timeout=self.timeout,
            show_progress_bar=False,
        )

        # ── Collect full trial history ────────────────────────────────────────
        trials_data = []
        for t in study.trials:
            row = {
                "trial":    t.number,
                "score":    round(t.value, 6) if t.value is not None else None,
                "state":    t.state.name,
                "duration_s": round(t.duration.total_seconds(), 2) if t.duration else None,
                "is_best":  (t.number == study.best_trial.number),
            }
            # flatten params
            p = dict(t.params)
            if model_name == "mlp" and "hidden_layer_sizes_n" in p:
                n_units = p.pop("hidden_layer_sizes_n")
                n_layers = p.pop("hidden_layer_sizes_layers")
                p["hidden_layer_sizes"] = str(tuple([n_units] * n_layers))
            row.update({f"param_{k}": v for k, v in p.items()})
            trials_data.append(row)
        self.all_trials[model_name] = trials_data

        # ── Best params ───────────────────────────────────────────────────────
        best = study.best_params.copy()
        if model_name == "mlp" and "hidden_layer_sizes_n" in best:
            n = best.pop("hidden_layer_sizes_n")
            layers = best.pop("hidden_layer_sizes_layers")
            best["hidden_layer_sizes"] = tuple([n] * layers)

        self.best_trial_info[model_name] = {
            "trial_number": study.best_trial.number,
            "score":        round(study.best_value, 6),
            "metric":       self.metric,
            "params":       best,
            "n_trials_run": len(study.trials),
            "n_trials_completed": sum(1 for t in study.trials if t.state.name == "COMPLETE"),
        }

        logger.info(
            f"  Best trial #{study.best_trial.number}  "
            f"{self.metric}={study.best_value:.4f}  params={best}"
        )
        self.best_params[model_name] = best
        return best

    def tune_all(self, X: np.ndarray, y: np.ndarray,
                 model_names: Optional[List[str]] = None) -> Dict[str, Dict]:
        model_names = model_names or list(SEARCH_SPACES.keys())
        for name in model_names:
            try:
                self.tune_model(name, X, y)
            except Exception as e:
                logger.error(f"Tuning failed for {name}: {e}")
                self.best_params[name] = {}
        return self.best_params

    def trials_dataframe(self, model_name: str) -> pd.DataFrame:
        """Return all trials for a model as a tidy DataFrame."""
        rows = self.all_trials.get(model_name, [])
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows)

    def summary_dataframe(self) -> pd.DataFrame:
        """Return one-row-per-model summary of best trial."""
        rows = []
        for model, info in self.best_trial_info.items():
            row = {
                "model":          model,
                "best_trial":     info["trial_number"],
                "best_score":     info["score"],
                "metric":         info["metric"],
                "n_trials_run":   info["n_trials_run"],
                "n_completed":    info["n_trials_completed"],
            }
            for k, v in info["params"].items():
                row[f"param_{k}"] = v
            rows.append(row)
        return pd.DataFrame(rows)
