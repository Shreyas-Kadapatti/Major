"""
Explainability Module
SHAP global/local explanations, feature importance, and optional LIME.
"""
from pathlib import Path
from typing import Any, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    logger.warning("SHAP not available.")

try:
    from lime.lime_tabular import LimeTabularExplainer
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False
    logger.warning("LIME not available.")


class ExplainabilityEngine:
    """
    Provides SHAP (global + local) and LIME explanations for trained models.
    """

    def __init__(self, config: Dict):
        self.config = config
        exp_cfg = config.get("explainability", {})
        self.shap_enabled = exp_cfg.get("shap_enabled", True) and SHAP_AVAILABLE
        self.lime_enabled = exp_cfg.get("lime_enabled", True) and LIME_AVAILABLE
        self.max_features = exp_cfg.get("max_display_features", 20)
        self.num_lime_samples = exp_cfg.get("num_lime_samples", 1000)
        self.shap_values = None
        self.explainer = None

    def _get_shap_explainer(self, model: Any, X: np.ndarray):
        """Get appropriate SHAP explainer based on model type."""
        model_type = type(model).__name__.lower()
        try:
            if any(t in model_type for t in ["xgb", "lgbm", "catboost", "randomforest", "decisiontree"]):
                return shap.TreeExplainer(model)
            elif "linear" in model_type or "logistic" in model_type:
                return shap.LinearExplainer(model, X)
            else:
                return shap.KernelExplainer(
                    model.predict_proba if hasattr(model, "predict_proba") else model.predict,
                    shap.sample(X, min(100, len(X)))
                )
        except Exception:
            return shap.KernelExplainer(
                model.predict_proba if hasattr(model, "predict_proba") else model.predict,
                shap.sample(X, min(50, len(X)))
            )

    def compute_shap(
        self,
        model: Any,
        X: np.ndarray,
        feature_names: Optional[List[str]] = None,
        max_samples: int = 200,
    ) -> Optional[np.ndarray]:
        """
        Compute SHAP values for global explanation.

        Args:
            model: Fitted model.
            X: Feature array.
            feature_names: Feature names.
            max_samples: Max samples for KernelExplainer.

        Returns:
            SHAP values array or None.
        """
        if not self.shap_enabled:
            return None

        try:
            sample = X[:min(max_samples, len(X))]
            self.explainer = self._get_shap_explainer(model, sample)
            shap_vals = self.explainer.shap_values(sample)

            # For multiclass, take absolute mean
            if isinstance(shap_vals, list):
                shap_vals = np.mean([np.abs(sv) for sv in shap_vals], axis=0)

            self.shap_values = shap_vals
            logger.info(f"SHAP values computed. Shape: {np.array(shap_vals).shape}")
            return shap_vals
        except Exception as e:
            logger.error(f"SHAP computation failed: {e}")
            return None

    def get_feature_importance(
        self,
        model: Any,
        feature_names: Optional[List[str]] = None,
        X: Optional[np.ndarray] = None,
    ) -> pd.DataFrame:
        """
        Extract feature importance from model or SHAP values.

        Returns DataFrame with feature, importance columns sorted descending.
        """
        importance = None
        names = feature_names or [f"feature_{i}" for i in range(100)]

        # Try native feature importance first
        if hasattr(model, "feature_importances_"):
            importance = model.feature_importances_
        elif hasattr(model, "coef_"):
            coef = model.coef_
            importance = np.abs(coef).mean(axis=0) if coef.ndim > 1 else np.abs(coef.flatten())

        # Fall back to SHAP
        if importance is None and self.shap_values is not None:
            importance = np.abs(self.shap_values).mean(axis=0)

        if importance is None:
            logger.warning("Could not extract feature importance.")
            return pd.DataFrame(columns=["feature", "importance"])

        n = min(len(importance), len(names))
        df = pd.DataFrame({
            "feature": names[:n],
            "importance": importance[:n],
        }).sort_values("importance", ascending=False).head(self.max_features)

        return df

    def shap_summary_figure(
        self,
        model: Any,
        X: np.ndarray,
        feature_names: Optional[List[str]] = None,
    ) -> Optional[plt.Figure]:
        """Generate SHAP summary bar plot figure."""
        if not self.shap_enabled:
            return None
        shap_vals = self.compute_shap(model, X, feature_names)
        if shap_vals is None:
            return None
        try:
            sample = X[:min(200, len(X))]
            fig, ax = plt.subplots(figsize=(10, 6))
            shap.summary_plot(
                shap_vals[:len(sample)],
                sample,
                feature_names=feature_names,
                plot_type="bar",
                max_display=self.max_features,
                show=False,
            )
            plt.tight_layout()
            return plt.gcf()
        except Exception as e:
            logger.error(f"SHAP summary plot failed: {e}")
            plt.close()
            return None

    def explain_instance_lime(
        self,
        model: Any,
        X_train: np.ndarray,
        instance: np.ndarray,
        feature_names: Optional[List[str]] = None,
        class_names: Optional[List[str]] = None,
    ) -> Optional[Dict]:
        """
        LIME explanation for a single prediction.

        Returns dict with feature contributions.
        """
        if not self.lime_enabled:
            return None
        try:
            explainer = LimeTabularExplainer(
                X_train,
                feature_names=feature_names,
                class_names=class_names,
                discretize_continuous=True,
                random_state=42,
            )
            exp = explainer.explain_instance(
                instance.flatten(),
                model.predict_proba,
                num_features=self.max_features,
                num_samples=self.num_lime_samples,
            )
            return dict(exp.as_list())
        except Exception as e:
            logger.error(f"LIME explanation failed: {e}")
            return None
