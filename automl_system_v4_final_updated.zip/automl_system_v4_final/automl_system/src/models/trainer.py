"""
Model Trainer Module
Trains multiple classifiers with cross-validation.
"""
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from sklearn.model_selection import StratifiedKFold, cross_validate

from src.models.registry import MODEL_REGISTRY, get_model
from src.utils.logger import get_logger

logger = get_logger(__name__)


class ModelTrainer:
    """
    Trains multiple classifiers and collects cross-validation metrics.
    """

    def __init__(self, config: Dict):
        self.config = config
        self.cv_folds = config.get("models", {}).get("cross_validation_folds", 5)
        self.random_state = config.get("project", {}).get("random_state", 42)
        self.trained_models: Dict[str, Any] = {}
        self.cv_results: Dict[str, Dict] = {}

    def train_single(
        self,
        model_name: str,
        X: np.ndarray,
        y: np.ndarray,
        params: Optional[Dict] = None,
    ) -> Tuple[Any, Dict]:
        """
        Train a single model with cross-validation.

        Args:
            model_name: Model key name.
            X: Feature array.
            y: Target array.
            params: Optional hyperparameters to set.

        Returns:
            Tuple of (fitted_model, cv_metrics_dict).
        """
        model = get_model(model_name)
        if params:
            model.set_params(**params)

        logger.info(f"Training {model_name}...")
        start = time.time()

        scoring = ["accuracy", "f1_weighted", "precision_weighted", "recall_weighted"]
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)

        cv_scores = cross_validate(
            model, X, y,
            cv=cv,
            scoring=scoring,
            return_train_score=False,
            n_jobs=-1,
        )

        metrics = {
            "accuracy": float(np.mean(cv_scores["test_accuracy"])),
            "accuracy_std": float(np.std(cv_scores["test_accuracy"])),
            "f1_weighted": float(np.mean(cv_scores["test_f1_weighted"])),
            "precision_weighted": float(np.mean(cv_scores["test_precision_weighted"])),
            "recall_weighted": float(np.mean(cv_scores["test_recall_weighted"])),
            "train_time_sec": round(time.time() - start, 2),
        }

        # Refit on full data
        model.fit(X, y)
        elapsed = round(time.time() - start, 2)
        metrics["total_time_sec"] = elapsed

        logger.info(f"  {model_name}: Acc={metrics['accuracy']:.4f}, F1={metrics['f1_weighted']:.4f}, Time={elapsed}s")
        return model, metrics

    def train_all(
        self,
        X: np.ndarray,
        y: np.ndarray,
        model_names: Optional[List[str]] = None,
        tuned_params: Optional[Dict[str, Dict]] = None,
    ) -> Dict[str, Any]:
        """
        Train all specified models.

        Args:
            X: Feature array.
            y: Target array.
            model_names: List of model names to train. Defaults to all available.
            tuned_params: Dict of model_name → best hyperparameters.

        Returns:
            Dictionary of model_name → fitted model.
        """
        if model_names is None:
            model_names = list(MODEL_REGISTRY.keys())

        tuned_params = tuned_params or {}

        for name in model_names:
            if name not in MODEL_REGISTRY:
                logger.warning(f"Model '{name}' not in registry, skipping.")
                continue
            try:
                model, metrics = self.train_single(
                    name, X, y,
                    params=tuned_params.get(name),
                )
                self.trained_models[name] = model
                self.cv_results[name] = metrics
            except Exception as e:
                logger.error(f"Failed to train {name}: {e}")

        logger.info(f"Training complete. {len(self.trained_models)} models trained.")
        return self.trained_models

    def get_leaderboard(self) -> List[Dict]:
        """
        Return sorted leaderboard by F1 score.

        Returns:
            List of dicts with model name and metrics, sorted descending by F1.
        """
        rows = []
        for name, metrics in self.cv_results.items():
            rows.append({"model": name, **metrics})
        return sorted(rows, key=lambda x: x.get("f1_weighted", 0), reverse=True)
