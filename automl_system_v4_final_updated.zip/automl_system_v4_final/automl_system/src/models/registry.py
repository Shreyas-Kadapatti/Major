"""
Model Registry — 12 Classification Models
Provides a unified interface for all supported classifiers.

Models:
  1.  logistic_regression    — sklearn
  2.  decision_tree          — sklearn
  3.  random_forest          — sklearn
  4.  extra_trees            — sklearn (NEW)
  5.  gradient_boosting      — sklearn (NEW)
  6.  knn                    — sklearn (NEW)
  7.  naive_bayes            — sklearn (NEW)
  8.  svm                    — sklearn
  9.  mlp                    — sklearn
  10. xgboost                — xgboost
  11. lightgbm               — lightgbm
  12. catboost               — catboost
"""
from typing import Any, Dict, List

from sklearn.ensemble import (
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
)
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from src.utils.logger import get_logger

logger = get_logger(__name__)

# ── Optional heavy boosting libs ──────────────────────────────────────────────
try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    logger.warning("XGBoost not installed — model skipped.")

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False
    logger.warning("LightGBM not installed — model skipped.")

try:
    from catboost import CatBoostClassifier
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False
    logger.warning("CatBoost not installed — model skipped.")

# ── Core registry (always available) ─────────────────────────────────────────
MODEL_REGISTRY: Dict[str, Any] = {
    # 1. Logistic Regression
    "logistic_regression": LogisticRegression(max_iter=1000, random_state=42),
    # 2. Decision Tree
    "decision_tree": DecisionTreeClassifier(random_state=42),
    # 3. Random Forest
    "random_forest": RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    # 4. Extra Trees  ← NEW
    "extra_trees": ExtraTreesClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    # 5. Gradient Boosting (sklearn)  ← NEW
    "gradient_boosting": GradientBoostingClassifier(n_estimators=100, random_state=42),
    # 6. K-Nearest Neighbours  ← NEW
    "knn": KNeighborsClassifier(n_neighbors=5, n_jobs=-1),
    # 7. Gaussian Naive Bayes  ← NEW
    "naive_bayes": GaussianNB(),
    # 8. SVM
    "svm": SVC(probability=True, random_state=42),
    # 9. MLP Neural Network
    "mlp": MLPClassifier(max_iter=500, random_state=42),
}

# ── Optional boosting models ──────────────────────────────────────────────────
if XGBOOST_AVAILABLE:   # 10
    MODEL_REGISTRY["xgboost"] = XGBClassifier(
        eval_metric="logloss", random_state=42, n_jobs=-1, verbosity=0
    )

if LIGHTGBM_AVAILABLE:  # 11
    MODEL_REGISTRY["lightgbm"] = LGBMClassifier(
        random_state=42, n_jobs=-1, verbose=-1
    )

if CATBOOST_AVAILABLE:  # 12
    MODEL_REGISTRY["catboost"] = CatBoostClassifier(random_state=42, verbose=0)


# ── Public helpers ────────────────────────────────────────────────────────────
def get_model(name: str):
    """
    Retrieve a fresh model instance by name.

    Args:
        name: Model key from MODEL_REGISTRY.

    Returns:
        Sklearn-compatible estimator (cloned to avoid state leakage).
    """
    from sklearn.base import clone
    if name not in MODEL_REGISTRY:
        raise ValueError(
            f"Model '{name}' not found. Available: {list(MODEL_REGISTRY.keys())}"
        )
    return clone(MODEL_REGISTRY[name])


def get_available_models() -> List[str]:
    """Return list of all registered model names."""
    return list(MODEL_REGISTRY.keys())


# ── Optuna hyperparameter search spaces ──────────────────────────────────────
# Format per param:
#   ("float",  low, high, log?)
#   ("int",    low, high)
#   ("categorical", [choices])
SEARCH_SPACES: Dict[str, Any] = {
    "logistic_regression": {
        "C":        ("float", 1e-3, 10.0, True),
        "solver":   ("categorical", ["lbfgs", "saga"]),
        "max_iter": ("int", 200, 2000),
    },
    "decision_tree": {
        "max_depth":        ("int", 2, 30),
        "min_samples_split":("int", 2, 20),
        "min_samples_leaf": ("int", 1, 10),
        "criterion":        ("categorical", ["gini", "entropy"]),
    },
    "random_forest": {
        "n_estimators":      ("int", 50, 500),
        "max_depth":         ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf":  ("int", 1, 10),
        "max_features":      ("categorical", ["sqrt", "log2"]),
    },
    "extra_trees": {
        "n_estimators":      ("int", 50, 500),
        "max_depth":         ("int", 2, 30),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf":  ("int", 1, 10),
        "max_features":      ("categorical", ["sqrt", "log2"]),
    },
    "gradient_boosting": {
        "n_estimators":   ("int", 50, 300),
        "max_depth":      ("int", 2, 8),
        "learning_rate":  ("float", 1e-3, 0.3, True),
        "subsample":      ("float", 0.5, 1.0, False),
        "min_samples_leaf":("int", 1, 10),
    },
    "knn": {
        "n_neighbors": ("int", 1, 30),
        "weights":     ("categorical", ["uniform", "distance"]),
        "metric":      ("categorical", ["euclidean", "manhattan", "minkowski"]),
        "p":           ("int", 1, 3),
    },
    "naive_bayes": {
        "var_smoothing": ("float", 1e-12, 1e-6, True),
    },
    "svm": {
        "C":      ("float", 1e-2, 100.0, True),
        "kernel": ("categorical", ["rbf", "poly", "sigmoid"]),
        "gamma":  ("categorical", ["scale", "auto"]),
    },
    "mlp": {
        "hidden_layer_sizes_n":      ("int", 50, 256),
        "hidden_layer_sizes_layers": ("int", 1, 3),
        "activation":    ("categorical", ["relu", "tanh"]),
        "alpha":         ("float", 1e-5, 1e-1, True),
        "learning_rate": ("categorical", ["constant", "adaptive"]),
    },
    "xgboost": {
        "n_estimators":     ("int", 50, 500),
        "max_depth":        ("int", 2, 10),
        "learning_rate":    ("float", 1e-3, 0.3, True),
        "subsample":        ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "gamma":            ("float", 0.0, 5.0, False),
        "reg_alpha":        ("float", 1e-3, 10.0, True),
        "reg_lambda":       ("float", 1e-3, 10.0, True),
    },
    "lightgbm": {
        "n_estimators":     ("int", 50, 500),
        "max_depth":        ("int", 2, 30),
        "learning_rate":    ("float", 1e-3, 0.3, True),
        "num_leaves":       ("int", 20, 150),
        "subsample":        ("float", 0.5, 1.0, False),
        "colsample_bytree": ("float", 0.5, 1.0, False),
        "reg_alpha":        ("float", 1e-3, 10.0, True),
        "reg_lambda":       ("float", 1e-3, 10.0, True),
    },
    "catboost": {
        "iterations":     ("int", 50, 500),
        "depth":          ("int", 2, 10),
        "learning_rate":  ("float", 1e-3, 0.3, True),
        "l2_leaf_reg":    ("float", 1e-3, 10.0, True),
    },
}

# ── Model metadata (for UI display) ──────────────────────────────────────────
MODEL_DESCRIPTIONS: Dict[str, str] = {
    "logistic_regression": "Linear model, fast baseline, interpretable coefficients.",
    "decision_tree":       "Single tree, fully interpretable, prone to overfitting.",
    "random_forest":       "Ensemble of trees, robust, great general-purpose model.",
    "extra_trees":         "Like Random Forest but with extra randomness — often faster.",
    "gradient_boosting":   "Sequential boosting (sklearn), strong on tabular data.",
    "knn":                 "Instance-based learner, no training phase, distance-based.",
    "naive_bayes":         "Probabilistic, very fast, assumes feature independence.",
    "svm":                 "Support vectors, works well in high-dimensional spaces.",
    "mlp":                 "Multi-layer perceptron neural network, flexible non-linear.",
    "xgboost":             "Extreme Gradient Boosting, top competition model.",
    "lightgbm":            "Light GBM, leaf-wise trees, very fast on large datasets.",
    "catboost":            "CatBoost, handles categoricals natively, minimal tuning.",
}
