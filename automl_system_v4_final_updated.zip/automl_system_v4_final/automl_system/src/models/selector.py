"""
Model Selection Module
Selects best model and persists it for deployment.
"""
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


class ModelSelector:
    """
    Selects the best trained model based on evaluation metrics.
    """

    def __init__(self, config: Dict):
        self.config = config
        self.metric = config.get("tuning", {}).get("metric", "f1_weighted")
        self.best_model_name: Optional[str] = None
        self.best_model: Optional[Any] = None

    def select(
        self,
        models: Dict[str, Any],
        leaderboard: pd.DataFrame,
    ) -> Tuple[str, Any]:
        """
        Select best model from leaderboard.

        Args:
            models: Dict of model_name → fitted model.
            leaderboard: DataFrame with model metrics.

        Returns:
            Tuple of (best_model_name, best_model).
        """
        if leaderboard.empty or not models:
            raise ValueError("No models available for selection.")

        metric_col = self.metric if self.metric in leaderboard.columns else "f1_weighted"
        if metric_col not in leaderboard.columns:
            metric_col = leaderboard.columns[1]  # fallback to first metric column

        best_row = leaderboard.sort_values(metric_col, ascending=False).iloc[0]
        self.best_model_name = best_row["model"]

        if self.best_model_name not in models:
            raise KeyError(f"Best model '{self.best_model_name}' not in trained models dict.")

        self.best_model = models[self.best_model_name]
        logger.info(
            f"Best model: {self.best_model_name} "
            f"({metric_col}={best_row[metric_col]:.4f})"
        )
        return self.best_model_name, self.best_model

    def save(self, path: str = "models/best_model.pkl") -> None:
        """Save best model to disk."""
        if self.best_model is None:
            raise RuntimeError("No best model selected. Call select() first.")

        save_path = Path(path)
        save_path.parent.mkdir(parents=True, exist_ok=True)

        with open(save_path, "wb") as f:
            pickle.dump({
                "model": self.best_model,
                "model_name": self.best_model_name,
            }, f)

        logger.info(f"Best model saved to {save_path}")

    @staticmethod
    def load(path: str = "models/best_model.pkl") -> Tuple[str, Any]:
        """Load best model from disk."""
        with open(path, "rb") as f:
            data = pickle.load(f)
        logger.info(f"Loaded model: {data['model_name']} from {path}")
        return data["model_name"], data["model"]
