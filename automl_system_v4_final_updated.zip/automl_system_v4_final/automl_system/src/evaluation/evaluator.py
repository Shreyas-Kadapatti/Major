"""
Evaluation Module
Computes classification metrics, confusion matrix, ROC curves.
"""
from typing import Any, Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    auc,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize

from src.utils.logger import get_logger

logger = get_logger(__name__)


class ModelEvaluator:
    """
    Computes evaluation metrics and generates visualization artifacts.
    """

    def __init__(self, config: Dict):
        self.config = config
        self.test_size = config.get("data", {}).get("test_size", 0.2)
        self.random_state = config.get("project", {}).get("random_state", 42)
        self.threshold = config.get("evaluation", {}).get("threshold", 0.5)

    def split_data(
        self, X: np.ndarray, y: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Split into train/test sets."""
        return train_test_split(X, y, test_size=self.test_size, random_state=self.random_state, stratify=y)

    def evaluate(self, model: Any, X_test: np.ndarray, y_test: np.ndarray) -> Dict:
        """
        Compute full set of classification metrics.

        Args:
            model: Fitted classifier.
            X_test: Test features.
            y_test: True labels.

        Returns:
            Dictionary of metric names → values.
        """
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test) if hasattr(model, "predict_proba") else None

        metrics = {
            "accuracy": float(accuracy_score(y_test, y_pred)),
            "f1_weighted": float(f1_score(y_test, y_pred, average="weighted", zero_division=0)),
            "precision_weighted": float(precision_score(y_test, y_pred, average="weighted", zero_division=0)),
            "recall_weighted": float(recall_score(y_test, y_pred, average="weighted", zero_division=0)),
        }

        if y_prob is not None:
            n_classes = len(np.unique(y_test))
            try:
                if n_classes == 2:
                    metrics["roc_auc"] = float(roc_auc_score(y_test, y_prob[:, 1]))
                else:
                    metrics["roc_auc"] = float(
                        roc_auc_score(y_test, y_prob, multi_class="ovr", average="weighted")
                    )
            except Exception:
                metrics["roc_auc"] = 0.0

        return metrics

    def confusion_matrix_data(
        self, model: Any, X_test: np.ndarray, y_test: np.ndarray, class_names: Optional[List[str]] = None
    ) -> Dict:
        """Return confusion matrix as dict with labels."""
        y_pred = model.predict(X_test)
        cm = confusion_matrix(y_test, y_pred)
        return {
            "matrix": cm.tolist(),
            "labels": class_names or [str(i) for i in range(cm.shape[0])],
        }

    def roc_curve_data(
        self, model: Any, X_test: np.ndarray, y_test: np.ndarray
    ) -> Optional[Dict]:
        """Compute ROC curve data for binary or multiclass."""
        if not hasattr(model, "predict_proba"):
            return None

        y_prob = model.predict_proba(X_test)
        n_classes = y_prob.shape[1]
        classes = np.unique(y_test)

        roc_data = {}
        if n_classes == 2:
            fpr, tpr, _ = roc_curve(y_test, y_prob[:, 1])
            roc_auc = auc(fpr, tpr)
            roc_data["binary"] = {"fpr": fpr.tolist(), "tpr": tpr.tolist(), "auc": roc_auc}
        else:
            y_bin = label_binarize(y_test, classes=classes)
            for i, cls in enumerate(classes):
                fpr, tpr, _ = roc_curve(y_bin[:, i], y_prob[:, i])
                roc_auc = auc(fpr, tpr)
                roc_data[str(cls)] = {"fpr": fpr.tolist(), "tpr": tpr.tolist(), "auc": roc_auc}

        return roc_data

    def compare_models(
        self,
        models: Dict[str, Any],
        X_test: np.ndarray,
        y_test: np.ndarray,
    ) -> pd.DataFrame:
        """
        Evaluate multiple models and return comparison DataFrame.

        Args:
            models: Dict of model_name → fitted model.
            X_test: Test features.
            y_test: True labels.

        Returns:
            Comparison DataFrame sorted by F1.
        """
        rows = []
        for name, model in models.items():
            metrics = self.evaluate(model, X_test, y_test)
            rows.append({"model": name, **metrics})

        df = pd.DataFrame(rows).sort_values("f1_weighted", ascending=False)
        logger.info(f"Model comparison:\n{df.to_string(index=False)}")
        return df

    def classification_report_text(
        self, model: Any, X_test: np.ndarray, y_test: np.ndarray,
        class_names: Optional[List[str]] = None
    ) -> str:
        """Return sklearn classification report as string."""
        y_pred = model.predict(X_test)
        return classification_report(y_test, y_pred, target_names=class_names, zero_division=0)
