"""
Artifact Exporter
Handles serialisation of the champion model with metadata (joblib),
and generation of the downloadable Performance Report (HTML).
"""
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import joblib
import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


# ── Model Artifact (joblib + metadata) ───────────────────────────────────────

def save_model_artifact(
    model: Any,
    preprocessor: Any,
    model_name: str,
    metadata: Dict,
    path: str = "models/champion_artifact.joblib",
) -> str:
    """
    Serialise champion model + preprocessor + metadata as a single joblib artifact.

    The bundle contains:
      - model:          fitted sklearn estimator
      - preprocessor:   fitted PreprocessingPipeline
      - model_name:     string identifier
      - metadata:       dict with metrics, params, feature names, class names,
                        dataset info, generated_at, version
    """
    bundle = {
        "model":          model,
        "preprocessor":   preprocessor,
        "model_name":     model_name,
        "metadata":       {
            **metadata,
            "generated_at": datetime.now().isoformat(),
            "artifact_version": "1.0",
            "serializer": "joblib",
        },
    }
    save_path = Path(path)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, save_path, compress=3)
    logger.info(f"Champion artifact saved → {save_path}  "
                f"({save_path.stat().st_size / 1024:.1f} KB)")
    return str(save_path)


def load_model_artifact(path: str) -> Dict:
    """Load and return the full artifact bundle."""
    bundle = joblib.load(path)
    logger.info(f"Artifact loaded: {bundle.get('model_name','unknown')}")
    return bundle


# ── Performance Report (HTML) ─────────────────────────────────────────────────

def build_performance_report(
    model_name: str,
    leaderboard_df: pd.DataFrame,
    train_metrics: Dict[str, float],
    val_metrics:   Dict[str, float],
    test_metrics:  Dict[str, float],
    best_params:   Dict[str, Any],
    class_names:   List[str],
    calibration_data: Optional[Dict] = None,
    generated_at: Optional[str] = None,
) -> str:
    """
    Build a full HTML Performance Report.

    Sections:
      1. Executive summary card
      2. Train / Val / Test metrics table
      3. Best hyperparameters
      4. All-model leaderboard
      5. Calibration curve (if provided)
    """
    generated_at = generated_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def metric_rows(md: Dict) -> str:
        if not md:
            return "<tr><td colspan='2'><em>Not available</em></td></tr>"
        return "\n".join(
            f"<tr><td>{k.replace('_',' ').title()}</td><td><strong>{v:.4f}</strong></td></tr>"
            for k, v in md.items() if isinstance(v, (int, float))
        )

    def param_rows(pd_: Dict) -> str:
        if not pd_:
            return "<tr><td colspan='2'><em>Default (no tuning)</em></td></tr>"
        return "\n".join(
            f"<tr><td><code>{k}</code></td><td><code>{v}</code></td></tr>"
            for k, v in pd_.items()
        )

    leaderboard_html = ""
    if leaderboard_df is not None and not leaderboard_df.empty:
        num_cols = [c for c in leaderboard_df.columns
                    if c != "model" and pd.api.types.is_numeric_dtype(leaderboard_df[c])]
        header = "<tr>" + "".join(
            f"<th>{'Model' if c=='model' else c.replace('_',' ').title()}</th>"
            for c in leaderboard_df.columns
        ) + "</tr>"
        rows_html = ""
        for _, row in leaderboard_df.iterrows():
            is_champ = row["model"] == model_name
            style = ' style="background:#f0fff4;font-weight:600;"' if is_champ else ""
            cells = ""
            for c in leaderboard_df.columns:
                val = row[c]
                fmt = f"{val:.4f}" if c in num_cols and isinstance(val, float) else str(val)
                cells += f"<td>{fmt}{'  🏆' if c=='model' and is_champ else ''}</td>"
            rows_html += f"<tr{style}>{cells}</tr>"
        leaderboard_html = f"""
        <h2>4. Model Leaderboard</h2>
        <table><thead>{header}</thead><tbody>{rows_html}</tbody></table>"""

    # Best test metric for summary card
    best_metric_val = test_metrics.get("f1_weighted", test_metrics.get("accuracy", 0))
    best_metric_name = "F1 (weighted)" if "f1_weighted" in test_metrics else "Accuracy"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Performance Report — {model_name}</title>
<style>
  *{{box-sizing:border-box;}}
  body{{font-family:'Segoe UI',sans-serif;background:#f0f4f8;color:#1a202c;margin:0;padding:32px;}}
  .container{{max-width:1100px;margin:0 auto;}}
  .header{{background:linear-gradient(135deg,#1a365d,#2c5282);color:#fff;
    border-radius:12px;padding:32px;margin-bottom:28px;}}
  .header h1{{margin:0;font-size:1.8rem;}}
  .header .sub{{opacity:.8;margin-top:6px;font-size:.95rem;}}
  .card-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:28px;}}
  .card{{background:#fff;border-radius:10px;padding:20px;text-align:center;
    box-shadow:0 2px 8px rgba(0,0,0,.08);border-top:4px solid #3182ce;}}
  .card .val{{font-size:2rem;font-weight:700;color:#3182ce;font-family:monospace;}}
  .card .lbl{{font-size:.78rem;text-transform:uppercase;color:#718096;letter-spacing:.06em;margin-top:4px;}}
  .section{{background:#fff;border-radius:10px;padding:24px;margin-bottom:20px;
    box-shadow:0 2px 8px rgba(0,0,0,.06);}}
  .section h2{{color:#2c5282;border-left:4px solid #63b3ed;padding-left:12px;margin-top:0;}}
  .metric-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;}}
  .metric-box{{background:#f7fafc;border-radius:8px;padding:16px;}}
  .metric-box h3{{margin:0 0 12px;color:#4a5568;font-size:.9rem;text-transform:uppercase;
    letter-spacing:.05em;}}
  table{{width:100%;border-collapse:collapse;}}
  th{{background:#ebf8ff;color:#2c5282;text-align:left;padding:10px 12px;
    font-size:.85rem;text-transform:uppercase;letter-spacing:.04em;}}
  td{{padding:10px 12px;border-bottom:1px solid #e2e8f0;font-size:.9rem;}}
  tr:hover td{{background:#f7fafc;}}
  code{{background:#edf2f7;padding:2px 6px;border-radius:4px;
    font-family:monospace;font-size:.82rem;color:#c53030;}}
  .champion{{background:#f0fff4!important;font-weight:600;}}
  .footer{{text-align:center;color:#a0aec0;font-size:.78rem;margin-top:32px;}}
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <h1>📊 Performance Report — {model_name.replace('_',' ').title()}</h1>
    <div class="sub">Generated by AutoML Studio · {generated_at} · Classes: {', '.join(class_names)}</div>
  </div>

  <div class="card-grid">
    <div class="card">
      <div class="val">{best_metric_val:.4f}</div>
      <div class="lbl">{best_metric_name} (Test)</div>
    </div>
    <div class="card">
      <div class="val">{test_metrics.get('accuracy', 0):.4f}</div>
      <div class="lbl">Accuracy (Test)</div>
    </div>
    <div class="card">
      <div class="val">{test_metrics.get('roc_auc', test_metrics.get('roc_auc_ovr', 0)):.4f}</div>
      <div class="lbl">ROC-AUC (Test)</div>
    </div>
  </div>

  <div class="section">
    <h2>1. Champion Model</h2>
    <table>
      <tr><th>Property</th><th>Value</th></tr>
      <tr><td>Model Name</td><td><strong>{model_name}</strong></td></tr>
      <tr><td>Classes</td><td>{', '.join(f'<code>{c}</code>' for c in class_names)}</td></tr>
      <tr><td>Generated At</td><td>{generated_at}</td></tr>
    </table>
  </div>

  <div class="section">
    <h2>2. Metrics — Train / Validation / Test</h2>
    <div class="metric-grid">
      <div class="metric-box">
        <h3>Train Set</h3>
        <table><tbody>{metric_rows(train_metrics)}</tbody></table>
      </div>
      <div class="metric-box">
        <h3>Validation Set</h3>
        <table><tbody>{metric_rows(val_metrics)}</tbody></table>
      </div>
      <div class="metric-box">
        <h3>Test Set</h3>
        <table><tbody>{metric_rows(test_metrics)}</tbody></table>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>3. Best Hyperparameters</h2>
    <table>
      <thead><tr><th>Parameter</th><th>Value</th></tr></thead>
      <tbody>{param_rows(best_params)}</tbody>
    </table>
  </div>

  {leaderboard_html}

  <div class="footer">AutoML Studio Performance Report · {generated_at}</div>
</div>
</body>
</html>"""
    return html
