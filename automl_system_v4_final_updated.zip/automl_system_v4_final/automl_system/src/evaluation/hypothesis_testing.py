"""
Hypothesis Testing Module
Statistical significance tests to determine whether model performance differences
are meaningful or due to chance.

Tests included:
  - McNemar's Test      — paired binary classifier comparison (exact / chi-square)
  - Wilcoxon Signed-Rank — non-parametric paired comparison of CV score arrays
  - Friedman Test       — multi-model comparison across multiple CV folds
  - Paired t-Test       — parametric paired comparison (assumes normality)
  - Effect Size (Cohen's d) — practical significance beyond p-value
"""
import warnings
from itertools import combinations
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import StratifiedKFold, cross_val_score

from src.utils.logger import get_logger

warnings.filterwarnings("ignore")
logger = get_logger(__name__)


# ── Low-level helpers ─────────────────────────────────────────────────────────

def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Cohen's d effect size between two arrays."""
    pooled_std = np.sqrt((np.std(a, ddof=1)**2 + np.std(b, ddof=1)**2) / 2)
    return float((np.mean(a) - np.mean(b)) / pooled_std) if pooled_std > 0 else 0.0


def interpret_effect(d: float) -> str:
    d = abs(d)
    if d < 0.2:  return "negligible"
    if d < 0.5:  return "small"
    if d < 0.8:  return "medium"
    return "large"


def interpret_p(p: float, alpha: float = 0.05) -> str:
    return "significant ✅" if p < alpha else "not significant ❌"


# ── Per-pair tests ────────────────────────────────────────────────────────────

def mcnemar_test(
    y_true: np.ndarray,
    preds_a: np.ndarray,
    preds_b: np.ndarray,
) -> Dict:
    """
    McNemar's test for two classifiers on the same test set.
    Tests whether one classifier makes significantly different errors than another.

    Returns dict with statistic, p_value, contingency table.
    """
    correct_a = (preds_a == y_true)
    correct_b = (preds_b == y_true)

    # Contingency table
    both_correct  = np.sum(correct_a  &  correct_b)
    only_a        = np.sum(correct_a  & ~correct_b)
    only_b        = np.sum(~correct_a &  correct_b)
    both_wrong    = np.sum(~correct_a & ~correct_b)

    # McNemar statistic (with continuity correction)
    b, c = int(only_a), int(only_b)
    if (b + c) == 0:
        return {"test": "McNemar", "statistic": 0.0, "p_value": 1.0,
                "b": b, "c": c, "interpretation": "Identical predictions"}

    statistic = (abs(b - c) - 1)**2 / (b + c)
    p_value   = float(stats.chi2.sf(statistic, df=1))

    return {
        "test":           "McNemar",
        "statistic":      round(statistic, 4),
        "p_value":        round(p_value, 6),
        "b_only_A_correct": b,
        "c_only_B_correct": c,
        "contingency":    [[int(both_correct), b], [c, int(both_wrong)]],
        "interpretation": interpret_p(p_value),
    }


def wilcoxon_test(scores_a: np.ndarray, scores_b: np.ndarray) -> Dict:
    """
    Wilcoxon signed-rank test for paired CV score arrays.
    Non-parametric — does not assume normality.
    """
    if len(scores_a) < 3 or len(scores_b) < 3:
        return {"test": "Wilcoxon", "error": "Need ≥3 paired observations"}
    try:
        stat, p = stats.wilcoxon(scores_a, scores_b, zero_method="wilcox",
                                  alternative="two-sided")
        d = cohens_d(scores_a, scores_b)
        return {
            "test":        "Wilcoxon Signed-Rank",
            "statistic":   round(float(stat), 4),
            "p_value":     round(float(p), 6),
            "effect_size": round(d, 4),
            "effect_label":interpret_effect(d),
            "mean_A":      round(float(np.mean(scores_a)), 4),
            "mean_B":      round(float(np.mean(scores_b)), 4),
            "interpretation": interpret_p(float(p)),
        }
    except Exception as e:
        return {"test": "Wilcoxon", "error": str(e)}


def paired_ttest(scores_a: np.ndarray, scores_b: np.ndarray) -> Dict:
    """Paired t-test for two sets of CV scores (assumes normality)."""
    try:
        stat, p = stats.ttest_rel(scores_a, scores_b)
        d = cohens_d(scores_a, scores_b)
        return {
            "test":         "Paired t-Test",
            "statistic":    round(float(stat), 4),
            "p_value":      round(float(p), 6),
            "effect_size":  round(d, 4),
            "effect_label": interpret_effect(d),
            "mean_A":       round(float(np.mean(scores_a)), 4),
            "mean_B":       round(float(np.mean(scores_b)), 4),
            "interpretation": interpret_p(float(p)),
        }
    except Exception as e:
        return {"test": "Paired t-Test", "error": str(e)}


def friedman_test(scores_matrix: Dict[str, np.ndarray]) -> Dict:
    """
    Friedman test across multiple models.
    Null hypothesis: all models perform equivalently.

    Args:
        scores_matrix: dict of model_name → CV score array (same length for all)

    Returns:
        dict with statistic, p_value, rankings.
    """
    names = list(scores_matrix.keys())
    if len(names) < 3:
        return {"test": "Friedman", "error": "Need ≥3 models"}
    try:
        arrays = [scores_matrix[n] for n in names]
        stat, p = stats.friedmanchisquare(*arrays)
        means   = {n: round(float(np.mean(scores_matrix[n])), 4) for n in names}
        ranked  = sorted(means.items(), key=lambda x: x[1], reverse=True)
        return {
            "test":       "Friedman",
            "statistic":  round(float(stat), 4),
            "p_value":    round(float(p), 6),
            "rankings":   ranked,
            "interpretation": interpret_p(float(p)),
        }
    except Exception as e:
        return {"test": "Friedman", "error": str(e)}


# ── Main class ────────────────────────────────────────────────────────────────

class HypothesisTester:
    """
    Runs a full suite of statistical tests comparing all trained models.

    Usage:
        tester = HypothesisTester(config)
        results = tester.run_all(trained_models, X_test, y_test, X_cv, y_cv)
    """

    def __init__(self, config: Dict, alpha: float = 0.05):
        self.config = config
        self.alpha  = alpha
        self.metric = config.get("tuning", {}).get("metric", "f1_weighted")
        self.cv_folds = config.get("models", {}).get("cross_validation_folds", 5)
        self.random_state = config.get("project", {}).get("random_state", 42)
        self.results: Dict = {}

    def get_cv_scores(
        self,
        models: Dict[str, Any],
        X: np.ndarray,
        y: np.ndarray,
    ) -> Dict[str, np.ndarray]:
        """Collect per-fold CV scores for each model."""
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True,
                             random_state=self.random_state)
        scores = {}
        for name, model in models.items():
            try:
                s = cross_val_score(model, X, y, cv=cv,
                                    scoring=self.metric, n_jobs=-1)
                scores[name] = s
                logger.info(f"  CV scores {name}: {s.round(4)}")
            except Exception as e:
                logger.warning(f"  CV scoring failed for {name}: {e}")
        return scores

    def run_all(
        self,
        models: Dict[str, Any],
        X_test: np.ndarray,
        y_test: np.ndarray,
        X_cv: Optional[np.ndarray] = None,
        y_cv: Optional[np.ndarray] = None,
        reference_model: Optional[str] = None,
    ) -> Dict:
        """
        Run full hypothesis testing suite.

        Args:
            models:          Trained model dict.
            X_test:          Test features.
            y_test:          Test labels.
            X_cv / y_cv:     Data for CV score collection (optional; uses X_test if None).
            reference_model: Champion model name to use as reference in pair tests.

        Returns:
            Nested results dict.
        """
        logger.info("Running hypothesis testing suite…")
        X_cv = X_cv if X_cv is not None else X_test
        y_cv = y_cv if y_cv is not None else y_test

        names = list(models.keys())
        if not reference_model or reference_model not in models:
            reference_model = names[0]

        # ── Collect predictions ───────────────────────────────────────────────
        preds = {n: m.predict(X_test) for n, m in models.items()}

        # ── Collect CV scores ─────────────────────────────────────────────────
        cv_scores = self.get_cv_scores(models, X_cv, y_cv)

        # ── McNemar pairwise vs reference ─────────────────────────────────────
        mcnemar_results = {}
        for name in names:
            if name == reference_model:
                continue
            mcnemar_results[f"{reference_model}_vs_{name}"] = mcnemar_test(
                y_test, preds[reference_model], preds[name]
            )

        # ── All pairwise Wilcoxon + t-test ────────────────────────────────────
        wilcoxon_results = {}
        ttest_results    = {}
        for a, b in combinations(names, 2):
            if a in cv_scores and b in cv_scores:
                key = f"{a}_vs_{b}"
                wilcoxon_results[key] = wilcoxon_test(cv_scores[a], cv_scores[b])
                ttest_results[key]    = paired_ttest(cv_scores[a], cv_scores[b])

        # ── Friedman multi-model ──────────────────────────────────────────────
        friedman_result = friedman_test(cv_scores) if len(cv_scores) >= 3 else {}

        # ── Summary table ─────────────────────────────────────────────────────
        summary_rows = []
        for key, res in wilcoxon_results.items():
            a, b = key.split("_vs_")
            summary_rows.append({
                "pair":          key,
                "model_A":       a,
                "model_B":       b,
                "mean_A":        res.get("mean_A"),
                "mean_B":        res.get("mean_B"),
                "wilcoxon_p":    res.get("p_value"),
                "wilcoxon_sig":  "✅" if res.get("p_value", 1) < self.alpha else "❌",
                "ttest_p":       ttest_results.get(key, {}).get("p_value"),
                "effect_size":   res.get("effect_size"),
                "effect_label":  res.get("effect_label"),
            })
        summary_df = pd.DataFrame(summary_rows)

        self.results = {
            "reference_model":  reference_model,
            "alpha":            self.alpha,
            "metric":           self.metric,
            "cv_scores":        {k: v.tolist() for k, v in cv_scores.items()},
            "mcnemar":          mcnemar_results,
            "wilcoxon":         wilcoxon_results,
            "paired_ttest":     ttest_results,
            "friedman":         friedman_result,
            "summary":          summary_df,
        }
        logger.info("Hypothesis testing complete.")
        return self.results

    def summary_dataframe(self) -> pd.DataFrame:
        return self.results.get("summary", pd.DataFrame())
