"""
Integration Test — Smoke-tests the full pipeline end-to-end.
Run: python tests/integration_test.py
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.datasets import load_iris

sys.path.insert(0, str(Path(__file__).parent.parent))


def make_config(tmp_dir: str) -> dict:
    return {
        "project": {"name": "IntegrationTest", "version": "1.0.0", "random_state": 42},
        "data": {"raw_path": tmp_dir, "processed_path": tmp_dir, "test_size": 0.2},
        "preprocessing": {
            "numeric_imputer": "median",
            "categorical_imputer": "most_frequent",
            "scaler": "standard",
            "encoding": "onehot",
        },
        "models": {
            "enabled": ["logistic_regression", "random_forest"],
            "cross_validation_folds": 3,
        },
        "tuning": {"enabled": False, "n_trials": 5, "timeout": 30, "metric": "f1_weighted"},
        "evaluation": {"metrics": ["accuracy", "f1_weighted"], "threshold": 0.5},
        "explainability": {
            "shap_enabled": False,
            "lime_enabled": False,
            "max_display_features": 10,
        },
        "tracking": {"mlflow": {"enabled": False}},
        "deployment": {"api": {"host": "0.0.0.0", "port": 8000}},
        "logging": {"level": "WARNING"},
    }


def run():
    import tempfile
    import os

    print("=" * 60)
    print("AutoML System — Integration Test")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmp:
        # ── 1. Load Iris ──────────────────────────────────────────────────────
        print("\n[1/6] Loading Iris dataset...")
        iris = load_iris(as_frame=True)
        df = iris.frame.copy()
        df["target"] = iris.target_names[iris.target]
        csv_path = os.path.join(tmp, "iris.csv")
        df.to_csv(csv_path, index=False)
        print(f"      Raw shape: {df.shape}")

        config = make_config(tmp)

        # ── 2. Ingestion ──────────────────────────────────────────────────────
        print("\n[2/6] Data ingestion...")
        from src.ingestion.data_loader import DataIngestion

        ingestion = DataIngestion(config)
        df_in, col_types, profile = ingestion.run(csv_path, "target")

        print(f"      Numeric cols: {col_types['numeric']}")
        print(f"      Categorical cols: {col_types['categorical']}")
        print(f"      Profile shape: {profile['shape']}")

        # ✅ FIX: account for duplicate removal during ingestion
        expected_shape = df.drop_duplicates().shape
        assert profile["shape"] == expected_shape, (
            f"Profile shape {profile['shape']} does not match expected {expected_shape}"
        )

        # ── 3. Preprocessing ──────────────────────────────────────────────────
        print("\n[3/6] Preprocessing...")
        from src.preprocessing.pipeline import PreprocessingPipeline

        pp = PreprocessingPipeline(config)
        X, y = pp.fit_transform(
            df_in,
            "target",
            col_types["numeric"],
            col_types["categorical"],
        )

        print(f"      X shape: {X.shape}")
        print(f"      y classes: {pp.label_encoder.classes_}")

        pp.save(os.path.join(tmp, "preprocessor.pkl"))

        # ── 4. Training ───────────────────────────────────────────────────────
        print("\n[4/6] Training models...")
        from src.models.trainer import ModelTrainer
        from sklearn.model_selection import train_test_split

        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        trainer = ModelTrainer(config)
        models = trainer.train_all(
            X_tr, y_tr, ["logistic_regression", "random_forest"]
        )

        board = trainer.get_leaderboard()
        for row in board:
            print(
                f"      {row['model']:25s}  "
                f"F1={row['f1_weighted']:.4f}  "
                f"Acc={row['accuracy']:.4f}"
            )

        # ── 5. Evaluation ─────────────────────────────────────────────────────
        print("\n[5/6] Evaluation...")
        from src.evaluation.evaluator import ModelEvaluator

        evaluator = ModelEvaluator(config)
        leaderboard = evaluator.compare_models(models, X_te, y_te)

        print(
            leaderboard[["model", "accuracy", "f1_weighted"]]
            .to_string(index=False)
        )

        # ── 6. Selection & Save ───────────────────────────────────────────────
        print("\n[6/6] Model selection & persistence...")
        from src.models.selector import ModelSelector

        selector = ModelSelector(config)
        best_name, best_model = selector.select(models, leaderboard)

        save_path = os.path.join(tmp, "best_model.pkl")
        selector.save(save_path)

        loaded_name, loaded_model = ModelSelector.load(save_path)

        assert loaded_name == best_name

        preds = loaded_model.predict(X_te)
        assert len(preds) == len(y_te)

        print(f"      Best model: {best_name}")
        print(f"      Prediction sample: {preds[:5]}")

    print("\n" + "=" * 60)
    print("✅ Integration test PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    run()
