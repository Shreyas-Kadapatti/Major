"""
Unit Tests for AutoML Classification System
"""
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Ensure project root is in path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Fixtures ───────────────────────────────────────────────────────────────────
@pytest.fixture
def sample_df():
    """Create a small synthetic classification DataFrame."""
    np.random.seed(42)
    n = 200
    return pd.DataFrame({
        "age": np.random.randint(18, 80, n),
        "income": np.random.normal(50000, 15000, n),
        "education": np.random.choice(["High School", "Bachelor", "Master", "PhD"], n),
        "city": np.random.choice(["NYC", "LA", "Chicago"], n),
        "target": np.random.choice(["low", "medium", "high"], n),
    })


@pytest.fixture
def minimal_config():
    return {
        "project": {"name": "test", "version": "1.0.0", "random_state": 42},
        "data": {"raw_path": "data/raw", "processed_path": "data/processed", "test_size": 0.2},
        "preprocessing": {
            "numeric_imputer": "median",
            "categorical_imputer": "most_frequent",
            "scaler": "standard",
            "encoding": "onehot",
        },
        "models": {"enabled": ["logistic_regression"], "cross_validation_folds": 3},
        "tuning": {"enabled": False, "n_trials": 5, "timeout": 30, "metric": "f1_weighted"},
        "evaluation": {"metrics": ["accuracy", "f1_weighted"], "threshold": 0.5},
        "explainability": {"shap_enabled": False, "lime_enabled": False, "max_display_features": 10},
        "tracking": {"mlflow": {"enabled": False, "tracking_uri": "mlruns", "experiment_name": "test"}},
        "deployment": {"api": {"host": "0.0.0.0", "port": 8000}},
        "logging": {"level": "WARNING"},
    }


# ── Data Ingestion Tests ───────────────────────────────────────────────────────
class TestDataIngestion:
    def test_load_csv(self, sample_df, minimal_config, tmp_path):
        from src.ingestion.data_loader import DataIngestion
        csv_path = tmp_path / "test.csv"
        sample_df.to_csv(csv_path, index=False)

        ingestion = DataIngestion(minimal_config)
        df = ingestion.load(str(csv_path))
        assert df.shape == sample_df.shape

    def test_validate_removes_duplicates(self, sample_df, minimal_config):
        from src.ingestion.data_loader import DataIngestion
        df_with_dups = pd.concat([sample_df, sample_df.head(10)], ignore_index=True)
        ingestion = DataIngestion(minimal_config)
        df_clean = ingestion.validate(df_with_dups, "target")
        assert len(df_clean) == len(sample_df)

    def test_missing_target_raises(self, sample_df, minimal_config):
        from src.ingestion.data_loader import DataIngestion
        ingestion = DataIngestion(minimal_config)
        with pytest.raises(ValueError, match="not found"):
            ingestion.validate(sample_df, "nonexistent_col")

    def test_detect_column_types(self, sample_df, minimal_config):
        from src.ingestion.data_loader import DataIngestion
        ingestion = DataIngestion(minimal_config)
        col_types = ingestion.detect_column_types(sample_df, "target")
        assert "age" in col_types["numeric"]
        assert "income" in col_types["numeric"]
        assert "education" in col_types["categorical"] or "education" in col_types["text"]

    def test_profile(self, sample_df, minimal_config):
        from src.ingestion.data_loader import DataIngestion
        ingestion = DataIngestion(minimal_config)
        profile = ingestion.profile(sample_df)
        assert "shape" in profile
        assert profile["shape"] == sample_df.shape


# ── Preprocessing Tests ────────────────────────────────────────────────────────
class TestPreprocessing:
    def test_fit_transform(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(
            sample_df, "target",
            numeric_cols=["age", "income"],
            categorical_cols=["education", "city"],
        )
        assert X.shape[0] == len(sample_df)
        assert len(y) == len(sample_df)

    def test_label_encoding(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        pp = PreprocessingPipeline(minimal_config)
        _, y = pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])
        assert set(y).issubset({0, 1, 2})

    def test_save_load(self, sample_df, minimal_config, tmp_path):
        from src.preprocessing.pipeline import PreprocessingPipeline
        pp = PreprocessingPipeline(minimal_config)
        pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])
        save_path = str(tmp_path / "pp.pkl")
        pp.save(save_path)

        pp2 = PreprocessingPipeline.load(save_path)
        assert pp2.pipeline is not None

    def test_transform_new_data(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        pp = PreprocessingPipeline(minimal_config)
        pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])
        new_data = sample_df.drop(columns=["target"]).head(5)
        X_new = pp.transform(new_data)
        assert X_new.shape[0] == 5


# ── Model Registry Tests ───────────────────────────────────────────────────────
class TestModelRegistry:
    def test_get_available_models(self):
        from src.models.registry import get_available_models
        models = get_available_models()
        assert "logistic_regression" in models
        assert "random_forest" in models
        assert len(models) >= 4

    def test_get_model(self):
        from src.models.registry import get_model
        lr = get_model("logistic_regression")
        assert hasattr(lr, "fit")
        assert hasattr(lr, "predict")

    def test_unknown_model_raises(self):
        from src.models.registry import get_model
        with pytest.raises(ValueError):
            get_model("this_does_not_exist")


# ── Model Trainer Tests ────────────────────────────────────────────────────────
class TestModelTrainer:
    def test_train_single(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        from src.models.trainer import ModelTrainer
        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])

        trainer = ModelTrainer(minimal_config)
        model, metrics = trainer.train_single("logistic_regression", X, y)
        assert model is not None
        assert "accuracy" in metrics
        assert 0.0 <= metrics["accuracy"] <= 1.0

    def test_leaderboard(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        from src.models.trainer import ModelTrainer
        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])

        trainer = ModelTrainer(minimal_config)
        trainer.train_all(X, y, model_names=["logistic_regression", "decision_tree"])
        board = trainer.get_leaderboard()
        assert len(board) == 2
        assert board[0]["f1_weighted"] >= board[1]["f1_weighted"]


# ── Evaluator Tests ────────────────────────────────────────────────────────────
class TestEvaluator:
    def test_evaluate(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        from src.models.trainer import ModelTrainer
        from src.evaluation.evaluator import ModelEvaluator
        from sklearn.model_selection import train_test_split

        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

        trainer = ModelTrainer(minimal_config)
        model, _ = trainer.train_single("logistic_regression", X_tr, y_tr)

        evaluator = ModelEvaluator(minimal_config)
        metrics = evaluator.evaluate(model, X_te, y_te)
        assert "accuracy" in metrics
        assert "f1_weighted" in metrics

    def test_confusion_matrix(self, sample_df, minimal_config):
        from src.preprocessing.pipeline import PreprocessingPipeline
        from src.models.trainer import ModelTrainer
        from src.evaluation.evaluator import ModelEvaluator
        from sklearn.model_selection import train_test_split

        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(sample_df, "target", ["age", "income"], ["education", "city"])
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

        trainer = ModelTrainer(minimal_config)
        model, _ = trainer.train_single("logistic_regression", X_tr, y_tr)

        evaluator = ModelEvaluator(minimal_config)
        cm_data = evaluator.confusion_matrix_data(model, X_te, y_te)
        assert "matrix" in cm_data
        assert "labels" in cm_data


# ── Integration Test ───────────────────────────────────────────────────────────
class TestIntegration:
    def test_full_pipeline_smoke(self, sample_df, minimal_config, tmp_path):
        """Smoke test: ensure full pipeline runs without errors."""
        from src.ingestion.data_loader import DataIngestion
        from src.preprocessing.pipeline import PreprocessingPipeline
        from src.models.trainer import ModelTrainer
        from src.evaluation.evaluator import ModelEvaluator
        from src.models.selector import ModelSelector
        from sklearn.model_selection import train_test_split

        csv_path = str(tmp_path / "data.csv")
        sample_df.to_csv(csv_path, index=False)

        ingestion = DataIngestion(minimal_config)
        df, col_types, profile = ingestion.run(csv_path, "target")

        pp = PreprocessingPipeline(minimal_config)
        X, y = pp.fit_transform(df, "target", col_types["numeric"], col_types["categorical"])
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

        trainer = ModelTrainer(minimal_config)
        models = trainer.train_all(X_tr, y_tr, ["logistic_regression", "decision_tree"])

        evaluator = ModelEvaluator(minimal_config)
        leaderboard = evaluator.compare_models(models, X_te, y_te)

        selector = ModelSelector(minimal_config)
        best_name, best_model = selector.select(models, leaderboard)

        assert best_name in models
        assert hasattr(best_model, "predict")

        save_path = str(tmp_path / "best_model.pkl")
        selector.save(save_path)
        loaded_name, loaded_model = ModelSelector.load(save_path)
        assert loaded_name == best_name


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
