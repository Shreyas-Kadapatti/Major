# 🤖 AutoML Classification System

A production-grade, modular, and scalable AutoML pipeline with explainability, experiment tracking, FastAPI deployment, and a Streamlit dashboard.

---

## 📁 Project Structure

```
automl_system/
├── config/
│   └── config.yaml              # Pipeline configuration
├── data/
│   ├── raw/                     # Raw input datasets
│   └── processed/               # Processed datasets
├── src/
│   ├── ingestion/
│   │   └── data_loader.py       # CSV/Excel/Parquet loading + profiling
│   ├── preprocessing/
│   │   └── pipeline.py          # sklearn Pipeline + ColumnTransformer
│   ├── models/
│   │   ├── registry.py          # Unified model registry + search spaces
│   │   ├── trainer.py           # Cross-validated model training
│   │   └── selector.py          # Best model selection + persistence
│   ├── tuning/
│   │   └── optuna_tuner.py      # Optuna Bayesian hyperparameter tuning
│   ├── evaluation/
│   │   └── evaluator.py         # Metrics, confusion matrix, ROC curves
│   ├── explainability/
│   │   └── shap_explainer.py    # SHAP global/local + LIME
│   ├── tracking/
│   │   └── mlflow_tracker.py    # MLflow experiment tracking + registry
│   ├── deployment/
│   │   ├── drift_detector.py    # KS/Chi-square data drift detection
│   │   └── model_monitor.py     # Production prediction monitoring
│   └── utils/
│       ├── config_loader.py     # YAML config loader
│       └── logger.py            # Centralized logging
├── pipeline/
│   └── training_pipeline.py    # End-to-end pipeline orchestrator
├── api/
│   └── app.py                  # FastAPI REST API
├── dashboard/
│   └── app.py                  # Streamlit multi-page dashboard
├── tests/
│   ├── test_pipeline.py        # Unit + integration tests (pytest)
│   └── integration_test.py     # Full smoke test
├── .github/
│   └── workflows/ci.yml        # GitHub Actions CI/CD
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Clone & Setup

```bash
git clone <your-repo-url>
cd automl_system
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Launch the Streamlit Dashboard

```bash
streamlit run dashboard/app.py
```

Open http://localhost:8501 in your browser.

---

### 3. Run via Python API

```python
from pipeline.training_pipeline import TrainingPipeline

pipeline = TrainingPipeline("config/config.yaml")
results = pipeline.run(
    file_path="data/raw/your_dataset.csv",
    target_col="target",
    model_names=["random_forest", "xgboost", "lightgbm"],
    tune=True,
)

print(results["leaderboard"])
print(f"Best model: {results['best_model_name']}")
```

---

### 4. Launch FastAPI Server

```bash
uvicorn api.app:app --host 0.0.0.0 --port 8000 --reload
```

API docs: http://localhost:8000/docs

#### Single Prediction
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"features": {"age": 35, "income": 60000, "education": "Bachelor"}, "explain": false}'
```

#### Batch Prediction
```bash
curl -X POST http://localhost:8000/predict/batch \
  -H "Content-Type: application/json" \
  -d '{"records": [{"age": 35, "income": 60000}, {"age": 28, "income": 42000}]}'
```

---

## 🐳 Docker

### Build & Run All Services

```bash
docker-compose up --build
```

| Service     | URL                    |
|-------------|------------------------|
| FastAPI     | http://localhost:8000  |
| Streamlit   | http://localhost:8501  |
| MLflow UI   | http://localhost:5000  |

### Run Single Service

```bash
# API only
docker-compose up api

# Dashboard only
docker-compose up dashboard
```

---

## ⚙️ Configuration

Edit `config/config.yaml` to customize:

```yaml
preprocessing:
  scaler: standard        # standard | minmax | robust
  numeric_imputer: median # mean | median | most_frequent
  encoding: onehot        # onehot | label

models:
  enabled:
    - logistic_regression
    - random_forest
    - xgboost
    - lightgbm
    - catboost

tuning:
  enabled: true
  n_trials: 50
  timeout: 300            # seconds per model

tracking:
  mlflow:
    enabled: true
    experiment_name: automl_classification
```

---

## 🧪 Tests

```bash
# Run all unit tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html

# Run integration test
python tests/integration_test.py
```

---

## 📊 Supported Models

| Model               | Tuning | Feature Importance | SHAP |
|---------------------|--------|--------------------|------|
| Logistic Regression | ✅     | ✅ (coef)          | ✅   |
| Decision Tree       | ✅     | ✅                 | ✅   |
| Random Forest       | ✅     | ✅                 | ✅   |
| XGBoost             | ✅     | ✅                 | ✅   |
| LightGBM            | ✅     | ✅                 | ✅   |
| CatBoost            | ✅     | ✅                 | ✅   |
| SVM                 | ✅     | ❌                 | ✅   |
| MLP                 | ✅     | ❌                 | ✅   |

---

## 📈 Dashboard Pages

| Page                | Features                                           |
|---------------------|----------------------------------------------------|
| 📂 Data Upload      | CSV/Excel/Parquet upload, preview, missing values  |
| ⚙️ Configuration    | Target, models, tuning, preprocessing settings     |
| 🚀 Training         | One-click training, real-time progress & logs      |
| 📈 Model Performance| Leaderboard, radar, confusion matrix, ROC curve    |
| 🔍 Explainability   | Feature importance, SHAP global & per-instance     |
| 🔮 Predictions      | Manual form input + batch CSV upload               |
| 📦 Model Registry   | MLflow run browser + metric comparison             |

---

## 🔍 Explainability

- **SHAP TreeExplainer** for tree-based models (XGBoost, LightGBM, Random Forest)
- **SHAP LinearExplainer** for linear models
- **SHAP KernelExplainer** for any black-box model
- **LIME** tabular explainer for local explanations
- Global feature importance bar charts
- Per-instance waterfall plots

---

## 📦 Bonus Features

- ✅ **Docker + docker-compose** for all services
- ✅ **GitHub Actions** CI/CD (lint, test, build, push)
- ✅ **Data Drift Detection** (KS test + Chi-square)
- ✅ **Model Monitoring** (latency, confidence, class distribution)
- ✅ **MLflow Model Registry** (Staging / Production stages)

---

## 🧱 Tech Stack

- **ML**: scikit-learn, XGBoost, LightGBM, CatBoost
- **Tuning**: Optuna (TPE Sampler + Median Pruner)
- **Tracking**: MLflow
- **Explainability**: SHAP, LIME
- **API**: FastAPI + Pydantic + Uvicorn
- **Dashboard**: Streamlit + Plotly
- **Testing**: pytest
- **CI/CD**: GitHub Actions
- **Containers**: Docker + docker-compose

---

## 📄 License

MIT License — see LICENSE for details.
