"""
Feature Leakage Detector
Mandatory pre-training step that flags suspiciously predictive or target-derived features.

WHY: Leakage silently inflates model performance metrics during training but causes
catastrophic failure in production. Catching it before training saves hours of debugging.
"""
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from src.utils.logger import get_logger

logger = get_logger(__name__)

_LEAKAGE_KEYWORDS = {
    "target", "label", "outcome", "result", "response", "y_true", "y_pred",
    "prediction", "predicted", "score", "flag", "ground_truth", "gt",
    "churn_label", "fraud_flag", "default_flag", "is_target",
}

_HIGH_CORR_THRESHOLD = 0.95
_WARN_CORR_THRESHOLD = 0.85
_HIGH_MI_THRESHOLD   = 0.90
_WARN_MI_THRESHOLD   = 0.70


class LeakageReport:
    def __init__(self):
        self.blocked:  List[Dict] = []
        self.warnings: List[Dict] = []
        self.clean:    List[str]  = []

    @property
    def has_blockers(self) -> bool:
        return len(self.blocked) > 0

    @property
    def has_warnings(self) -> bool:
        return len(self.warnings) > 0

    def summary(self) -> str:
        lines = [
            f"Leakage scan: {len(self.blocked)} blocked, "
            f"{len(self.warnings)} warnings, {len(self.clean)} clean"
        ]
        for item in self.blocked:
            lines.append(f"  [BLOCK]  {item['feature']}: {item['reason']} ({item['detail']})")
        for item in self.warnings:
            lines.append(f"  [WARN]   {item['feature']}: {item['reason']} ({item['detail']})")
        return "\n".join(lines)

    def to_dataframe(self) -> pd.DataFrame:
        rows = (
            [{"feature": d["feature"], "severity": "BLOCK",
              "reason": d["reason"], "detail": d["detail"]} for d in self.blocked]
            + [{"feature": d["feature"], "severity": "WARN",
                "reason": d["reason"], "detail": d["detail"]} for d in self.warnings]
        )
        return (
            pd.DataFrame(rows)
            if rows
            else pd.DataFrame(columns=["feature", "severity", "reason", "detail"])
        )


class FeatureLeakageDetector:
    """
    Fast, model-agnostic leakage detection using:
      1. Name-based heuristics
      2. High Pearson |r| with target (numeric features)
      3. Normalised mutual information (all feature types)
      4. Eta-squared class separation (near-perfect separation check)
    """

    def __init__(
        self,
        high_corr_threshold: float = _HIGH_CORR_THRESHOLD,
        warn_corr_threshold: float = _WARN_CORR_THRESHOLD,
        high_mi_threshold:   float = _HIGH_MI_THRESHOLD,
        warn_mi_threshold:   float = _WARN_MI_THRESHOLD,
    ):
        self.high_corr = high_corr_threshold
        self.warn_corr = warn_corr_threshold
        self.high_mi   = high_mi_threshold
        self.warn_mi   = warn_mi_threshold

    def _name_heuristic(self, col: str, target_col: str) -> Tuple[bool, str]:
        col_lower    = col.lower().replace("-", "_").replace(" ", "_")
        target_lower = target_col.lower().replace("-", "_").replace(" ", "_")
        if target_lower in col_lower or col_lower in target_lower:
            return True, f"Column name contains/matches target name '{target_col}'"
        for kw in _LEAKAGE_KEYWORDS:
            if kw in col_lower:
                return True, f"Column name contains leakage keyword '{kw}'"
        return False, ""

    def _numeric_correlation(self, series: pd.Series, target: pd.Series) -> float:
        try:
            merged = pd.concat([series, target], axis=1).dropna()
            if len(merged) < 10:
                return 0.0
            r = merged.iloc[:, 0].corr(merged.iloc[:, 1])
            return abs(float(r)) if not np.isnan(r) else 0.0
        except Exception:
            return 0.0

    def _normalised_mi(self, series: pd.Series, target: pd.Series) -> float:
        try:
            from sklearn.metrics import normalized_mutual_info_score
            x = series.fillna("__missing__").astype(str)
            y = target.fillna("__missing__").astype(str)
            return float(normalized_mutual_info_score(x, y))
        except Exception:
            return 0.0

    def _eta_squared(self, series: pd.Series, target: pd.Series) -> float:
        try:
            df_tmp = pd.DataFrame({"feat": series, "tgt": target}).dropna()
            if df_tmp["tgt"].nunique() < 2 or len(df_tmp) < 10:
                return 0.0
            group_means = df_tmp.groupby("tgt")["feat"].mean()
            grand_mean  = df_tmp["feat"].mean()
            ss_between  = sum(
                (df_tmp["tgt"] == g).sum() * (m - grand_mean) ** 2
                for g, m in group_means.items()
            )
            ss_total = ((df_tmp["feat"] - grand_mean) ** 2).sum()
            return float(ss_between / ss_total) if ss_total > 0 else 0.0
        except Exception:
            return 0.0

    def detect(self, df: pd.DataFrame, target_col: str) -> LeakageReport:
        """
        Run all leakage checks. Returns a LeakageReport with blocked/warnings/clean.
        Must be called BEFORE any model training.
        """
        report = LeakageReport()
        feature_cols = [c for c in df.columns if c != target_col]
        target = df[target_col]

        try:
            from sklearn.preprocessing import LabelEncoder
            y_enc = pd.Series(
                LabelEncoder().fit_transform(target.astype(str)), index=target.index
            )
        except Exception:
            y_enc = target if pd.api.types.is_numeric_dtype(target) else pd.Series(
                np.zeros(len(target))
            )

        for col in feature_cols:
            series  = df[col]
            flagged = False

            # 1 — Name heuristic
            leaked, name_reason = self._name_heuristic(col, target_col)
            if leaked:
                report.blocked.append({
                    "feature": col, "reason": "Name heuristic",
                    "detail": name_reason, "score": 1.0,
                })
                continue  # no need for further checks

            # 2 — Numeric correlation + eta-squared
            if pd.api.types.is_numeric_dtype(series):
                corr = self._numeric_correlation(series, y_enc)
                if corr >= self.high_corr:
                    report.blocked.append({
                        "feature": col, "reason": "High target correlation",
                        "detail": f"|r| = {corr:.3f} ≥ {self.high_corr}",
                        "score": corr,
                    })
                    flagged = True
                elif corr >= self.warn_corr:
                    report.warnings.append({
                        "feature": col, "reason": "Suspicious target correlation",
                        "detail": f"|r| = {corr:.3f} — review whether this is available at inference time",
                        "score": corr,
                    })
                    flagged = True

                if not flagged:
                    eta2 = self._eta_squared(series, target)
                    if eta2 >= 0.90:
                        report.blocked.append({
                            "feature": col, "reason": "Near-perfect class separation",
                            "detail": f"η² = {eta2:.3f} — feature almost perfectly separates classes alone",
                            "score": eta2,
                        })
                        flagged = True
                    elif eta2 >= 0.70:
                        report.warnings.append({
                            "feature": col, "reason": "Strong class separation",
                            "detail": f"η² = {eta2:.3f} — verify this feature is available at inference time",
                            "score": eta2,
                        })
                        flagged = True

            # 3 — Normalised mutual information (all types)
            if not flagged:
                nmi = self._normalised_mi(series, target)
                if nmi >= self.high_mi:
                    report.blocked.append({
                        "feature": col, "reason": "High mutual information",
                        "detail": f"NMI = {nmi:.3f} ≥ {self.high_mi}",
                        "score": nmi,
                    })
                    flagged = True
                elif nmi >= self.warn_mi:
                    report.warnings.append({
                        "feature": col, "reason": "Suspicious mutual information",
                        "detail": f"NMI = {nmi:.3f} ≥ {self.warn_mi}",
                        "score": nmi,
                    })
                    flagged = True

            if not flagged:
                report.clean.append(col)

        logger.info(report.summary())
        return report
