"""
Explainability Module — Model-Aware SHAP with Caching

WHY:
  - Model-aware selection (Tree/Linear/Kernel) ensures SHAP values are as
    accurate as possible; using KernelExplainer on a tree model wastes minutes.
  - Caching means the dashboard never recomputes SHAP on repeated UI actions,
    keeping latency low even on large datasets.
  - Approximate-method warnings (Guardrail #5) inform non-expert users when
    explanations may be less precise.
"""
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import hashlib
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.utils.logger import get_logger

logger = get_logger(__name__)

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    logger.warning("SHAP not installed — explainability disabled.")

try:
    from lime.lime_tabular import LimeTabularExplainer
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False

_TREE_MODELS   = {"xgb", "lgbm", "lgb", "catboost", "randomforest", "extratrees",
                  "gradientboosting", "decisiontree", "histgradient"}
_LINEAR_MODELS = {"logisticregression", "linearregression", "ridge", "lasso",
                  "elasticnet", "sgdclassifier", "sgdregressor", "linearsvc",
                  "linearsvm", "bernoullinb", "gaussiannb", "multinomialnb"}

_KERNEL_MAX_BACKGROUND = 50
_KERNEL_MAX_EXPLAIN    = 100


def _model_family(model):
    name = type(model).__name__.lower()
    for key in _TREE_MODELS:
        if key in name:
            return "tree"
    for key in _LINEAR_MODELS:
        if key in name:
            return "linear"
    return "kernel"


def _model_fingerprint(model, X):
    try:
        model_id  = str(id(model))
        data_hash = hashlib.md5(X[:10].tobytes()).hexdigest()[:8]
        return f"{type(model).__name__}_{model_id}_{data_hash}"
    except Exception:
        return str(id(model))


_SHAP_CACHE: Dict[str, Dict] = {}


def get_cached_shap(key):
    return _SHAP_CACHE.get(key)


def set_cached_shap(key, payload):
    _SHAP_CACHE[key] = payload


def clear_shap_cache():
    _SHAP_CACHE.clear()


class ExplainabilityEngine:
    def __init__(self, config: Dict):
        self.config     = config
        exp_cfg         = config.get("explainability", {})
        self.shap_enabled     = exp_cfg.get("shap_enabled", True) and SHAP_AVAILABLE
        self.lime_enabled     = exp_cfg.get("lime_enabled", True) and LIME_AVAILABLE
        self.max_features     = exp_cfg.get("max_display_features", 20)
        self.num_lime_samples = exp_cfg.get("num_lime_samples", 500)
        self.shap_values      = None
        self.explainer        = None
        self._is_approximate  = False
        self._cache_key       = None

    def _build_explainer(self, model, X_background):
        """Factory: return (explainer, is_approximate)."""
        family = _model_family(model)
        logger.info(f"SHAP explainer family: {family} for {type(model).__name__}")

        if family == "tree":
            try:
                return shap.TreeExplainer(model), False
            except Exception as e:
                logger.warning(f"TreeExplainer failed ({e}), falling back to Kernel")

        if family == "linear":
            try:
                return shap.LinearExplainer(model, X_background), False
            except Exception as e:
                logger.warning(f"LinearExplainer failed ({e}), falling back to Kernel")

        bg = shap.sample(X_background, min(_KERNEL_MAX_BACKGROUND, len(X_background)))
        pred_fn = (
            model.predict_proba if hasattr(model, "predict_proba") else model.predict
        )
        return shap.KernelExplainer(pred_fn, bg), True

    def compute_shap(self, model, X, feature_names=None, max_samples=200, force_recompute=False):
        if not self.shap_enabled:
            return None

        cache_key       = _model_fingerprint(model, X)
        self._cache_key = cache_key

        if not force_recompute:
            cached = get_cached_shap(cache_key)
            if cached is not None:
                self.shap_values     = cached["shap_values"]
                self.explainer       = cached["explainer"]
                self._is_approximate = cached["is_approximate"]
                logger.info("SHAP cache hit — skipping recomputation.")
                return self.shap_values

        try:
            family    = _model_family(model)
            n_explain = (
                min(_KERNEL_MAX_EXPLAIN, len(X)) if family == "kernel"
                else min(max_samples, len(X))
            )
            sample = X[:n_explain]

            self.explainer, self._is_approximate = self._build_explainer(model, sample)
            raw = self.explainer.shap_values(sample)

            if isinstance(raw, list):
                sv = np.array(raw[1]) if len(raw) == 2 else np.mean([np.array(a) for a in raw], axis=0)
            else:
                sv = np.array(raw)

            if sv.ndim == 3:
                sv = sv.mean(axis=2)

            self.shap_values = sv.astype(float)

            set_cached_shap(cache_key, {
                "shap_values":    self.shap_values,
                "explainer":      self.explainer,
                "is_approximate": self._is_approximate,
                "sample":         sample,
            })

            logger.info(f"SHAP computed: shape={self.shap_values.shape}, approximate={self._is_approximate}")
            return self.shap_values

        except Exception as e:
            logger.error(f"SHAP computation failed: {e}")
            return None

    @property
    def is_approximate(self):
        return self._is_approximate

    @property
    def explainer_type(self):
        return type(self.explainer).__name__ if self.explainer else "None"

    def get_feature_importance(self, model, feature_names=None, X=None):
        importance = None
        names = feature_names or [f"feature_{i}" for i in range(100)]

        if hasattr(model, "feature_importances_"):
            importance = model.feature_importances_
        elif hasattr(model, "coef_"):
            coef = model.coef_
            importance = np.abs(coef).mean(axis=0) if coef.ndim > 1 else np.abs(coef.flatten())

        if importance is None and self.shap_values is not None:
            importance = np.abs(self.shap_values).mean(axis=0)

        if importance is None:
            logger.warning("Feature importance unavailable.")
            return pd.DataFrame(columns=["feature", "importance"])

        n  = min(len(importance), len(names))
        return (
            pd.DataFrame({"feature": names[:n], "importance": importance[:n]})
            .sort_values("importance", ascending=False)
            .head(self.max_features)
        )

    def shap_summary_figure(self, model, X, feature_names=None):
        if not self.shap_enabled:
            return None
        shap_vals = self.compute_shap(model, X, feature_names)
        if shap_vals is None:
            return None
        try:
            sample = X[:min(200, len(X))]
            fig, _ = plt.subplots(figsize=(10, 6))
            shap.summary_plot(
                shap_vals[:len(sample)], sample,
                feature_names=feature_names, plot_type="bar",
                max_display=self.max_features, show=False,
            )
            plt.tight_layout()
            return plt.gcf()
        except Exception as e:
            logger.error(f"SHAP summary plot failed: {e}")
            plt.close()
            return None

    def explain_instance_lime(self, model, X_train, instance, feature_names=None, class_names=None):
        if not self.lime_enabled:
            return None
        try:
            explainer = LimeTabularExplainer(
                X_train, feature_names=feature_names,
                class_names=class_names, discretize_continuous=True, random_state=42,
            )
            exp = explainer.explain_instance(
                instance.flatten(), model.predict_proba,
                num_features=self.max_features, num_samples=self.num_lime_samples,
            )
            return dict(exp.as_list())
        except Exception as e:
            logger.error(f"LIME explanation failed: {e}")
            return None
