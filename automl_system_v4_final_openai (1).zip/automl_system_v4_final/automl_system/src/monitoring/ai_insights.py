"""
OpenAI AI Insights Engine
Uses GPT-4o to generate intelligent, contextual analysis of AutoML results.

WHY: Non-expert users need plain-English interpretation of metrics, SHAP values,
and guardrail warnings — not just numbers. GPT-4o bridges that gap by providing
actionable, context-aware recommendations directly inside the dashboard.
"""
import os
from typing import Dict, List, Optional
from src.utils.logger import get_logger

logger = get_logger(__name__)


class AIInsightsEngine:
    """
    Wraps the OpenAI API to generate contextual insights about model results,
    SR 11-7 compliance status, SHAP explanations, and production readiness.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self._client = None
        self.available = False
        if self.api_key:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self.api_key)
                self.available = True
                logger.info("OpenAI AI Insights Engine initialised.")
            except ImportError:
                logger.warning("openai package not installed — run: pip install openai")
            except Exception as e:
                logger.warning(f"OpenAI client init failed: {e}")

    def _call(self, prompt: str, max_tokens: int = 600) -> str:
        if not self.available:
            return ""
        try:
            response = self._client.chat.completions.create(
                model="gpt-4o",
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            logger.warning(f"AI Insights API call failed: {e}")
            return ""

    def model_performance_insights(
        self,
        model_name: str,
        test_metrics: Dict[str, float],
        train_metrics: Dict[str, float],
        class_names: List[str],
        n_rows: int,
        guardrail_warnings: List[str],
        leakage_blocked: List[str],
    ) -> str:
        """Generate plain-English performance analysis."""
        warnings_str = "\n".join(guardrail_warnings) if guardrail_warnings else "None"
        metrics_str  = "\n".join(f"  {k}: {v:.4f}" for k, v in test_metrics.items())
        train_str    = "\n".join(f"  {k}: {v:.4f}" for k, v in train_metrics.items())
        prompt = f"""You are a senior machine learning engineer reviewing AutoML results for a business stakeholder.

Model: {model_name}
Classes: {', '.join(str(c) for c in class_names)}
Training rows: {n_rows:,}

Test Metrics:
{metrics_str}

Train Metrics:
{train_str}

Guardrail Warnings:
{warnings_str}

Leakage-blocked features: {leakage_blocked if leakage_blocked else 'None'}

In 4-5 concise bullet points:
1. Assess model quality (is this good/bad for the problem type?)
2. Flag any overfitting or underfitting signals
3. Call out the most important warning from the guardrails
4. Give one specific, actionable recommendation to improve the model
5. State whether this model appears production-ready based on these metrics

Be direct, specific, and avoid generic ML jargon. Use plain language a business analyst can understand."""
        return self._call(prompt, max_tokens=500)

    def shap_interpretation(
        self,
        top_features: List[Dict],
        model_name: str,
        target_col: str,
        is_approximate: bool,
    ) -> str:
        """Generate plain-English SHAP feature importance interpretation."""
        feat_str = "\n".join(
            f"  {i+1}. {f['feature']}: {f['importance']:.4f}"
            for i, f in enumerate(top_features[:10])
        )
        prompt = f"""You are explaining SHAP feature importance results to a business stakeholder (non-technical).

Model: {model_name}
Target variable: {target_col}
SHAP method: {'Approximate (KernelExplainer)' if is_approximate else 'Exact (Tree/LinearExplainer)'}

Top features by mean |SHAP| value:
{feat_str}

In 3-4 bullet points, explain:
1. Which features drive predictions most and what that means in business terms
2. Any surprising or suspicious features they should investigate
3. Whether the feature importance pattern makes intuitive sense
4. One actionable insight based on this explanation

Keep it concise, plain-English, and business-focused. No code, no formulas."""
        return self._call(prompt, max_tokens=400)

    def sr117_compliance_narrative(
        self,
        risk_tier: Dict,
        model_name: str,
        test_metrics: Dict[str, float],
        lineage: Dict,
        has_shap: bool,
        has_fairness: bool,
        guardrail_warnings: List[str],
    ) -> str:
        """Generate SR 11-7 compliance narrative for the model card."""
        steps_str   = "\n".join(f"  - {s}" for s in risk_tier.get("required_steps", []))
        reasons_str = "\n".join(f"  - {r}" for r in risk_tier.get("reasons", []))
        metrics_str = "\n".join(f"  {k}: {v:.4f}" for k, v in test_metrics.items())
        prompt = f"""You are a model risk management specialist writing a compliance narrative for SR 11-7 model documentation.

Model: {model_name}
SR 11-7 Risk Tier: {risk_tier.get('tier', 'UNKNOWN')} — {risk_tier.get('description', '')}

Risk scoring reasons:
{reasons_str}

Test Performance:
{metrics_str}

Explainability: {'SHAP computed — model is explainable' if has_shap else 'SHAP not available'}
Fairness Analysis: {'Completed' if has_fairness else 'Not performed'}
Data Lineage: {'Recorded — invertible sklearn pipeline' if lineage else 'Not recorded'}
Leakage Detection: {'Run — {n} features blocked'.format(n=len(lineage.get('leakage_blocked',[]))) if lineage else 'Not run'}

Required validation steps for this tier:
{steps_str}

Write a 2-paragraph SR 11-7 compliance narrative:
Paragraph 1: Describe the model's purpose, validation approach taken, and evidence of sound development practices.
Paragraph 2: Identify remaining compliance gaps, required next steps before production deployment, and ongoing monitoring requirements.

Use formal model risk management language appropriate for a bank/financial institution regulatory submission."""
        return self._call(prompt, max_tokens=600)

    def drift_analysis_insights(
        self,
        drift_report: Dict,
        model_name: str,
    ) -> str:
        """Interpret monitoring drift report in plain English."""
        summary  = drift_report.get("summary", {})
        alerts   = summary.get("feature_alerts", 0)
        warns    = summary.get("feature_warnings", 0)
        health   = summary.get("overall_health", "Unknown")
        drifted  = [
            f"{col}: PSI={info['psi']}"
            for col, info in drift_report.get("feature_drift", {}).items()
            if info.get("status") in ("alert", "monitor")
        ][:8]
        prompt = f"""You are a model monitoring specialist reviewing a drift detection report.

Model: {model_name}
Overall Health: {health}
Feature alerts (PSI > 0.20): {alerts}
Feature warnings (PSI 0.10–0.20): {warns}
Data quality issues: {summary.get('dq_issues', 0)}

Drifting features (top):
{chr(10).join(drifted) if drifted else 'None detected'}

In 3 concise bullet points:
1. Interpret what this drift pattern means for model reliability
2. Which specific features need investigation and why
3. Recommended immediate action (retrain / monitor / no action)

Be specific and actionable."""
        return self._call(prompt, max_tokens=350)
