"""
Model Monitoring & Drift Detection — SR 11-7 Ongoing Monitoring Requirement

SR 11-7 Section: "Ongoing monitoring should include outcome analysis,
benchmarking, and back-testing to detect model degradation."

This module provides:
  1. Population Stability Index (PSI) — feature distribution drift
  2. Performance drift detection — metric degradation over time
  3. Prediction distribution shift — output probability drift
  4. Data quality checks — missing rate, range violations
  5. SR 11-7 risk tier assignment
"""
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from src.utils.logger import get_logger

logger = get_logger(__name__)

# PSI thresholds (industry standard)
PSI_STABLE  = 0.10   # < 0.10 → no significant change
PSI_MONITOR = 0.20   # 0.10–0.20 → moderate shift, monitor
PSI_ALERT   = 0.20   # > 0.20 → significant shift, action required

# SR 11-7 Risk Tiers
RISK_TIERS = {
    "HIGH":   "Tier 1 — Full independent validation, quarterly review, board-level approval required",
    "MEDIUM": "Tier 2 — Internal validation, semi-annual review, senior management sign-off",
    "LOW":    "Tier 3 — Self-assessment, annual review, business owner sign-off",
}


def compute_psi(expected: np.ndarray, actual: np.ndarray, n_bins: int = 10) -> float:
    """
    Population Stability Index between training distribution and new data.
    PSI = Σ (Actual% - Expected%) × ln(Actual% / Expected%)
    """
    try:
        bins = np.percentile(expected, np.linspace(0, 100, n_bins + 1))
        bins = np.unique(bins)
        if len(bins) < 2:
            return 0.0
        exp_counts, _ = np.histogram(expected, bins=bins)
        act_counts, _ = np.histogram(actual,   bins=bins)
        eps = 1e-8
        exp_pct = (exp_counts + eps) / (len(expected) + eps)
        act_pct = (act_counts + eps) / (len(actual)   + eps)
        psi = float(np.sum((act_pct - exp_pct) * np.log(act_pct / exp_pct)))
        return max(0.0, psi)
    except Exception as e:
        logger.warning(f"PSI computation failed: {e}")
        return 0.0


def psi_label(psi: float) -> str:
    if psi < PSI_STABLE:  return "🟢 Stable"
    if psi < PSI_MONITOR: return "🟡 Monitor"
    return "🔴 Alert — Significant Drift"


class ModelMonitor:
    """
    SR 11-7 compliant ongoing model monitoring.
    Compares new production data against training baseline.
    """

    def __init__(
        self,
        train_df: pd.DataFrame,
        train_predictions: Optional[np.ndarray] = None,
        train_probas: Optional[np.ndarray] = None,
        feature_names: Optional[List[str]] = None,
    ):
        self.train_df          = train_df.copy()
        self.train_predictions = train_predictions
        self.train_probas      = train_probas
        self.feature_names     = feature_names or list(train_df.columns)
        self._baseline_stats   = self._compute_baseline_stats()

    def _compute_baseline_stats(self) -> Dict:
        stats = {}
        for col in self.train_df.columns:
            s = self.train_df[col]
            if pd.api.types.is_numeric_dtype(s):
                stats[col] = {
                    "type":     "numeric",
                    "mean":     float(s.mean()),
                    "std":      float(s.std()),
                    "min":      float(s.min()),
                    "max":      float(s.max()),
                    "null_pct": float(s.isna().mean()),
                    "values":   s.dropna().values,
                }
            else:
                vc = s.value_counts(normalize=True)
                stats[col] = {
                    "type":      "categorical",
                    "top_cats":  vc.head(20).to_dict(),
                    "null_pct":  float(s.isna().mean()),
                    "n_unique":  int(s.nunique()),
                }
        return stats

    def run(
        self,
        new_df: pd.DataFrame,
        new_predictions: Optional[np.ndarray] = None,
        new_probas: Optional[np.ndarray] = None,
        new_actuals: Optional[np.ndarray] = None,
        metrics_baseline: Optional[Dict[str, float]] = None,
        metrics_new: Optional[Dict[str, float]] = None,
    ) -> Dict:
        """
        Full monitoring run. Returns structured report dict.
        """
        report = {
            "feature_drift":  self._feature_drift(new_df),
            "data_quality":   self._data_quality(new_df),
            "pred_drift":     self._prediction_drift(new_predictions, new_probas),
            "perf_drift":     self._performance_drift(metrics_baseline, metrics_new),
            "summary":        {},
        }

        # Overall health
        alerts = sum(1 for f in report["feature_drift"].values() if f.get("status") == "alert")
        warns  = sum(1 for f in report["feature_drift"].values() if f.get("status") == "monitor")
        dq_issues = sum(1 for f in report["data_quality"].values() if f.get("issue"))

        report["summary"] = {
            "feature_alerts":   alerts,
            "feature_warnings": warns,
            "dq_issues":        dq_issues,
            "overall_health":   (
                "🔴 Action Required" if alerts > 0 or dq_issues > 2
                else "🟡 Monitor" if warns > 0 or dq_issues > 0
                else "🟢 Healthy"
            ),
        }
        return report

    def _feature_drift(self, new_df: pd.DataFrame) -> Dict:
        results = {}
        for col in self.train_df.columns:
            if col not in new_df.columns:
                continue
            bstat = self._baseline_stats.get(col, {})
            if bstat.get("type") == "numeric" and pd.api.types.is_numeric_dtype(new_df[col]):
                psi = compute_psi(
                    bstat["values"],
                    new_df[col].dropna().values,
                )
                results[col] = {
                    "psi":    round(psi, 4),
                    "label":  psi_label(psi),
                    "status": "alert" if psi >= PSI_ALERT else "monitor" if psi >= PSI_STABLE else "ok",
                    "train_mean": round(bstat["mean"], 4),
                    "new_mean":   round(float(new_df[col].mean()), 4),
                }
            else:
                # Categorical: check for new categories
                train_cats = set(bstat.get("top_cats", {}).keys())
                new_cats   = set(new_df[col].dropna().astype(str).unique())
                new_only   = new_cats - train_cats
                results[col] = {
                    "new_categories": list(new_only)[:10],
                    "status": "monitor" if new_only else "ok",
                    "label":  f"🟡 {len(new_only)} new categories" if new_only else "🟢 Stable",
                }
        return results

    def _data_quality(self, new_df: pd.DataFrame) -> Dict:
        results = {}
        for col in self.train_df.columns:
            if col not in new_df.columns:
                continue
            bstat    = self._baseline_stats.get(col, {})
            new_null = float(new_df[col].isna().mean())
            base_null = bstat.get("null_pct", 0.0)
            issue    = new_null > base_null + 0.10   # >10pp increase in nulls
            entry = {"null_pct": round(new_null, 4), "baseline_null": round(base_null, 4), "issue": issue}
            if bstat.get("type") == "numeric":
                new_min = float(new_df[col].min()) if not new_df[col].dropna().empty else bstat["min"]
                new_max = float(new_df[col].max()) if not new_df[col].dropna().empty else bstat["max"]
                out_of_range = (new_min < bstat["min"] * 1.5) or (new_max > bstat["max"] * 1.5)
                entry["out_of_range"] = out_of_range
                if out_of_range:
                    entry["issue"] = True
            results[col] = entry
        return results

    def _prediction_drift(self, new_preds, new_probas) -> Dict:
        if self.train_probas is None or new_probas is None:
            return {"available": False}
        try:
            psi = compute_psi(
                self.train_probas[:, -1] if self.train_probas.ndim > 1 else self.train_probas,
                new_probas[:, -1]        if new_probas.ndim > 1        else new_probas,
            )
            return {
                "available": True,
                "psi":    round(psi, 4),
                "label":  psi_label(psi),
                "status": "alert" if psi >= PSI_ALERT else "monitor" if psi >= PSI_STABLE else "ok",
                "train_mean_proba": round(float(np.mean(self.train_probas[:, -1])), 4)
                    if self.train_probas.ndim > 1 else None,
                "new_mean_proba": round(float(np.mean(new_probas[:, -1])), 4)
                    if new_probas.ndim > 1 else None,
            }
        except Exception:
            return {"available": False}

    def _performance_drift(self, baseline: Optional[Dict], new_metrics: Optional[Dict]) -> Dict:
        if not baseline or not new_metrics:
            return {"available": False}
        results = {"available": True, "metrics": {}}
        for metric, base_val in baseline.items():
            if metric not in new_metrics:
                continue
            new_val = new_metrics[metric]
            delta   = new_val - base_val
            pct     = (delta / max(abs(base_val), 1e-8)) * 100
            results["metrics"][metric] = {
                "baseline": round(base_val, 4),
                "current":  round(new_val,  4),
                "delta":    round(delta, 4),
                "delta_pct": round(pct, 2),
                "status":   "alert" if pct < -10 else "monitor" if pct < -5 else "ok",
            }
        return results


def assign_sr117_risk_tier(
    n_rows: int,
    n_classes: int,
    intended_use: str,
    test_f1: float,
    has_fairness_analysis: bool,
) -> Dict:
    """
    Assign SR 11-7 model risk tier based on model characteristics.
    Returns tier, rationale, and required validation steps.
    """
    score = 0
    reasons = []

    if n_rows < 1000:
        score += 2; reasons.append("Small training dataset (<1,000 rows) increases model uncertainty")
    elif n_rows < 10000:
        score += 1; reasons.append("Moderate training dataset (<10,000 rows)")

    if n_classes > 5:
        score += 1; reasons.append(f"Complex multi-class problem ({n_classes} classes)")

    keywords_high = {"credit", "fraud", "loan", "risk", "churn", "medical", "health",
                     "insurance", "regulatory", "compliance", "default"}
    if any(kw in intended_use.lower() for kw in keywords_high):
        score += 3; reasons.append("High-stakes domain detected in intended use description")

    if test_f1 < 0.70:
        score += 2; reasons.append(f"Low test F1 ({test_f1:.2f}) — model may not meet production standards")
    elif test_f1 < 0.85:
        score += 1; reasons.append(f"Moderate test F1 ({test_f1:.2f})")

    if not has_fairness_analysis:
        score += 1; reasons.append("No fairness analysis performed")

    tier = "HIGH" if score >= 5 else "MEDIUM" if score >= 2 else "LOW"

    required_steps = {
        "HIGH": [
            "Independent model validation by separate team",
            "Full documentation package (model card + technical spec)",
            "Board Risk Committee approval",
            "Quarterly performance review",
            "Mandatory fairness audit across protected attributes",
            "Stress testing and sensitivity analysis",
        ],
        "MEDIUM": [
            "Internal validation review",
            "Model card sign-off by senior data science lead",
            "Semi-annual performance review",
            "Fairness review recommended",
        ],
        "LOW": [
            "Self-assessment checklist completion",
            "Model card documentation",
            "Annual performance review",
        ],
    }

    return {
        "tier":            tier,
        "score":           score,
        "description":     RISK_TIERS[tier],
        "reasons":         reasons,
        "required_steps":  required_steps[tier],
    }
