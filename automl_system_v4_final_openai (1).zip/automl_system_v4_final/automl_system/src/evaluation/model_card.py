"""
Model Card Generator
Auto-generates a structured Model Card (PDF + Markdown) documenting:
  - Data lineage & statistics
  - Algorithm details
  - Train/val/test metrics
  - Hyperparameters chosen
  - Intended use & limitations
  - Ethical considerations
"""
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from src.utils.logger import get_logger

logger = get_logger(__name__)


class ModelCardGenerator:
    """
    Generates a comprehensive Model Card for the trained champion model.
    Outputs both Markdown text and an HTML-rendered version for download.
    """

    def __init__(self):
        self.card_data: Dict[str, Any] = {}

    def build(
        self,
        model_name: str,
        model_type: str,
        dataset_name: str,
        target_col: str,
        feature_names: List[str],
        class_names: List[str],
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float],
        test_metrics: Dict[str, float],
        best_params: Dict[str, Any],
        dataset_shape: tuple,
        dataset_profile: Optional[Dict] = None,
        n_trials_run: int = 0,
        best_trial_number: int = 0,
        tuning_metric: str = "f1_weighted",
        intended_use: str = "Binary or multiclass tabular classification.",
        limitations: str = "Performance may degrade on out-of-distribution data.",
        ethical_notes: str = "Ensure dataset used for training is free of harmful bias.",
        sr117_risk_tier: Optional[Dict] = None,
        sr117_narrative: str = "",
        ai_performance_insights: str = "",
        data_lineage: Optional[Dict] = None,
        shap_explainer_type: str = "",
        shap_is_approximate: bool = False,
        guardrail_warnings: Optional[List[str]] = None,
    ) -> "ModelCardGenerator":
        """Populate the card with all required fields including SR 11-7 compliance."""

        self.card_data = {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "model": {
                "name":       model_name,
                "type":       model_type,
                "version":    "1.0",
                "framework":  "scikit-learn / AutoML Studio v4",
            },
            "data": {
                "dataset_name":   dataset_name,
                "target_column":  target_col,
                "n_rows":         dataset_shape[0],
                "n_features_raw": dataset_shape[1],
                "n_features_processed": len(feature_names),
                "feature_names":  feature_names[:30],
                "class_names":    class_names,
                "n_classes":      len(class_names),
                "profile":        dataset_profile or {},
            },
            "training": {
                "best_params":        best_params,
                "tuning_metric":      tuning_metric,
                "best_trial_number":  best_trial_number,
                "n_trials_run":       n_trials_run,
            },
            "metrics": {
                "train": train_metrics,
                "val":   val_metrics,
                "test":  test_metrics,
            },
            "intended_use":   intended_use,
            "limitations":    limitations,
            "ethical_notes":  ethical_notes,
            "sr117": {
                "risk_tier":            sr117_risk_tier or {},
                "compliance_narrative": sr117_narrative,
                "checklist": {
                    "data_lineage_recorded":       bool(data_lineage),
                    "leakage_detection_run":       bool(data_lineage and data_lineage.get("leakage_blocked") is not None),
                    "shap_explainability":         bool(shap_explainer_type),
                    "shap_is_approximate":         shap_is_approximate,
                    "shap_explainer_type":         shap_explainer_type,
                    "guardrails_reviewed":         bool(guardrail_warnings is not None),
                    "invertible_pipeline":         True,
                    "config_driven_retraining":    True,
                    "model_card_generated":        True,
                },
            },
            "ai_insights":        ai_performance_insights,
            "guardrail_warnings": guardrail_warnings or [],
        }
        logger.info(f"Model card built for '{model_name}'.")
        return self

    def to_markdown(self) -> str:
        """Render the model card as a Markdown string (SR 11-7 compliant)."""
        d    = self.card_data
        sr117 = d.get("sr117", {})
        _vsteps = sr117.get("risk_tier", {}).get("required_steps", ["Not assessed"])
        validation_steps_str = "\n".join(f"- {s}" for s in _vsteps)
        if not d:
            return "# Model Card\n\n*Not generated yet. Train a model first.*"

        m   = d["model"]
        dat = d["data"]
        tr  = d["training"]
        met = d["metrics"]

        def fmt_metrics(md: Dict) -> str:
            if not md:
                return "_Not available_"
            return "\n".join(
                f"| {k.replace('_',' ').title()} | {v:.4f} |"
                for k, v in md.items() if isinstance(v, (int, float))
            )

        params_str = "\n".join(
            f"| `{k}` | `{v}` |"
            for k, v in tr["best_params"].items()
        ) or "_No hyperparameters (default)_"

        features_str = ", ".join(f"`{f}`" for f in dat["feature_names"][:20])
        if len(dat["feature_names"]) > 20:
            features_str += f" … (+{len(dat['feature_names'])-20} more)"

        md = f"""# 🤖 Model Card — {m['name'].replace('_',' ').title()}

> Auto-generated by **AutoML Studio** on {d['generated_at']}

---

## 1. Model Details

| Field | Value |
|---|---|
| **Model Name** | `{m['name']}` |
| **Algorithm** | {m['type']} |
| **Version** | {m['version']} |
| **Framework** | {m['framework']} |
| **Generated** | {d['generated_at']} |

---

## 2. Data Lineage

| Field | Value |
|---|---|
| **Dataset** | {dat['dataset_name']} |
| **Target Column** | `{dat['target_column']}` |
| **Rows** | {dat['n_rows']:,} |
| **Raw Features** | {dat['n_features_raw']:,} |
| **Processed Features** | {dat['n_features_processed']:,} |
| **Classes** | {', '.join(f'`{c}`' for c in dat['class_names'])} |
| **Number of Classes** | {dat['n_classes']} |

**Features used (first 20):** {features_str}

---

## 3. Training Configuration

| Field | Value |
|---|---|
| **Tuning Metric** | `{tr['tuning_metric']}` |
| **Best Trial** | #{tr['best_trial_number']} of {tr['n_trials_run']} trials |

### Best Hyperparameters

| Parameter | Value |
|---|---|
{params_str}

---

## 4. Performance Metrics

### Train Set
| Metric | Score |
|---|---|
{fmt_metrics(met['train'])}

### Validation Set
| Metric | Score |
|---|---|
{fmt_metrics(met['val'])}

### Test Set
| Metric | Score |
|---|---|
{fmt_metrics(met['test'])}

---

## 5. Intended Use

{d['intended_use']}

---

## 6. Limitations

{d['limitations']}

---

## 7. Ethical Considerations

{d['ethical_notes']}

---

## 8. SR 11-7 Model Risk Compliance

| Field | Value |
|---|---|
| **Risk Tier** | {sr117.get('risk_tier', {}).get('tier', 'Not assessed')} |
| **Description** | {sr117.get('risk_tier', {}).get('description', '—')} |
| **Data Lineage Recorded** | {'✅ Yes' if sr117.get('checklist', {}).get('data_lineage_recorded') else '❌ No'} |
| **Leakage Detection Run** | {'✅ Run' if sr117.get('checklist', {}).get('leakage_detection_run') else '❌ Not run'} |
| **SHAP Explainability** | {'✅ ' + sr117.get('checklist', {}).get('shap_explainer_type', 'Available') if sr117.get('checklist', {}).get('shap_explainability') else '❌ Not available'} |
| **Invertible Pipeline** | {'✅ Yes' if sr117.get('checklist', {}).get('invertible_pipeline') else '❌ No'} |
| **Config-Driven Retraining** | {'✅ Yes' if sr117.get('checklist', {}).get('config_driven_retraining') else '❌ No'} |

### Required Validation Steps

{validation_steps_str}

### SR 11-7 Compliance Narrative

{sr117.get('compliance_narrative') or '_AI narrative not generated — provide OpenAI API key to enable._'}

---

## 9. AI-Generated Performance Insights

{d.get('ai_insights') or '_AI insights not available — provide OpenAI API key to enable._'}

---

*Auto-generated by AutoML Studio v4 · {d['generated_at']} · SR 11-7 narratives require review by a qualified model risk professional before regulatory submission.*
"""
        return md

    def to_html(self) -> str:
        """Render the model card as styled HTML for download."""
        md_text = self.to_markdown()
        # Simple conversion: headers, tables, bold, code
        import re
        html_body = md_text
        # h1-h3
        html_body = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html_body, flags=re.MULTILINE)
        html_body = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html_body, flags=re.MULTILINE)
        html_body = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html_body, flags=re.MULTILINE)
        # Bold
        html_body = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html_body)
        # Code inline
        html_body = re.sub(r'`([^`]+)`', r'<code>\1</code>', html_body)
        # Horizontal rule
        html_body = re.sub(r'^---$', r'<hr>', html_body, flags=re.MULTILINE)
        # Table rows
        lines = html_body.split('\n')
        result, in_table = [], False
        for line in lines:
            if '|' in line and line.strip().startswith('|'):
                if line.strip().replace('|','').replace('-','').replace(' ','') == '':
                    continue   # separator row
                if not in_table:
                    result.append('<table><tbody>')
                    in_table = True
                cells = [c.strip() for c in line.strip().strip('|').split('|')]
                row_html = '<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'
                result.append(row_html)
            else:
                if in_table:
                    result.append('</tbody></table>')
                    in_table = False
                result.append(f'<p>{line}</p>' if line.strip() and not line.startswith('<') else line)
        if in_table:
            result.append('</tbody></table>')
        html_body = '\n'.join(result)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Model Card — {self.card_data.get('model',{}).get('name','')}</title>
<style>
  body {{font-family:'Segoe UI',sans-serif;max-width:900px;margin:40px auto;padding:0 24px;
        background:#f8fafc;color:#1a202c;line-height:1.7;}}
  h1 {{color:#1a365d;border-bottom:3px solid #3182ce;padding-bottom:10px;}}
  h2 {{color:#2c5282;border-left:4px solid #63b3ed;padding-left:12px;margin-top:32px;}}
  h3 {{color:#2b6cb0;}}
  table {{width:100%;border-collapse:collapse;margin:16px 0;background:#fff;
          box-shadow:0 1px 4px rgba(0,0,0,.08);border-radius:8px;overflow:hidden;}}
  td {{padding:10px 14px;border-bottom:1px solid #e2e8f0;font-size:.9rem;}}
  tr:first-child td {{background:#ebf8ff;font-weight:600;color:#2c5282;}}
  tr:hover td {{background:#f0f9ff;}}
  code {{background:#edf2f7;padding:2px 6px;border-radius:4px;
         font-family:'JetBrains Mono',monospace;font-size:.85rem;color:#c53030;}}
  hr {{border:none;border-top:1px solid #e2e8f0;margin:24px 0;}}
  p {{color:#4a5568;}}
  strong {{color:#2d3748;}}
  .footer {{text-align:center;color:#a0aec0;font-size:.8rem;margin-top:48px;
            border-top:1px solid #e2e8f0;padding-top:16px;}}
</style>
</head>
<body>
{html_body}
<div class="footer">Auto-generated by AutoML Studio · {self.card_data.get('generated_at','')}</div>
</body>
</html>"""

    def to_dict(self) -> Dict:
        """Return raw card data as dict (for JSON export)."""
        return self.card_data
