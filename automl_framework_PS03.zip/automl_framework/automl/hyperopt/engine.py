"""
Hyperparameter Optimization Engine
Uses Optuna with TPE sampler and pruning.
Respects time and trial budgets from config.
"""
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import optuna
from sklearn.base import ClassifierMixin
from sklearn.model_selection import cross_val_score, StratifiedKFold

from ..algorithms.registry import AlgorithmRegistry

logger = logging.getLogger(__name__)
optuna.logging.set_verbosity(optuna.logging.WARNING)


class HyperoptEngine:
    """
    Optuna-based hyperparameter optimizer.

    Config keys:
      max_trials          : int (default 50)
      max_time_seconds    : int (default 3600)
      cv_folds            : int (default 5)
      metric              : str ('roc_auc', 'f1', 'precision', 'recall', etc.)
      direction           : 'maximize' | 'minimize'
      sampler             : 'tpe' | 'random' | 'cmaes'
      pruner              : 'median' | 'hyperband' | 'none'
    """

    def __init__(self, config: Dict[str, Any], registry: AlgorithmRegistry):
        self.config = config
        self.registry = registry
        self.max_trials = config.get("max_trials", 50)
        self.max_time = config.get("max_time_seconds", 3600)
        self.cv_folds = config.get("cv_folds", 5)
        self.metric = config.get("metric", "roc_auc")
        self.direction = config.get("direction", "maximize")
        self.task_type = config.get("task_type", "binary")

        self.study_: Optional[optuna.Study] = None
        self.best_params_: Dict = {}
        self.best_score_: float = 0.0
        self.trials_history_: List[Dict] = []

    def optimize(
        self,
        algorithm_name: str,
        X_train: np.ndarray,
        y_train: np.ndarray,
        search_space_override: Optional[Dict] = None,
    ) -> Tuple[Dict, float]:
        """
        Run hyperparameter search for a single algorithm.
        Returns (best_params, best_score).
        """
        search_space = search_space_override or self.registry.get_search_space(algorithm_name)

        sampler = self._build_sampler()
        pruner = self._build_pruner()

        self.study_ = optuna.create_study(
            direction=self.direction,
            sampler=sampler,
            pruner=pruner,
        )

        start_time = time.time()

        def objective(trial: optuna.Trial) -> float:
            # Check time budget
            if time.time() - start_time > self.max_time:
                trial.study.stop()
                return float("-inf") if self.direction == "maximize" else float("inf")

            params = self._suggest_params(trial, search_space)
            model = self.registry.instantiate(algorithm_name, params, self.task_type)

            cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            scoring = self._get_scoring()

            try:
                scores = cross_val_score(
                    model, X_train, y_train,
                    cv=cv, scoring=scoring, n_jobs=-1,
                    error_score=0.0,
                )
                score = float(np.mean(scores))
            except Exception as e:
                logger.debug(f"Trial failed: {e}")
                score = 0.0

            return score

        self.study_.optimize(
            objective,
            n_trials=self.max_trials,
            timeout=self.max_time,
            show_progress_bar=False,
            callbacks=[self._trial_callback],
        )

        self.best_params_ = self.study_.best_params
        self.best_score_ = self.study_.best_value

        logger.info(
            f"[{algorithm_name}] Best {self.metric}: {self.best_score_:.4f} "
            f"in {len(self.study_.trials)} trials"
        )

        return self.best_params_, self.best_score_

    def get_trials_dataframe(self) -> "pd.DataFrame":
        import pandas as pd
        if self.study_ is None:
            return pd.DataFrame()
        return self.study_.trials_dataframe()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _suggest_params(self, trial: optuna.Trial, search_space: Dict) -> Dict:
        params = {}
        for name, spec in search_space.items():
            if not spec:
                continue
            ptype = spec[0]
            if ptype == "float":
                params[name] = trial.suggest_float(name, spec[1], spec[2])
            elif ptype == "float_log":
                params[name] = trial.suggest_float(name, spec[1], spec[2], log=True)
            elif ptype == "int":
                params[name] = trial.suggest_int(name, spec[1], spec[2])
            elif ptype == "int_optional":
                val = trial.suggest_int(name, spec[1], spec[2] + 1)
                params[name] = None if val > spec[2] else val
            elif ptype == "categorical":
                params[name] = trial.suggest_categorical(name, spec[1])
        return params

    def _get_scoring(self) -> str:
        scoring_map = {
            "roc_auc": "roc_auc" if self.task_type == "binary" else "roc_auc_ovr",
            "f1": "f1" if self.task_type == "binary" else "f1_macro",
            "precision": "precision" if self.task_type == "binary" else "precision_macro",
            "recall": "recall" if self.task_type == "binary" else "recall_macro",
            "accuracy": "accuracy",
            "f1_macro": "f1_macro",
            "f1_weighted": "f1_weighted",
        }
        return scoring_map.get(self.metric, self.metric)

    def _build_sampler(self):
        sampler_name = self.config.get("sampler", "tpe")
        if sampler_name == "tpe":
            return optuna.samplers.TPESampler(seed=42)
        elif sampler_name == "random":
            return optuna.samplers.RandomSampler(seed=42)
        elif sampler_name == "cmaes":
            return optuna.samplers.CmaEsSampler(seed=42)
        return optuna.samplers.TPESampler(seed=42)

    def _build_pruner(self):
        pruner_name = self.config.get("pruner", "median")
        if pruner_name == "median":
            return optuna.pruners.MedianPruner(n_startup_trials=5)
        elif pruner_name == "hyperband":
            return optuna.pruners.HyperbandPruner()
        return optuna.pruners.NopPruner()

    def _trial_callback(self, study: optuna.Study, trial: optuna.Trial):
        self.trials_history_.append({
            "trial": trial.number,
            "value": trial.value,
            "params": trial.params,
            "state": str(trial.state),
        })
