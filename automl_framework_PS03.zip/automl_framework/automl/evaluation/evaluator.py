"""
Evaluation Module
Cross-validation, comprehensive metrics, calibration, McNemar test.
"""
import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.base import ClassifierMixin
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    accuracy_score, roc_auc_score, f1_score,
    precision_score, recall_score, confusion_matrix,
    classification_report, brier_score_loss, log_loss,
    average_precision_score,
)
from sklearn.model_selection import StratifiedKFold, cross_validate
from statsmodels.stats.contingency_tables import mcnemar

logger = logging.getLogger(__name__)


class ModelEvaluator:
    """
    Comprehensive model evaluation.
    Supports binary and multiclass classification.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.task_type = config.get("task_type", "binary")
        self.cv_folds = config.get("cv_folds", 5)
        self.metric = config.get("metric", "roc_auc")
        self.results_: Dict = {}

    def cross_validate(
        self,
        model: ClassifierMixin,
        X: np.ndarray,
        y: np.ndarray,
        model_name: str = "model",
    ) -> Dict:
        """Run stratified k-fold cross-validation."""
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=42)

        scoring = self._get_scoring_dict()
        cv_results = cross_validate(
            model, X, y, cv=cv, scoring=scoring,
            n_jobs=-1, return_train_score=True,
            error_score=0.0,
        )

        summary = {}
        for key, vals in cv_results.items():
            if key.startswith("test_") or key.startswith("train_"):
                summary[f"{key}_mean"] = round(float(np.mean(vals)), 4)
                summary[f"{key}_std"] = round(float(np.std(vals)), 4)

        summary["model_name"] = model_name
        summary["cv_folds"] = self.cv_folds
        logger.info(
            f"[{model_name}] CV {self.metric}: "
            f"{summary.get(f'test_{self.metric}_mean', 'N/A'):.4f} "
            f"± {summary.get(f'test_{self.metric}_std', 'N/A'):.4f}"
        )
        return summary

    def evaluate_holdout(
        self,
        model: ClassifierMixin,
        X_test: np.ndarray,
        y_test: np.ndarray,
        model_name: str = "model",
    ) -> Dict:
        """Evaluate model on held-out test set."""
        y_pred = model.predict(X_test)
        y_proba = self._get_proba(model, X_test)

        metrics = self._compute_metrics(y_test, y_pred, y_proba)
        metrics["model_name"] = model_name
        calibration = self._compute_calibration(y_test, y_proba)
        metrics["calibration"] = calibration

        self.results_[model_name] = metrics
        return metrics

    def mcnemar_test(
        self,
        y_true: np.ndarray,
        preds_a: np.ndarray,
        preds_b: np.ndarray,
        name_a: str = "model_a",
        name_b: str = "model_b",
    ) -> Dict:
        """Statistical significance test between two models (McNemar's test)."""
        correct_a = (preds_a == y_true)
        correct_b = (preds_b == y_true)

        # Contingency table
        both_correct = np.sum(correct_a & correct_b)
        a_only = np.sum(correct_a & ~correct_b)
        b_only = np.sum(~correct_a & correct_b)
        both_wrong = np.sum(~correct_a & ~correct_b)

        table = np.array([[both_correct, a_only], [b_only, both_wrong]])
        result = mcnemar(table, exact=True)

        return {
            "name_a": name_a,
            "name_b": name_b,
            "statistic": float(result.statistic),
            "p_value": float(result.pvalue),
            "significant": result.pvalue < 0.05,
            "contingency_table": table.tolist(),
        }

    def rank_models(self, metric: Optional[str] = None) -> pd.DataFrame:
        """Return a DataFrame ranking all evaluated models."""
        metric = metric or self.metric
        rows = []
        for name, res in self.results_.items():
            row = {"model": name}
            row.update({k: v for k, v in res.items() if isinstance(v, (int, float))})
            rows.append(row)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        if metric in df.columns:
            df = df.sort_values(metric, ascending=False).reset_index(drop=True)
        return df

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _compute_metrics(self, y_true, y_pred, y_proba) -> Dict:
        m = {}
        average = "binary" if self.task_type == "binary" else "macro"

        m["accuracy"] = round(float(accuracy_score(y_true, y_pred)), 4)
        m["f1"] = round(float(f1_score(y_true, y_pred, average=average, zero_division=0)), 4)
        m["precision"] = round(float(precision_score(y_true, y_pred, average=average, zero_division=0)), 4)
        m["recall"] = round(float(recall_score(y_true, y_pred, average=average, zero_division=0)), 4)
        m["confusion_matrix"] = confusion_matrix(y_true, y_pred).tolist()
        m["classification_report"] = classification_report(y_true, y_pred, zero_division=0)

        if y_proba is not None:
            try:
                if self.task_type == "binary":
                    proba_pos = y_proba[:, 1] if y_proba.ndim > 1 else y_proba
                    m["roc_auc"] = round(float(roc_auc_score(y_true, proba_pos)), 4)
                    m["avg_precision"] = round(float(average_precision_score(y_true, proba_pos)), 4)
                    m["brier_score"] = round(float(brier_score_loss(y_true, proba_pos)), 4)
                    m["log_loss"] = round(float(log_loss(y_true, proba_pos)), 4)
                else:
                    m["roc_auc"] = round(float(roc_auc_score(y_true, y_proba, multi_class="ovr", average="macro")), 4)
                    m["log_loss"] = round(float(log_loss(y_true, y_proba)), 4)
            except Exception as e:
                logger.debug(f"Could not compute proba-based metrics: {e}")

        return m

    def _compute_calibration(self, y_true, y_proba) -> Dict:
        if y_proba is None or self.task_type != "binary":
            return {}
        try:
            proba_pos = y_proba[:, 1] if y_proba.ndim > 1 else y_proba
            fraction_of_positives, mean_predicted = calibration_curve(
                y_true, proba_pos, n_bins=10, strategy="uniform"
            )
            return {
                "fraction_of_positives": fraction_of_positives.tolist(),
                "mean_predicted_value": mean_predicted.tolist(),
            }
        except Exception:
            return {}

    def _get_proba(self, model, X) -> Optional[np.ndarray]:
        if hasattr(model, "predict_proba"):
            try:
                return model.predict_proba(X)
            except Exception:
                pass
        if hasattr(model, "decision_function"):
            try:
                scores = model.decision_function(X)
                if scores.ndim == 1:
                    scores = np.column_stack([-scores, scores])
                return scores
            except Exception:
                pass
        return None

    def _get_scoring_dict(self) -> Dict:
        base = {
            "accuracy": "accuracy",
            "f1": "f1" if self.task_type == "binary" else "f1_macro",
            "precision": "precision" if self.task_type == "binary" else "precision_macro",
            "recall": "recall" if self.task_type == "binary" else "recall_macro",
        }
        if self.task_type == "binary":
            base["roc_auc"] = "roc_auc"
            base["avg_precision"] = "average_precision"
        else:
            base["roc_auc"] = "roc_auc_ovr"
        return base
