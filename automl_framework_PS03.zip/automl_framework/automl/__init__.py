"""
AutoML Classification Framework with Explainability
PS-03 | Opus Technologies Global
"""
__version__ = "1.0.0"
__author__ = "Team #03 — Mansi Apet, Shreyas Kadapatti, Sachi Parsekar"

from .pipeline import AutoMLPipeline
from .ingestion import DataLoader
from .preprocessing import PreprocessingPipeline, LeakageDetector
from .algorithms import AlgorithmRegistry
from .hyperopt import HyperoptEngine
from .evaluation import ModelEvaluator
from .explainability import ExplainabilityModule
from .registry import ModelRegistry
from .packaging import ReportGenerator

__all__ = [
    "AutoMLPipeline",
    "DataLoader",
    "PreprocessingPipeline",
    "LeakageDetector",
    "AlgorithmRegistry",
    "HyperoptEngine",
    "ModelEvaluator",
    "ExplainabilityModule",
    "ModelRegistry",
    "ReportGenerator",
]
