"""
Preprocessing Pipeline
Fully serializable sklearn pipeline with:
- Imputation (median/mode/KNN)
- Encoding (OHE, target, ordinal)
- Scaling (robust/standard)
- Text vectorization (TF-IDF)
All steps are invertible for data lineage compliance (C3).
"""
import logging
from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    StandardScaler, RobustScaler, OrdinalEncoder,
    OneHotEncoder, LabelEncoder
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Invertible Target Encoder
# ---------------------------------------------------------------------------

class InvertibleTargetEncoder(BaseEstimator, TransformerMixin):
    """
    Target (mean) encoder for categorical features.
    Stores mapping for inverse transform (data lineage compliance).
    Uses smoothing to reduce overfitting.
    """

    def __init__(self, smoothing: float = 1.0):
        self.smoothing = smoothing
        self.mapping_: Dict[str, Dict] = {}
        self.global_mean_: float = 0.0

    def fit(self, X: pd.DataFrame, y: pd.Series):
        self.global_mean_ = float(y.mean())
        for col in X.columns:
            stats = pd.DataFrame({"x": X[col], "y": y}).groupby("x")["y"].agg(["mean", "count"])
            smoother = stats["count"] / (stats["count"] + self.smoothing)
            stats["encoded"] = smoother * stats["mean"] + (1 - smoother) * self.global_mean_
            self.mapping_[col] = stats["encoded"].to_dict()
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        out = pd.DataFrame(index=X.index)
        for col in X.columns:
            out[col] = X[col].map(self.mapping_[col]).fillna(self.global_mean_)
        return out.values

    def inverse_transform(self, X: np.ndarray, columns: List[str]) -> pd.DataFrame:
        """Invert encoded values back to original categories (approximate)."""
        df = pd.DataFrame(X, columns=columns)
        for i, col in enumerate(columns):
            reverse_map = {v: k for k, v in self.mapping_[col].items()}
            df[col] = df.iloc[:, i].map(
                lambda val: min(reverse_map, key=lambda k: abs(reverse_map[k] - val))
                if reverse_map else val
            )
        return df


# ---------------------------------------------------------------------------
# Invertible OHE wrapper
# ---------------------------------------------------------------------------

class InvertibleOHE(BaseEstimator, TransformerMixin):
    """OHE with stored column names for inverse transform."""

    def __init__(self, handle_unknown: str = "ignore", max_categories: int = 50):
        self.handle_unknown = handle_unknown
        self.max_categories = max_categories
        self.ohe_ = None
        self.input_cols_: List[str] = []
        self.output_cols_: List[str] = []

    def fit(self, X: pd.DataFrame, y=None):
        self.input_cols_ = list(X.columns)
        self.ohe_ = OneHotEncoder(
            handle_unknown=self.handle_unknown,
            sparse_output=False,
            max_categories=self.max_categories,
        )
        self.ohe_.fit(X)
        self.output_cols_ = list(self.ohe_.get_feature_names_out(self.input_cols_))
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        return self.ohe_.transform(X)

    def inverse_transform(self, X: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(
            self.ohe_.inverse_transform(X),
            columns=self.input_cols_
        )

    def get_feature_names_out(self, input_features=None):
        return np.array(self.output_cols_)


# ---------------------------------------------------------------------------
# Main Preprocessing Pipeline
# ---------------------------------------------------------------------------

class PreprocessingPipeline:
    """
    Builds a fully serializable sklearn ColumnTransformer pipeline.
    All transformation metadata is stored for inverse transform (C3).
    """

    def __init__(self, config: Dict[str, Any]):
        """
        config keys:
          numeric_features      : list of numeric column names
          categorical_features  : list of categorical column names
          text_features         : list of text column names (TF-IDF)
          ordinal_features      : dict {col: [ordered_categories]}
          drop_features         : list of columns to drop
          impute_strategy       : 'median' | 'mean' | 'knn'
          encoding_strategy     : 'ohe' | 'target' | 'ordinal'
          scaling_strategy      : 'robust' | 'standard' | 'none'
          text_max_features     : int, TF-IDF vocab size (default 500)
        """
        self.config = config
        self.pipeline_: Optional[Pipeline] = None
        self.label_encoder_: Optional[LabelEncoder] = None
        self.feature_names_out_: List[str] = []
        self._transformers_log: List[str] = []

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "PreprocessingPipeline":
        X = self._drop_features(X)
        transformers = self._build_transformers(X, y)

        self.column_transformer_ = ColumnTransformer(
            transformers=transformers,
            remainder="drop",
            verbose_feature_names_out=False,
        )
        self.pipeline_ = Pipeline([("preprocessor", self.column_transformer_)])
        self.pipeline_.fit(X, y)

        self._compute_feature_names(X)
        logger.info(f"Preprocessing fitted. Output features: {len(self.feature_names_out_)}")
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = self._drop_features(X)
        arr = self.pipeline_.transform(X)
        return pd.DataFrame(arr, columns=self.feature_names_out_, index=X.index)

    def fit_transform(self, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
        self.fit(X, y)
        return self.transform(X)

    def inverse_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Inverse transform for data lineage compliance (C3).
        Reconstructs approximate original feature values.
        """
        result = pd.DataFrame(index=X.index)
        for name, transformer, cols in self.column_transformer_.transformers_:
            if name == "remainder":
                continue
            sub = X[[c for c in X.columns if c.startswith(name) or c in cols]]
            if hasattr(transformer, "inverse_transform"):
                try:
                    inv = transformer.inverse_transform(sub.values)
                    if isinstance(inv, pd.DataFrame):
                        result = pd.concat([result, inv], axis=1)
                    else:
                        inv_df = pd.DataFrame(inv, columns=cols if len(cols) == inv.shape[1] else sub.columns, index=X.index)
                        result = pd.concat([result, inv_df], axis=1)
                except Exception as e:
                    logger.warning(f"Could not inverse transform '{name}': {e}")
        return result

    def encode_target(self, y: pd.Series) -> np.ndarray:
        self.label_encoder_ = LabelEncoder()
        return self.label_encoder_.fit_transform(y)

    def decode_target(self, y_encoded: np.ndarray) -> np.ndarray:
        if self.label_encoder_ is None:
            return y_encoded
        return self.label_encoder_.inverse_transform(y_encoded)

    def get_feature_names(self) -> List[str]:
        return self.feature_names_out_

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _drop_features(self, X: pd.DataFrame) -> pd.DataFrame:
        drop = self.config.get("drop_features", [])
        return X.drop(columns=[c for c in drop if c in X.columns])

    def _build_transformers(self, X: pd.DataFrame, y: pd.Series):
        transformers = []
        cfg = self.config
        impute_strategy = cfg.get("impute_strategy", "median")
        encoding_strategy = cfg.get("encoding_strategy", "ohe")
        scaling_strategy = cfg.get("scaling_strategy", "robust")

        # ---- Numeric features ----
        num_cols = [c for c in cfg.get("numeric_features", []) if c in X.columns]
        if num_cols:
            imputer = KNNImputer(n_neighbors=5) if impute_strategy == "knn" else \
                      SimpleImputer(strategy=impute_strategy if impute_strategy in ["mean", "median"] else "median")
            scaler = RobustScaler() if scaling_strategy == "robust" else \
                     StandardScaler() if scaling_strategy == "standard" else "passthrough"
            steps = [("impute", imputer)]
            if scaler != "passthrough":
                steps.append(("scale", scaler))
            transformers.append(("numeric", Pipeline(steps), num_cols))
            self._transformers_log.append(f"Numeric ({len(num_cols)} cols): impute={impute_strategy}, scale={scaling_strategy}")

        # ---- Categorical features ----
        cat_cols = [c for c in cfg.get("categorical_features", []) if c in X.columns]
        if cat_cols:
            cat_imputer = SimpleImputer(strategy="most_frequent")
            if encoding_strategy == "ohe":
                encoder = InvertibleOHE(max_categories=cfg.get("ohe_max_categories", 50))
            elif encoding_strategy == "target":
                encoder = InvertibleTargetEncoder(smoothing=cfg.get("target_encoding_smoothing", 1.0))
            else:
                encoder = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)

            cat_pipeline = Pipeline([
                ("impute", cat_imputer),
                ("encode", encoder),
            ])
            # Target encoder needs y — fit manually
            if encoding_strategy == "target":
                imputed = cat_imputer.fit_transform(X[cat_cols])
                imputed_df = pd.DataFrame(imputed, columns=cat_cols, index=X.index)
                encoder.fit(imputed_df, y)
                # Wrap in a fitted pipeline
                cat_pipeline = Pipeline([("impute", cat_imputer), ("encode", encoder)])

            transformers.append(("categorical", cat_pipeline, cat_cols))
            self._transformers_log.append(f"Categorical ({len(cat_cols)} cols): encode={encoding_strategy}")

        # ---- Ordinal features ----
        ord_cfg = cfg.get("ordinal_features", {})
        ord_cols = [c for c in ord_cfg if c in X.columns]
        if ord_cols:
            categories = [ord_cfg[c] for c in ord_cols]
            ord_pipeline = Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("encode", OrdinalEncoder(categories=categories, handle_unknown="use_encoded_value", unknown_value=-1)),
            ])
            transformers.append(("ordinal", ord_pipeline, ord_cols))
            self._transformers_log.append(f"Ordinal ({len(ord_cols)} cols)")

        # ---- Text features ----
        text_cols = [c for c in cfg.get("text_features", []) if c in X.columns]
        if text_cols:
            from sklearn.feature_extraction.text import TfidfVectorizer
            max_feat = cfg.get("text_max_features", 500)
            for col in text_cols:
                tfidf = Pipeline([
                    ("fill", SimpleImputer(strategy="constant", fill_value="")),
                    ("tfidf", TfidfVectorizer(max_features=max_feat)),
                ])
                transformers.append((f"text_{col}", tfidf, [col]))
            self._transformers_log.append(f"Text ({len(text_cols)} cols): TF-IDF max_features={max_feat}")

        if not transformers:
            raise ValueError(
                "No features configured for preprocessing. "
                "Check your feature_config in the YAML."
            )

        return transformers

    def _compute_feature_names(self, X: pd.DataFrame):
        try:
            self.feature_names_out_ = list(
                self.column_transformer_.get_feature_names_out()
            )
        except Exception:
            self.feature_names_out_ = [f"feature_{i}" for i in range(
                self.pipeline_.transform(X.head(1)).shape[1]
            )]
